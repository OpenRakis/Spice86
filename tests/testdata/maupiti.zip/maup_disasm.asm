00000000  B102              mov cl,0x2
00000002  D3E8              shr ax,cl
00000004  03D8              add bx,ax
00000006  5A                pop dx
00000007  59                pop cx
00000008  58                pop ax
00000009  C3                ret
0000000A  1E                push ds
0000000B  56                push si
0000000C  57                push di
0000000D  33FF              xor di,di
0000000F  1E                push ds
00000010  B8420A            mov ax,0xa42
00000013  8ED8              mov ds,ax
00000015  8D1E9802          lea bx,[0x298]
00000019  B8420A            mov ax,0xa42
0000001C  8EC0              mov es,ax
0000001E  8D36D802          lea si,[0x2d8]
00000022  B91000            mov cx,0x10
00000025  53                push bx
00000026  57                push di
00000027  32E4              xor ah,ah
00000029  268A04            mov al,[es:si]
0000002C  D1E0              shl ax,1
0000002E  03D8              add bx,ax
00000030  8B17              mov dx,[bx]
00000032  899338FF          mov [bp+di-0xc8],dx
00000036  83C720            add di,byte +0x20
00000039  83C310            add bx,byte +0x10
0000003C  8B17              mov dx,[bx]
0000003E  899338FF          mov [bp+di-0xc8],dx
00000042  5F                pop di
00000043  5B                pop bx
00000044  83C702            add di,byte +0x2
00000047  46                inc si
00000048  E2DB              loop 0x25
0000004A  1F                pop ds
0000004B  8B5E06            mov bx,[bp+0x6]
0000004E  035E0A            add bx,[bp+0xa]
00000051  4B                dec bx
00000052  83E3FC            and bx,byte -0x4
00000055  83C303            add bx,byte +0x3
00000058  8B4606            mov ax,[bp+0x6]
0000005B  25FCFF            and ax,0xfffc
0000005E  2BD8              sub bx,ax
00000060  43                inc bx
00000061  895E0A            mov [bp+0xa],bx
00000064  894606            mov [bp+0x6],ax
00000067  E8DA00            call 0x144
0000006A  8B4608            mov ax,[bp+0x8]
0000006D  B94001            mov cx,0x140
00000070  F7E1              mul cx
00000072  8BD8              mov bx,ax
00000074  035E06            add bx,[bp+0x6]
00000077  8E1E9404          mov ds,[0x494]
0000007B  B800B8            mov ax,0xb800
0000007E  8EC0              mov es,ax
00000080  33FF              xor di,di
00000082  81FE0020          cmp si,0x2000
00000086  7C03              jl 0x8b
00000088  83C720            add di,byte +0x20
0000008B  8B560C            mov dx,[bp+0xc]
0000008E  52                push dx
0000008F  56                push si
00000090  53                push bx
00000091  8B4E0A            mov cx,[bp+0xa]
00000094  D1E9              shr cx,1
00000096  D1E9              shr cx,1
00000098  32E4              xor ah,ah
0000009A  8A07              mov al,[bx]
0000009C  D1E0              shl ax,1
0000009E  03F8              add di,ax
000000A0  8B9338FF          mov dx,[bp+di-0xc8]
000000A4  D0CA              ror dl,1
000000A6  D0CE              ror dh,1
000000A8  D0CE              ror dh,1
000000AA  02D6              add dl,dh
000000AC  2BF8              sub di,ax
000000AE  32E4              xor ah,ah
000000B0  43                inc bx
000000B1  8A07              mov al,[bx]
000000B3  43                inc bx
000000B4  D1E0              shl ax,1
000000B6  03F8              add di,ax
000000B8  8AB338FF          mov dh,[bp+di-0xc8]
000000BC  D0CE              ror dh,1
000000BE  D0CE              ror dh,1
000000C0  D0CE              ror dh,1
000000C2  02D6              add dl,dh
000000C4  8AB339FF          mov dh,[bp+di-0xc7]
000000C8  D0E6              shl dh,1
000000CA  D0E6              shl dh,1
000000CC  D0E6              shl dh,1
000000CE  D0E6              shl dh,1
000000D0  02D6              add dl,dh
000000D2  2BF8              sub di,ax
000000D4  32E4              xor ah,ah
000000D6  8A07              mov al,[bx]
000000D8  43                inc bx
000000D9  D1E0              shl ax,1
000000DB  03F8              add di,ax
000000DD  8AB338FF          mov dh,[bp+di-0xc8]
000000E1  D0E6              shl dh,1
000000E3  D0E6              shl dh,1
000000E5  D0E6              shl dh,1
000000E7  02D6              add dl,dh
000000E9  8AB339FF          mov dh,[bp+di-0xc7]
000000ED  D0E6              shl dh,1
000000EF  D0E6              shl dh,1
000000F1  02D6              add dl,dh
000000F3  2BF8              sub di,ax
000000F5  32E4              xor ah,ah
000000F7  8A07              mov al,[bx]
000000F9  43                inc bx
000000FA  D1E0              shl ax,1
000000FC  03F8              add di,ax
000000FE  8AB338FF          mov dh,[bp+di-0xc8]
00000102  D0E6              shl dh,1
00000104  02D6              add dl,dh
00000106  8AB339FF          mov dh,[bp+di-0xc7]
0000010A  02D6              add dl,dh
0000010C  2BF8              sub di,ax
0000010E  268814            mov [es:si],dl
00000111  46                inc si
00000112  49                dec cx
00000113  7402              jz 0x117
00000115  EB81              jmp short 0x98
00000117  5B                pop bx
00000118  5E                pop si
00000119  5A                pop dx
0000011A  81C34001          add bx,0x140
0000011E  81FE0020          cmp si,0x2000
00000122  7D0A              jnl 0x12e
00000124  81C60020          add si,0x2000
00000128  83C720            add di,byte +0x20
0000012B  EB0B              jmp short 0x138
0000012D  90                nop
0000012E  81EE0020          sub si,0x2000
00000132  83EF20            sub di,byte +0x20
00000135  83C650            add si,byte +0x50
00000138  4A                dec dx
00000139  7403              jz 0x13e
0000013B  E950FF            jmp 0x8e
0000013E  5F                pop di
0000013F  5E                pop si
00000140  1F                pop ds
00000141  E94803            jmp 0x48c
00000144  8B4608            mov ax,[bp+0x8]
00000147  250100            and ax,0x1
0000014A  B90020            mov cx,0x2000
0000014D  F7E1              mul cx
0000014F  8BF0              mov si,ax
00000151  8B4608            mov ax,[bp+0x8]
00000154  D1E8              shr ax,1
00000156  B95000            mov cx,0x50
00000159  F7E1              mul cx
0000015B  03F0              add si,ax
0000015D  8B4606            mov ax,[bp+0x6]
00000160  D1E8              shr ax,1
00000162  D1E8              shr ax,1
00000164  03F0              add si,ax
00000166  C3                ret
00000167  B8420A            mov ax,0xa42
0000016A  8ED8              mov ds,ax
0000016C  C606740601        mov byte [0x674],0x1
00000171  57                push di
00000172  56                push si
00000173  BACE03            mov dx,0x3ce
00000176  B80502            mov ax,0x205
00000179  EF                out dx,ax
0000017A  B80300            mov ax,0x3
0000017D  EF                out dx,ax
0000017E  E81303            call 0x494
00000181  33DB              xor bx,bx
00000183  8B4608            mov ax,[bp+0x8]
00000186  B95000            mov cx,0x50
00000189  F7E1              mul cx
0000018B  03D8              add bx,ax
0000018D  8B4606            mov ax,[bp+0x6]
00000190  D1E0              shl ax,1
00000192  B103              mov cl,0x3
00000194  D3E8              shr ax,cl
00000196  03D8              add bx,ax
00000198  8B4606            mov ax,[bp+0x6]
0000019B  D1E0              shl ax,1
0000019D  250700            and ax,0x7
000001A0  8AC8              mov cl,al
000001A2  B480              mov ah,0x80
000001A4  D2EC              shr ah,cl
000001A6  8B4E0A            mov cx,[bp+0xa]
000001A9  8B560C            mov dx,[bp+0xc]
000001AC  52                push dx
000001AD  BA00A0            mov dx,0xa000
000001B0  8EC2              mov es,dx
000001B2  8E5E12            mov ds,[bp+0x12]
000001B5  8B7614            mov si,[bp+0x14]
000001B8  5A                pop dx
000001B9  52                push dx
000001BA  50                push ax
000001BB  53                push bx
000001BC  56                push si
000001BD  51                push cx
000001BE  BACE03            mov dx,0x3ce
000001C1  8B3C              mov di,[si]
000001C3  83E70F            and di,byte +0xf
000001C6  D1E7              shl di,1
000001C8  268A07            mov al,[es:bx]
000001CB  B008              mov al,0x8
000001CD  EF                out dx,ax
000001CE  8A43C0            mov al,[bp+di-0x40]
000001D1  D0EC              shr ah,1
000001D3  268807            mov [es:bx],al
000001D6  268A07            mov al,[es:bx]
000001D9  B008              mov al,0x8
000001DB  EF                out dx,ax
000001DC  8A43C1            mov al,[bp+di-0x3f]
000001DF  268807            mov [es:bx],al
000001E2  D0EC              shr ah,1
000001E4  46                inc si
000001E5  0AE4              or ah,ah
000001E7  7503              jnz 0x1ec
000001E9  B480              mov ah,0x80
000001EB  43                inc bx
000001EC  E2D3              loop 0x1c1
000001EE  59                pop cx
000001EF  5E                pop si
000001F0  5B                pop bx
000001F1  58                pop ax
000001F2  5A                pop dx
000001F3  81C64001          add si,0x140
000001F7  83C350            add bx,byte +0x50
000001FA  FECA              dec dl
000001FC  75BB              jnz 0x1b9
000001FE  B8420A            mov ax,0xa42
00000201  8ED8              mov ds,ax
00000203  C606740600        mov byte [0x674],0x0
00000208  5E                pop si
00000209  5F                pop di
0000020A  E97F02            jmp 0x48c
0000020D  56                push si
0000020E  57                push di
0000020F  E88500            call 0x297
00000212  B800B8            mov ax,0xb800
00000215  8EC0              mov es,ax
00000217  8B4608            mov ax,[bp+0x8]
0000021A  B94001            mov cx,0x140
0000021D  F7E1              mul cx
0000021F  8BF8              mov di,ax
00000221  8B4606            mov ax,[bp+0x6]
00000224  8BC8              mov cx,ax
00000226  25FEFF            and ax,0xfffe
00000229  894606            mov [bp+0x6],ax
0000022C  03F8              add di,ax
0000022E  034E0A            add cx,[bp+0xa]
00000231  49                dec cx
00000232  83E1FE            and cx,byte -0x2
00000235  83C102            add cx,byte +0x2
00000238  2BC8              sub cx,ax
0000023A  D1E9              shr cx,1
0000023C  894E0A            mov [bp+0xa],cx
0000023F  8E1E9404          mov ds,[0x494]
00000243  8B560C            mov dx,[bp+0xc]
00000246  E86700            call 0x2b0
00000249  FF4608            inc word [bp+0x8]
0000024C  57                push di
0000024D  51                push cx
0000024E  8B4608            mov ax,[bp+0x8]
00000251  48                dec ax
00000252  250100            and ax,0x1
00000255  D1E0              shl ax,1
00000257  D1E0              shl ax,1
00000259  D1E0              shl ax,1
0000025B  D1E0              shl ax,1
0000025D  8BF0              mov si,ax
0000025F  8A05              mov al,[di]
00000261  32E4              xor ah,ah
00000263  03F0              add si,ax
00000265  8A6AC0            mov ch,[bp+si-0x40]
00000268  80E5F0            and ch,0xf0
0000026B  2BF0              sub si,ax
0000026D  8A4501            mov al,[di+0x1]
00000270  03F0              add si,ax
00000272  8A62C0            mov ah,[bp+si-0x40]
00000275  80E40F            and ah,0xf
00000278  02EC              add ch,ah
0000027A  26882F            mov [es:bx],ch
0000027D  32E4              xor ah,ah
0000027F  2BF0              sub si,ax
00000281  32ED              xor ch,ch
00000283  83C702            add di,byte +0x2
00000286  43                inc bx
00000287  E2D6              loop 0x25f
00000289  59                pop cx
0000028A  5F                pop di
0000028B  81C74001          add di,0x140
0000028F  4A                dec dx
00000290  75B4              jnz 0x246
00000292  5F                pop di
00000293  5E                pop si
00000294  E9F501            jmp 0x48c
00000297  1E                push ds
00000298  55                push bp
00000299  16                push ss
0000029A  07                pop es
0000029B  8BFD              mov di,bp
0000029D  83EF40            sub di,byte +0x40
000002A0  B91000            mov cx,0x10
000002A3  8B36E200          mov si,[0xe2]
000002A7  8E1EE000          mov ds,[0xe0]
000002AB  F3A5              rep movsw
000002AD  5D                pop bp
000002AE  1F                pop ds
000002AF  C3                ret
000002B0  50                push ax
000002B1  51                push cx
000002B2  52                push dx
000002B3  8B4608            mov ax,[bp+0x8]
000002B6  250300            and ax,0x3
000002B9  B90020            mov cx,0x2000
000002BC  F7E1              mul cx
000002BE  8BD8              mov bx,ax
000002C0  8B4608            mov ax,[bp+0x8]
000002C3  D1E8              shr ax,1
000002C5  D1E8              shr ax,1
000002C7  B9A000            mov cx,0xa0
000002CA  F7E1              mul cx
000002CC  03D8              add bx,ax
000002CE  8B4606            mov ax,[bp+0x6]
000002D1  D1E8              shr ax,1
000002D3  03D8              add bx,ax
000002D5  5A                pop dx
000002D6  59                pop cx
000002D7  58                pop ax
000002D8  C3                ret
000002D9  8B4608            mov ax,[bp+0x8]
000002DC  B94001            mov cx,0x140
000002DF  F7E1              mul cx
000002E1  8BF8              mov di,ax
000002E3  037E06            add di,[bp+0x6]
000002E6  B800A0            mov ax,0xa000
000002E9  8EC0              mov es,ax
000002EB  8B4612            mov ax,[bp+0x12]
000002EE  8ED8              mov ds,ax
000002F0  8B7614            mov si,[bp+0x14]
000002F3  8B560C            mov dx,[bp+0xc]
000002F6  8B4E0A            mov cx,[bp+0xa]
000002F9  8BC6              mov ax,si
000002FB  8BDF              mov bx,di
000002FD  81C34001          add bx,0x140
00000301  054001            add ax,0x140
00000304  F3A4              rep movsb
00000306  8BF0              mov si,ax
00000308  8BFB              mov di,bx
0000030A  FECA              dec dl
0000030C  75E8              jnz 0x2f6
0000030E  1F                pop ds
0000030F  5E                pop si
00000310  5F                pop di
00000311  E97801            jmp 0x48c
00000314  1E                push ds
00000315  56                push si
00000316  57                push di
00000317  33FF              xor di,di
00000319  1E                push ds
0000031A  B8420A            mov ax,0xa42
0000031D  8ED8              mov ds,ax
0000031F  8D1E9802          lea bx,[0x298]
00000323  B8420A            mov ax,0xa42
00000326  8EC0              mov es,ax
00000328  8D36D802          lea si,[0x2d8]
0000032C  B91000            mov cx,0x10
0000032F  53                push bx
00000330  57                push di
00000331  32E4              xor ah,ah
00000333  268A04            mov al,[es:si]
00000336  D1E0              shl ax,1
00000338  03D8              add bx,ax
0000033A  8B17              mov dx,[bx]
0000033C  899338FF          mov [bp+di-0xc8],dx
00000340  83C720            add di,byte +0x20
00000343  83C310            add bx,byte +0x10
00000346  8B17              mov dx,[bx]
00000348  899338FF          mov [bp+di-0xc8],dx
0000034C  5F                pop di
0000034D  5B                pop bx
0000034E  83C702            add di,byte +0x2
00000351  46                inc si
00000352  E2DB              loop 0x32f
00000354  1F                pop ds
00000355  8B5E06            mov bx,[bp+0x6]
00000358  035E0A            add bx,[bp+0xa]
0000035B  4B                dec bx
0000035C  83E3FC            and bx,byte -0x4
0000035F  83C303            add bx,byte +0x3
00000362  8B4606            mov ax,[bp+0x6]
00000365  25FCFF            and ax,0xfffc
00000368  2BD8              sub bx,ax
0000036A  43                inc bx
0000036B  895E0A            mov [bp+0xa],bx
0000036E  894606            mov [bp+0x6],ax
00000371  E8F300            call 0x467
00000374  8B4608            mov ax,[bp+0x8]
00000377  B94001            mov cx,0x140
0000037A  F7E1              mul cx
0000037C  8BD8              mov bx,ax
0000037E  035E06            add bx,[bp+0x6]
00000381  8E1E9404          mov ds,[0x494]
00000385  B800B0            mov ax,0xb000
00000388  8EC0              mov es,ax
0000038A  33FF              xor di,di
0000038C  81FE0040          cmp si,0x4000
00000390  7C03              jl 0x395
00000392  83C720            add di,byte +0x20
00000395  8B560C            mov dx,[bp+0xc]
00000398  52                push dx
00000399  56                push si
0000039A  53                push bx
0000039B  E81000            call 0x3ae
0000039E  5B                pop bx
0000039F  5E                pop si
000003A0  81C60020          add si,0x2000
000003A4  56                push si
000003A5  53                push bx
000003A6  E80500            call 0x3ae
000003A9  5B                pop bx
000003AA  5E                pop si
000003AB  E98700            jmp 0x435
000003AE  8B4E0A            mov cx,[bp+0xa]
000003B1  D1E9              shr cx,1
000003B3  D1E9              shr cx,1
000003B5  32E4              xor ah,ah
000003B7  8A07              mov al,[bx]
000003B9  D1E0              shl ax,1
000003BB  03F8              add di,ax
000003BD  8B9338FF          mov dx,[bp+di-0xc8]
000003C1  D0CA              ror dl,1
000003C3  D0CE              ror dh,1
000003C5  D0CE              ror dh,1
000003C7  02D6              add dl,dh
000003C9  2BF8              sub di,ax
000003CB  32E4              xor ah,ah
000003CD  43                inc bx
000003CE  8A07              mov al,[bx]
000003D0  43                inc bx
000003D1  D1E0              shl ax,1
000003D3  03F8              add di,ax
000003D5  8AB338FF          mov dh,[bp+di-0xc8]
000003D9  D0CE              ror dh,1
000003DB  D0CE              ror dh,1
000003DD  D0CE              ror dh,1
000003DF  02D6              add dl,dh
000003E1  8AB339FF          mov dh,[bp+di-0xc7]
000003E5  D0E6              shl dh,1
000003E7  D0E6              shl dh,1
000003E9  D0E6              shl dh,1
000003EB  D0E6              shl dh,1
000003ED  02D6              add dl,dh
000003EF  2BF8              sub di,ax
000003F1  32E4              xor ah,ah
000003F3  8A07              mov al,[bx]
000003F5  43                inc bx
000003F6  D1E0              shl ax,1
000003F8  03F8              add di,ax
000003FA  8AB338FF          mov dh,[bp+di-0xc8]
000003FE  D0E6              shl dh,1
00000400  D0E6              shl dh,1
00000402  D0E6              shl dh,1
00000404  02D6              add dl,dh
00000406  8AB339FF          mov dh,[bp+di-0xc7]
0000040A  D0E6              shl dh,1
0000040C  D0E6              shl dh,1
0000040E  02D6              add dl,dh
00000410  2BF8              sub di,ax
00000412  32E4              xor ah,ah
00000414  8A07              mov al,[bx]
00000416  43                inc bx
00000417  D1E0              shl ax,1
00000419  03F8              add di,ax
0000041B  8AB338FF          mov dh,[bp+di-0xc8]
0000041F  D0E6              shl dh,1
00000421  02D6              add dl,dh
00000423  8AB339FF          mov dh,[bp+di-0xc7]
00000427  02D6              add dl,dh
00000429  2BF8              sub di,ax
0000042B  268814            mov [es:si],dl
0000042E  46                inc si
0000042F  49                dec cx
00000430  7402              jz 0x434
00000432  EB81              jmp short 0x3b5
00000434  C3                ret
00000435  5A                pop dx
00000436  81C34001          add bx,0x140
0000043A  81FE0060          cmp si,0x6000
0000043E  7D0A              jnl 0x44a
00000440  81C60020          add si,0x2000
00000444  83C720            add di,byte +0x20
00000447  EB0E              jmp short 0x457
00000449  90                nop
0000044A  81EE0060          sub si,0x6000
0000044E  83C650            add si,byte +0x50
00000451  83EF20            sub di,byte +0x20
00000454  EB01              jmp short 0x457
00000456  90                nop
00000457  4A                dec dx
00000458  7403              jz 0x45d
0000045A  E93BFF            jmp 0x398
0000045D  81C41201          add sp,0x112
00000461  5F                pop di
00000462  5E                pop si
00000463  1F                pop ds
00000464  EB26              jmp short 0x48c
00000466  90                nop
00000467  8B4608            mov ax,[bp+0x8]
0000046A  D1E0              shl ax,1
0000046C  250300            and ax,0x3
0000046F  B90020            mov cx,0x2000
00000472  F7E1              mul cx
00000474  8BF0              mov si,ax
00000476  8B4608            mov ax,[bp+0x8]
00000479  D1E8              shr ax,1
0000047B  B95000            mov cx,0x50
0000047E  F7E1              mul cx
00000480  03F0              add si,ax
00000482  8B4606            mov ax,[bp+0x6]
00000485  D1E8              shr ax,1
00000487  D1E8              shr ax,1
00000489  03F0              add si,ax
0000048B  C3                ret
0000048C  8BE5              mov sp,bp
0000048E  83EC02            sub sp,byte +0x2
00000491  1F                pop ds
00000492  5D                pop bp
00000493  CB                retf
00000494  1E                push ds
00000495  16                push ss
00000496  07                pop es
00000497  8E5E18            mov ds,[bp+0x18]
0000049A  8B7616            mov si,[bp+0x16]
0000049D  B91000            mov cx,0x10
000004A0  8BFD              mov di,bp
000004A2  83EF40            sub di,byte +0x40
000004A5  F3A5              rep movsw
000004A7  1F                pop ds
000004A8  C3                ret
000004A9  55                push bp
000004AA  8BEC              mov bp,sp
000004AC  8BE9              mov bp,cx
000004AE  8B5E00            mov bx,[bp+0x0]
000004B1  8B4602            mov ax,[bp+0x2]
000004B4  B10C              mov cl,0xc
000004B6  D3E0              shl ax,cl
000004B8  8EC0              mov es,ax
000004BA  268A07            mov al,[es:bx]
000004BD  32E4              xor ah,ah
000004BF  33D2              xor dx,dx
000004C1  5D                pop bp
000004C2  CB                retf
000004C3  55                push bp
000004C4  8BEC              mov bp,sp
000004C6  8BE9              mov bp,cx
000004C8  8B5E00            mov bx,[bp+0x0]
000004CB  8B4602            mov ax,[bp+0x2]
000004CE  E85802            call 0x729
000004D1  8EC0              mov es,ax
000004D3  268B07            mov ax,[es:bx]
000004D6  86E0              xchg ah,al
000004D8  33D2              xor dx,dx
000004DA  5D                pop bp
000004DB  CB                retf
000004DC  55                push bp
000004DD  8BEC              mov bp,sp
000004DF  56                push si
000004E0  8BE9              mov bp,cx
000004E2  8B5E00            mov bx,[bp+0x0]
000004E5  8B4602            mov ax,[bp+0x2]
000004E8  E83E02            call 0x729
000004EB  8EC0              mov es,ax
000004ED  8BF3              mov si,bx
000004EF  268B14            mov dx,[es:si]
000004F2  268B4402          mov ax,[es:si+0x2]
000004F6  86E0              xchg ah,al
000004F8  86F2              xchg dh,dl
000004FA  5E                pop si
000004FB  5D                pop bp
000004FC  CB                retf
000004FD  55                push bp
000004FE  8BEC              mov bp,sp
00000500  8BE9              mov bp,cx
00000502  8B5E04            mov bx,[bp+0x4]
00000505  8B4606            mov ax,[bp+0x6]
00000508  B10C              mov cl,0xc
0000050A  D3E0              shl ax,cl
0000050C  8EC0              mov es,ax
0000050E  8B4600            mov ax,[bp+0x0]
00000511  268807            mov [es:bx],al
00000514  5D                pop bp
00000515  CB                retf
00000516  55                push bp
00000517  8BEC              mov bp,sp
00000519  8BE9              mov bp,cx
0000051B  8B5E04            mov bx,[bp+0x4]
0000051E  8B4606            mov ax,[bp+0x6]
00000521  E80502            call 0x729
00000524  8EC0              mov es,ax
00000526  8B4600            mov ax,[bp+0x0]
00000529  86E0              xchg ah,al
0000052B  268907            mov [es:bx],ax
0000052E  5D                pop bp
0000052F  CB                retf
00000530  55                push bp
00000531  8BEC              mov bp,sp
00000533  56                push si
00000534  8BE9              mov bp,cx
00000536  8B5E04            mov bx,[bp+0x4]
00000539  8B4606            mov ax,[bp+0x6]
0000053C  E8EA01            call 0x729
0000053F  8BF3              mov si,bx
00000541  8EC0              mov es,ax
00000543  8B4600            mov ax,[bp+0x0]
00000546  8B5602            mov dx,[bp+0x2]
00000549  86F2              xchg dh,dl
0000054B  86E0              xchg ah,al
0000054D  268914            mov [es:si],dx
00000550  26894402          mov [es:si+0x2],ax
00000554  5E                pop si
00000555  5D                pop bp
00000556  CB                retf
00000557  55                push bp
00000558  8BEC              mov bp,sp
0000055A  8BE9              mov bp,cx
0000055C  8B5E04            mov bx,[bp+0x4]
0000055F  8B4606            mov ax,[bp+0x6]
00000562  E8C401            call 0x729
00000565  8EC0              mov es,ax
00000567  8BF3              mov si,bx
00000569  8B4600            mov ax,[bp+0x0]
0000056C  D1E0              shl ax,1
0000056E  03F0              add si,ax
00000570  268B04            mov ax,[es:si]
00000573  86E0              xchg ah,al
00000575  268B5CFE          mov bx,[es:si-0x2]
00000579  86FB              xchg bh,bl
0000057B  2BC3              sub ax,bx
0000057D  33D2              xor dx,dx
0000057F  5D                pop bp
00000580  CB                retf
00000581  55                push bp
00000582  8BEC              mov bp,sp
00000584  33C0              xor ax,ax
00000586  8EC0              mov es,ax
00000588  BB6601            mov bx,0x166
0000058B  BEC603            mov si,0x3c6
0000058E  268B04            mov ax,[es:si]
00000591  2500F0            and ax,0xf000
00000594  B10C              mov cl,0xc
00000596  D3E8              shr ax,cl
00000598  8BD0              mov dx,ax
0000059A  268B04            mov ax,[es:si]
0000059D  25FF0F            and ax,0xfff
000005A0  B104              mov cl,0x4
000005A2  D3E0              shl ax,cl
000005A4  03D8              add bx,ax
000005A6  7301              jnc 0x5a9
000005A8  42                inc dx
000005A9  8BC3              mov ax,bx
000005AB  5D                pop bp
000005AC  CB                retf
000005AD  55                push bp
000005AE  8BEC              mov bp,sp
000005B0  8E068101          mov es,[0x181]
000005B4  B449              mov ah,0x49
000005B6  8B1E7F01          mov bx,[0x17f]
000005BA  CD21              int 0x21
000005BC  C606680100        mov byte [0x168],0x0
000005C1  B448              mov ah,0x48
000005C3  BB0105            mov bx,0x501
000005C6  CD21              int 0x21
000005C8  A3BA00            mov [0xba],ax
000005CB  33C0              xor ax,ax
000005CD  A3B800            mov [0xb8],ax
000005D0  B448              mov ah,0x48
000005D2  BB2002            mov bx,0x220
000005D5  CD21              int 0x21
000005D7  A3BE00            mov [0xbe],ax
000005DA  33C0              xor ax,ax
000005DC  A3BC00            mov [0xbc],ax
000005DF  B448              mov ah,0x48
000005E1  BBFFFF            mov bx,0xffff
000005E4  B448              mov ah,0x48
000005E6  CD21              int 0x21
000005E8  53                push bx
000005E9  81FB3737          cmp bx,0x3737
000005ED  7D27              jnl 0x616
000005EF  B8420A            mov ax,0xa42
000005F2  8D1E1704          lea bx,[0x417]
000005F6  8EC0              mov es,ax
000005F8  8BEB              mov bp,bx
000005FA  B002              mov al,0x2
000005FC  B413              mov ah,0x13
000005FE  B91200            mov cx,0x12
00000601  B601              mov dh,0x1
00000603  B201              mov dl,0x1
00000605  B700              mov bh,0x0
00000607  CD10              int 0x10
00000609  BA3C00            mov dx,0x3c
0000060C  B9FFFF            mov cx,0xffff
0000060F  E2FE              loop 0x60f
00000611  4A                dec dx
00000612  75F8              jnz 0x60c
00000614  CD19              int 0x19
00000616  B448              mov ah,0x48
00000618  CD21              int 0x21
0000061A  5B                pop bx
0000061B  4B                dec bx
0000061C  03C3              add ax,bx
0000061E  2D8813            sub ax,0x1388
00000621  A39404            mov [0x494],ax
00000624  058813            add ax,0x1388
00000627  2BC3              sub ax,bx
00000629  833E920404        cmp word [0x492],byte +0x4
0000062E  750C              jnz 0x63c
00000630  C7069404FF7F      mov word [0x494],0x7fff
00000636  812E94048813      sub word [0x494],0x1388
0000063C  50                push ax
0000063D  9A4A04F006        call 0x6f0:0x44a
00000642  58                pop ax
00000643  8BD0              mov dx,ax
00000645  B10C              mov cl,0xc
00000647  D3EA              shr dx,cl
00000649  25FF0F            and ax,0xfff
0000064C  B104              mov cl,0x4
0000064E  D3E0              shl ax,cl
00000650  5D                pop bp
00000651  CB                retf
00000652  55                push bp
00000653  8BEC              mov bp,sp
00000655  8B460E            mov ax,[bp+0xe]
00000658  A36901            mov [0x169],ax
0000065B  8B4E12            mov cx,[bp+0x12]
0000065E  8B460C            mov ax,[bp+0xc]
00000661  8EC0              mov es,ax
00000663  8B760A            mov si,[bp+0xa]
00000666  8B7E06            mov di,[bp+0x6]
00000669  268A3C            mov bh,[es:si]
0000066C  46                inc si
0000066D  268A1C            mov bl,[es:si]
00000670  46                inc si
00000671  83F900            cmp cx,byte +0x0
00000674  7405              jz 0x67b
00000676  03FB              add di,bx
00000678  49                dec cx
00000679  EBEE              jmp short 0x669
0000067B  8BCF              mov cx,di
0000067D  03CB              add cx,bx
0000067F  49                dec cx
00000680  8B4608            mov ax,[bp+0x8]
00000683  8EC0              mov es,ax
00000685  B280              mov dl,0x80
00000687  8D362904          lea si,[0x429]
0000068B  E86400            call 0x6f2
0000068E  3C1E              cmp al,0x1e
00000690  7506              jnz 0x698
00000692  8D364604          lea si,[0x446]
00000696  EBF3              jmp short 0x68b
00000698  3C1F              cmp al,0x1f
0000069A  7506              jnz 0x6a2
0000069C  8D366304          lea si,[0x463]
000006A0  EBE9              jmp short 0x68b
000006A2  03F0              add si,ax
000006A4  4E                dec si
000006A5  52                push dx
000006A6  53                push bx
000006A7  8A14              mov dl,[si]
000006A9  8CC0              mov ax,es
000006AB  8B5E10            mov bx,[bp+0x10]
000006AE  8EC3              mov es,bx
000006B0  8B5E0E            mov bx,[bp+0xe]
000006B3  268817            mov [es:bx],dl
000006B6  43                inc bx
000006B7  895E0E            mov [bp+0xe],bx
000006BA  8EC0              mov es,ax
000006BC  5B                pop bx
000006BD  5A                pop dx
000006BE  41                inc cx
000006BF  3BCF              cmp cx,di
000006C1  742D              jz 0x6f0
000006C3  49                dec cx
000006C4  3BCF              cmp cx,di
000006C6  75BF              jnz 0x687
000006C8  32F6              xor dh,dh
000006CA  83FA10            cmp dx,byte +0x10
000006CD  7C45              jl 0x714
000006CF  E82000            call 0x6f2
000006D2  0AC0              or al,al
000006D4  743E              jz 0x714
000006D6  8D362904          lea si,[0x429]
000006DA  03F0              add si,ax
000006DC  4E                dec si
000006DD  8A14              mov dl,[si]
000006DF  8CC0              mov ax,es
000006E1  8B5E10            mov bx,[bp+0x10]
000006E4  8EC3              mov es,bx
000006E6  8B5E0E            mov bx,[bp+0xe]
000006E9  268817            mov [es:bx],dl
000006EC  43                inc bx
000006ED  895E0E            mov [bp+0xe],bx
000006F0  EB22              jmp short 0x714
000006F2  53                push bx
000006F3  51                push cx
000006F4  B90500            mov cx,0x5
000006F7  33C0              xor ax,ax
000006F9  268A1D            mov bl,[es:di]
000006FC  22DA              and bl,dl
000006FE  7402              jz 0x702
00000700  FEC0              inc al
00000702  D0E0              shl al,1
00000704  D0EA              shr dl,1
00000706  0AD2              or dl,dl
00000708  7503              jnz 0x70d
0000070A  B280              mov dl,0x80
0000070C  47                inc di
0000070D  E2EA              loop 0x6f9
0000070F  D0E8              shr al,1
00000711  59                pop cx
00000712  5B                pop bx
00000713  C3                ret
00000714  8B460E            mov ax,[bp+0xe]
00000717  2B066901          sub ax,[0x169]
0000071B  8B5E10            mov bx,[bp+0x10]
0000071E  8EC3              mov es,bx
00000720  8B5E0E            mov bx,[bp+0xe]
00000723  26C60700          mov byte [es:bx],0x0
00000727  5D                pop bp
00000728  CB                retf
00000729  51                push cx
0000072A  B10C              mov cl,0xc
0000072C  D3E0              shl ax,cl
0000072E  B104              mov cl,0x4
00000730  53                push bx
00000731  D3EB              shr bx,cl
00000733  03C3              add ax,bx
00000735  5B                pop bx
00000736  83E30F            and bx,byte +0xf
00000739  59                pop cx
0000073A  C3                ret
0000073B  55                push bp
0000073C  8BEC              mov bp,sp
0000073E  56                push si
0000073F  33C9              xor cx,cx
00000741  8E4608            mov es,[bp+0x8]
00000744  8B7606            mov si,[bp+0x6]
00000747  8B460A            mov ax,[bp+0xa]
0000074A  33D2              xor dx,dx
0000074C  BBE803            mov bx,0x3e8
0000074F  F7F3              div bx
00000751  0BC0              or ax,ax
00000753  7403              jz 0x758
00000755  E82700            call 0x77f
00000758  8BC2              mov ax,dx
0000075A  33D2              xor dx,dx
0000075C  BB6400            mov bx,0x64
0000075F  F7F3              div bx
00000761  0BC0              or ax,ax
00000763  7403              jz 0x768
00000765  E81700            call 0x77f
00000768  8BC2              mov ax,dx
0000076A  33D2              xor dx,dx
0000076C  BB0A00            mov bx,0xa
0000076F  F7F3              div bx
00000771  0BC0              or ax,ax
00000773  7403              jz 0x778
00000775  E80700            call 0x77f
00000778  8BC2              mov ax,dx
0000077A  E80200            call 0x77f
0000077D  EB08              jmp short 0x787
0000077F  0435              add al,0x35
00000781  268804            mov [es:si],al
00000784  46                inc si
00000785  41                inc cx
00000786  C3                ret
00000787  8BC1              mov ax,cx
00000789  33D2              xor dx,dx
0000078B  5E                pop si
0000078C  5D                pop bp
0000078D  CB                retf
0000078E  55                push bp
0000078F  8BEC              mov bp,sp
00000791  06                push es
00000792  1E                push ds
00000793  56                push si
00000794  57                push di
00000795  1E                push ds
00000796  8B3E7901          mov di,[0x179]
0000079A  8E067701          mov es,[0x177]
0000079E  8BF3              mov si,bx
000007A0  8ED8              mov ds,ax
000007A2  B91000            mov cx,0x10
000007A5  F3A4              rep movsb
000007A7  46                inc si
000007A8  1F                pop ds
000007A9  B91000            mov cx,0x10
000007AC  8B3EF400          mov di,[0xf4]
000007B0  50                push ax
000007B1  57                push di
000007B2  1E                push ds
000007B3  8EC0              mov es,ax
000007B5  8B3E7501          mov di,[0x175]
000007B9  8E1E7301          mov ds,[0x173]
000007BD  32E4              xor ah,ah
000007BF  268A04            mov al,[es:si]
000007C2  D1E0              shl ax,1
000007C4  03F8              add di,ax
000007C6  8B05              mov ax,[di]
000007C8  1F                pop ds
000007C9  5F                pop di
000007CA  1E                push ds
000007CB  8E1EF200          mov ds,[0xf2]
000007CF  8905              mov [di],ax
000007D1  1F                pop ds
000007D2  58                pop ax
000007D3  83C702            add di,byte +0x2
000007D6  46                inc si
000007D7  E2D7              loop 0x7b0
000007D9  5F                pop di
000007DA  5E                pop si
000007DB  1F                pop ds
000007DC  07                pop es
000007DD  5D                pop bp
000007DE  CB                retf
000007DF  005756            add [bx+0x56],dl
000007E2  55                push bp
000007E3  83EC06            sub sp,byte +0x6
000007E6  8BEC              mov bp,sp
000007E8  FEC8              dec al
000007EA  32E4              xor ah,ah
000007EC  50                push ax
000007ED  50                push ax
000007EE  8E06B400          mov es,[0xb4]
000007F2  8B3EB600          mov di,[0xb6]
000007F6  83C760            add di,byte +0x60
000007F9  268B05            mov ax,[es:di]
000007FC  894600            mov [bp+0x0],ax
000007FF  8B3EB600          mov di,[0xb6]
00000803  83C74E            add di,byte +0x4e
00000806  268A05            mov al,[es:di]
00000809  884602            mov [bp+0x2],al
0000080C  58                pop ax
0000080D  8B3EB600          mov di,[0xb6]
00000811  26037D62          add di,[es:di+0x62]
00000815  B102              mov cl,0x2
00000817  D3E0              shl ax,cl
00000819  03F8              add di,ax
0000081B  8B36B600          mov si,[0xb6]
0000081F  2603746A          add si,[es:si+0x6a]
00000823  D1E8              shr ax,1
00000825  03F0              add si,ax
00000827  268B04            mov ax,[es:si]
0000082A  0106D600          add [0xd6],ax
0000082E  50                push ax
0000082F  268B1D            mov bx,[es:di]
00000832  268B5502          mov dx,[es:di+0x2]
00000836  0AD2              or dl,dl
00000838  7462              jz 0x89c
0000083A  8BC3              mov ax,bx
0000083C  B103              mov cl,0x3
0000083E  D3EB              shr bx,cl
00000840  D3E3              shl bx,cl
00000842  2BC3              sub ax,bx
00000844  D3EB              shr bx,cl
00000846  8B3EB600          mov di,[0xb6]
0000084A  26037D5C          add di,[es:di+0x5c]
0000084E  03FB              add di,bx
00000850  8A7602            mov dh,[bp+0x2]
00000853  8B1E9604          mov bx,[0x496]
00000857  8AE3              mov ah,bl
00000859  803E8E0401        cmp byte [0x48e],0x1
0000085E  745E              jz 0x8be
00000860  56                push si
00000861  1E                push ds
00000862  E89301            call 0x9f8
00000865  50                push ax
00000866  52                push dx
00000867  56                push si
00000868  B580              mov ch,0x80
0000086A  268B1D            mov bx,[es:di]
0000086D  86FB              xchg bh,bl
0000086F  8AC8              mov cl,al
00000871  D3E3              shl bx,cl
00000873  8ADC              mov bl,ah
00000875  8AE7              mov ah,bh
00000877  22FD              and bh,ch
00000879  0AFF              or bh,bh
0000087B  7402              jz 0x87f
0000087D  881C              mov [si],bl
0000087F  8AFC              mov bh,ah
00000881  46                inc si
00000882  D0ED              shr ch,1
00000884  FECA              dec dl
00000886  75ED              jnz 0x875
00000888  5E                pop si
00000889  81C64001          add si,0x140
0000088D  5A                pop dx
0000088E  58                pop ax
0000088F  8ACA              mov cl,dl
00000891  32ED              xor ch,ch
00000893  037E00            add di,[bp+0x0]
00000896  FECE              dec dh
00000898  75CB              jnz 0x865
0000089A  1F                pop ds
0000089B  5E                pop si
0000089C  58                pop ax
0000089D  2906D600          sub [0xd6],ax
000008A1  8B3EB600          mov di,[0xb6]
000008A5  26037D66          add di,[es:di+0x66]
000008A9  58                pop ax
000008AA  D1E0              shl ax,1
000008AC  03F8              add di,ax
000008AE  268B05            mov ax,[es:di]
000008B1  32E4              xor ah,ah
000008B3  0106D600          add [0xd6],ax
000008B7  83C406            add sp,byte +0x6
000008BA  5D                pop bp
000008BB  5E                pop si
000008BC  5F                pop di
000008BD  C3                ret
000008BE  56                push si
000008BF  1E                push ds
000008C0  E83501            call 0x9f8
000008C3  50                push ax
000008C4  52                push dx
000008C5  56                push si
000008C6  B580              mov ch,0x80
000008C8  268B1D            mov bx,[es:di]
000008CB  86FB              xchg bh,bl
000008CD  8AC8              mov cl,al
000008CF  D3E3              shl bx,cl
000008D1  8ADC              mov bl,ah
000008D3  8AE7              mov ah,bh
000008D5  22FD              and bh,ch
000008D7  0AFF              or bh,bh
000008D9  7403              jz 0x8de
000008DB  E81F13            call 0x1bfd
000008DE  8AFC              mov bh,ah
000008E0  46                inc si
000008E1  D0ED              shr ch,1
000008E3  FECA              dec dl
000008E5  75EC              jnz 0x8d3
000008E7  5E                pop si
000008E8  81C64001          add si,0x140
000008EC  5A                pop dx
000008ED  58                pop ax
000008EE  8ACA              mov cl,dl
000008F0  32ED              xor ch,ch
000008F2  037E00            add di,[bp+0x0]
000008F5  FECE              dec dh
000008F7  75CA              jnz 0x8c3
000008F9  1F                pop ds
000008FA  5E                pop si
000008FB  58                pop ax
000008FC  2906D600          sub [0xd6],ax
00000900  8B3EB600          mov di,[0xb6]
00000904  26037D66          add di,[es:di+0x66]
00000908  58                pop ax
00000909  D1E0              shl ax,1
0000090B  03F8              add di,ax
0000090D  268B05            mov ax,[es:di]
00000910  32E4              xor ah,ah
00000912  0106D600          add [0xd6],ax
00000916  83C406            add sp,byte +0x6
00000919  5D                pop bp
0000091A  5E                pop si
0000091B  5F                pop di
0000091C  C3                ret
0000091D  50                push ax
0000091E  06                push es
0000091F  56                push si
00000920  A19404            mov ax,[0x494]
00000923  8EC0              mov es,ax
00000925  B7A0              mov bh,0xa0
00000927  A1D800            mov ax,[0xd8]
0000092A  F6E7              mul bh
0000092C  D1E0              shl ax,1
0000092E  8BF0              mov si,ax
00000930  0336D600          add si,[0xd6]
00000934  26881C            mov [es:si],bl
00000937  5E                pop si
00000938  07                pop es
00000939  58                pop ax
0000093A  C3                ret
0000093B  55                push bp
0000093C  8BEC              mov bp,sp
0000093E  57                push di
0000093F  56                push si
00000940  8B460A            mov ax,[bp+0xa]
00000943  BA1000            mov dx,0x10
00000946  F7E2              mul dx
00000948  837E0800          cmp word [bp+0x8],byte +0x0
0000094C  7502              jnz 0x950
0000094E  EB03              jmp short 0x953
00000950  05001E            add ax,0x1e00
00000953  8E06BA00          mov es,[0xba]
00000957  8B3EB800          mov di,[0xb8]
0000095B  03F8              add di,ax
0000095D  B510              mov ch,0x10
0000095F  E8AD00            call 0xa0f
00000962  8B4606            mov ax,[bp+0x6]
00000965  833EC00000        cmp word [0xc0],byte +0x0
0000096A  7412              jz 0x97e
0000096C  3D0C00            cmp ax,0xc
0000096F  7C05              jl 0x976
00000971  2D0C00            sub ax,0xc
00000974  EB0B              jmp short 0x981
00000976  832ED60006        sub word [0xd6],byte +0x6
0000097B  B80600            mov ax,0x6
0000097E  2D0600            sub ax,0x6
00000981  8BD8              mov bx,ax
00000983  B104              mov cl,0x4
00000985  D3E8              shr ax,cl
00000987  D3E0              shl ax,cl
00000989  2BD8              sub bx,ax
0000098B  D3E8              shr ax,cl
0000098D  53                push bx
0000098E  0AC0              or al,al
00000990  741F              jz 0x9b1
00000992  50                push ax
00000993  8B3EB800          mov di,[0xb8]
00000997  837E0800          cmp word [bp+0x8],byte +0x0
0000099B  7406              jz 0x9a3
0000099D  81C7801E          add di,0x1e80
000009A1  EB04              jmp short 0x9a7
000009A3  81C78000          add di,0x80
000009A7  B510              mov ch,0x10
000009A9  E86300            call 0xa0f
000009AC  58                pop ax
000009AD  FEC8              dec al
000009AF  75E1              jnz 0x992
000009B1  5B                pop bx
000009B2  0ADB              or bl,bl
000009B4  7419              jz 0x9cf
000009B6  8AEB              mov ch,bl
000009B8  8B3EB800          mov di,[0xb8]
000009BC  837E0800          cmp word [bp+0x8],byte +0x0
000009C0  7406              jz 0x9c8
000009C2  81C7801E          add di,0x1e80
000009C6  EB04              jmp short 0x9cc
000009C8  81C78000          add di,0x80
000009CC  E84000            call 0xa0f
000009CF  8B460A            mov ax,[bp+0xa]
000009D2  BA1000            mov dx,0x10
000009D5  F7E2              mul dx
000009D7  837E0800          cmp word [bp+0x8],byte +0x0
000009DB  7505              jnz 0x9e2
000009DD  05000F            add ax,0xf00
000009E0  EB03              jmp short 0x9e5
000009E2  05002D            add ax,0x2d00
000009E5  8E06BA00          mov es,[0xba]
000009E9  8B3EB800          mov di,[0xb8]
000009ED  03F8              add di,ax
000009EF  B510              mov ch,0x10
000009F1  E81B00            call 0xa0f
000009F4  5E                pop si
000009F5  5F                pop di
000009F6  5D                pop bp
000009F7  CB                retf
000009F8  50                push ax
000009F9  52                push dx
000009FA  A1D800            mov ax,[0xd8]
000009FD  BA4001            mov dx,0x140
00000A00  F7E2              mul dx
00000A02  8BF0              mov si,ax
00000A04  0336D600          add si,[0xd6]
00000A08  8E1E9404          mov ds,[0x494]
00000A0C  5A                pop dx
00000A0D  58                pop ax
00000A0E  C3                ret
00000A0F  B10C              mov cl,0xc
00000A11  1E                push ds
00000A12  50                push ax
00000A13  B8420A            mov ax,0xa42
00000A16  8ED8              mov ds,ax
00000A18  58                pop ax
00000A19  803E8E0401        cmp byte [0x48e],0x1
00000A1E  743D              jz 0xa5d
00000A20  1F                pop ds
00000A21  52                push dx
00000A22  1E                push ds
00000A23  56                push si
00000A24  E8D1FF            call 0x9f8
00000A27  51                push cx
00000A28  56                push si
00000A29  51                push cx
00000A2A  268A1D            mov bl,[es:di]
00000A2D  80FB02            cmp bl,0x2
00000A30  7402              jz 0xa34
00000A32  881C              mov [si],bl
00000A34  47                inc di
00000A35  46                inc si
00000A36  FECD              dec ch
00000A38  75F0              jnz 0xa2a
00000A3A  59                pop cx
00000A3B  8BC1              mov ax,cx
00000A3D  32C0              xor al,al
00000A3F  8AC4              mov al,ah
00000A41  32E4              xor ah,ah
00000A43  2BF8              sub di,ax
00000A45  5E                pop si
00000A46  81C74001          add di,0x140
00000A4A  81C64001          add si,0x140
00000A4E  FEC9              dec cl
00000A50  75D6              jnz 0xa28
00000A52  59                pop cx
00000A53  5E                pop si
00000A54  1F                pop ds
00000A55  5A                pop dx
00000A56  0106D600          add [0xd6],ax
00000A5A  32ED              xor ch,ch
00000A5C  C3                ret
00000A5D  1F                pop ds
00000A5E  52                push dx
00000A5F  1E                push ds
00000A60  56                push si
00000A61  E894FF            call 0x9f8
00000A64  51                push cx
00000A65  56                push si
00000A66  51                push cx
00000A67  268A1D            mov bl,[es:di]
00000A6A  80FB02            cmp bl,0x2
00000A6D  7403              jz 0xa72
00000A6F  E88B11            call 0x1bfd
00000A72  47                inc di
00000A73  46                inc si
00000A74  FECD              dec ch
00000A76  75EF              jnz 0xa67
00000A78  59                pop cx
00000A79  8BC1              mov ax,cx
00000A7B  32C0              xor al,al
00000A7D  8AC4              mov al,ah
00000A7F  32E4              xor ah,ah
00000A81  2BF8              sub di,ax
00000A83  5E                pop si
00000A84  81C74001          add di,0x140
00000A88  81C64001          add si,0x140
00000A8C  FEC9              dec cl
00000A8E  75D5              jnz 0xa65
00000A90  59                pop cx
00000A91  5E                pop si
00000A92  1F                pop ds
00000A93  5A                pop dx
00000A94  0106D600          add [0xd6],ax
00000A98  32ED              xor ch,ch
00000A9A  C3                ret
00000A9B  06                push es
00000A9C  50                push ax
00000A9D  B800A0            mov ax,0xa000
00000AA0  8EC0              mov es,ax
00000AA2  26881C            mov [es:si],bl
00000AA5  58                pop ax
00000AA6  07                pop es
00000AA7  C3                ret
00000AA8  55                push bp
00000AA9  8BEC              mov bp,sp
00000AAB  56                push si
00000AAC  57                push di
00000AAD  1E                push ds
00000AAE  8B1ED400          mov bx,[0xd4]
00000AB2  891E9604          mov [0x496],bx
00000AB6  8E4608            mov es,[bp+0x8]
00000AB9  8B7E06            mov di,[bp+0x6]
00000ABC  06                push es
00000ABD  268A05            mov al,[es:di]
00000AC0  0AC0              or al,al
00000AC2  7412              jz 0xad6
00000AC4  3C65              cmp al,0x65
00000AC6  740E              jz 0xad6
00000AC8  E815FD            call 0x7e0
00000ACB  47                inc di
00000ACC  07                pop es
00000ACD  8B460A            mov ax,[bp+0xa]
00000AD0  0106D600          add [0xd6],ax
00000AD4  EBE6              jmp short 0xabc
00000AD6  07                pop es
00000AD7  1F                pop ds
00000AD8  5F                pop di
00000AD9  5E                pop si
00000ADA  5D                pop bp
00000ADB  CB                retf
00000ADC  55                push bp
00000ADD  8BEC              mov bp,sp
00000ADF  1E                push ds
00000AE0  57                push di
00000AE1  56                push si
00000AE2  83EC28            sub sp,byte +0x28
00000AE5  33C0              xor ax,ax
00000AE7  8946FE            mov [bp-0x2],ax
00000AEA  A1D600            mov ax,[0xd6]
00000AED  8946FC            mov [bp-0x4],ax
00000AF0  833ECE0000        cmp word [0xce],byte +0x0
00000AF5  7428              jz 0xb1f
00000AF7  FF0ECE00          dec word [0xce]
00000AFB  8B36CE00          mov si,[0xce]
00000AFF  FF06CE00          inc word [0xce]
00000B03  B8420A            mov ax,0xa42
00000B06  8EC0              mov es,ax
00000B08  32E4              xor ah,ah
00000B0A  268A04            mov al,[es:si]
00000B0D  03F0              add si,ax
00000B0F  8976FA            mov [bp-0x6],si
00000B12  8C46F8            mov [bp-0x8],es
00000B15  268A04            mov al,[es:si]
00000B18  FEC0              inc al
00000B1A  32E4              xor ah,ah
00000B1C  8946FE            mov [bp-0x2],ax
00000B1F  8E4608            mov es,[bp+0x8]
00000B22  8B7E06            mov di,[bp+0x6]
00000B25  33C0              xor ax,ax
00000B27  8946F6            mov [bp-0xa],ax
00000B2A  8946F4            mov [bp-0xc],ax
00000B2D  57                push di
00000B2E  1E                push ds
00000B2F  E80501            call 0xc37
00000B32  1F                pop ds
00000B33  5F                pop di
00000B34  837EF000          cmp word [bp-0x10],byte +0x0
00000B38  7503              jnz 0xb3d
00000B3A  E9DF00            jmp 0xc1c
00000B3D  8B46FC            mov ax,[bp-0x4]
00000B40  A3D600            mov [0xd6],ax
00000B43  8B4612            mov ax,[bp+0x12]
00000B46  3D0100            cmp ax,0x1
00000B49  7514              jnz 0xb5f
00000B4B  8B460E            mov ax,[bp+0xe]
00000B4E  2B46F0            sub ax,[bp-0x10]
00000B51  8B5EF2            mov bx,[bp-0xe]
00000B54  4B                dec bx
00000B55  F7FB              idiv bx
00000B57  8956F4            mov [bp-0xc],dx
00000B5A  8946F6            mov [bp-0xa],ax
00000B5D  EB11              jmp short 0xb70
00000B5F  3D0200            cmp ax,0x2
00000B62  750C              jnz 0xb70
00000B64  8B460E            mov ax,[bp+0xe]
00000B67  2B46F0            sub ax,[bp-0x10]
00000B6A  D1E8              shr ax,1
00000B6C  0106D600          add [0xd6],ax
00000B70  268A05            mov al,[es:di]
00000B73  0AC0              or al,al
00000B75  7503              jnz 0xb7a
00000B77  E9B500            jmp 0xc2f
00000B7A  3C65              cmp al,0x65
00000B7C  7503              jnz 0xb81
00000B7E  E99B00            jmp 0xc1c
00000B81  833ECE0000        cmp word [0xce],byte +0x0
00000B86  7529              jnz 0xbb1
00000B88  8B1ED400          mov bx,[0xd4]
00000B8C  891E9604          mov [0x496],bx
00000B90  268A05            mov al,[es:di]
00000B93  E87A00            call 0xc10
00000B96  47                inc di
00000B97  A1D600            mov ax,[0xd6]
00000B9A  0346F6            add ax,[bp-0xa]
00000B9D  A3D600            mov [0xd6],ax
00000BA0  FF4EF2            dec word [bp-0xe]
00000BA3  837EF201          cmp word [bp-0xe],byte +0x1
00000BA7  7506              jnz 0xbaf
00000BA9  0346F4            add ax,[bp-0xc]
00000BAC  A3D600            mov [0xd6],ax
00000BAF  EBBF              jmp short 0xb70
00000BB1  837E1400          cmp word [bp+0x14],byte +0x0
00000BB5  7537              jnz 0xbee
00000BB7  FF4EFE            dec word [bp-0x2]
00000BBA  837EFE00          cmp word [bp-0x2],byte +0x0
00000BBE  7402              jz 0xbc2
00000BC0  EBC6              jmp short 0xb88
00000BC2  56                push si
00000BC3  06                push es
00000BC4  8E46F8            mov es,[bp-0x8]
00000BC7  8B76FA            mov si,[bp-0x6]
00000BCA  46                inc si
00000BCB  268A04            mov al,[es:si]
00000BCE  FEC0              inc al
00000BD0  0AC0              or al,al
00000BD2  7508              jnz 0xbdc
00000BD4  83EE41            sub si,byte +0x41
00000BD7  268A04            mov al,[es:si]
00000BDA  FEC8              dec al
00000BDC  8976FA            mov [bp-0x6],si
00000BDF  FEC0              inc al
00000BE1  32E4              xor ah,ah
00000BE3  8946FE            mov [bp-0x2],ax
00000BE6  07                pop es
00000BE7  5E                pop si
00000BE8  8B1EC400          mov bx,[0xc4]
00000BEC  EB9E              jmp short 0xb8c
00000BEE  268A05            mov al,[es:di]
00000BF1  06                push es
00000BF2  56                push si
00000BF3  8E460C            mov es,[bp+0xc]
00000BF6  8B760A            mov si,[bp+0xa]
00000BF9  268A0C            mov cl,[es:si]
00000BFC  3AC1              cmp al,cl
00000BFE  750B              jnz 0xc0b
00000C00  FF460A            inc word [bp+0xa]
00000C03  5E                pop si
00000C04  07                pop es
00000C05  8B1EC400          mov bx,[0xc4]
00000C09  EB81              jmp short 0xb8c
00000C0B  5E                pop si
00000C0C  07                pop es
00000C0D  E978FF            jmp 0xb88
00000C10  06                push es
00000C11  1E                push ds
00000C12  57                push di
00000C13  56                push si
00000C14  E8C9FB            call 0x7e0
00000C17  5E                pop si
00000C18  5F                pop di
00000C19  1F                pop ds
00000C1A  07                pop es
00000C1B  C3                ret
00000C1C  A1D800            mov ax,[0xd8]
00000C1F  034610            add ax,[bp+0x10]
00000C22  A3D800            mov [0xd8],ax
00000C25  47                inc di
00000C26  8B46FC            mov ax,[bp-0x4]
00000C29  A3D600            mov [0xd6],ax
00000C2C  E9F6FE            jmp 0xb25
00000C2F  83C428            add sp,byte +0x28
00000C32  5E                pop si
00000C33  5F                pop di
00000C34  1F                pop ds
00000C35  5D                pop bp
00000C36  CB                retf
00000C37  33C0              xor ax,ax
00000C39  8946F2            mov [bp-0xe],ax
00000C3C  8946F0            mov [bp-0x10],ax
00000C3F  268A05            mov al,[es:di]
00000C42  0AC0              or al,al
00000C44  7501              jnz 0xc47
00000C46  C3                ret
00000C47  3C65              cmp al,0x65
00000C49  7501              jnz 0xc4c
00000C4B  C3                ret
00000C4C  32E4              xor ah,ah
00000C4E  FEC8              dec al
00000C50  D1E0              shl ax,1
00000C52  06                push es
00000C53  8E06B400          mov es,[0xb4]
00000C57  8B36B600          mov si,[0xb6]
00000C5B  26037466          add si,[es:si+0x66]
00000C5F  03F0              add si,ax
00000C61  268A04            mov al,[es:si]
00000C64  07                pop es
00000C65  32E4              xor ah,ah
00000C67  0146F0            add [bp-0x10],ax
00000C6A  FF46F2            inc word [bp-0xe]
00000C6D  47                inc di
00000C6E  EBCF              jmp short 0xc3f
00000C70  55                push bp
00000C71  8BEC              mov bp,sp
00000C73  57                push di
00000C74  56                push si
00000C75  8BE9              mov bp,cx
00000C77  8B4608            mov ax,[bp+0x8]
00000C7A  8B5E0C            mov bx,[bp+0xc]
00000C7D  A3D600            mov [0xd6],ax
00000C80  891ED800          mov [0xd8],bx
00000C84  8E06BA00          mov es,[0xba]
00000C88  8B3EB800          mov di,[0xb8]
00000C8C  8BD7              mov dx,di
00000C8E  837E1400          cmp word [bp+0x14],byte +0x0
00000C92  7525              jnz 0xcb9
00000C94  81C7A000          add di,0xa0
00000C98  B92410            mov cx,0x1024
00000C9B  E873FD            call 0xa11
00000C9E  8B3EB800          mov di,[0xb8]
00000CA2  81C79000          add di,0x90
00000CA6  E83700            call 0xce0
00000CA9  8B3EB800          mov di,[0xb8]
00000CAD  81C7B000          add di,0xb0
00000CB1  B92410            mov cx,0x1024
00000CB4  E85AFD            call 0xa11
00000CB7  EB23              jmp short 0xcdc
00000CB9  81C7D000          add di,0xd0
00000CBD  B92410            mov cx,0x1024
00000CC0  E84EFD            call 0xa11
00000CC3  8B3EB800          mov di,[0xb8]
00000CC7  81C7C000          add di,0xc0
00000CCB  E81200            call 0xce0
00000CCE  8B3EB800          mov di,[0xb8]
00000CD2  81C7E000          add di,0xe0
00000CD6  B92410            mov cx,0x1024
00000CD9  E835FD            call 0xa11
00000CDC  5E                pop si
00000CDD  5F                pop di
00000CDE  5D                pop bp
00000CDF  CB                retf
00000CE0  8B4610            mov ax,[bp+0x10]
00000CE3  2D2200            sub ax,0x22
00000CE6  8BD0              mov dx,ax
00000CE8  B104              mov cl,0x4
00000CEA  D3E8              shr ax,cl
00000CEC  50                push ax
00000CED  D3E0              shl ax,cl
00000CEF  2BD0              sub dx,ax
00000CF1  58                pop ax
00000CF2  0AC0              or al,al
00000CF4  740E              jz 0xd04
00000CF6  50                push ax
00000CF7  57                push di
00000CF8  B92410            mov cx,0x1024
00000CFB  E813FD            call 0xa11
00000CFE  5F                pop di
00000CFF  58                pop ax
00000D00  FEC8              dec al
00000D02  75F2              jnz 0xcf6
00000D04  0AD2              or dl,dl
00000D06  7407              jz 0xd0f
00000D08  8AEA              mov ch,dl
00000D0A  B124              mov cl,0x24
00000D0C  E802FD            call 0xa11
00000D0F  C3                ret
00000D10  55                push bp
00000D11  8BEC              mov bp,sp
00000D13  57                push di
00000D14  56                push si
00000D15  1E                push ds
00000D16  8BE9              mov bp,cx
00000D18  8B4600            mov ax,[bp+0x0]
00000D1B  3DC700            cmp ax,0xc7
00000D1E  7E06              jng 0xd26
00000D20  B8C700            mov ax,0xc7
00000D23  894600            mov [bp+0x0],ax
00000D26  8E069404          mov es,[0x494]
00000D2A  8B4608            mov ax,[bp+0x8]
00000D2D  BA4001            mov dx,0x140
00000D30  F7E2              mul dx
00000D32  8B5E0C            mov bx,[bp+0xc]
00000D35  81E3F001          and bx,0x1f0
00000D39  895E0C            mov [bp+0xc],bx
00000D3C  03C3              add ax,bx
00000D3E  8BF8              mov di,ax
00000D40  837E1800          cmp word [bp+0x18],byte +0x0
00000D44  750B              jnz 0xd51
00000D46  8B5E10            mov bx,[bp+0x10]
00000D49  8B4612            mov ax,[bp+0x12]
00000D4C  E84901            call 0xe98
00000D4F  EB09              jmp short 0xd5a
00000D51  8B5E14            mov bx,[bp+0x14]
00000D54  8B4616            mov ax,[bp+0x16]
00000D57  E83E01            call 0xe98
00000D5A  8ED8              mov ds,ax
00000D5C  8BF3              mov si,bx
00000D5E  B104              mov cl,0x4
00000D60  8B460C            mov ax,[bp+0xc]
00000D63  8B5E04            mov bx,[bp+0x4]
00000D66  81E3F001          and bx,0x1f0
00000D6A  83C30F            add bx,byte +0xf
00000D6D  895E04            mov [bp+0x4],bx
00000D70  43                inc bx
00000D71  2BD8              sub bx,ax
00000D73  8B4600            mov ax,[bp+0x0]
00000D76  40                inc ax
00000D77  2B4608            sub ax,[bp+0x8]
00000D7A  837E1800          cmp word [bp+0x18],byte +0x0
00000D7E  7527              jnz 0xda7
00000D80  53                push bx
00000D81  57                push di
00000D82  268A15            mov dl,[es:di]
00000D85  47                inc di
00000D86  D2E2              shl dl,cl
00000D88  4B                dec bx
00000D89  7505              jnz 0xd90
00000D8B  8814              mov [si],dl
00000D8D  46                inc si
00000D8E  EB0C              jmp short 0xd9c
00000D90  268A35            mov dh,[es:di]
00000D93  02F2              add dh,dl
00000D95  47                inc di
00000D96  8834              mov [si],dh
00000D98  46                inc si
00000D99  4B                dec bx
00000D9A  75E6              jnz 0xd82
00000D9C  5F                pop di
00000D9D  5B                pop bx
00000D9E  81C74001          add di,0x140
00000DA2  48                dec ax
00000DA3  75DB              jnz 0xd80
00000DA5  EB46              jmp short 0xded
00000DA7  53                push bx
00000DA8  57                push di
00000DA9  8A14              mov dl,[si]
00000DAB  D2EA              shr dl,cl
00000DAD  268815            mov [es:di],dl
00000DB0  47                inc di
00000DB1  4B                dec bx
00000DB2  740F              jz 0xdc3
00000DB4  8A34              mov dh,[si]
00000DB6  80E60F            and dh,0xf
00000DB9  268835            mov [es:di],dh
00000DBC  46                inc si
00000DBD  47                inc di
00000DBE  4B                dec bx
00000DBF  75E8              jnz 0xda9
00000DC1  EB01              jmp short 0xdc4
00000DC3  46                inc si
00000DC4  5F                pop di
00000DC5  5B                pop bx
00000DC6  81C74001          add di,0x140
00000DCA  48                dec ax
00000DCB  75DA              jnz 0xda7
00000DCD  1F                pop ds
00000DCE  8B5E10            mov bx,[bp+0x10]
00000DD1  8B4612            mov ax,[bp+0x12]
00000DD4  E8C100            call 0xe98
00000DD7  0BC0              or ax,ax
00000DD9  7410              jz 0xdeb
00000DDB  8B5E14            mov bx,[bp+0x14]
00000DDE  8B4616            mov ax,[bp+0x16]
00000DE1  E8B400            call 0xe98
00000DE4  2BF3              sub si,bx
00000DE6  8BC6              mov ax,si
00000DE8  EB46              jmp short 0xe30
00000DEA  90                nop
00000DEB  EB14              jmp short 0xe01
00000DED  1F                pop ds
00000DEE  8B5E10            mov bx,[bp+0x10]
00000DF1  8B4612            mov ax,[bp+0x12]
00000DF4  E8A100            call 0xe98
00000DF7  0BC0              or ax,ax
00000DF9  7406              jz 0xe01
00000DFB  2BF3              sub si,bx
00000DFD  8BC6              mov ax,si
00000DFF  EB2F              jmp short 0xe30
00000E01  8B5E14            mov bx,[bp+0x14]
00000E04  8B4616            mov ax,[bp+0x16]
00000E07  E88E00            call 0xe98
00000E0A  2BF3              sub si,bx
00000E0C  8BC6              mov ax,si
00000E0E  50                push ax
00000E0F  8B460C            mov ax,[bp+0xc]
00000E12  A39E00            mov [0x9e],ax
00000E15  8B5E08            mov bx,[bp+0x8]
00000E18  891EA400          mov [0xa4],bx
00000E1C  8B4E04            mov cx,[bp+0x4]
00000E1F  890EA000          mov [0xa0],cx
00000E23  8B5600            mov dx,[bp+0x0]
00000E26  8916A200          mov [0xa2],dx
00000E2A  9A750D9304        call 0x493:0xd75
00000E2F  58                pop ax
00000E30  33D2              xor dx,dx
00000E32  5E                pop si
00000E33  5F                pop di
00000E34  5D                pop bp
00000E35  CB                retf
00000E36  55                push bp
00000E37  8BEC              mov bp,sp
00000E39  56                push si
00000E3A  57                push di
00000E3B  1E                push ds
00000E3C  8BE9              mov bp,cx
00000E3E  8A5E00            mov bl,[bp+0x0]
00000E41  8B4604            mov ax,[bp+0x4]
00000E44  50                push ax
00000E45  A3D800            mov [0xd8],ax
00000E48  8B4608            mov ax,[bp+0x8]
00000E4B  50                push ax
00000E4C  A3D600            mov [0xd6],ax
00000E4F  E8CBFA            call 0x91d
00000E52  FF06D800          inc word [0xd8]
00000E56  E8C4FA            call 0x91d
00000E59  FF06D600          inc word [0xd6]
00000E5D  E8BDFA            call 0x91d
00000E60  FF0ED800          dec word [0xd8]
00000E64  E8B6FA            call 0x91d
00000E67  8B5E0C            mov bx,[bp+0xc]
00000E6A  8B460E            mov ax,[bp+0xe]
00000E6D  E82800            call 0xe98
00000E70  0BC0              or ax,ax
00000E72  751D              jnz 0xe91
00000E74  58                pop ax
00000E75  5B                pop bx
00000E76  891EA400          mov [0xa4],bx
00000E7A  050200            add ax,0x2
00000E7D  891EA200          mov [0xa2],bx
00000E81  A39E00            mov [0x9e],ax
00000E84  83C302            add bx,byte +0x2
00000E87  A3A000            mov [0xa0],ax
00000E8A  9A750D9304        call 0x493:0xd75
00000E8F  EB02              jmp short 0xe93
00000E91  58                pop ax
00000E92  58                pop ax
00000E93  1F                pop ds
00000E94  5F                pop di
00000E95  5E                pop si
00000E96  5D                pop bp
00000E97  CB                retf
00000E98  51                push cx
00000E99  B10C              mov cl,0xc
00000E9B  D3E0              shl ax,cl
00000E9D  B104              mov cl,0x4
00000E9F  53                push bx
00000EA0  D3EB              shr bx,cl
00000EA2  03C3              add ax,bx
00000EA4  5B                pop bx
00000EA5  83E30F            and bx,byte +0xf
00000EA8  59                pop cx
00000EA9  C3                ret
00000EAA  55                push bp
00000EAB  8BEC              mov bp,sp
00000EAD  56                push si
00000EAE  57                push di
00000EAF  1E                push ds
00000EB0  8BE9              mov bp,cx
00000EB2  8B4600            mov ax,[bp+0x0]
00000EB5  8B7604            mov si,[bp+0x4]
00000EB8  8B5608            mov dx,[bp+0x8]
00000EBB  8B7E0C            mov di,[bp+0xc]
00000EBE  50                push ax
00000EBF  32DB              xor bl,bl
00000EC1  8BC8              mov cx,ax
00000EC3  2BCA              sub cx,dx
00000EC5  41                inc cx
00000EC6  893ED600          mov [0xd6],di
00000ECA  8916D800          mov [0xd8],dx
00000ECE  51                push cx
00000ECF  8BC6              mov ax,si
00000ED1  2BC7              sub ax,di
00000ED3  40                inc ax
00000ED4  8BC8              mov cx,ax
00000ED6  57                push di
00000ED7  52                push dx
00000ED8  56                push si
00000ED9  E841FA            call 0x91d
00000EDC  FF06D600          inc word [0xd6]
00000EE0  E2F7              loop 0xed9
00000EE2  5E                pop si
00000EE3  5A                pop dx
00000EE4  5F                pop di
00000EE5  893ED600          mov [0xd6],di
00000EE9  FF06D800          inc word [0xd8]
00000EED  59                pop cx
00000EEE  E2DE              loop 0xece
00000EF0  52                push dx
00000EF1  8B5E10            mov bx,[bp+0x10]
00000EF4  8B4612            mov ax,[bp+0x12]
00000EF7  E89EFF            call 0xe98
00000EFA  0BC0              or ax,ax
00000EFC  7518              jnz 0xf16
00000EFE  5A                pop dx
00000EFF  58                pop ax
00000F00  893E9E00          mov [0x9e],di
00000F04  8916A400          mov [0xa4],dx
00000F08  A3A200            mov [0xa2],ax
00000F0B  8936A000          mov [0xa0],si
00000F0F  9A750D9304        call 0x493:0xd75
00000F14  EB02              jmp short 0xf18
00000F16  5A                pop dx
00000F17  58                pop ax
00000F18  1F                pop ds
00000F19  5F                pop di
00000F1A  5E                pop si
00000F1B  5D                pop bp
00000F1C  CB                retf
00000F1D  55                push bp
00000F1E  8BEC              mov bp,sp
00000F20  56                push si
00000F21  57                push di
00000F22  1E                push ds
00000F23  8BE9              mov bp,cx
00000F25  8B4604            mov ax,[bp+0x4]
00000F28  8B5E08            mov bx,[bp+0x8]
00000F2B  8B4E0C            mov cx,[bp+0xc]
00000F2E  8B5610            mov dx,[bp+0x10]
00000F31  C606800400        mov byte [0x480],0x0
00000F36  8BF3              mov si,bx
00000F38  2BF2              sub si,dx
00000F3A  3BD3              cmp dx,bx
00000F3C  7E09              jng 0xf47
00000F3E  8BF2              mov si,dx
00000F40  2BF3              sub si,bx
00000F42  C606800401        mov byte [0x480],0x1
00000F47  C606810400        mov byte [0x481],0x0
00000F4C  8BF8              mov di,ax
00000F4E  2BF9              sub di,cx
00000F50  3BC8              cmp cx,ax
00000F52  7E09              jng 0xf5d
00000F54  8BF9              mov di,cx
00000F56  2BF8              sub di,ax
00000F58  C606810401        mov byte [0x481],0x1
00000F5D  50                push ax
00000F5E  53                push bx
00000F5F  51                push cx
00000F60  52                push dx
00000F61  8916D600          mov [0xd6],dx
00000F65  890ED800          mov [0xd8],cx
00000F69  89368204          mov [0x482],si
00000F6D  3BF7              cmp si,di
00000F6F  7F04              jg 0xf75
00000F71  893E8204          mov [0x482],di
00000F75  B80004            mov ax,0x400
00000F78  33D2              xor dx,dx
00000F7A  8B0E8204          mov cx,[0x482]
00000F7E  F7F1              div cx
00000F80  A38804            mov [0x488],ax
00000F83  33C9              xor cx,cx
00000F85  51                push cx
00000F86  B80004            mov ax,0x400
00000F89  33D2              xor dx,dx
00000F8B  8B0E8204          mov cx,[0x482]
00000F8F  F7F1              div cx
00000F91  59                pop cx
00000F92  F7E6              mul si
00000F94  F7E1              mul cx
00000F96  51                push cx
00000F97  B90004            mov cx,0x400
00000F9A  F7F1              div cx
00000F9C  59                pop cx
00000F9D  2906D600          sub [0xd6],ax
00000FA1  803E800401        cmp byte [0x480],0x1
00000FA6  7408              jz 0xfb0
00000FA8  0106D600          add [0xd6],ax
00000FAC  0106D600          add [0xd6],ax
00000FB0  50                push ax
00000FB1  51                push cx
00000FB2  B80004            mov ax,0x400
00000FB5  33D2              xor dx,dx
00000FB7  8B0E8204          mov cx,[0x482]
00000FBB  F7F1              div cx
00000FBD  59                pop cx
00000FBE  F7E7              mul di
00000FC0  F7E1              mul cx
00000FC2  51                push cx
00000FC3  B90004            mov cx,0x400
00000FC6  F7F1              div cx
00000FC8  59                pop cx
00000FC9  2906D800          sub [0xd8],ax
00000FCD  803E810401        cmp byte [0x481],0x1
00000FD2  7408              jz 0xfdc
00000FD4  0106D800          add [0xd8],ax
00000FD8  0106D800          add [0xd8],ax
00000FDC  50                push ax
00000FDD  8B5E00            mov bx,[bp+0x0]
00000FE0  E83AF9            call 0x91d
00000FE3  58                pop ax
00000FE4  8BD8              mov bx,ax
00000FE6  803E810401        cmp byte [0x481],0x1
00000FEB  7406              jz 0xff3
00000FED  2906D800          sub [0xd8],ax
00000FF1  EB04              jmp short 0xff7
00000FF3  0106D800          add [0xd8],ax
00000FF7  58                pop ax
00000FF8  803E800401        cmp byte [0x480],0x1
00000FFD  7406              jz 0x1005
00000FFF  2906D600          sub [0xd6],ax
00001003  EB04              jmp short 0x1009
00001005  0106D600          add [0xd6],ax
00001009  3BD8              cmp bx,ax
0000100B  7E02              jng 0x100f
0000100D  8BC3              mov ax,bx
0000100F  8B168204          mov dx,[0x482]
00001013  3BC2              cmp ax,dx
00001015  7404              jz 0x101b
00001017  41                inc cx
00001018  E96AFF            jmp 0xf85
0000101B  8B5E14            mov bx,[bp+0x14]
0000101E  8B4616            mov ax,[bp+0x16]
00001021  E874FE            call 0xe98
00001024  0BC0              or ax,ax
00001026  7531              jnz 0x1059
00001028  5A                pop dx
00001029  59                pop cx
0000102A  5B                pop bx
0000102B  58                pop ax
0000102C  A3A200            mov [0xa2],ax
0000102F  891EA000          mov [0xa0],bx
00001033  890EA400          mov [0xa4],cx
00001037  89169E00          mov [0x9e],dx
0000103B  3BD3              cmp dx,bx
0000103D  7E08              jng 0x1047
0000103F  891E9E00          mov [0x9e],bx
00001043  8916A000          mov [0xa0],dx
00001047  3BC8              cmp cx,ax
00001049  7E07              jng 0x1052
0000104B  A3A400            mov [0xa4],ax
0000104E  890EA200          mov [0xa2],cx
00001052  9A750D9304        call 0x493:0xd75
00001057  EB04              jmp short 0x105d
00001059  5A                pop dx
0000105A  59                pop cx
0000105B  5B                pop bx
0000105C  58                pop ax
0000105D  1F                pop ds
0000105E  5F                pop di
0000105F  5E                pop si
00001060  5D                pop bp
00001061  CB                retf
00001062  55                push bp
00001063  8BEC              mov bp,sp
00001065  56                push si
00001066  57                push di
00001067  1E                push ds
00001068  C606A60401        mov byte [0x4a6],0x1
0000106D  C606740E00        mov byte [0xe74],0x0
00001072  C606270601        mov byte [0x627],0x1
00001077  8BE9              mov bp,cx
00001079  32C9              xor cl,cl
0000107B  E8D102            call 0x134f
0000107E  E83905            call 0x15ba
00001081  E87D04            call 0x1501
00001084  E85C05            call 0x15e3
00001087  3C01              cmp al,0x1
00001089  7505              jnz 0x1090
0000108B  33C0              xor ax,ax
0000108D  E9EC00            jmp 0x117c
00001090  B101              mov cl,0x1
00001092  E8BA02            call 0x134f
00001095  E82205            call 0x15ba
00001098  E86604            call 0x1501
0000109B  E84505            call 0x15e3
0000109E  3C01              cmp al,0x1
000010A0  7405              jz 0x10a7
000010A2  33C0              xor ax,ax
000010A4  E9D500            jmp 0x117c
000010A7  E83905            call 0x15e3
000010AA  B102              mov cl,0x2
000010AC  E8A002            call 0x134f
000010AF  E83701            call 0x11e9
000010B2  0AFF              or bh,bh
000010B4  7518              jnz 0x10ce
000010B6  E82A05            call 0x15e3
000010B9  B103              mov cl,0x3
000010BB  E89102            call 0x134f
000010BE  E8F904            call 0x15ba
000010C1  E83D04            call 0x1501
000010C4  E81C05            call 0x15e3
000010C7  3C01              cmp al,0x1
000010C9  74DC              jz 0x10a7
000010CB  E9AE00            jmp 0x117c
000010CE  53                push bx
000010CF  53                push bx
000010D0  E8E704            call 0x15ba
000010D3  E82B04            call 0x1501
000010D6  5B                pop bx
000010D7  B401              mov ah,0x1
000010D9  D0DF              rcr bh,1
000010DB  7202              jc 0x10df
000010DD  32E4              xor ah,ah
000010DF  B302              mov bl,0x2
000010E1  D0DF              rcr bh,1
000010E3  7202              jc 0x10e7
000010E5  32DB              xor bl,bl
000010E7  B503              mov ch,0x3
000010E9  D0DF              rcr bh,1
000010EB  7202              jc 0x10ef
000010ED  32ED              xor ch,ch
000010EF  B104              mov cl,0x4
000010F1  D0DF              rcr bh,1
000010F3  7202              jc 0x10f7
000010F5  32C9              xor cl,cl
000010F7  3AC4              cmp al,ah
000010F9  7503              jnz 0x10fe
000010FB  EB16              jmp short 0x1113
000010FD  90                nop
000010FE  3AC3              cmp al,bl
00001100  7503              jnz 0x1105
00001102  EB0F              jmp short 0x1113
00001104  90                nop
00001105  3AC5              cmp al,ch
00001107  7503              jnz 0x110c
00001109  EB08              jmp short 0x1113
0000110B  90                nop
0000110C  3AC1              cmp al,cl
0000110E  7403              jz 0x1113
00001110  5B                pop bx
00001111  EBBB              jmp short 0x10ce
00001113  5B                pop bx
00001114  0430              add al,0x30
00001116  1E                push ds
00001117  BB420A            mov bx,0xa42
0000111A  8EDB              mov ds,bx
0000111C  8D3E6B05          lea di,[0x56b]
00001120  88450B            mov [di+0xb],al
00001123  8BD7              mov dx,di
00001125  B8803D            mov ax,0x3d80
00001128  CD21              int 0x21
0000112A  7237              jc 0x1163
0000112C  8BD8              mov bx,ax
0000112E  53                push bx
0000112F  33C9              xor cx,cx
00001131  33D2              xor dx,dx
00001133  B80042            mov ax,0x4200
00001136  CD21              int 0x21
00001138  7229              jc 0x1163
0000113A  B9A309            mov cx,0x9a3
0000113D  8B5E04            mov bx,[bp+0x4]
00001140  8B4606            mov ax,[bp+0x6]
00001143  E852FD            call 0xe98
00001146  8ED8              mov ds,ax
00001148  8BD3              mov dx,bx
0000114A  5B                pop bx
0000114B  B43F              mov ah,0x3f
0000114D  CD21              int 0x21
0000114F  7212              jc 0x1163
00001151  53                push bx
00001152  E8CD01            call 0x1322
00001155  5B                pop bx
00001156  B43E              mov ah,0x3e
00001158  CD21              int 0x21
0000115A  1F                pop ds
0000115B  E88504            call 0x15e3
0000115E  B80100            mov ax,0x1
00001161  EB19              jmp short 0x117c
00001163  1F                pop ds
00001164  E87C04            call 0x15e3
00001167  B105              mov cl,0x5
00001169  E8E301            call 0x134f
0000116C  E84B04            call 0x15ba
0000116F  E88F03            call 0x1501
00001172  E86E04            call 0x15e3
00001175  3C01              cmp al,0x1
00001177  7503              jnz 0x117c
00001179  E9FDFE            jmp 0x1079
0000117C  33D2              xor dx,dx
0000117E  1F                pop ds
0000117F  C606A60400        mov byte [0x4a6],0x0
00001184  5F                pop di
00001185  5E                pop si
00001186  5D                pop bp
00001187  CB                retf
00001188  C3                ret
00001189  55                push bp
0000118A  8BEC              mov bp,sp
0000118C  C606A60401        mov byte [0x4a6],0x1
00001191  56                push si
00001192  57                push di
00001193  1E                push ds
00001194  8BE9              mov bp,cx
00001196  B101              mov cl,0x1
00001198  E8B401            call 0x134f
0000119B  E81C04            call 0x15ba
0000119E  E86003            call 0x1501
000011A1  3C01              cmp al,0x1
000011A3  7406              jz 0x11ab
000011A5  E83B04            call 0x15e3
000011A8  E9DA00            jmp 0x1285
000011AB  E83504            call 0x15e3
000011AE  803E720602        cmp byte [0x672],0x2
000011B3  7426              jz 0x11db
000011B5  E81B01            call 0x12d3
000011B8  0BC0              or ax,ax
000011BA  741F              jz 0x11db
000011BC  B103              mov cl,0x3
000011BE  E88E01            call 0x134f
000011C1  E8F603            call 0x15ba
000011C4  E83A03            call 0x1501
000011C7  3C01              cmp al,0x1
000011C9  7406              jz 0x11d1
000011CB  E81504            call 0x15e3
000011CE  E9B400            jmp 0x1285
000011D1  E80F04            call 0x15e3
000011D4  EBC0              jmp short 0x1196
000011D6  E80A04            call 0x15e3
000011D9  EBD0              jmp short 0x11ab
000011DB  E80504            call 0x15e3
000011DE  E80300            call 0x11e4
000011E1  EB39              jmp short 0x121c
000011E3  90                nop
000011E4  B104              mov cl,0x4
000011E6  E86601            call 0x134f
000011E9  E8A300            call 0x128f
000011EC  33C9              xor cx,cx
000011EE  53                push bx
000011EF  51                push cx
000011F0  D0DF              rcr bh,1
000011F2  53                push bx
000011F3  731B              jnc 0x1210
000011F5  1E                push ds
000011F6  B8420A            mov ax,0xa42
000011F9  8ED8              mov ds,ax
000011FB  8D368D05          lea si,[0x58d]
000011FF  D1E1              shl cx,1
00001201  D1E1              shl cx,1
00001203  D1E1              shl cx,1
00001205  03F1              add si,cx
00001207  8B5C02            mov bx,[si+0x2]
0000120A  8B3C              mov di,[si]
0000120C  1F                pop ds
0000120D  E87D03            call 0x158d
00001210  5B                pop bx
00001211  59                pop cx
00001212  41                inc cx
00001213  83F904            cmp cx,byte +0x4
00001216  7402              jz 0x121a
00001218  EBD5              jmp short 0x11ef
0000121A  5B                pop bx
0000121B  C3                ret
0000121C  E89B03            call 0x15ba
0000121F  E8DF02            call 0x1501
00001222  1E                push ds
00001223  0430              add al,0x30
00001225  BB420A            mov bx,0xa42
00001228  8D3E6B05          lea di,[0x56b]
0000122C  88450B            mov [di+0xb],al
0000122F  8BD7              mov dx,di
00001231  B43C              mov ah,0x3c
00001233  33C9              xor cx,cx
00001235  CD21              int 0x21
00001237  7234              jc 0x126d
00001239  B43D              mov ah,0x3d
0000123B  B002              mov al,0x2
0000123D  CD21              int 0x21
0000123F  722C              jc 0x126d
00001241  8BD8              mov bx,ax
00001243  B9A309            mov cx,0x9a3
00001246  E8AC00            call 0x12f5
00001249  53                push bx
0000124A  8B5E04            mov bx,[bp+0x4]
0000124D  8B4606            mov ax,[bp+0x6]
00001250  E845FC            call 0xe98
00001253  8ED8              mov ds,ax
00001255  8BD3              mov dx,bx
00001257  5B                pop bx
00001258  B440              mov ah,0x40
0000125A  CD21              int 0x21
0000125C  720F              jc 0x126d
0000125E  1F                pop ds
0000125F  1E                push ds
00001260  B43E              mov ah,0x3e
00001262  CD21              int 0x21
00001264  7207              jc 0x126d
00001266  1F                pop ds
00001267  E87903            call 0x15e3
0000126A  EB19              jmp short 0x1285
0000126C  90                nop
0000126D  1F                pop ds
0000126E  E87203            call 0x15e3
00001271  B10A              mov cl,0xa
00001273  E8D900            call 0x134f
00001276  E84103            call 0x15ba
00001279  E88502            call 0x1501
0000127C  E86403            call 0x15e3
0000127F  EB04              jmp short 0x1285
00001281  90                nop
00001282  EB01              jmp short 0x1285
00001284  90                nop
00001285  1F                pop ds
00001286  C606A60400        mov byte [0x4a6],0x0
0000128B  5F                pop di
0000128C  5E                pop si
0000128D  5D                pop bp
0000128E  CB                retf
0000128F  1E                push ds
00001290  BB0100            mov bx,0x1
00001293  B180              mov cl,0x80
00001295  B8420A            mov ax,0xa42
00001298  8ED8              mov ds,ax
0000129A  8D166B05          lea dx,[0x56b]
0000129E  8BFA              mov di,dx
000012A0  51                push cx
000012A1  53                push bx
000012A2  80C330            add bl,0x30
000012A5  885D0B            mov [di+0xb],bl
000012A8  E81500            call 0x12c0
000012AB  5B                pop bx
000012AC  59                pop cx
000012AD  D0C1              rol cl,1
000012AF  0AE4              or ah,ah
000012B1  7502              jnz 0x12b5
000012B3  02F9              add bh,cl
000012B5  FEC3              inc bl
000012B7  80FB05            cmp bl,0x5
000012BA  7402              jz 0x12be
000012BC  EBD7              jmp short 0x1295
000012BE  1F                pop ds
000012BF  C3                ret
000012C0  B8803D            mov ax,0x3d80
000012C3  CD21              int 0x21
000012C5  7209              jc 0x12d0
000012C7  8BD8              mov bx,ax
000012C9  B43E              mov ah,0x3e
000012CB  CD21              int 0x21
000012CD  32E4              xor ah,ah
000012CF  C3                ret
000012D0  B4FF              mov ah,0xff
000012D2  C3                ret
000012D3  1E                push ds
000012D4  B90300            mov cx,0x3
000012D7  B8420A            mov ax,0xa42
000012DA  8ED8              mov ds,ax
000012DC  8D167805          lea dx,[0x578]
000012E0  B8803D            mov ax,0x3d80
000012E3  CD21              int 0x21
000012E5  7309              jnc 0x12f0
000012E7  83C207            add dx,byte +0x7
000012EA  E2F4              loop 0x12e0
000012EC  33C0              xor ax,ax
000012EE  1F                pop ds
000012EF  C3                ret
000012F0  1F                pop ds
000012F1  B8FFFF            mov ax,0xffff
000012F4  C3                ret
000012F5  50                push ax
000012F6  53                push bx
000012F7  51                push cx
000012F8  06                push es
000012F9  56                push si
000012FA  1E                push ds
000012FB  57                push di
000012FC  8B5E04            mov bx,[bp+0x4]
000012FF  8B4606            mov ax,[bp+0x6]
00001302  E893FB            call 0xe98
00001305  8EC0              mov es,ax
00001307  8BFB              mov di,bx
00001309  81C79B09          add di,0x99b
0000130D  B8420A            mov ax,0xa42
00001310  BE3528            mov si,0x2835
00001313  8ED8              mov ds,ax
00001315  B90800            mov cx,0x8
00001318  F3A4              rep movsb
0000131A  5F                pop di
0000131B  1F                pop ds
0000131C  5E                pop si
0000131D  07                pop es
0000131E  59                pop cx
0000131F  5B                pop bx
00001320  58                pop ax
00001321  C3                ret
00001322  50                push ax
00001323  53                push bx
00001324  51                push cx
00001325  06                push es
00001326  56                push si
00001327  1E                push ds
00001328  57                push di
00001329  8B5E04            mov bx,[bp+0x4]
0000132C  8B4606            mov ax,[bp+0x6]
0000132F  E866FB            call 0xe98
00001332  8BF3              mov si,bx
00001334  81C69B09          add si,0x99b
00001338  B9420A            mov cx,0xa42
0000133B  BF3528            mov di,0x2835
0000133E  8EC1              mov es,cx
00001340  8ED8              mov ds,ax
00001342  B90800            mov cx,0x8
00001345  F3A4              rep movsb
00001347  5F                pop di
00001348  1F                pop ds
00001349  5E                pop si
0000134A  07                pop es
0000134B  59                pop cx
0000134C  5B                pop bx
0000134D  58                pop ax
0000134E  C3                ret
0000134F  C7068C040000      mov word [0x48c],0x0
00001355  8E06AA00          mov es,[0xaa]
00001359  8B36A800          mov si,[0xa8]
0000135D  8BFE              mov di,si
0000135F  26037D02          add di,[es:di+0x2]
00001363  56                push si
00001364  32ED              xor ch,ch
00001366  83C604            add si,byte +0x4
00001369  D0E1              shl cl,1
0000136B  03F1              add si,cx
0000136D  268B04            mov ax,[es:si]
00001370  5E                pop si
00001371  03F0              add si,ax
00001373  46                inc si
00001374  46                inc si
00001375  33D2              xor dx,dx
00001377  33C0              xor ax,ax
00001379  50                push ax
0000137A  50                push ax
0000137B  50                push ax
0000137C  268B44FE          mov ax,[es:si-0x2]
00001380  A38A04            mov [0x48a],ax
00001383  50                push ax
00001384  52                push dx
00001385  BB0001            mov bx,0x100
00001388  2BD8              sub bx,ax
0000138A  D1EB              shr bx,1
0000138C  83C304            add bx,byte +0x4
0000138F  B84600            mov ax,0x46
00001392  50                push ax
00001393  53                push bx
00001394  51                push cx
00001395  52                push dx
00001396  33D2              xor dx,dx
00001398  B94001            mov cx,0x140
0000139B  F7E0              mul ax
0000139D  03C3              add ax,bx
0000139F  33D2              xor dx,dx
000013A1  52                push dx
000013A2  52                push dx
000013A3  8BF8              mov di,ax
000013A5  A19404            mov ax,[0x494]
000013A8  E83D01            call 0x14e8
000013AB  50                push ax
000013AC  57                push di
000013AD  A1BE00            mov ax,[0xbe]
000013B0  052000            add ax,0x20
000013B3  8B3EBC00          mov di,[0xbc]
000013B7  E82E01            call 0x14e8
000013BA  50                push ax
000013BB  57                push di
000013BC  33C0              xor ax,ax
000013BE  50                push ax
000013BF  891E8404          mov [0x484],bx
000013C3  53                push bx
000013C4  50                push ax
000013C5  B84600            mov ax,0x46
000013C8  50                push ax
000013C9  268B44FE          mov ax,[es:si-0x2]
000013CD  03D8              add bx,ax
000013CF  33C0              xor ax,ax
000013D1  50                push ax
000013D2  83EB04            sub bx,byte +0x4
000013D5  891E8604          mov [0x486],bx
000013D9  53                push bx
000013DA  50                push ax
000013DB  B86900            mov ax,0x69
000013DE  50                push ax
000013DF  B82400            mov ax,0x24
000013E2  8BCC              mov cx,sp
000013E4  CDFE              int 0xfe
000013E6  83C41C            add sp,byte +0x1c
000013E9  5A                pop dx
000013EA  59                pop cx
000013EB  5B                pop bx
000013EC  58                pop ax
000013ED  50                push ax
000013EE  52                push dx
000013EF  53                push bx
000013F0  52                push dx
000013F1  52                push dx
000013F2  52                push dx
000013F3  52                push dx
000013F4  8BCC              mov cx,sp
000013F6  B80A00            mov ax,0xa
000013F9  CDFE              int 0xfe
000013FB  83C418            add sp,byte +0x18
000013FE  50                push ax
000013FF  53                push bx
00001400  56                push si
00001401  8BC3              mov ax,bx
00001403  33C9              xor cx,cx
00001405  268B1C            mov bx,[es:si]
00001408  268B5402          mov dx,[es:si+0x2]
0000140C  03D8              add bx,ax
0000140E  83C246            add dx,byte +0x46
00001411  52                push dx
00001412  53                push bx
00001413  E82500            call 0x143b
00001416  E83400            call 0x144d
00001419  33C9              xor cx,cx
0000141B  5B                pop bx
0000141C  4B                dec bx
0000141D  5A                pop dx
0000141E  53                push bx
0000141F  52                push dx
00001420  E82A00            call 0x144d
00001423  B90F00            mov cx,0xf
00001426  5A                pop dx
00001427  5B                pop bx
00001428  4A                dec dx
00001429  E82100            call 0x144d
0000142C  5E                pop si
0000142D  5B                pop bx
0000142E  58                pop ax
0000142F  83C60C            add si,byte +0xc
00001432  268B0C            mov cx,[es:si]
00001435  83F9FF            cmp cx,byte -0x1
00001438  75C4              jnz 0x13fe
0000143A  C3                ret
0000143B  50                push ax
0000143C  268B4408          mov ax,[es:si+0x8]
00001440  0BC0              or ax,ax
00001442  7507              jnz 0x144b
00001444  268B4404          mov ax,[es:si+0x4]
00001448  E87400            call 0x14bf
0000144B  58                pop ax
0000144C  C3                ret
0000144D  33C0              xor ax,ax
0000144F  48                dec ax
00001450  50                push ax
00001451  50                push ax
00001452  40                inc ax
00001453  8B3EA800          mov di,[0xa8]
00001457  26037D02          add di,[es:di+0x2]
0000145B  8CC0              mov ax,es
0000145D  E88800            call 0x14e8
00001460  50                push ax
00001461  57                push di
00001462  8B3EA800          mov di,[0xa8]
00001466  26033D            add di,[es:di]
00001469  8CC0              mov ax,es
0000146B  E87A00            call 0x14e8
0000146E  50                push ax
0000146F  57                push di
00001470  8B3EA800          mov di,[0xa8]
00001474  26037DFE          add di,[es:di-0x2]
00001478  8CC0              mov ax,es
0000147A  E86B00            call 0x14e8
0000147D  50                push ax
0000147E  57                push di
0000147F  83EC08            sub sp,byte +0x8
00001482  33C0              xor ax,ax
00001484  50                push ax
00001485  53                push bx
00001486  50                push ax
00001487  52                push dx
00001488  33D2              xor dx,dx
0000148A  A18A04            mov ax,[0x48a]
0000148D  268B7C08          mov di,[es:si+0x8]
00001491  0BFF              or di,di
00001493  7405              jz 0x149a
00001495  2D1400            sub ax,0x14
00001498  EB03              jmp short 0x149d
0000149A  2D2000            sub ax,0x20
0000149D  52                push dx
0000149E  50                push ax
0000149F  B80700            mov ax,0x7
000014A2  52                push dx
000014A3  50                push ax
000014A4  52                push dx
000014A5  51                push cx
000014A6  268B4408          mov ax,[es:si+0x8]
000014AA  52                push dx
000014AB  50                push ax
000014AC  52                push dx
000014AD  52                push dx
000014AE  52                push dx
000014AF  268B440A          mov ax,[es:si+0xa]
000014B3  50                push ax
000014B4  8BCC              mov cx,sp
000014B6  B80900            mov ax,0x9
000014B9  CDFE              int 0xfe
000014BB  83C438            add sp,byte +0x38
000014BE  C3                ret
000014BF  51                push cx
000014C0  56                push si
000014C1  57                push di
000014C2  1E                push ds
000014C3  FF068C04          inc word [0x48c]
000014C7  8B368C04          mov si,[0x48c]
000014CB  4E                dec si
000014CC  B103              mov cl,0x3
000014CE  D3E6              shl si,cl
000014D0  B9420A            mov cx,0xa42
000014D3  8ED9              mov ds,cx
000014D5  8D3E8D05          lea di,[0x58d]
000014D9  03FE              add di,si
000014DB  891D              mov [di],bx
000014DD  895502            mov [di+0x2],dx
000014E0  894504            mov [di+0x4],ax
000014E3  1F                pop ds
000014E4  5F                pop di
000014E5  5E                pop si
000014E6  59                pop cx
000014E7  C3                ret
000014E8  51                push cx
000014E9  50                push ax
000014EA  B10C              mov cl,0xc
000014EC  D3E8              shr ax,cl
000014EE  8AE8              mov ch,al
000014F0  58                pop ax
000014F1  B104              mov cl,0x4
000014F3  D3E0              shl ax,cl
000014F5  03F8              add di,ax
000014F7  7302              jnc 0x14fb
000014F9  FEC5              inc ch
000014FB  8AC5              mov al,ch
000014FD  32E4              xor ah,ah
000014FF  59                pop cx
00001500  C3                ret
00001501  8E069800          mov es,[0x98]
00001505  8B369A00          mov si,[0x9a]
00001509  33C0              xor ax,ax
0000150B  268904            mov [es:si],ax
0000150E  BA0100            mov dx,0x1
00001511  E81000            call 0x1524
00001514  0BC0              or ax,ax
00001516  750B              jnz 0x1523
00001518  8B0E8C04          mov cx,[0x48c]
0000151C  3BCA              cmp cx,dx
0000151E  74EE              jz 0x150e
00001520  42                inc dx
00001521  EBEE              jmp short 0x1511
00001523  C3                ret
00001524  52                push dx
00001525  1E                push ds
00001526  4A                dec dx
00001527  B103              mov cl,0x3
00001529  D3E2              shl dx,cl
0000152B  8D3E8D05          lea di,[0x58d]
0000152F  03FA              add di,dx
00001531  B9420A            mov cx,0xa42
00001534  8ED9              mov ds,cx
00001536  8B05              mov ax,[di]
00001538  8B5D02            mov bx,[di+0x2]
0000153B  8B5504            mov dx,[di+0x4]
0000153E  1F                pop ds
0000153F  268A4C01          mov cl,[es:si+0x1]
00001543  80F901            cmp cl,0x1
00001546  7411              jz 0x1559
00001548  80F902            cmp cl,0x2
0000154B  740C              jz 0x1559
0000154D  EB06              jmp short 0x1555
0000154F  5A                pop dx
00001550  8BC2              mov ax,dx
00001552  32E4              xor ah,ah
00001554  C3                ret
00001555  33C0              xor ax,ax
00001557  5A                pop dx
00001558  C3                ret
00001559  833E8C0401        cmp word [0x48c],byte +0x1
0000155E  741D              jz 0x157d
00001560  39069400          cmp [0x94],ax
00001564  7CEF              jl 0x1555
00001566  03C2              add ax,dx
00001568  39069400          cmp [0x94],ax
0000156C  7FE7              jg 0x1555
0000156E  391E9600          cmp [0x96],bx
00001572  7CE1              jl 0x1555
00001574  83C310            add bx,byte +0x10
00001577  391E9600          cmp [0x96],bx
0000157B  7FD8              jg 0x1555
0000157D  51                push cx
0000157E  33C9              xor cx,cx
00001580  26890C            mov [es:si],cx
00001583  59                pop cx
00001584  8BF8              mov di,ax
00001586  2BFA              sub di,dx
00001588  83EB10            sub bx,byte +0x10
0000158B  EBC2              jmp short 0x154f
0000158D  83C702            add di,byte +0x2
00001590  83C30A            add bx,byte +0xa
00001593  33D2              xor dx,dx
00001595  33C0              xor ax,ax
00001597  E80900            call 0x15a3
0000159A  4B                dec bx
0000159B  4F                dec di
0000159C  B80F00            mov ax,0xf
0000159F  E80100            call 0x15a3
000015A2  C3                ret
000015A3  51                push cx
000015A4  33C9              xor cx,cx
000015A6  51                push cx
000015A7  51                push cx
000015A8  52                push dx
000015A9  57                push di
000015AA  52                push dx
000015AB  53                push bx
000015AC  52                push dx
000015AD  50                push ax
000015AE  8BCC              mov cx,sp
000015B0  B80800            mov ax,0x8
000015B3  CDFE              int 0xfe
000015B5  83C410            add sp,byte +0x10
000015B8  59                pop cx
000015B9  C3                ret
000015BA  50                push ax
000015BB  53                push bx
000015BC  51                push cx
000015BD  33C0              xor ax,ax
000015BF  8B1E8404          mov bx,[0x484]
000015C3  50                push ax
000015C4  53                push bx
000015C5  50                push ax
000015C6  BB4600            mov bx,0x46
000015C9  53                push bx
000015CA  8B1E8604          mov bx,[0x486]
000015CE  50                push ax
000015CF  53                push bx
000015D0  BB6900            mov bx,0x69
000015D3  50                push ax
000015D4  53                push bx
000015D5  B81D00            mov ax,0x1d
000015D8  8BCC              mov cx,sp
000015DA  CDFE              int 0xfe
000015DC  83C410            add sp,byte +0x10
000015DF  59                pop cx
000015E0  5B                pop bx
000015E1  58                pop ax
000015E2  C3                ret
000015E3  50                push ax
000015E4  57                push di
000015E5  51                push cx
000015E6  33C0              xor ax,ax
000015E8  50                push ax
000015E9  B80100            mov ax,0x1
000015EC  50                push ax
000015ED  A1BE00            mov ax,[0xbe]
000015F0  052000            add ax,0x20
000015F3  8B3EBC00          mov di,[0xbc]
000015F7  E8EEFE            call 0x14e8
000015FA  50                push ax
000015FB  57                push di
000015FC  33C0              xor ax,ax
000015FE  50                push ax
000015FF  50                push ax
00001600  50                push ax
00001601  33FF              xor di,di
00001603  A18404            mov ax,[0x484]
00001606  50                push ax
00001607  57                push di
00001608  B84600            mov ax,0x46
0000160B  50                push ax
0000160C  A18604            mov ax,[0x486]
0000160F  57                push di
00001610  50                push ax
00001611  57                push di
00001612  B86900            mov ax,0x69
00001615  50                push ax
00001616  8BCC              mov cx,sp
00001618  B82400            mov ax,0x24
0000161B  CDFE              int 0xfe
0000161D  83C41C            add sp,byte +0x1c
00001620  59                pop cx
00001621  5F                pop di
00001622  58                pop ax
00001623  C3                ret
00001624  55                push bp
00001625  8BEC              mov bp,sp
00001627  8BE9              mov bp,cx
00001629  8B4600            mov ax,[bp+0x0]
0000162C  051E00            add ax,0x1e
0000162F  50                push ax
00001630  8B4604            mov ax,[bp+0x4]
00001633  50                push ax
00001634  8B5E08            mov bx,[bp+0x8]
00001637  8B460A            mov ax,[bp+0xa]
0000163A  E85BF8            call 0xe98
0000163D  50                push ax
0000163E  53                push bx
0000163F  9AEF11DB02        call 0x2db:0x11ef
00001644  83C408            add sp,byte +0x8
00001647  5D                pop bp
00001648  CB                retf
00001649  55                push bp
0000164A  8BEC              mov bp,sp
0000164C  C7066B062000      mov word [0x66b],0x20
00001652  8BE9              mov bp,cx
00001654  8B5E08            mov bx,[bp+0x8]
00001657  8B460A            mov ax,[bp+0xa]
0000165A  E83BF8            call 0xe98
0000165D  8B5E04            mov bx,[bp+0x4]
00001660  8B4606            mov ax,[bp+0x6]
00001663  E832F8            call 0xe98
00001666  8EC0              mov es,ax
00001668  8BF3              mov si,bx
0000166A  06                push es
0000166B  56                push si
0000166C  1E                push ds
0000166D  B82200            mov ax,0x22
00001670  50                push ax
00001671  33C9              xor cx,cx
00001673  51                push cx
00001674  06                push es
00001675  56                push si
00001676  9AEF11DB02        call 0x2db:0x11ef
0000167B  83C408            add sp,byte +0x8
0000167E  1F                pop ds
0000167F  5E                pop si
00001680  07                pop es
00001681  06                push es
00001682  56                push si
00001683  1E                push ds
00001684  33C9              xor cx,cx
00001686  51                push cx
00001687  51                push cx
00001688  FF369404          push word [0x494]
0000168C  56                push si
0000168D  06                push es
0000168E  9A00009304        call 0x493:0x0
00001693  83C40A            add sp,byte +0xa
00001696  1F                pop ds
00001697  5E                pop si
00001698  07                pop es
00001699  06                push es
0000169A  56                push si
0000169B  1E                push ds
0000169C  B82200            mov ax,0x22
0000169F  50                push ax
000016A0  8B4610            mov ax,[bp+0x10]
000016A3  A39C04            mov [0x49c],ax
000016A6  B90300            mov cx,0x3
000016A9  F7E1              mul cx
000016AB  40                inc ax
000016AC  50                push ax
000016AD  06                push es
000016AE  56                push si
000016AF  9AEF11DB02        call 0x2db:0x11ef
000016B4  83C408            add sp,byte +0x8
000016B7  1F                pop ds
000016B8  5E                pop si
000016B9  07                pop es
000016BA  33C0              xor ax,ax
000016BC  48                dec ax
000016BD  50                push ax
000016BE  B81C00            mov ax,0x1c
000016C1  50                push ax
000016C2  FF369404          push word [0x494]
000016C6  56                push si
000016C7  06                push es
000016C8  9A00009304        call 0x493:0x0
000016CD  83C40A            add sp,byte +0xa
000016D0  1E                push ds
000016D1  B82200            mov ax,0x22
000016D4  50                push ax
000016D5  8B4610            mov ax,[bp+0x10]
000016D8  B90300            mov cx,0x3
000016DB  F7E1              mul cx
000016DD  050300            add ax,0x3
000016E0  50                push ax
000016E1  8B5E08            mov bx,[bp+0x8]
000016E4  8B460A            mov ax,[bp+0xa]
000016E7  E8AEF7            call 0xe98
000016EA  A39804            mov [0x498],ax
000016ED  891E9A04          mov [0x49a],bx
000016F1  50                push ax
000016F2  53                push bx
000016F3  9AEF11DB02        call 0x2db:0x11ef
000016F8  83C408            add sp,byte +0x8
000016FB  B82C00            mov ax,0x2c
000016FE  50                push ax
000016FF  33C0              xor ax,ax
00001701  50                push ax
00001702  8B5E14            mov bx,[bp+0x14]
00001705  8B4616            mov ax,[bp+0x16]
00001708  E88DF7            call 0xe98
0000170B  C6068F0401        mov byte [0x48f],0x1
00001710  054416            add ax,0x1644
00001713  3B069404          cmp ax,[0x494]
00001717  720A              jc 0x1723
00001719  58                pop ax
0000171A  58                pop ax
0000171B  C6068F0400        mov byte [0x48f],0x0
00001720  EB2B              jmp short 0x174d
00001722  90                nop
00001723  2D4416            sub ax,0x1644
00001726  50                push ax
00001727  53                push bx
00001728  9AEF11DB02        call 0x2db:0x11ef
0000172D  83C408            add sp,byte +0x8
00001730  B82B00            mov ax,0x2b
00001733  50                push ax
00001734  33C0              xor ax,ax
00001736  50                push ax
00001737  8B5E18            mov bx,[bp+0x18]
0000173A  8B461A            mov ax,[bp+0x1a]
0000173D  E858F7            call 0xe98
00001740  33DB              xor bx,bx
00001742  40                inc ax
00001743  50                push ax
00001744  53                push bx
00001745  9AEF11DB02        call 0x2db:0x11ef
0000174A  83C408            add sp,byte +0x8
0000174D  1F                pop ds
0000174E  8B460C            mov ax,[bp+0xc]
00001751  3D0100            cmp ax,0x1
00001754  7506              jnz 0x175c
00001756  8B5E10            mov bx,[bp+0x10]
00001759  E84600            call 0x17a2
0000175C  833E920405        cmp word [0x492],byte +0x5
00001761  742E              jz 0x1791
00001763  1E                push ds
00001764  8E06F200          mov es,[0xf2]
00001768  8B3EF400          mov di,[0xf4]
0000176C  8B36750E          mov si,[0xe75]
00001770  8E1E770E          mov ds,[0xe77]
00001774  B91000            mov cx,0x10
00001777  F3A5              rep movsw
00001779  1F                pop ds
0000177A  1E                push ds
0000177B  8E067701          mov es,[0x177]
0000177F  8B3E7901          mov di,[0x179]
00001783  8B36790E          mov si,[0xe79]
00001787  8E1E7B0E          mov ds,[0xe7b]
0000178B  B91000            mov cx,0x10
0000178E  F3A4              rep movsb
00001790  1F                pop ds
00001791  BB0300            mov bx,0x3
00001794  B80B00            mov ax,0xb
00001797  B93C01            mov cx,0x13c
0000179A  BAC400            mov dx,0xc4
0000179D  E8A501            call 0x1945
000017A0  5D                pop bp
000017A1  CB                retf
000017A2  1E                push ds
000017A3  B8420A            mov ax,0xa42
000017A6  8ED8              mov ds,ax
000017A8  8D360D06          lea si,[0x60d]
000017AC  03F3              add si,bx
000017AE  32E4              xor ah,ah
000017B0  8A04              mov al,[si]
000017B2  32FF              xor bh,bh
000017B4  8A5C09            mov bl,[si+0x9]
000017B7  1F                pop ds
000017B8  50                push ax
000017B9  81EB2001          sub bx,0x120
000017BD  53                push bx
000017BE  FF369404          push word [0x494]
000017C2  FF369A04          push word [0x49a]
000017C6  FF369804          push word [0x498]
000017CA  9A00009304        call 0x493:0x0
000017CF  83C40A            add sp,byte +0xa
000017D2  C3                ret
000017D3  55                push bp
000017D4  8BEC              mov bp,sp
000017D6  8BE9              mov bp,cx
000017D8  C7066B061F00      mov word [0x66b],0x1f
000017DE  8B5E04            mov bx,[bp+0x4]
000017E1  8B4606            mov ax,[bp+0x6]
000017E4  E8B1F6            call 0xe98
000017E7  1E                push ds
000017E8  53                push bx
000017E9  50                push ax
000017EA  53                push bx
000017EB  50                push ax
000017EC  B92300            mov cx,0x23
000017EF  51                push cx
000017F0  33C9              xor cx,cx
000017F2  51                push cx
000017F3  50                push ax
000017F4  53                push bx
000017F5  9AEF11DB02        call 0x2db:0x11ef
000017FA  83C408            add sp,byte +0x8
000017FD  58                pop ax
000017FE  5B                pop bx
000017FF  50                push ax
00001800  53                push bx
00001801  51                push cx
00001802  031E6D06          add bx,[0x66d]
00001806  83EB22            sub bx,byte +0x22
00001809  50                push ax
0000180A  53                push bx
0000180B  E89A01            call 0x19a8
0000180E  5B                pop bx
0000180F  58                pop ax
00001810  83C311            add bx,byte +0x11
00001813  50                push ax
00001814  53                push bx
00001815  E8AC01            call 0x19c4
00001818  5B                pop bx
00001819  58                pop ax
0000181A  E8EB01            call 0x1a08
0000181D  59                pop cx
0000181E  5B                pop bx
0000181F  58                pop ax
00001820  833E920405        cmp word [0x492],byte +0x5
00001825  750D              jnz 0x1834
00001827  83C302            add bx,byte +0x2
0000182A  51                push cx
0000182B  B90400            mov cx,0x4
0000182E  9A2418DB02        call 0x2db:0x1824
00001833  59                pop cx
00001834  58                pop ax
00001835  5B                pop bx
00001836  1F                pop ds
00001837  50                push ax
00001838  53                push bx
00001839  1E                push ds
0000183A  33C9              xor cx,cx
0000183C  51                push cx
0000183D  51                push cx
0000183E  FF369404          push word [0x494]
00001842  53                push bx
00001843  50                push ax
00001844  9A00009304        call 0x493:0x0
00001849  83C40A            add sp,byte +0xa
0000184C  1F                pop ds
0000184D  5B                pop bx
0000184E  58                pop ax
0000184F  50                push ax
00001850  53                push bx
00001851  1E                push ds
00001852  B92300            mov cx,0x23
00001855  51                push cx
00001856  8B4E08            mov cx,[bp+0x8]
00001859  41                inc cx
0000185A  51                push cx
0000185B  50                push ax
0000185C  53                push bx
0000185D  9AEF11DB02        call 0x2db:0x11ef
00001862  83C408            add sp,byte +0x8
00001865  1F                pop ds
00001866  5B                pop bx
00001867  58                pop ax
00001868  1E                push ds
00001869  B9E6FF            mov cx,0xffe6
0000186C  51                push cx
0000186D  B9AEFF            mov cx,0xffae
00001870  51                push cx
00001871  FF369404          push word [0x494]
00001875  53                push bx
00001876  50                push ax
00001877  9A00009304        call 0x493:0x0
0000187C  83C40A            add sp,byte +0xa
0000187F  BB0300            mov bx,0x3
00001882  B80B00            mov ax,0xb
00001885  B90401            mov cx,0x104
00001888  BAC400            mov dx,0xc4
0000188B  1F                pop ds
0000188C  50                push ax
0000188D  58                pop ax
0000188E  5D                pop bp
0000188F  CB                retf
00001890  55                push bp
00001891  8BEC              mov bp,sp
00001893  8BE9              mov bp,cx
00001895  8B5E08            mov bx,[bp+0x8]
00001898  8B460A            mov ax,[bp+0xa]
0000189B  E8FAF5            call 0xe98
0000189E  8B4E00            mov cx,[bp+0x0]
000018A1  890E6B06          mov [0x66b],cx
000018A5  1E                push ds
000018A6  50                push ax
000018A7  53                push bx
000018A8  50                push ax
000018A9  53                push bx
000018AA  50                push ax
000018AB  53                push bx
000018AC  50                push ax
000018AD  53                push bx
000018AE  51                push cx
000018AF  33C9              xor cx,cx
000018B1  51                push cx
000018B2  50                push ax
000018B3  53                push bx
000018B4  9AEF11DB02        call 0x2db:0x11ef
000018B9  83C408            add sp,byte +0x8
000018BC  5B                pop bx
000018BD  58                pop ax
000018BE  5B                pop bx
000018BF  58                pop ax
000018C0  83C320            add bx,byte +0x20
000018C3  5B                pop bx
000018C4  58                pop ax
000018C5  83C342            add bx,byte +0x42
000018C8  51                push cx
000018C9  B90300            mov cx,0x3
000018CC  9A2418DB02        call 0x2db:0x1824
000018D1  59                pop cx
000018D2  5B                pop bx
000018D3  58                pop ax
000018D4  1F                pop ds
000018D5  33C9              xor cx,cx
000018D7  51                push cx
000018D8  51                push cx
000018D9  FF369404          push word [0x494]
000018DD  83C340            add bx,byte +0x40
000018E0  53                push bx
000018E1  50                push ax
000018E2  9A00009304        call 0x493:0x0
000018E7  83C40A            add sp,byte +0xa
000018EA  8B5E04            mov bx,[bp+0x4]
000018ED  8B4606            mov ax,[bp+0x6]
000018F0  E8A5F5            call 0xe98
000018F3  0BC0              or ax,ax
000018F5  7424              jz 0x191b
000018F7  8B4E00            mov cx,[bp+0x0]
000018FA  51                push cx
000018FB  B90100            mov cx,0x1
000018FE  51                push cx
000018FF  50                push ax
00001900  53                push bx
00001901  9AEF11DB02        call 0x2db:0x11ef
00001906  83C408            add sp,byte +0x8
00001909  50                push ax
0000190A  52                push dx
0000190B  8B5E04            mov bx,[bp+0x4]
0000190E  8B4606            mov ax,[bp+0x6]
00001911  E884F5            call 0xe98
00001914  E87200            call 0x1989
00001917  5A                pop dx
00001918  58                pop ax
00001919  EB02              jmp short 0x191d
0000191B  33C0              xor ax,ax
0000191D  1E                push ds
0000191E  50                push ax
0000191F  52                push dx
00001920  8B4600            mov ax,[bp+0x0]
00001923  3D1D00            cmp ax,0x1d
00001926  7F0F              jg 0x1937
00001928  BB0300            mov bx,0x3
0000192B  B80B00            mov ax,0xb
0000192E  B90401            mov cx,0x104
00001931  BAAF00            mov dx,0xaf
00001934  E80E00            call 0x1945
00001937  5A                pop dx
00001938  58                pop ax
00001939  1F                pop ds
0000193A  50                push ax
0000193B  58                pop ax
0000193C  33D2              xor dx,dx
0000193E  9A34064207        call 0x742:0x634
00001943  5D                pop bp
00001944  CB                retf
00001945  1E                push ds
00001946  8E1E9404          mov ds,[0x494]
0000194A  51                push cx
0000194B  52                push dx
0000194C  50                push ax
0000194D  B94001            mov cx,0x140
00001950  F7E1              mul cx
00001952  03C3              add ax,bx
00001954  8BF8              mov di,ax
00001956  58                pop ax
00001957  5A                pop dx
00001958  59                pop cx
00001959  2BCB              sub cx,bx
0000195B  41                inc cx
0000195C  2BD0              sub dx,ax
0000195E  42                inc dx
0000195F  51                push cx
00001960  33C0              xor ax,ax
00001962  8825              mov [di],ah
00001964  47                inc di
00001965  E2FB              loop 0x1962
00001967  4F                dec di
00001968  52                push dx
00001969  8825              mov [di],ah
0000196B  81C74001          add di,0x140
0000196F  4A                dec dx
00001970  75F7              jnz 0x1969
00001972  81EF4001          sub di,0x140
00001976  5A                pop dx
00001977  59                pop cx
00001978  8825              mov [di],ah
0000197A  4F                dec di
0000197B  E2FB              loop 0x1978
0000197D  47                inc di
0000197E  8825              mov [di],ah
00001980  81EF4001          sub di,0x140
00001984  4A                dec dx
00001985  75F7              jnz 0x197e
00001987  1F                pop ds
00001988  C3                ret
00001989  031E6D06          add bx,[0x66d]
0000198D  83EB33            sub bx,byte +0x33
00001990  50                push ax
00001991  53                push bx
00001992  E81300            call 0x19a8
00001995  5B                pop bx
00001996  58                pop ax
00001997  83C311            add bx,byte +0x11
0000199A  50                push ax
0000199B  53                push bx
0000199C  E82500            call 0x19c4
0000199F  5B                pop bx
000019A0  58                pop ax
000019A1  83C311            add bx,byte +0x11
000019A4  E86100            call 0x1a08
000019A7  C3                ret
000019A8  1E                push ds
000019A9  56                push si
000019AA  57                push di
000019AB  06                push es
000019AC  51                push cx
000019AD  8E066B01          mov es,[0x16b]
000019B1  8B3E6D01          mov di,[0x16d]
000019B5  8BF3              mov si,bx
000019B7  8ED8              mov ds,ax
000019B9  B91000            mov cx,0x10
000019BC  F3A4              rep movsb
000019BE  59                pop cx
000019BF  07                pop es
000019C0  5F                pop di
000019C1  5E                pop si
000019C2  1F                pop ds
000019C3  C3                ret
000019C4  1E                push ds
000019C5  56                push si
000019C6  57                push di
000019C7  06                push es
000019C8  51                push cx
000019C9  B91000            mov cx,0x10
000019CC  8EC0              mov es,ax
000019CE  8BF3              mov si,bx
000019D0  8B3E7101          mov di,[0x171]
000019D4  32E4              xor ah,ah
000019D6  268A04            mov al,[es:si]
000019D9  D1E0              shl ax,1
000019DB  06                push es
000019DC  56                push si
000019DD  8E067301          mov es,[0x173]
000019E1  8B367501          mov si,[0x175]
000019E5  03F0              add si,ax
000019E7  268B04            mov ax,[es:si]
000019EA  5E                pop si
000019EB  07                pop es
000019EC  46                inc si
000019ED  1E                push ds
000019EE  8E1E6F01          mov ds,[0x16f]
000019F2  8905              mov [di],ax
000019F4  83C740            add di,byte +0x40
000019F7  8905              mov [di],ax
000019F9  83EF40            sub di,byte +0x40
000019FC  83C702            add di,byte +0x2
000019FF  1F                pop ds
00001A00  E2D2              loop 0x19d4
00001A02  59                pop cx
00001A03  07                pop es
00001A04  5F                pop di
00001A05  5E                pop si
00001A06  1F                pop ds
00001A07  C3                ret
00001A08  1E                push ds
00001A09  56                push si
00001A0A  57                push di
00001A0B  06                push es
00001A0C  51                push cx
00001A0D  B91000            mov cx,0x10
00001A10  8EC0              mov es,ax
00001A12  8BF3              mov si,bx
00001A14  8B3E7101          mov di,[0x171]
00001A18  83C720            add di,byte +0x20
00001A1B  32E4              xor ah,ah
00001A1D  268A04            mov al,[es:si]
00001A20  D1E0              shl ax,1
00001A22  06                push es
00001A23  56                push si
00001A24  8E067301          mov es,[0x173]
00001A28  8B367501          mov si,[0x175]
00001A2C  03F0              add si,ax
00001A2E  268B04            mov ax,[es:si]
00001A31  5E                pop si
00001A32  07                pop es
00001A33  46                inc si
00001A34  1E                push ds
00001A35  8E1E6F01          mov ds,[0x16f]
00001A39  8905              mov [di],ax
00001A3B  83C702            add di,byte +0x2
00001A3E  1F                pop ds
00001A3F  E2DA              loop 0x1a1b
00001A41  59                pop cx
00001A42  07                pop es
00001A43  5F                pop di
00001A44  5E                pop si
00001A45  1F                pop ds
00001A46  C3                ret
00001A47  55                push bp
00001A48  8BEC              mov bp,sp
00001A4A  8B1E9C04          mov bx,[0x49c]
00001A4E  53                push bx
00001A4F  1E                push ds
00001A50  E84FFD            call 0x17a2
00001A53  1F                pop ds
00001A54  5B                pop bx
00001A55  1E                push ds
00001A56  B8420A            mov ax,0xa42
00001A59  8ED8              mov ds,ax
00001A5B  8D360D06          lea si,[0x60d]
00001A5F  03F3              add si,bx
00001A61  32E4              xor ah,ah
00001A63  8A04              mov al,[si]
00001A65  32FF              xor bh,bh
00001A67  8A5C09            mov bl,[si+0x9]
00001A6A  1F                pop ds
00001A6B  891E9E00          mov [0x9e],bx
00001A6F  83C320            add bx,byte +0x20
00001A72  891EA000          mov [0xa0],bx
00001A76  A3A400            mov [0xa4],ax
00001A79  052000            add ax,0x20
00001A7C  A3A200            mov [0xa2],ax
00001A7F  9A750D9304        call 0x493:0xd75
00001A84  5D                pop bp
00001A85  CB                retf
00001A86  55                push bp
00001A87  8BEC              mov bp,sp
00001A89  06                push es
00001A8A  1E                push ds
00001A8B  56                push si
00001A8C  57                push di
00001A8D  1E                push ds
00001A8E  50                push ax
00001A8F  53                push bx
00001A90  51                push cx
00001A91  52                push dx
00001A92  B8420A            mov ax,0xa42
00001A95  8ED8              mov ds,ax
00001A97  803EA60401        cmp byte [0x4a6],0x1
00001A9C  7509              jnz 0x1aa7
00001A9E  E842FB            call 0x15e3
00001AA1  B10A              mov cl,0xa
00001AA3  1E                push ds
00001AA4  EB4C              jmp short 0x1af2
00001AA6  90                nop
00001AA7  833E5F0621        cmp word [0x65f],byte +0x21
00001AAC  7505              jnz 0x1ab3
00001AAE  C606A50401        mov byte [0x4a5],0x1
00001AB3  833E5F061F        cmp word [0x65f],byte +0x1f
00001AB8  7505              jnz 0x1abf
00001ABA  C606A50401        mov byte [0x4a5],0x1
00001ABF  803E3F2801        cmp byte [0x283f],0x1
00001AC4  7505              jnz 0x1acb
00001AC6  C606A50401        mov byte [0x4a5],0x1
00001ACB  A1A304            mov ax,[0x4a3]
00001ACE  0AE4              or ah,ah
00001AD0  7405              jz 0x1ad7
00001AD2  C606A20401        mov byte [0x4a2],0x1
00001AD7  803E270601        cmp byte [0x627],0x1
00001ADC  7505              jnz 0x1ae3
00001ADE  C6068E0400        mov byte [0x48e],0x0
00001AE3  8AC8              mov cl,al
00001AE5  1E                push ds
00001AE6  51                push cx
00001AE7  E8CA00            call 0x1bb4
00001AEA  59                pop cx
00001AEB  803EA50401        cmp byte [0x4a5],0x1
00001AF0  7519              jnz 0x1b0b
00001AF2  C6068E0400        mov byte [0x48e],0x0
00001AF7  E855F8            call 0x134f
00001AFA  E8BDFA            call 0x15ba
00001AFD  E801FA            call 0x1501
00001B00  E8E0FA            call 0x15e3
00001B03  C606A50400        mov byte [0x4a5],0x0
00001B08  EB1E              jmp short 0x1b28
00001B0A  90                nop
00001B0B  C6068E0401        mov byte [0x48e],0x1
00001B10  E83CF8            call 0x134f
00001B13  C6068E0400        mov byte [0x48e],0x0
00001B18  8E069800          mov es,[0x98]
00001B1C  8B369A00          mov si,[0x9a]
00001B20  268A4401          mov al,[es:si+0x1]
00001B24  0AC0              or al,al
00001B26  74F8              jz 0x1b20
00001B28  1F                pop ds
00001B29  C606A20400        mov byte [0x4a2],0x0
00001B2E  EB0C              jmp short 0x1b3c
00001B30  90                nop
00001B31  BA6400            mov dx,0x64
00001B34  B9FFFF            mov cx,0xffff
00001B37  E2FE              loop 0x1b37
00001B39  4A                dec dx
00001B3A  75F8              jnz 0x1b34
00001B3C  5A                pop dx
00001B3D  59                pop cx
00001B3E  5B                pop bx
00001B3F  58                pop ax
00001B40  1F                pop ds
00001B41  5F                pop di
00001B42  5E                pop si
00001B43  1F                pop ds
00001B44  07                pop es
00001B45  5D                pop bp
00001B46  CB                retf
00001B47  55                push bp
00001B48  8BEC              mov bp,sp
00001B4A  1E                push ds
00001B4B  06                push es
00001B4C  56                push si
00001B4D  57                push di
00001B4E  50                push ax
00001B4F  E86200            call 0x1bb4
00001B52  58                pop ax
00001B53  C6068E0401        mov byte [0x48e],0x1
00001B58  A3A304            mov [0x4a3],ax
00001B5B  0AE4              or ah,ah
00001B5D  7405              jz 0x1b64
00001B5F  C606A20401        mov byte [0x4a2],0x1
00001B64  32E4              xor ah,ah
00001B66  8AC8              mov cl,al
00001B68  833E5F0621        cmp word [0x65f],byte +0x21
00001B6D  7411              jz 0x1b80
00001B6F  833E5F061F        cmp word [0x65f],byte +0x1f
00001B74  740A              jz 0x1b80
00001B76  803E3F2801        cmp byte [0x283f],0x1
00001B7B  7403              jz 0x1b80
00001B7D  EB1A              jmp short 0x1b99
00001B7F  90                nop
00001B80  C6068E0400        mov byte [0x48e],0x0
00001B85  C606A50401        mov byte [0x4a5],0x1
00001B8A  E8C2F7            call 0x134f
00001B8D  E82AFA            call 0x15ba
00001B90  E86EF9            call 0x1501
00001B93  E84DFA            call 0x15e3
00001B96  EB11              jmp short 0x1ba9
00001B98  90                nop
00001B99  C606A50400        mov byte [0x4a5],0x0
00001B9E  E8AEF7            call 0x134f
00001BA1  E85DF9            call 0x1501
00001BA4  C6068E0400        mov byte [0x48e],0x0
00001BA9  C606A20400        mov byte [0x4a2],0x0
00001BAE  5F                pop di
00001BAF  5E                pop si
00001BB0  07                pop es
00001BB1  1F                pop ds
00001BB2  5D                pop bp
00001BB3  CB                retf
00001BB4  8E06DC00          mov es,[0xdc]
00001BB8  8B36DE00          mov si,[0xde]
00001BBC  83C61E            add si,byte +0x1e
00001BBF  26C704FFFF        mov word [es:si],0xffff
00001BC4  8E06E000          mov es,[0xe0]
00001BC8  8B36E200          mov si,[0xe2]
00001BCC  83C60F            add si,byte +0xf
00001BCF  26C604FF          mov byte [es:si],0xff
00001BD3  26C64410FF        mov byte [es:si+0x10],0xff
00001BD8  8E067701          mov es,[0x177]
00001BDC  8B367901          mov si,[0x179]
00001BE0  83C60F            add si,byte +0xf
00001BE3  26C60403          mov byte [es:si],0x3
00001BE7  833E920405        cmp word [0x492],byte +0x5
00001BEC  750E              jnz 0x1bfc
00001BEE  B81010            mov ax,0x1010
00001BF1  BB0F00            mov bx,0xf
00001BF4  B53F              mov ch,0x3f
00001BF6  8ACD              mov cl,ch
00001BF8  8AF1              mov dh,cl
00001BFA  CD10              int 0x10
00001BFC  C3                ret
00001BFD  56                push si
00001BFE  50                push ax
00001BFF  B8420A            mov ax,0xa42
00001C02  8ED8              mov ds,ax
00001C04  A19204            mov ax,[0x492]
00001C07  3D0500            cmp ax,0x5
00001C0A  750A              jnz 0x1c16
00001C0C  B800A0            mov ax,0xa000
00001C0F  8ED8              mov ds,ax
00001C11  881C              mov [si],bl
00001C13  58                pop ax
00001C14  5E                pop si
00001C15  C3                ret
00001C16  3D0200            cmp ax,0x2
00001C19  7403              jz 0x1c1e
00001C1B  E9A100            jmp 0x1cbf
00001C1E  53                push bx
00001C1F  51                push cx
00001C20  52                push dx
00001C21  57                push di
00001C22  06                push es
00001C23  55                push bp
00001C24  8BEC              mov bp,sp
00001C26  81EC1201          sub sp,0x112
00001C2A  8BC6              mov ax,si
00001C2C  E87900            call 0x1ca8
00001C2F  53                push bx
00001C30  B94001            mov cx,0x140
00001C33  33D2              xor dx,dx
00001C35  F7F9              idiv cx
00001C37  89169E04          mov [0x49e],dx
00001C3B  A3A004            mov [0x4a0],ax
00001C3E  8BF3              mov si,bx
00001C40  BACE03            mov dx,0x3ce
00001C43  B80502            mov ax,0x205
00001C46  EF                out dx,ax
00001C47  B80300            mov ax,0x3
00001C4A  EF                out dx,ax
00001C4B  33DB              xor bx,bx
00001C4D  A1A004            mov ax,[0x4a0]
00001C50  B95000            mov cx,0x50
00001C53  F7E1              mul cx
00001C55  03D8              add bx,ax
00001C57  A19E04            mov ax,[0x49e]
00001C5A  D1E0              shl ax,1
00001C5C  B103              mov cl,0x3
00001C5E  D3E8              shr ax,cl
00001C60  03D8              add bx,ax
00001C62  A19E04            mov ax,[0x49e]
00001C65  D1E0              shl ax,1
00001C67  250700            and ax,0x7
00001C6A  8AC8              mov cl,al
00001C6C  B480              mov ah,0x80
00001C6E  D2EC              shr ah,cl
00001C70  BA00A0            mov dx,0xa000
00001C73  8EC2              mov es,dx
00001C75  BACE03            mov dx,0x3ce
00001C78  5E                pop si
00001C79  8BFE              mov di,si
00001C7B  83E70F            and di,byte +0xf
00001C7E  D1E7              shl di,1
00001C80  268A07            mov al,[es:bx]
00001C83  B008              mov al,0x8
00001C85  EF                out dx,ax
00001C86  8A43C0            mov al,[bp+di-0x40]
00001C89  D0EC              shr ah,1
00001C8B  268807            mov [es:bx],al
00001C8E  268A07            mov al,[es:bx]
00001C91  B008              mov al,0x8
00001C93  EF                out dx,ax
00001C94  8A43C1            mov al,[bp+di-0x3f]
00001C97  268807            mov [es:bx],al
00001C9A  FB                sti
00001C9B  81C41201          add sp,0x112
00001C9F  5D                pop bp
00001CA0  07                pop es
00001CA1  5F                pop di
00001CA2  5A                pop dx
00001CA3  59                pop cx
00001CA4  5B                pop bx
00001CA5  58                pop ax
00001CA6  5E                pop si
00001CA7  C3                ret
00001CA8  1E                push ds
00001CA9  16                push ss
00001CAA  07                pop es
00001CAB  8B36DE00          mov si,[0xde]
00001CAF  8E1EDC00          mov ds,[0xdc]
00001CB3  B91000            mov cx,0x10
00001CB6  8BFD              mov di,bp
00001CB8  83EF40            sub di,byte +0x40
00001CBB  F3A5              rep movsw
00001CBD  1F                pop ds
00001CBE  C3                ret
00001CBF  3D0100            cmp ax,0x1
00001CC2  7403              jz 0x1cc7
00001CC4  E9A800            jmp 0x1d6f
00001CC7  53                push bx
00001CC8  51                push cx
00001CC9  52                push dx
00001CCA  57                push di
00001CCB  06                push es
00001CCC  32FF              xor bh,bh
00001CCE  8BC6              mov ax,si
00001CD0  B94001            mov cx,0x140
00001CD3  33D2              xor dx,dx
00001CD5  F7F9              idiv cx
00001CD7  89169E04          mov [0x49e],dx
00001CDB  A3A004            mov [0x4a0],ax
00001CDE  8BD3              mov dx,bx
00001CE0  1E                push ds
00001CE1  B8420A            mov ax,0xa42
00001CE4  8ED8              mov ds,ax
00001CE6  8D1E3B05          lea bx,[0x53b]
00001CEA  B8420A            mov ax,0xa42
00001CED  8EC0              mov es,ax
00001CEF  8D365B05          lea si,[0x55b]
00001CF3  03F2              add si,dx
00001CF5  32E4              xor ah,ah
00001CF7  268A04            mov al,[es:si]
00001CFA  D1E0              shl ax,1
00001CFC  1E                push ds
00001CFD  BA420A            mov dx,0xa42
00001D00  8EDA              mov ds,dx
00001D02  8B16A004          mov dx,[0x4a0]
00001D06  1F                pop ds
00001D07  83E201            and dx,byte +0x1
00001D0A  83FA01            cmp dx,byte +0x1
00001D0D  7503              jnz 0x1d12
00001D0F  83C310            add bx,byte +0x10
00001D12  03D8              add bx,ax
00001D14  8B17              mov dx,[bx]
00001D16  1F                pop ds
00001D17  52                push dx
00001D18  E83100            call 0x1d4c
00001D1B  5A                pop dx
00001D1C  8B0E9E04          mov cx,[0x49e]
00001D20  D1E1              shl cx,1
00001D22  83E107            and cx,byte +0x7
00001D25  B43F              mov ah,0x3f
00001D27  D2CC              ror ah,cl
00001D29  D0E2              shl dl,1
00001D2B  02F2              add dh,dl
00001D2D  B506              mov ch,0x6
00001D2F  2AE9              sub ch,cl
00001D31  8ACD              mov cl,ch
00001D33  D2E6              shl dh,cl
00001D35  BB00B8            mov bx,0xb800
00001D38  8EC3              mov es,bx
00001D3A  268A04            mov al,[es:si]
00001D3D  22C4              and al,ah
00001D3F  02C6              add al,dh
00001D41  268804            mov [es:si],al
00001D44  07                pop es
00001D45  5F                pop di
00001D46  5A                pop dx
00001D47  59                pop cx
00001D48  5B                pop bx
00001D49  58                pop ax
00001D4A  5E                pop si
00001D4B  C3                ret
00001D4C  A1A004            mov ax,[0x4a0]
00001D4F  250100            and ax,0x1
00001D52  B90020            mov cx,0x2000
00001D55  F7E1              mul cx
00001D57  8BF0              mov si,ax
00001D59  A1A004            mov ax,[0x4a0]
00001D5C  D1E8              shr ax,1
00001D5E  B95000            mov cx,0x50
00001D61  F7E1              mul cx
00001D63  03F0              add si,ax
00001D65  A19E04            mov ax,[0x49e]
00001D68  D1E8              shr ax,1
00001D6A  D1E8              shr ax,1
00001D6C  03F0              add si,ax
00001D6E  C3                ret
00001D6F  3D0300            cmp ax,0x3
00001D72  7403              jz 0x1d77
00001D74  E9C400            jmp 0x1e3b
00001D77  53                push bx
00001D78  51                push cx
00001D79  52                push dx
00001D7A  57                push di
00001D7B  06                push es
00001D7C  32FF              xor bh,bh
00001D7E  8BC6              mov ax,si
00001D80  B94001            mov cx,0x140
00001D83  33D2              xor dx,dx
00001D85  F7F9              idiv cx
00001D87  89169E04          mov [0x49e],dx
00001D8B  A3A004            mov [0x4a0],ax
00001D8E  8BD3              mov dx,bx
00001D90  1E                push ds
00001D91  B8420A            mov ax,0xa42
00001D94  8ED8              mov ds,ax
00001D96  8D1E3B05          lea bx,[0x53b]
00001D9A  B8420A            mov ax,0xa42
00001D9D  8EC0              mov es,ax
00001D9F  8D365B05          lea si,[0x55b]
00001DA3  03F2              add si,dx
00001DA5  32E4              xor ah,ah
00001DA7  268A04            mov al,[es:si]
00001DAA  D1E0              shl ax,1
00001DAC  1E                push ds
00001DAD  BA420A            mov dx,0xa42
00001DB0  8EDA              mov ds,dx
00001DB2  8B16A004          mov dx,[0x4a0]
00001DB6  1F                pop ds
00001DB7  83E201            and dx,byte +0x1
00001DBA  83FA01            cmp dx,byte +0x1
00001DBD  7503              jnz 0x1dc2
00001DBF  83C310            add bx,byte +0x10
00001DC2  03D8              add bx,ax
00001DC4  8B17              mov dx,[bx]
00001DC6  1F                pop ds
00001DC7  52                push dx
00001DC8  E84B00            call 0x1e16
00001DCB  5A                pop dx
00001DCC  8B0E9E04          mov cx,[0x49e]
00001DD0  D1E1              shl cx,1
00001DD2  83E107            and cx,byte +0x7
00001DD5  B43F              mov ah,0x3f
00001DD7  D2CC              ror ah,cl
00001DD9  D0E2              shl dl,1
00001DDB  02F2              add dh,dl
00001DDD  B506              mov ch,0x6
00001DDF  2AE9              sub ch,cl
00001DE1  8ACD              mov cl,ch
00001DE3  D2E6              shl dh,cl
00001DE5  BB00B0            mov bx,0xb000
00001DE8  8EC3              mov es,bx
00001DEA  268A04            mov al,[es:si]
00001DED  22C4              and al,ah
00001DEF  02C6              add al,dh
00001DF1  268804            mov [es:si],al
00001DF4  81FE0060          cmp si,0x6000
00001DF8  7D07              jnl 0x1e01
00001DFA  81C60020          add si,0x2000
00001DFE  EB0B              jmp short 0x1e0b
00001E00  90                nop
00001E01  81EE0060          sub si,0x6000
00001E05  83C650            add si,byte +0x50
00001E08  EB01              jmp short 0x1e0b
00001E0A  90                nop
00001E0B  268804            mov [es:si],al
00001E0E  07                pop es
00001E0F  5F                pop di
00001E10  5A                pop dx
00001E11  59                pop cx
00001E12  5B                pop bx
00001E13  58                pop ax
00001E14  5E                pop si
00001E15  C3                ret
00001E16  A1A004            mov ax,[0x4a0]
00001E19  D1E0              shl ax,1
00001E1B  250300            and ax,0x3
00001E1E  B90020            mov cx,0x2000
00001E21  F7E1              mul cx
00001E23  8BF0              mov si,ax
00001E25  A1A004            mov ax,[0x4a0]
00001E28  D1E8              shr ax,1
00001E2A  B95000            mov cx,0x50
00001E2D  F7E1              mul cx
00001E2F  03F0              add si,ax
00001E31  A19E04            mov ax,[0x49e]
00001E34  D1E8              shr ax,1
00001E36  D1E8              shr ax,1
00001E38  03F0              add si,ax
00001E3A  C3                ret
00001E3B  3D0400            cmp ax,0x4
00001E3E  7403              jz 0x1e43
00001E40  E9B300            jmp 0x1ef6
00001E43  53                push bx
00001E44  51                push cx
00001E45  52                push dx
00001E46  57                push di
00001E47  06                push es
00001E48  55                push bp
00001E49  8BEC              mov bp,sp
00001E4B  81EC1201          sub sp,0x112
00001E4F  8BC6              mov ax,si
00001E51  B94001            mov cx,0x140
00001E54  33D2              xor dx,dx
00001E56  F7F9              idiv cx
00001E58  89169E04          mov [0x49e],dx
00001E5C  A3A004            mov [0x4a0],ax
00001E5F  E85200            call 0x1eb4
00001E62  B800B8            mov ax,0xb800
00001E65  8EC0              mov es,ax
00001E67  32FF              xor bh,bh
00001E69  8BD3              mov dx,bx
00001E6B  52                push dx
00001E6C  E85E00            call 0x1ecd
00001E6F  5A                pop dx
00001E70  8BF2              mov si,dx
00001E72  A1A004            mov ax,[0x4a0]
00001E75  250100            and ax,0x1
00001E78  0BC0              or ax,ax
00001E7A  7403              jz 0x1e7f
00001E7C  83C610            add si,byte +0x10
00001E7F  8A62C0            mov ah,[bp+si-0x40]
00001E82  268A07            mov al,[es:bx]
00001E85  8B0E9E04          mov cx,[0x49e]
00001E89  83E101            and cx,byte +0x1
00001E8C  0BC9              or cx,cx
00001E8E  750D              jnz 0x1e9d
00001E90  240F              and al,0xf
00001E92  80E4F0            and ah,0xf0
00001E95  02C4              add al,ah
00001E97  268807            mov [es:bx],al
00001E9A  EB0B              jmp short 0x1ea7
00001E9C  90                nop
00001E9D  24F0              and al,0xf0
00001E9F  80E40F            and ah,0xf
00001EA2  02C4              add al,ah
00001EA4  268807            mov [es:bx],al
00001EA7  81C41201          add sp,0x112
00001EAB  5D                pop bp
00001EAC  07                pop es
00001EAD  5F                pop di
00001EAE  5A                pop dx
00001EAF  59                pop cx
00001EB0  5B                pop bx
00001EB1  58                pop ax
00001EB2  5E                pop si
00001EB3  C3                ret
00001EB4  1E                push ds
00001EB5  55                push bp
00001EB6  16                push ss
00001EB7  07                pop es
00001EB8  8BFD              mov di,bp
00001EBA  83EF40            sub di,byte +0x40
00001EBD  B91000            mov cx,0x10
00001EC0  8B36E200          mov si,[0xe2]
00001EC4  8E1EE000          mov ds,[0xe0]
00001EC8  F3A5              rep movsw
00001ECA  5D                pop bp
00001ECB  1F                pop ds
00001ECC  C3                ret
00001ECD  50                push ax
00001ECE  51                push cx
00001ECF  52                push dx
00001ED0  A1A004            mov ax,[0x4a0]
00001ED3  250300            and ax,0x3
00001ED6  B90020            mov cx,0x2000
00001ED9  F7E1              mul cx
00001EDB  8BD8              mov bx,ax
00001EDD  A1A004            mov ax,[0x4a0]
00001EE0  D1E8              shr ax,1
00001EE2  D1E8              shr ax,1
00001EE4  B9A000            mov cx,0xa0
00001EE7  F7E1              mul cx
00001EE9  03D8              add bx,ax
00001EEB  A19E04            mov ax,[0x49e]
00001EEE  D1E8              shr ax,1
00001EF0  03D8              add bx,ax
00001EF2  5A                pop dx
00001EF3  59                pop cx
00001EF4  58                pop ax
00001EF5  C3                ret
00001EF6  53                push bx
00001EF7  51                push cx
00001EF8  52                push dx
00001EF9  57                push di
00001EFA  06                push es
00001EFB  55                push bp
00001EFC  8BEC              mov bp,sp
00001EFE  81EC1201          sub sp,0x112
00001F02  8BC6              mov ax,si
00001F04  E8A1FD            call 0x1ca8
00001F07  B94001            mov cx,0x140
00001F0A  33D2              xor dx,dx
00001F0C  F7F9              idiv cx
00001F0E  8BCB              mov cx,bx
00001F10  51                push cx
00001F11  89169E04          mov [0x49e],dx
00001F15  A3A004            mov [0x4a0],ax
00001F18  B800B8            mov ax,0xb800
00001F1B  8EC0              mov es,ax
00001F1D  8B0E9E04          mov cx,[0x49e]
00001F21  D1E1              shl cx,1
00001F23  83E107            and cx,byte +0x7
00001F26  51                push cx
00001F27  B400              mov ah,0x0
00001F29  88A60AFF          mov [bp-0xf6],ah
00001F2D  88A608FF          mov [bp-0xf8],ah
00001F31  88A606FF          mov [bp-0xfa],ah
00001F35  88A604FF          mov [bp-0xfc],ah
00001F39  E8A300            call 0x1fdf
00001F3C  59                pop cx
00001F3D  B480              mov ah,0x80
00001F3F  D2CC              ror ah,cl
00001F41  59                pop cx
00001F42  BADD03            mov dx,0x3dd
00001F45  FA                cli
00001F46  8BF9              mov di,cx
00001F48  83E70F            and di,byte +0xf
00001F4B  D1E7              shl di,1
00001F4D  8A43C0            mov al,[bp+di-0x40]
00001F50  A801              test al,0x1
00001F52  7404              jz 0x1f58
00001F54  00A60AFF          add [bp-0xf6],ah
00001F58  A802              test al,0x2
00001F5A  7404              jz 0x1f60
00001F5C  00A608FF          add [bp-0xf8],ah
00001F60  A804              test al,0x4
00001F62  7404              jz 0x1f68
00001F64  00A606FF          add [bp-0xfa],ah
00001F68  A808              test al,0x8
00001F6A  7404              jz 0x1f70
00001F6C  00A604FF          add [bp-0xfc],ah
00001F70  D0CC              ror ah,1
00001F72  8A43C1            mov al,[bp+di-0x3f]
00001F75  A801              test al,0x1
00001F77  7404              jz 0x1f7d
00001F79  00A60AFF          add [bp-0xf6],ah
00001F7D  A802              test al,0x2
00001F7F  7404              jz 0x1f85
00001F81  00A608FF          add [bp-0xf8],ah
00001F85  A804              test al,0x4
00001F87  7404              jz 0x1f8d
00001F89  00A606FF          add [bp-0xfa],ah
00001F8D  A808              test al,0x8
00001F8F  7404              jz 0x1f95
00001F91  00A604FF          add [bp-0xfc],ah
00001F95  8AC4              mov al,ah
00001F97  D0C0              rol al,1
00001F99  02E0              add ah,al
00001F9B  F6D4              not ah
00001F9D  B001              mov al,0x1
00001F9F  EE                out dx,al
00001FA0  8A860AFF          mov al,[bp-0xf6]
00001FA4  262027            and [es:bx],ah
00001FA7  260007            add [es:bx],al
00001FAA  B002              mov al,0x2
00001FAC  EE                out dx,al
00001FAD  8A8608FF          mov al,[bp-0xf8]
00001FB1  262027            and [es:bx],ah
00001FB4  260007            add [es:bx],al
00001FB7  B004              mov al,0x4
00001FB9  EE                out dx,al
00001FBA  8A8606FF          mov al,[bp-0xfa]
00001FBE  262027            and [es:bx],ah
00001FC1  260007            add [es:bx],al
00001FC4  B008              mov al,0x8
00001FC6  EE                out dx,al
00001FC7  8A8604FF          mov al,[bp-0xfc]
00001FCB  262027            and [es:bx],ah
00001FCE  260007            add [es:bx],al
00001FD1  FB                sti
00001FD2  81C41201          add sp,0x112
00001FD6  5D                pop bp
00001FD7  07                pop es
00001FD8  5F                pop di
00001FD9  5A                pop dx
00001FDA  59                pop cx
00001FDB  5B                pop bx
00001FDC  58                pop ax
00001FDD  5E                pop si
00001FDE  C3                ret
00001FDF  50                push ax
00001FE0  51                push cx
00001FE1  52                push dx
00001FE2  A1A004            mov ax,[0x4a0]
00001FE5  D1E8              shr ax,1
00001FE7  B95000            mov cx,0x50
00001FEA  F7E1              mul cx
00001FEC  8BD8              mov bx,ax
00001FEE  A1A004            mov ax,[0x4a0]
00001FF1  250100            and ax,0x1
00001FF4  B90020            mov cx,0x2000
00001FF7  F7E1              mul cx
00001FF9  03D8              add bx,ax
00001FFB  A19E04            mov ax,[0x49e]
00001FFE  B102              mov cl,0x2
00002000  D3E8              shr ax,cl
00002002  03D8              add bx,ax
00002004  5A                pop dx
00002005  59                pop cx
00002006  58                pop ax
00002007  C3                ret
00002008  C3                ret
00002009  00A19204          add [bx+di+0x492],ah
0000200D  0AC0              or al,al
0000200F  7414              jz 0x2025
00002011  FEC8              dec al
00002013  7413              jz 0x2028
00002015  FEC8              dec al
00002017  7412              jz 0x202b
00002019  FEC8              dec al
0000201B  7411              jz 0x202e
0000201D  FEC8              dec al
0000201F  7410              jz 0x2031
00002021  FEC8              dec al
00002023  740F              jz 0x2034
00002025  E9A801            jmp 0x21d0
00002028  EB0D              jmp short 0x2037
0000202A  90                nop
0000202B  E9AE00            jmp 0x20dc
0000202E  E94001            jmp 0x2171
00002031  E92F03            jmp 0x2363
00002034  E99D03            jmp 0x23d4
00002037  52                push dx
00002038  8B1E9400          mov bx,[0x94]
0000203C  53                push bx
0000203D  E8F403            call 0x2434
00002040  B800B8            mov ax,0xb800
00002043  8EC0              mov es,ax
00002045  59                pop cx
00002046  83E103            and cx,byte +0x3
00002049  D1E1              shl cx,1
0000204B  B506              mov ch,0x6
0000204D  2AE9              sub ch,cl
0000204F  8ACD              mov cl,ch
00002051  5A                pop dx
00002052  8E1EBA00          mov ds,[0xba]
00002056  BB1000            mov bx,0x10
00002059  57                push di
0000205A  56                push si
0000205B  8A2D              mov ch,[di]
0000205D  E82200            call 0x2082
00002060  47                inc di
00002061  4B                dec bx
00002062  75F7              jnz 0x205b
00002064  5E                pop si
00002065  5F                pop di
00002066  81C74001          add di,0x140
0000206A  81FE0020          cmp si,0x2000
0000206E  7C0A              jl 0x207a
00002070  81EE0020          sub si,0x2000
00002074  83C650            add si,byte +0x50
00002077  EB05              jmp short 0x207e
00002079  90                nop
0000207A  81C60020          add si,0x2000
0000207E  4A                dec dx
0000207F  75D5              jnz 0x2056
00002081  C3                ret
00002082  80FD02            cmp ch,0x2
00002085  741B              jz 0x20a2
00002087  80E503            and ch,0x3
0000208A  32E4              xor ah,ah
0000208C  B4FC              mov ah,0xfc
0000208E  D2C4              rol ah,cl
00002090  268A04            mov al,[es:si]
00002093  22C4              and al,ah
00002095  D2E5              shl ch,cl
00002097  02C5              add al,ch
00002099  81FE0040          cmp si,0x4000
0000209D  7303              jnc 0x20a2
0000209F  268804            mov [es:si],al
000020A2  0AC9              or cl,cl
000020A4  7405              jz 0x20ab
000020A6  FEC9              dec cl
000020A8  FEC9              dec cl
000020AA  C3                ret
000020AB  B106              mov cl,0x6
000020AD  46                inc si
000020AE  C3                ret
000020AF  80FD02            cmp ch,0x2
000020B2  741B              jz 0x20cf
000020B4  80E503            and ch,0x3
000020B7  32E4              xor ah,ah
000020B9  B4FC              mov ah,0xfc
000020BB  D2C4              rol ah,cl
000020BD  268A04            mov al,[es:si]
000020C0  22C4              and al,ah
000020C2  D2E5              shl ch,cl
000020C4  02C5              add al,ch
000020C6  81FE0080          cmp si,0x8000
000020CA  7303              jnc 0x20cf
000020CC  268804            mov [es:si],al
000020CF  0AC9              or cl,cl
000020D1  7405              jz 0x20d8
000020D3  FEC9              dec cl
000020D5  FEC9              dec cl
000020D7  C3                ret
000020D8  B106              mov cl,0x6
000020DA  46                inc si
000020DB  C3                ret
000020DC  55                push bp
000020DD  8BEC              mov bp,sp
000020DF  81EC1201          sub sp,0x112
000020E3  8BFA              mov di,dx
000020E5  E8F803            call 0x24e0
000020E8  57                push di
000020E9  E83103            call 0x241d
000020EC  BACE03            mov dx,0x3ce
000020EF  B80502            mov ax,0x205
000020F2  EF                out dx,ax
000020F3  B80300            mov ax,0x3
000020F6  EF                out dx,ax
000020F7  B800A0            mov ax,0xa000
000020FA  8EC0              mov es,ax
000020FC  8B0E9400          mov cx,[0x94]
00002100  D1E1              shl cx,1
00002102  80E107            and cl,0x7
00002105  B580              mov ch,0x80
00002107  D2ED              shr ch,cl
00002109  58                pop ax
0000210A  BACE03            mov dx,0x3ce
0000210D  8E1EBA00          mov ds,[0xba]
00002111  51                push cx
00002112  50                push ax
00002113  53                push bx
00002114  57                push di
00002115  B110              mov cl,0x10
00002117  8B35              mov si,[di]
00002119  83E60F            and si,byte +0xf
0000211C  83FE02            cmp si,byte +0x2
0000211F  7505              jnz 0x2126
00002121  D0ED              shr ch,1
00002123  EB29              jmp short 0x214e
00002125  90                nop
00002126  D1E6              shl si,1
00002128  81FB803E          cmp bx,0x3e80
0000212C  7204              jc 0x2132
0000212E  D0ED              shr ch,1
00002130  EB1C              jmp short 0x214e
00002132  268A07            mov al,[es:bx]
00002135  8AE5              mov ah,ch
00002137  B008              mov al,0x8
00002139  EF                out dx,ax
0000213A  8A62C0            mov ah,[bp+si-0x40]
0000213D  268827            mov [es:bx],ah
00002140  D0ED              shr ch,1
00002142  268A27            mov ah,[es:bx]
00002145  8AE5              mov ah,ch
00002147  EF                out dx,ax
00002148  8A62C1            mov ah,[bp+si-0x3f]
0000214B  268827            mov [es:bx],ah
0000214E  D0ED              shr ch,1
00002150  47                inc di
00002151  0AED              or ch,ch
00002153  7503              jnz 0x2158
00002155  B580              mov ch,0x80
00002157  43                inc bx
00002158  FEC9              dec cl
0000215A  75BB              jnz 0x2117
0000215C  5F                pop di
0000215D  5B                pop bx
0000215E  58                pop ax
0000215F  59                pop cx
00002160  81C74001          add di,0x140
00002164  83C350            add bx,byte +0x50
00002167  FEC8              dec al
00002169  75A6              jnz 0x2111
0000216B  81C41201          add sp,0x112
0000216F  5D                pop bp
00002170  C3                ret
00002171  52                push dx
00002172  8B1E9400          mov bx,[0x94]
00002176  53                push bx
00002177  E80E03            call 0x2488
0000217A  B800B0            mov ax,0xb000
0000217D  8EC0              mov es,ax
0000217F  59                pop cx
00002180  83E103            and cx,byte +0x3
00002183  D1E1              shl cx,1
00002185  B506              mov ch,0x6
00002187  2AE9              sub ch,cl
00002189  8ACD              mov cl,ch
0000218B  5A                pop dx
0000218C  8E1EBA00          mov ds,[0xba]
00002190  BB1000            mov bx,0x10
00002193  57                push di
00002194  56                push si
00002195  8A2D              mov ch,[di]
00002197  E815FF            call 0x20af
0000219A  47                inc di
0000219B  4B                dec bx
0000219C  75F7              jnz 0x2195
0000219E  5E                pop si
0000219F  5F                pop di
000021A0  81C60020          add si,0x2000
000021A4  BB1000            mov bx,0x10
000021A7  57                push di
000021A8  56                push si
000021A9  8A2D              mov ch,[di]
000021AB  E801FF            call 0x20af
000021AE  47                inc di
000021AF  4B                dec bx
000021B0  75F7              jnz 0x21a9
000021B2  5E                pop si
000021B3  5F                pop di
000021B4  81C74001          add di,0x140
000021B8  81FE0060          cmp si,0x6000
000021BC  7C0A              jl 0x21c8
000021BE  81EE0060          sub si,0x6000
000021C2  83C650            add si,byte +0x50
000021C5  EB05              jmp short 0x21cc
000021C7  90                nop
000021C8  81C60020          add si,0x2000
000021CC  4A                dec dx
000021CD  75C1              jnz 0x2190
000021CF  C3                ret
000021D0  55                push bp
000021D1  8BEC              mov bp,sp
000021D3  81EC1201          sub sp,0x112
000021D7  52                push dx
000021D8  E80503            call 0x24e0
000021DB  E8DB02            call 0x24b9
000021DE  B800B8            mov ax,0xb800
000021E1  8EC0              mov es,ax
000021E3  A19400            mov ax,[0x94]
000021E6  D1E0              shl ax,1
000021E8  250700            and ax,0x7
000021EB  8AC8              mov cl,al
000021ED  B47F              mov ah,0x7f
000021EF  D2CC              ror ah,cl
000021F1  5A                pop dx
000021F2  B91000            mov cx,0x10
000021F5  8B36BA00          mov si,[0xba]
000021F9  8EDE              mov ds,si
000021FB  B0FF              mov al,0xff
000021FD  53                push bx
000021FE  50                push ax
000021FF  52                push dx
00002200  51                push cx
00002201  57                push di
00002202  BADD03            mov dx,0x3dd
00002205  B001              mov al,0x1
00002207  EE                out dx,al
00002208  268A07            mov al,[es:bx]
0000220B  88860AFF          mov [bp-0xf6],al
0000220F  B002              mov al,0x2
00002211  EE                out dx,al
00002212  268A07            mov al,[es:bx]
00002215  888608FF          mov [bp-0xf8],al
00002219  B004              mov al,0x4
0000221B  EE                out dx,al
0000221C  268A07            mov al,[es:bx]
0000221F  888606FF          mov [bp-0xfa],al
00002223  B008              mov al,0x8
00002225  EE                out dx,al
00002226  268A07            mov al,[es:bx]
00002229  888604FF          mov [bp-0xfc],al
0000222D  8B35              mov si,[di]
0000222F  83E60F            and si,byte +0xf
00002232  83FE02            cmp si,byte +0x2
00002235  7505              jnz 0x223c
00002237  D0CC              ror ah,1
00002239  E98A00            jmp 0x22c6
0000223C  D1E6              shl si,1
0000223E  20A60AFF          and [bp-0xf6],ah
00002242  20A608FF          and [bp-0xf8],ah
00002246  20A606FF          and [bp-0xfa],ah
0000224A  20A604FF          and [bp-0xfc],ah
0000224E  8A42C0            mov al,[bp+si-0x40]
00002251  A801              test al,0x1
00002253  7408              jz 0x225d
00002255  F6D4              not ah
00002257  00A60AFF          add [bp-0xf6],ah
0000225B  F6D4              not ah
0000225D  A802              test al,0x2
0000225F  7408              jz 0x2269
00002261  F6D4              not ah
00002263  00A608FF          add [bp-0xf8],ah
00002267  F6D4              not ah
00002269  A804              test al,0x4
0000226B  7408              jz 0x2275
0000226D  F6D4              not ah
0000226F  00A606FF          add [bp-0xfa],ah
00002273  F6D4              not ah
00002275  A808              test al,0x8
00002277  7408              jz 0x2281
00002279  F6D4              not ah
0000227B  00A604FF          add [bp-0xfc],ah
0000227F  F6D4              not ah
00002281  D0CC              ror ah,1
00002283  20A60AFF          and [bp-0xf6],ah
00002287  20A608FF          and [bp-0xf8],ah
0000228B  20A606FF          and [bp-0xfa],ah
0000228F  20A604FF          and [bp-0xfc],ah
00002293  8A42C1            mov al,[bp+si-0x3f]
00002296  A801              test al,0x1
00002298  7408              jz 0x22a2
0000229A  F6D4              not ah
0000229C  00A60AFF          add [bp-0xf6],ah
000022A0  F6D4              not ah
000022A2  A802              test al,0x2
000022A4  7408              jz 0x22ae
000022A6  F6D4              not ah
000022A8  00A608FF          add [bp-0xf8],ah
000022AC  F6D4              not ah
000022AE  A804              test al,0x4
000022B0  7408              jz 0x22ba
000022B2  F6D4              not ah
000022B4  00A606FF          add [bp-0xfa],ah
000022B8  F6D4              not ah
000022BA  A808              test al,0x8
000022BC  7408              jz 0x22c6
000022BE  F6D4              not ah
000022C0  00A604FF          add [bp-0xfc],ah
000022C4  F6D4              not ah
000022C6  D0CC              ror ah,1
000022C8  80FC7F            cmp ah,0x7f
000022CB  7538              jnz 0x2305
000022CD  81FB803E          cmp bx,0x3e80
000022D1  732A              jnc 0x22fd
000022D3  B001              mov al,0x1
000022D5  EE                out dx,al
000022D6  8A860AFF          mov al,[bp-0xf6]
000022DA  268807            mov [es:bx],al
000022DD  B002              mov al,0x2
000022DF  EE                out dx,al
000022E0  8A8608FF          mov al,[bp-0xf8]
000022E4  268807            mov [es:bx],al
000022E7  B004              mov al,0x4
000022E9  EE                out dx,al
000022EA  8A8606FF          mov al,[bp-0xfa]
000022EE  268807            mov [es:bx],al
000022F1  B008              mov al,0x8
000022F3  EE                out dx,al
000022F4  8A8604FF          mov al,[bp-0xfc]
000022F8  268807            mov [es:bx],al
000022FB  B47F              mov ah,0x7f
000022FD  47                inc di
000022FE  43                inc bx
000022FF  49                dec cx
00002300  7438              jz 0x233a
00002302  E900FF            jmp 0x2205
00002305  47                inc di
00002306  49                dec cx
00002307  7403              jz 0x230c
00002309  E921FF            jmp 0x222d
0000230C  81FB803E          cmp bx,0x3e80
00002310  7328              jnc 0x233a
00002312  B001              mov al,0x1
00002314  EE                out dx,al
00002315  8A860AFF          mov al,[bp-0xf6]
00002319  268807            mov [es:bx],al
0000231C  B002              mov al,0x2
0000231E  EE                out dx,al
0000231F  8A8608FF          mov al,[bp-0xf8]
00002323  268807            mov [es:bx],al
00002326  B004              mov al,0x4
00002328  EE                out dx,al
00002329  8A8606FF          mov al,[bp-0xfa]
0000232D  268807            mov [es:bx],al
00002330  B008              mov al,0x8
00002332  EE                out dx,al
00002333  8A8604FF          mov al,[bp-0xfc]
00002337  268807            mov [es:bx],al
0000233A  5F                pop di
0000233B  81C74001          add di,0x140
0000233F  59                pop cx
00002340  5A                pop dx
00002341  58                pop ax
00002342  5B                pop bx
00002343  81FB0020          cmp bx,0x2000
00002347  7C0A              jl 0x2353
00002349  81EB0020          sub bx,0x2000
0000234D  83C350            add bx,byte +0x50
00002350  EB05              jmp short 0x2357
00002352  90                nop
00002353  81C30020          add bx,0x2000
00002357  4A                dec dx
00002358  7403              jz 0x235d
0000235A  E9A0FE            jmp 0x21fd
0000235D  81C41201          add sp,0x112
00002361  5D                pop bp
00002362  C3                ret
00002363  52                push dx
00002364  52                push dx
00002365  E89501            call 0x24fd
00002368  B800B8            mov ax,0xb800
0000236B  8EC0              mov es,ax
0000236D  5A                pop dx
0000236E  8B1E9400          mov bx,[0x94]
00002372  83E301            and bx,byte +0x1
00002375  52                push dx
00002376  E8E400            call 0x245d
00002379  1E                push ds
0000237A  57                push di
0000237B  8E1EBA00          mov ds,[0xba]
0000237F  B104              mov cl,0x4
00002381  B510              mov ch,0x10
00002383  8A05              mov al,[di]
00002385  3C02              cmp al,0x2
00002387  7428              jz 0x23b1
00002389  240F              and al,0xf
0000238B  80FB01            cmp bl,0x1
0000238E  7416              jz 0x23a6
00002390  D2E0              shl al,cl
00002392  81FE0080          cmp si,0x8000
00002396  7319              jnc 0x23b1
00002398  268A24            mov ah,[es:si]
0000239B  80E40F            and ah,0xf
0000239E  02E0              add ah,al
000023A0  268824            mov [es:si],ah
000023A3  EB0C              jmp short 0x23b1
000023A5  90                nop
000023A6  268A24            mov ah,[es:si]
000023A9  80E4F0            and ah,0xf0
000023AC  02E0              add ah,al
000023AE  268824            mov [es:si],ah
000023B1  FEC3              inc bl
000023B3  80E301            and bl,0x1
000023B6  0ADB              or bl,bl
000023B8  7501              jnz 0x23bb
000023BA  46                inc si
000023BB  47                inc di
000023BC  FECD              dec ch
000023BE  75C3              jnz 0x2383
000023C0  5F                pop di
000023C1  81C74001          add di,0x140
000023C5  1F                pop ds
000023C6  FF069600          inc word [0x96]
000023CA  5A                pop dx
000023CB  4A                dec dx
000023CC  75A0              jnz 0x236e
000023CE  5A                pop dx
000023CF  29169600          sub [0x96],dx
000023D3  C3                ret
000023D4  1E                push ds
000023D5  52                push dx
000023D6  BA4001            mov dx,0x140
000023D9  8B1E9400          mov bx,[0x94]
000023DD  E82E00            call 0x240e
000023E0  B800A0            mov ax,0xa000
000023E3  8EC0              mov es,ax
000023E5  A1BA00            mov ax,[0xba]
000023E8  8ED8              mov ds,ax
000023EA  5A                pop dx
000023EB  B91000            mov cx,0x10
000023EE  81FE00FA          cmp si,0xfa00
000023F2  7309              jnc 0x23fd
000023F4  8A05              mov al,[di]
000023F6  3C02              cmp al,0x2
000023F8  7403              jz 0x23fd
000023FA  268804            mov [es:si],al
000023FD  46                inc si
000023FE  47                inc di
000023FF  E2ED              loop 0x23ee
00002401  81C63001          add si,0x130
00002405  81C73001          add di,0x130
00002409  4A                dec dx
0000240A  75DF              jnz 0x23eb
0000240C  1F                pop ds
0000240D  C3                ret
0000240E  E8EC00            call 0x24fd
00002411  A19600            mov ax,[0x96]
00002414  8BCA              mov cx,dx
00002416  F7E1              mul cx
00002418  03C3              add ax,bx
0000241A  8BF0              mov si,ax
0000241C  C3                ret
0000241D  E8DD00            call 0x24fd
00002420  A19600            mov ax,[0x96]
00002423  B95000            mov cx,0x50
00002426  F7E1              mul cx
00002428  8BD8              mov bx,ax
0000242A  A19400            mov ax,[0x94]
0000242D  B102              mov cl,0x2
0000242F  D3E8              shr ax,cl
00002431  03D8              add bx,ax
00002433  C3                ret
00002434  E8C600            call 0x24fd
00002437  A19600            mov ax,[0x96]
0000243A  250100            and ax,0x1
0000243D  B90020            mov cx,0x2000
00002440  F7E1              mul cx
00002442  8BF0              mov si,ax
00002444  A19600            mov ax,[0x96]
00002447  D1E8              shr ax,1
00002449  B95000            mov cx,0x50
0000244C  F7E1              mul cx
0000244E  03F0              add si,ax
00002450  A19400            mov ax,[0x94]
00002453  B102              mov cl,0x2
00002455  D3E8              shr ax,cl
00002457  03F0              add si,ax
00002459  C3                ret
0000245A  E8A000            call 0x24fd
0000245D  50                push ax
0000245E  53                push bx
0000245F  51                push cx
00002460  52                push dx
00002461  A19600            mov ax,[0x96]
00002464  250300            and ax,0x3
00002467  B90020            mov cx,0x2000
0000246A  F7E1              mul cx
0000246C  8BF0              mov si,ax
0000246E  A19600            mov ax,[0x96]
00002471  D1E8              shr ax,1
00002473  D1E8              shr ax,1
00002475  B9A000            mov cx,0xa0
00002478  F7E1              mul cx
0000247A  03F0              add si,ax
0000247C  A19400            mov ax,[0x94]
0000247F  D1E8              shr ax,1
00002481  03F0              add si,ax
00002483  5A                pop dx
00002484  59                pop cx
00002485  5B                pop bx
00002486  58                pop ax
00002487  C3                ret
00002488  E87200            call 0x24fd
0000248B  50                push ax
0000248C  53                push bx
0000248D  51                push cx
0000248E  52                push dx
0000248F  A19600            mov ax,[0x96]
00002492  D1E8              shr ax,1
00002494  BB5000            mov bx,0x50
00002497  F7E3              mul bx
00002499  8BF0              mov si,ax
0000249B  A19600            mov ax,[0x96]
0000249E  D1E0              shl ax,1
000024A0  250300            and ax,0x3
000024A3  B90020            mov cx,0x2000
000024A6  F7E1              mul cx
000024A8  03F0              add si,ax
000024AA  8B1E9400          mov bx,[0x94]
000024AE  D1EB              shr bx,1
000024B0  D1EB              shr bx,1
000024B2  03F3              add si,bx
000024B4  5A                pop dx
000024B5  59                pop cx
000024B6  5B                pop bx
000024B7  58                pop ax
000024B8  C3                ret
000024B9  E84100            call 0x24fd
000024BC  A19600            mov ax,[0x96]
000024BF  D1E8              shr ax,1
000024C1  B95000            mov cx,0x50
000024C4  F7E1              mul cx
000024C6  8BD8              mov bx,ax
000024C8  A19400            mov ax,[0x94]
000024CB  B102              mov cl,0x2
000024CD  D3E8              shr ax,cl
000024CF  03D8              add bx,ax
000024D1  A19600            mov ax,[0x96]
000024D4  250100            and ax,0x1
000024D7  0AC0              or al,al
000024D9  7404              jz 0x24df
000024DB  81C30020          add bx,0x2000
000024DF  C3                ret
000024E0  57                push di
000024E1  56                push si
000024E2  1E                push ds
000024E3  8B36DE00          mov si,[0xde]
000024E7  8E1EDC00          mov ds,[0xdc]
000024EB  8CD0              mov ax,ss
000024ED  8EC0              mov es,ax
000024EF  8BFD              mov di,bp
000024F1  83EF40            sub di,byte +0x40
000024F4  B91000            mov cx,0x10
000024F7  F3A5              rep movsw
000024F9  1F                pop ds
000024FA  5E                pop si
000024FB  5F                pop di
000024FC  C3                ret
000024FD  8B0EA600          mov cx,[0xa6]
00002501  D1E1              shl cx,1
00002503  B8420A            mov ax,0xa42
00002506  8EC0              mov es,ax
00002508  8D36FE07          lea si,[0x7fe]
0000250C  03F1              add si,cx
0000250E  268B3C            mov di,[es:si]
00002511  033EB800          add di,[0xb8]
00002515  C3                ret
00002516  55                push bp
00002517  8BEC              mov bp,sp
00002519  FB                sti
0000251A  50                push ax
0000251B  52                push dx
0000251C  1E                push ds
0000251D  06                push es
0000251E  56                push si
0000251F  B8420A            mov ax,0xa42
00002522  8ED8              mov ds,ax
00002524  E460              in al,0x60
00002526  A39C00            mov [0x9c],ax
00002529  50                push ax
0000252A  E461              in al,0x61
0000252C  8AE0              mov ah,al
0000252E  0C80              or al,0x80
00002530  E661              out 0x61,al
00002532  86E0              xchg ah,al
00002534  E661              out 0x61,al
00002536  58                pop ax
00002537  8E069800          mov es,[0x98]
0000253B  8B369A00          mov si,[0x9a]
0000253F  803E610601        cmp byte [0x661],0x1
00002544  7403              jz 0x2549
00002546  E80B00            call 0x2554
00002549  FA                cli
0000254A  B020              mov al,0x20
0000254C  E620              out 0x20,al
0000254E  5E                pop si
0000254F  07                pop es
00002550  1F                pop ds
00002551  5A                pop dx
00002552  58                pop ax
00002553  CF                iret
00002554  3C3B              cmp al,0x3b
00002556  7502              jnz 0x255a
00002558  EB6D              jmp short 0x25c7
0000255A  3C46              cmp al,0x46
0000255C  7500              jnz 0x255e
0000255E  3C45              cmp al,0x45
00002560  7503              jnz 0x2565
00002562  E98400            jmp 0x25e9
00002565  3C44              cmp al,0x44
00002567  7503              jnz 0x256c
00002569  EB7E              jmp short 0x25e9
0000256B  90                nop
0000256C  3C02              cmp al,0x2
0000256E  7503              jnz 0x2573
00002570  E98D00            jmp 0x2600
00002573  3C03              cmp al,0x3
00002575  7503              jnz 0x257a
00002577  E99900            jmp 0x2613
0000257A  3C04              cmp al,0x4
0000257C  7503              jnz 0x2581
0000257E  E9A500            jmp 0x2626
00002581  3C05              cmp al,0x5
00002583  7503              jnz 0x2588
00002585  E9B100            jmp 0x2639
00002588  3C38              cmp al,0x38
0000258A  7503              jnz 0x258f
0000258C  E93901            jmp 0x26c8
0000258F  3C3A              cmp al,0x3a
00002591  7503              jnz 0x2596
00002593  E93201            jmp 0x26c8
00002596  3C20              cmp al,0x20
00002598  7503              jnz 0x259d
0000259A  E93801            jmp 0x26d5
0000259D  3C1F              cmp al,0x1f
0000259F  7503              jnz 0x25a4
000025A1  E93101            jmp 0x26d5
000025A4  3C1E              cmp al,0x1e
000025A6  7500              jnz 0x25a8
000025A8  C606580600        mov byte [0x658],0x0
000025AD  C606570600        mov byte [0x657],0x0
000025B2  C606590600        mov byte [0x659],0x0
000025B7  C6065A0600        mov byte [0x65a],0x0
000025BC  C6065B0600        mov byte [0x65b],0x0
000025C1  C6065C0600        mov byte [0x65c],0x0
000025C6  C3                ret
000025C7  803E580600        cmp byte [0x658],0x0
000025CC  750F              jnz 0x25dd
000025CE  268A441A          mov al,[es:si+0x1a]
000025D2  F6D0              not al
000025D4  2688441A          mov [es:si+0x1a],al
000025D8  C606580601        mov byte [0x658],0x1
000025DD  C3                ret
000025DE  268A441B          mov al,[es:si+0x1b]
000025E2  F6D0              not al
000025E4  2688441B          mov [es:si+0x1b],al
000025E8  C3                ret
000025E9  803E570600        cmp byte [0x657],0x0
000025EE  750F              jnz 0x25ff
000025F0  268A441C          mov al,[es:si+0x1c]
000025F4  F6D0              not al
000025F6  2688441C          mov [es:si+0x1c],al
000025FA  C606570601        mov byte [0x657],0x1
000025FF  C3                ret
00002600  803E590600        cmp byte [0x659],0x0
00002605  750B              jnz 0x2612
00002607  B80100            mov ax,0x1
0000260A  E83F00            call 0x264c
0000260D  C606590601        mov byte [0x659],0x1
00002612  C3                ret
00002613  803E5A0600        cmp byte [0x65a],0x0
00002618  750B              jnz 0x2625
0000261A  B80200            mov ax,0x2
0000261D  E82C00            call 0x264c
00002620  C6065A0601        mov byte [0x65a],0x1
00002625  C3                ret
00002626  803E5B0600        cmp byte [0x65b],0x0
0000262B  750B              jnz 0x2638
0000262D  B80300            mov ax,0x3
00002630  E81900            call 0x264c
00002633  C6065B0601        mov byte [0x65b],0x1
00002638  C3                ret
00002639  803E5C0600        cmp byte [0x65c],0x0
0000263E  750B              jnz 0x264b
00002640  B80400            mov ax,0x4
00002643  E80600            call 0x264c
00002646  C6065C0601        mov byte [0x65c],0x1
0000264B  C3                ret
0000264C  06                push es
0000264D  56                push si
0000264E  48                dec ax
0000264F  50                push ax
00002650  A19400            mov ax,[0x94]
00002653  A34F06            mov [0x64f],ax
00002656  A19600            mov ax,[0x96]
00002659  A35106            mov [0x651],ax
0000265C  53                push bx
0000265D  51                push cx
0000265E  57                push di
0000265F  56                push si
00002660  55                push bp
00002661  06                push es
00002662  1E                push ds
00002663  A1700E            mov ax,[0xe70]
00002666  50                push ax
00002667  A1720E            mov ax,[0xe72]
0000266A  50                push ax
0000266B  50                push ax
0000266C  B8F300            mov ax,0xf3
0000266F  50                push ax
00002670  8BCC              mov cx,sp
00002672  9A240A9304        call 0x493:0xa24
00002677  83C408            add sp,byte +0x8
0000267A  1F                pop ds
0000267B  07                pop es
0000267C  5D                pop bp
0000267D  5E                pop si
0000267E  5F                pop di
0000267F  59                pop cx
00002680  5B                pop bx
00002681  53                push bx
00002682  8BD8              mov bx,ax
00002684  92                xchg ax,dx
00002685  E84808            call 0x2ed0
00002688  8EC0              mov es,ax
0000268A  8BF3              mov si,bx
0000268C  5B                pop bx
0000268D  58                pop ax
0000268E  D1E0              shl ax,1
00002690  D1E0              shl ax,1
00002692  03F0              add si,ax
00002694  268B04            mov ax,[es:si]
00002697  86E0              xchg ah,al
00002699  050500            add ax,0x5
0000269C  5E                pop si
0000269D  07                pop es
0000269E  86E0              xchg ah,al
000026A0  26894402          mov [es:si+0x2],ax
000026A4  B80600            mov ax,0x6
000026A7  86E0              xchg ah,al
000026A9  26894404          mov [es:si+0x4],ax
000026AD  C3                ret
000026AE  833EA60005        cmp word [0xa6],byte +0x5
000026B3  741F              jz 0x26d4
000026B5  A14F06            mov ax,[0x64f]
000026B8  86E0              xchg ah,al
000026BA  26894402          mov [es:si+0x2],ax
000026BE  A15106            mov ax,[0x651]
000026C1  86E0              xchg ah,al
000026C3  26894404          mov [es:si+0x4],ax
000026C7  C3                ret
000026C8  803E730601        cmp byte [0x673],0x1
000026CD  7405              jz 0x26d4
000026CF  C606610602        mov byte [0x661],0x2
000026D4  C3                ret
000026D5  50                push ax
000026D6  53                push bx
000026D7  51                push cx
000026D8  52                push dx
000026D9  56                push si
000026DA  57                push di
000026DB  1E                push ds
000026DC  06                push es
000026DD  55                push bp
000026DE  9AF507E808        call 0x8e8:0x7f5
000026E3  5D                pop bp
000026E4  07                pop es
000026E5  1F                pop ds
000026E6  5F                pop di
000026E7  5E                pop si
000026E8  5A                pop dx
000026E9  59                pop cx
000026EA  5B                pop bx
000026EB  58                pop ax
000026EC  C3                ret
000026ED  55                push bp
000026EE  8BEC              mov bp,sp
000026F0  FB                sti
000026F1  50                push ax
000026F2  53                push bx
000026F3  51                push cx
000026F4  52                push dx
000026F5  56                push si
000026F6  57                push di
000026F7  1E                push ds
000026F8  06                push es
000026F9  55                push bp
000026FA  B8420A            mov ax,0xa42
000026FD  8ED8              mov ds,ax
000026FF  8E069800          mov es,[0x98]
00002703  8B369A00          mov si,[0x9a]
00002707  FE0E2506          dec byte [0x625]
0000270B  FF063F06          inc word [0x63f]
0000270F  803E250600        cmp byte [0x625],0x0
00002714  7525              jnz 0x273b
00002716  268B4416          mov ax,[es:si+0x16]
0000271A  050002            add ax,0x200
0000271D  26894416          mov [es:si+0x16],ax
00002721  C606250624        mov byte [0x625],0x24
00002726  803E610601        cmp byte [0x661],0x1
0000272B  750E              jnz 0x273b
0000272D  B82400            mov ax,0x24
00002730  B11B              mov cl,0x1b
00002732  F6E1              mul cl
00002734  B112              mov cl,0x12
00002736  F6F1              div cl
00002738  A22506            mov [0x625],al
0000273B  833E660100        cmp word [0x166],byte +0x0
00002740  754C              jnz 0x278e
00002742  1E                push ds
00002743  06                push es
00002744  53                push bx
00002745  B401              mov ah,0x1
00002747  CD16              int 0x16
00002749  741C              jz 0x2767
0000274B  32E4              xor ah,ah
0000274D  CD16              int 0x16
0000274F  86E0              xchg ah,al
00002751  32E4              xor ah,ah
00002753  A39C00            mov [0x9c],ax
00002756  5B                pop bx
00002757  07                pop es
00002758  1F                pop ds
00002759  8E069800          mov es,[0x98]
0000275D  8B369A00          mov si,[0x9a]
00002761  E8F0FD            call 0x2554
00002764  EB28              jmp short 0x278e
00002766  90                nop
00002767  5B                pop bx
00002768  07                pop es
00002769  1F                pop ds
0000276A  C7069C000000      mov word [0x9c],0x0
00002770  C606580600        mov byte [0x658],0x0
00002775  C606570600        mov byte [0x657],0x0
0000277A  C606590600        mov byte [0x659],0x0
0000277F  C6065A0600        mov byte [0x65a],0x0
00002784  C6065B0600        mov byte [0x65b],0x0
00002789  C6065C0600        mov byte [0x65c],0x0
0000278E  803E610601        cmp byte [0x661],0x1
00002793  750B              jnz 0x27a0
00002795  833E630600        cmp word [0x663],byte +0x0
0000279A  7404              jz 0x27a0
0000279C  FF0E6306          dec word [0x663]
000027A0  803E390601        cmp byte [0x639],0x1
000027A5  750A              jnz 0x27b1
000027A7  803E610601        cmp byte [0x661],0x1
000027AC  7403              jz 0x27b1
000027AE  E9EF02            jmp 0x2aa0
000027B1  803E740601        cmp byte [0x674],0x1
000027B6  7503              jnz 0x27bb
000027B8  E9E502            jmp 0x2aa0
000027BB  E8D200            call 0x2890
000027BE  803E280601        cmp byte [0x628],0x1
000027C3  7403              jz 0x27c8
000027C5  E9CC00            jmp 0x2894
000027C8  803E610601        cmp byte [0x661],0x1
000027CD  740B              jz 0x27da
000027CF  B80300            mov ax,0x3
000027D2  CD33              int 0x33
000027D4  80E303            and bl,0x3
000027D7  E8A201            call 0x297c
000027DA  803E270601        cmp byte [0x627],0x1
000027DF  740D              jz 0x27ee
000027E1  803E610601        cmp byte [0x661],0x1
000027E6  7503              jnz 0x27eb
000027E8  E94402            jmp 0x2a2f
000027EB  E9B202            jmp 0x2aa0
000027EE  803E610601        cmp byte [0x661],0x1
000027F3  7529              jnz 0x281e
000027F5  833E630600        cmp word [0x663],byte +0x0
000027FA  750B              jnz 0x2807
000027FC  8B0E9400          mov cx,[0x94]
00002800  8B169600          mov dx,[0x96]
00002804  EB18              jmp short 0x281e
00002806  90                nop
00002807  8E066506          mov es,[0x665]
0000280B  8B366906          mov si,[0x669]
0000280F  268B4C02          mov cx,[es:si+0x2]
00002813  268B5404          mov dx,[es:si+0x4]
00002817  83FAFC            cmp dx,byte -0x4
0000281A  7502              jnz 0x281e
0000281C  33D2              xor dx,dx
0000281E  C606620600        mov byte [0x662],0x0
00002823  B8420A            mov ax,0xa42
00002826  8ED8              mov ds,ax
00002828  8E069800          mov es,[0x98]
0000282C  8B369A00          mov si,[0x9a]
00002830  51                push cx
00002831  52                push dx
00002832  268B4402          mov ax,[es:si+0x2]
00002836  268B5C04          mov bx,[es:si+0x4]
0000283A  86E0              xchg ah,al
0000283C  86FB              xchg bh,bl
0000283E  3B069400          cmp ax,[0x94]
00002842  7506              jnz 0x284a
00002844  3B1E9600          cmp bx,[0x96]
00002848  741E              jz 0x2868
0000284A  5A                pop dx
0000284B  59                pop cx
0000284C  8BC8              mov cx,ax
0000284E  8BD3              mov dx,bx
00002850  C606620601        mov byte [0x662],0x1
00002855  803E280601        cmp byte [0x628],0x1
0000285A  7507              jnz 0x2863
0000285C  50                push ax
0000285D  B80400            mov ax,0x4
00002860  CD33              int 0x33
00002862  58                pop ax
00002863  51                push cx
00002864  52                push dx
00002865  EB09              jmp short 0x2870
00002867  90                nop
00002868  3BC1              cmp ax,cx
0000286A  7504              jnz 0x2870
0000286C  3BDA              cmp bx,dx
0000286E  741B              jz 0x288b
00002870  1E                push ds
00002871  BAC800            mov dx,0xc8
00002874  2B169600          sub dx,[0x96]
00002878  83FA10            cmp dx,byte +0x10
0000287B  7D07              jnl 0x2884
0000287D  0BD2              or dx,dx
0000287F  7409              jz 0x288a
00002881  EB04              jmp short 0x2887
00002883  90                nop
00002884  BA1000            mov dx,0x10
00002887  E8D405            call 0x2e5e
0000288A  1F                pop ds
0000288B  5A                pop dx
0000288C  59                pop cx
0000288D  E90301            jmp 0x2993
00002890  A19C00            mov ax,[0x9c]
00002893  C3                ret
00002894  803E610601        cmp byte [0x661],0x1
00002899  740F              jz 0x28aa
0000289B  E8F2FF            call 0x2890
0000289E  50                push ax
0000289F  E83D00            call 0x28df
000028A2  58                pop ax
000028A3  0BDB              or bx,bx
000028A5  7503              jnz 0x28aa
000028A7  E80300            call 0x28ad
000028AA  E92DFF            jmp 0x27da
000028AD  B301              mov bl,0x1
000028AF  3C39              cmp al,0x39
000028B1  7504              jnz 0x28b7
000028B3  E8C600            call 0x297c
000028B6  C3                ret
000028B7  3C3C              cmp al,0x3c
000028B9  7504              jnz 0x28bf
000028BB  E8BE00            call 0x297c
000028BE  C3                ret
000028BF  B302              mov bl,0x2
000028C1  3C12              cmp al,0x12
000028C3  7504              jnz 0x28c9
000028C5  E8B400            call 0x297c
000028C8  C3                ret
000028C9  3C1C              cmp al,0x1c
000028CB  7504              jnz 0x28d1
000028CD  E8AC00            call 0x297c
000028D0  C3                ret
000028D1  3C2B              cmp al,0x2b
000028D3  7504              jnz 0x28d9
000028D5  E8A400            call 0x297c
000028D8  C3                ret
000028D9  32DB              xor bl,bl
000028DB  E89E00            call 0x297c
000028DE  C3                ret
000028DF  33DB              xor bx,bx
000028E1  8B0E9400          mov cx,[0x94]
000028E5  8B169600          mov dx,[0x96]
000028E9  3C4B              cmp al,0x4b
000028EB  7459              jz 0x2946
000028ED  3C4D              cmp al,0x4d
000028EF  7445              jz 0x2936
000028F1  3C48              cmp al,0x48
000028F3  7431              jz 0x2926
000028F5  3C50              cmp al,0x50
000028F7  741D              jz 0x2916
000028F9  3C49              cmp al,0x49
000028FB  7459              jz 0x2956
000028FD  3C51              cmp al,0x51
000028FF  7468              jz 0x2969
00002901  32C0              xor al,al
00002903  26884414          mov [es:si+0x14],al
00002907  26884415          mov [es:si+0x15],al
0000290B  C6065D0600        mov byte [0x65d],0x0
00002910  C6065E0600        mov byte [0x65e],0x0
00002915  C3                ret
00002916  26FE4415          inc byte [es:si+0x15]
0000291A  268A4415          mov al,[es:si+0x15]
0000291E  32E4              xor ah,ah
00002920  03D0              add dx,ax
00002922  BBFFFF            mov bx,0xffff
00002925  C3                ret
00002926  26FE4415          inc byte [es:si+0x15]
0000292A  268A4415          mov al,[es:si+0x15]
0000292E  32E4              xor ah,ah
00002930  2BD0              sub dx,ax
00002932  BBFFFF            mov bx,0xffff
00002935  C3                ret
00002936  26FE4414          inc byte [es:si+0x14]
0000293A  268A4414          mov al,[es:si+0x14]
0000293E  32E4              xor ah,ah
00002940  03C8              add cx,ax
00002942  BBFFFF            mov bx,0xffff
00002945  C3                ret
00002946  26FE4414          inc byte [es:si+0x14]
0000294A  268A4414          mov al,[es:si+0x14]
0000294E  32E4              xor ah,ah
00002950  2BC8              sub cx,ax
00002952  BBFFFF            mov bx,0xffff
00002955  C3                ret
00002956  803E5D0601        cmp byte [0x65d],0x1
0000295B  7408              jz 0x2965
0000295D  83EA0C            sub dx,byte +0xc
00002960  C6065D0601        mov byte [0x65d],0x1
00002965  BBFFFF            mov bx,0xffff
00002968  C3                ret
00002969  803E5E0601        cmp byte [0x65e],0x1
0000296E  740B              jz 0x297b
00002970  83C20C            add dx,byte +0xc
00002973  C6065E0601        mov byte [0x65e],0x1
00002978  BBFFFF            mov bx,0xffff
0000297B  C3                ret
0000297C  8E069800          mov es,[0x98]
00002980  8B369A00          mov si,[0x9a]
00002984  381E3A06          cmp [0x63a],bl
00002988  7408              jz 0x2992
0000298A  26885C01          mov [es:si+0x1],bl
0000298E  881E3A06          mov [0x63a],bl
00002992  C3                ret
00002993  33DB              xor bx,bx
00002995  8E069800          mov es,[0x98]
00002999  8B369A00          mov si,[0x9a]
0000299D  803E620601        cmp byte [0x662],0x1
000029A2  7442              jz 0x29e6
000029A4  268B440C          mov ax,[es:si+0xc]
000029A8  86E0              xchg ah,al
000029AA  3BC8              cmp cx,ax
000029AC  7F08              jg 0x29b6
000029AE  8BC8              mov cx,ax
000029B0  BBFFFF            mov bx,0xffff
000029B3  EB10              jmp short 0x29c5
000029B5  90                nop
000029B6  268B4410          mov ax,[es:si+0x10]
000029BA  86E0              xchg ah,al
000029BC  3BC8              cmp cx,ax
000029BE  7C05              jl 0x29c5
000029C0  8BC8              mov cx,ax
000029C2  BBFFFF            mov bx,0xffff
000029C5  268B440E          mov ax,[es:si+0xe]
000029C9  86E0              xchg ah,al
000029CB  3BD0              cmp dx,ax
000029CD  7F08              jg 0x29d7
000029CF  8BD0              mov dx,ax
000029D1  BBFFFF            mov bx,0xffff
000029D4  EB10              jmp short 0x29e6
000029D6  90                nop
000029D7  268B4412          mov ax,[es:si+0x12]
000029DB  86E0              xchg ah,al
000029DD  3BD0              cmp dx,ax
000029DF  7C05              jl 0x29e6
000029E1  8BD0              mov dx,ax
000029E3  BBFFFF            mov bx,0xffff
000029E6  0BDB              or bx,bx
000029E8  7416              jz 0x2a00
000029EA  803E280601        cmp byte [0x628],0x1
000029EF  750F              jnz 0x2a00
000029F1  1E                push ds
000029F2  06                push es
000029F3  56                push si
000029F4  51                push cx
000029F5  52                push dx
000029F6  B80400            mov ax,0x4
000029F9  CD33              int 0x33
000029FB  5A                pop dx
000029FC  59                pop cx
000029FD  5E                pop si
000029FE  07                pop es
000029FF  1F                pop ds
00002A00  890E9400          mov [0x94],cx
00002A04  89169600          mov [0x96],dx
00002A08  86E9              xchg ch,cl
00002A0A  26894C02          mov [es:si+0x2],cx
00002A0E  86F2              xchg dh,dl
00002A10  26895404          mov [es:si+0x4],dx
00002A14  1E                push ds
00002A15  BAC800            mov dx,0xc8
00002A18  2B169600          sub dx,[0x96]
00002A1C  83FA10            cmp dx,byte +0x10
00002A1F  7D07              jnl 0x2a28
00002A21  0BD2              or dx,dx
00002A23  7409              jz 0x2a2e
00002A25  EB04              jmp short 0x2a2b
00002A27  90                nop
00002A28  BA1000            mov dx,0x10
00002A2B  E8DCF5            call 0x200a
00002A2E  1F                pop ds
00002A2F  803E610601        cmp byte [0x661],0x1
00002A34  756A              jnz 0x2aa0
00002A36  833E630600        cmp word [0x663],byte +0x0
00002A3B  7563              jnz 0x2aa0
00002A3D  803EF90001        cmp byte [0xf9],0x1
00002A42  7508              jnz 0x2a4c
00002A44  8306630603        add word [0x663],byte +0x3
00002A49  EB55              jmp short 0x2aa0
00002A4B  90                nop
00002A4C  8306690606        add word [0x669],byte +0x6
00002A51  8E066506          mov es,[0x665]
00002A55  8B366906          mov si,[0x669]
00002A59  268A4401          mov al,[es:si+0x1]
00002A5D  06                push es
00002A5E  56                push si
00002A5F  8E069800          mov es,[0x98]
00002A63  8B369A00          mov si,[0x9a]
00002A67  26884401          mov [es:si+0x1],al
00002A6B  5E                pop si
00002A6C  07                pop es
00002A6D  32E4              xor ah,ah
00002A6F  EB01              jmp short 0x2a72
00002A71  90                nop
00002A72  268A4406          mov al,[es:si+0x6]
00002A76  3CFF              cmp al,0xff
00002A78  751F              jnz 0x2a99
00002A7A  8B366706          mov si,[0x667]
00002A7E  89366906          mov [0x669],si
00002A82  268A04            mov al,[es:si]
00002A85  B001              mov al,0x1
00002A87  06                push es
00002A88  56                push si
00002A89  8E069800          mov es,[0x98]
00002A8D  8B369A00          mov si,[0x9a]
00002A91  26884401          mov [es:si+0x1],al
00002A95  5E                pop si
00002A96  07                pop es
00002A97  B0FF              mov al,0xff
00002A99  B11B              mov cl,0x1b
00002A9B  F6E1              mul cl
00002A9D  A36306            mov [0x663],ax
00002AA0  FA                cli
00002AA1  B020              mov al,0x20
00002AA3  E620              out 0x20,al
00002AA5  5D                pop bp
00002AA6  07                pop es
00002AA7  1F                pop ds
00002AA8  5F                pop di
00002AA9  5E                pop si
00002AAA  5A                pop dx
00002AAB  59                pop cx
00002AAC  5B                pop bx
00002AAD  58                pop ax
00002AAE  CF                iret
00002AAF  55                push bp
00002AB0  8BEC              mov bp,sp
00002AB2  803E740E01        cmp byte [0xe74],0x1
00002AB7  741C              jz 0x2ad5
00002AB9  FE065606          inc byte [0x656]
00002ABD  803E560600        cmp byte [0x656],0x0
00002AC2  7505              jnz 0x2ac9
00002AC4  C606270601        mov byte [0x627],0x1
00002AC9  803E560600        cmp byte [0x656],0x0
00002ACE  7E05              jng 0x2ad5
00002AD0  C606560600        mov byte [0x656],0x0
00002AD5  5D                pop bp
00002AD6  CB                retf
00002AD7  55                push bp
00002AD8  8BEC              mov bp,sp
00002ADA  33DB              xor bx,bx
00002ADC  803E740E01        cmp byte [0xe74],0x1
00002AE1  7420              jz 0x2b03
00002AE3  803E270601        cmp byte [0x627],0x1
00002AE8  7519              jnz 0x2b03
00002AEA  833EA60005        cmp word [0xa6],byte +0x5
00002AEF  7412              jz 0x2b03
00002AF1  C606270600        mov byte [0x627],0x0
00002AF6  51                push cx
00002AF7  BA1000            mov dx,0x10
00002AFA  9A220D9304        call 0x493:0xd22
00002AFF  BBFFFF            mov bx,0xffff
00002B02  59                pop cx
00002B03  8BE9              mov bp,cx
00002B05  8B4604            mov ax,[bp+0x4]
00002B08  A3A600            mov [0xa6],ax
00002B0B  0BDB              or bx,bx
00002B0D  7405              jz 0x2b14
00002B0F  C606270601        mov byte [0x627],0x1
00002B14  5D                pop bp
00002B15  CB                retf
00002B16  55                push bp
00002B17  8BEC              mov bp,sp
00002B19  C606390601        mov byte [0x639],0x1
00002B1E  1E                push ds
00002B1F  57                push di
00002B20  56                push si
00002B21  C606270600        mov byte [0x627],0x0
00002B26  51                push cx
00002B27  8B0EA600          mov cx,[0xa6]
00002B2B  51                push cx
00002B2C  BF3900            mov di,0x39
00002B2F  BA1000            mov dx,0x10
00002B32  B007              mov al,0x7
00002B34  E8DA02            call 0x2e11
00002B37  BF3900            mov di,0x39
00002B3A  BA6B00            mov dx,0x6b
00002B3D  B008              mov al,0x8
00002B3F  E8CF02            call 0x2e11
00002B42  59                pop cx
00002B43  890EA600          mov [0xa6],cx
00002B47  59                pop cx
00002B48  8BE9              mov bp,cx
00002B4A  8B4614            mov ax,[bp+0x14]
00002B4D  8B7600            mov si,[bp+0x0]
00002B50  8B4E04            mov cx,[bp+0x4]
00002B53  8B5608            mov dx,[bp+0x8]
00002B56  8B7E0C            mov di,[bp+0xc]
00002B59  8B5E10            mov bx,[bp+0x10]
00002B5C  0BDB              or bx,bx
00002B5E  7403              jz 0x2b63
00002B60  EB79              jmp short 0x2bdb
00002B62  90                nop
00002B63  0BC0              or ax,ax
00002B65  752F              jnz 0x2b96
00002B67  83FAFF            cmp dx,byte -0x1
00002B6A  7510              jnz 0x2b7c
00002B6C  8B163106          mov dx,[0x631]
00002B70  8B3E2906          mov di,[0x629]
00002B74  C6063C0601        mov byte [0x63c],0x1
00002B79  EB06              jmp short 0x2b81
00002B7B  90                nop
00002B7C  C6063C0600        mov byte [0x63c],0x0
00002B81  890E2906          mov [0x629],cx
00002B85  89363106          mov [0x631],si
00002B89  893E2D06          mov [0x62d],di
00002B8D  89163506          mov [0x635],dx
00002B91  B007              mov al,0x7
00002B93  EB30              jmp short 0x2bc5
00002B95  90                nop
00002B96  83FAFF            cmp dx,byte -0x1
00002B99  7510              jnz 0x2bab
00002B9B  8B163306          mov dx,[0x633]
00002B9F  8B3E2B06          mov di,[0x62b]
00002BA3  C6063B0601        mov byte [0x63b],0x1
00002BA8  EB06              jmp short 0x2bb0
00002BAA  90                nop
00002BAB  C6063B0600        mov byte [0x63b],0x0
00002BB0  890E2B06          mov [0x62b],cx
00002BB4  89363306          mov [0x633],si
00002BB8  893E2F06          mov [0x62f],di
00002BBC  89163706          mov [0x637],dx
00002BC0  B008              mov al,0x8
00002BC2  EB01              jmp short 0x2bc5
00002BC4  90                nop
00002BC5  8B0EA600          mov cx,[0xa6]
00002BC9  890E2306          mov [0x623],cx
00002BCD  32E4              xor ah,ah
00002BCF  E83F02            call 0x2e11
00002BD2  A12306            mov ax,[0x623]
00002BD5  A3A600            mov [0xa6],ax
00002BD8  EB27              jmp short 0x2c01
00002BDA  90                nop
00002BDB  0BC0              or ax,ax
00002BDD  7519              jnz 0x2bf8
00002BDF  A12906            mov ax,[0x629]
00002BE2  8B1E3106          mov bx,[0x631]
00002BE6  A39400            mov [0x94],ax
00002BE9  891E9600          mov [0x96],bx
00002BED  52                push dx
00002BEE  BA0C00            mov dx,0xc
00002BF1  E86A02            call 0x2e5e
00002BF4  5A                pop dx
00002BF5  E93502            jmp 0x2e2d
00002BF8  A12B06            mov ax,[0x62b]
00002BFB  8B1E3306          mov bx,[0x633]
00002BFF  EBE5              jmp short 0x2be6
00002C01  803E3C0600        cmp byte [0x63c],0x0
00002C06  7503              jnz 0x2c0b
00002C08  E92202            jmp 0x2e2d
00002C0B  803E3B0600        cmp byte [0x63b],0x0
00002C10  7503              jnz 0x2c15
00002C12  E91802            jmp 0x2e2d
00002C15  8BEC              mov bp,sp
00002C17  83EC1C            sub sp,byte +0x1c
00002C1A  A12D06            mov ax,[0x62d]
00002C1D  8B1E2906          mov bx,[0x629]
00002C21  E8DB01            call 0x2dff
00002C24  894EFA            mov [bp-0x6],cx
00002C27  8876FF            mov [bp-0x1],dh
00002C2A  A12F06            mov ax,[0x62f]
00002C2D  8B1E2B06          mov bx,[0x62b]
00002C31  E8CB01            call 0x2dff
00002C34  894EF8            mov [bp-0x8],cx
00002C37  8876FE            mov [bp-0x2],dh
00002C3A  A13506            mov ax,[0x635]
00002C3D  8B1E3106          mov bx,[0x631]
00002C41  E8BB01            call 0x2dff
00002C44  894EF6            mov [bp-0xa],cx
00002C47  8876FD            mov [bp-0x3],dh
00002C4A  A13706            mov ax,[0x637]
00002C4D  8B1E3306          mov bx,[0x633]
00002C51  E8AB01            call 0x2dff
00002C54  894EF4            mov [bp-0xc],cx
00002C57  8876FC            mov [bp-0x4],dh
00002C5A  8B46FA            mov ax,[bp-0x6]
00002C5D  8B5EF6            mov bx,[bp-0xa]
00002C60  E89201            call 0x2df5
00002C63  894EF2            mov [bp-0xe],cx
00002C66  8B46F8            mov ax,[bp-0x8]
00002C69  8B5EF4            mov bx,[bp-0xc]
00002C6C  E88601            call 0x2df5
00002C6F  894EF0            mov [bp-0x10],cx
00002C72  C746EE0000        mov word [bp-0x12],0x0
00002C77  A13D06            mov ax,[0x63d]
00002C7A  B90004            mov cx,0x400
00002C7D  F7E1              mul cx
00002C7F  50                push ax
00002C80  52                push dx
00002C81  837EF200          cmp word [bp-0xe],byte +0x0
00002C85  7408              jz 0x2c8f
00002C87  8B4EF2            mov cx,[bp-0xe]
00002C8A  F7F1              div cx
00002C8C  8946EE            mov [bp-0x12],ax
00002C8F  C746EC0000        mov word [bp-0x14],0x0
00002C94  5A                pop dx
00002C95  58                pop ax
00002C96  837EF000          cmp word [bp-0x10],byte +0x0
00002C9A  7408              jz 0x2ca4
00002C9C  8B4EF0            mov cx,[bp-0x10]
00002C9F  F7F1              div cx
00002CA1  8946EC            mov [bp-0x14],ax
00002CA4  33C9              xor cx,cx
00002CA6  C646EB00          mov byte [bp-0x15],0x0
00002CAA  C646EA00          mov byte [bp-0x16],0x0
00002CAE  8B46EE            mov ax,[bp-0x12]
00002CB1  8B5EFA            mov bx,[bp-0x6]
00002CB4  E83201            call 0x2de9
00002CB7  8B3E2D06          mov di,[0x62d]
00002CBB  2BF8              sub di,ax
00002CBD  807EFF00          cmp byte [bp-0x1],0x0
00002CC1  7504              jnz 0x2cc7
00002CC3  03F8              add di,ax
00002CC5  03F8              add di,ax
00002CC7  8B5EFA            mov bx,[bp-0x6]
00002CCA  0BDB              or bx,bx
00002CCC  7505              jnz 0x2cd3
00002CCE  33C0              xor ax,ax
00002CD0  EB0E              jmp short 0x2ce0
00002CD2  90                nop
00002CD3  8B46EE            mov ax,[bp-0x12]
00002CD6  8B76F6            mov si,[bp-0xa]
00002CD9  8BDE              mov bx,si
00002CDB  E80B01            call 0x2de9
00002CDE  33D2              xor dx,dx
00002CE0  8B163506          mov dx,[0x635]
00002CE4  2BD0              sub dx,ax
00002CE6  807EFD00          cmp byte [bp-0x3],0x0
00002CEA  7504              jnz 0x2cf0
00002CEC  03D0              add dx,ax
00002CEE  03D0              add dx,ax
00002CF0  51                push cx
00002CF1  807EEB00          cmp byte [bp-0x15],0x0
00002CF5  7509              jnz 0x2d00
00002CF7  57                push di
00002CF8  52                push dx
00002CF9  B007              mov al,0x7
00002CFB  51                push cx
00002CFC  E81201            call 0x2e11
00002CFF  59                pop cx
00002D00  8B46EC            mov ax,[bp-0x14]
00002D03  8B5EF8            mov bx,[bp-0x8]
00002D06  E8E000            call 0x2de9
00002D09  8B3E2F06          mov di,[0x62f]
00002D0D  2BF8              sub di,ax
00002D0F  807EFE00          cmp byte [bp-0x2],0x0
00002D13  7504              jnz 0x2d19
00002D15  03F8              add di,ax
00002D17  03F8              add di,ax
00002D19  8B5EF8            mov bx,[bp-0x8]
00002D1C  0BDB              or bx,bx
00002D1E  7505              jnz 0x2d25
00002D20  33C0              xor ax,ax
00002D22  EB0A              jmp short 0x2d2e
00002D24  90                nop
00002D25  8B46EC            mov ax,[bp-0x14]
00002D28  8B5EF4            mov bx,[bp-0xc]
00002D2B  E8BB00            call 0x2de9
00002D2E  8B163706          mov dx,[0x637]
00002D32  2BD0              sub dx,ax
00002D34  807EFC00          cmp byte [bp-0x4],0x0
00002D38  7504              jnz 0x2d3e
00002D3A  03D0              add dx,ax
00002D3C  03D0              add dx,ax
00002D3E  807EEA00          cmp byte [bp-0x16],0x0
00002D42  7507              jnz 0x2d4b
00002D44  57                push di
00002D45  52                push dx
00002D46  B008              mov al,0x8
00002D48  E8C600            call 0x2e11
00002D4B  807EEA00          cmp byte [bp-0x16],0x0
00002D4F  7529              jnz 0x2d7a
00002D51  5A                pop dx
00002D52  5F                pop di
00002D53  E88B00            call 0x2de1
00002D56  893E9400          mov [0x94],di
00002D5A  89169600          mov [0x96],dx
00002D5E  52                push dx
00002D5F  57                push di
00002D60  BA0C00            mov dx,0xc
00002D63  E8F800            call 0x2e5e
00002D66  5F                pop di
00002D67  5A                pop dx
00002D68  A13306            mov ax,[0x633]
00002D6B  3BC2              cmp ax,dx
00002D6D  750B              jnz 0x2d7a
00002D6F  A12B06            mov ax,[0x62b]
00002D72  3BC7              cmp ax,di
00002D74  7504              jnz 0x2d7a
00002D76  C646EA01          mov byte [bp-0x16],0x1
00002D7A  807EEB00          cmp byte [bp-0x15],0x0
00002D7E  7526              jnz 0x2da6
00002D80  5A                pop dx
00002D81  5F                pop di
00002D82  893E9400          mov [0x94],di
00002D86  89169600          mov [0x96],dx
00002D8A  52                push dx
00002D8B  57                push di
00002D8C  BA0C00            mov dx,0xc
00002D8F  E8CC00            call 0x2e5e
00002D92  5F                pop di
00002D93  5A                pop dx
00002D94  A13106            mov ax,[0x631]
00002D97  3BC2              cmp ax,dx
00002D99  750B              jnz 0x2da6
00002D9B  A12906            mov ax,[0x629]
00002D9E  3BC7              cmp ax,di
00002DA0  7504              jnz 0x2da6
00002DA2  C646EB01          mov byte [bp-0x15],0x1
00002DA6  59                pop cx
00002DA7  41                inc cx
00002DA8  807EEB01          cmp byte [bp-0x15],0x1
00002DAC  7530              jnz 0x2dde
00002DAE  807EEA01          cmp byte [bp-0x16],0x1
00002DB2  752A              jnz 0x2dde
00002DB4  83C41C            add sp,byte +0x1c
00002DB7  C6063C0600        mov byte [0x63c],0x0
00002DBC  C6063B0600        mov byte [0x63b],0x0
00002DC1  8B3E2906          mov di,[0x629]
00002DC5  8B163106          mov dx,[0x631]
00002DC9  B007              mov al,0x7
00002DCB  E84300            call 0x2e11
00002DCE  8B3E2B06          mov di,[0x62b]
00002DD2  8B163306          mov dx,[0x633]
00002DD6  B008              mov al,0x8
00002DD8  E83600            call 0x2e11
00002DDB  EB4A              jmp short 0x2e27
00002DDD  90                nop
00002DDE  E9CDFE            jmp 0x2cae
00002DE1  51                push cx
00002DE2  B9204E            mov cx,0x4e20
00002DE5  E2FE              loop 0x2de5
00002DE7  59                pop cx
00002DE8  C3                ret
00002DE9  F7E3              mul bx
00002DEB  F7E1              mul cx
00002DED  51                push cx
00002DEE  B90004            mov cx,0x400
00002DF1  F7F1              div cx
00002DF3  59                pop cx
00002DF4  C3                ret
00002DF5  3BC3              cmp ax,bx
00002DF7  7F03              jg 0x2dfc
00002DF9  8BCB              mov cx,bx
00002DFB  C3                ret
00002DFC  8BC8              mov cx,ax
00002DFE  C3                ret
00002DFF  3BC3              cmp ax,bx
00002E01  7E07              jng 0x2e0a
00002E03  2BC3              sub ax,bx
00002E05  8BC8              mov cx,ax
00002E07  B601              mov dh,0x1
00002E09  C3                ret
00002E0A  2BD8              sub bx,ax
00002E0C  8BCB              mov cx,bx
00002E0E  32F6              xor dh,dh
00002E10  C3                ret
00002E11  893E9400          mov [0x94],di
00002E15  89169600          mov [0x96],dx
00002E19  BA0C00            mov dx,0xc
00002E1C  32E4              xor ah,ah
00002E1E  A3A600            mov [0xa6],ax
00002E21  1E                push ds
00002E22  E8E5F1            call 0x200a
00002E25  1F                pop ds
00002E26  C3                ret
00002E27  A12306            mov ax,[0x623]
00002E2A  A3A600            mov [0xa6],ax
00002E2D  8E069800          mov es,[0x98]
00002E31  8B369A00          mov si,[0x9a]
00002E35  268B4402          mov ax,[es:si+0x2]
00002E39  86E0              xchg ah,al
00002E3B  A39400            mov [0x94],ax
00002E3E  268B4404          mov ax,[es:si+0x4]
00002E42  86E0              xchg ah,al
00002E44  A39600            mov [0x96],ax
00002E47  52                push dx
00002E48  BA0C00            mov dx,0xc
00002E4B  E81000            call 0x2e5e
00002E4E  5A                pop dx
00002E4F  C606270601        mov byte [0x627],0x1
00002E54  C606390600        mov byte [0x639],0x0
00002E59  5E                pop si
00002E5A  5F                pop di
00002E5B  1F                pop ds
00002E5C  5D                pop bp
00002E5D  CB                retf
00002E5E  A19204            mov ax,[0x492]
00002E61  0BC0              or ax,ax
00002E63  740F              jz 0x2e74
00002E65  48                dec ax
00002E66  740C              jz 0x2e74
00002E68  48                dec ax
00002E69  7409              jz 0x2e74
00002E6B  48                dec ax
00002E6C  7406              jz 0x2e74
00002E6E  48                dec ax
00002E6F  7403              jz 0x2e74
00002E71  48                dec ax
00002E72  7410              jz 0x2e84
00002E74  1E                push ds
00002E75  52                push dx
00002E76  51                push cx
00002E77  53                push bx
00002E78  50                push ax
00002E79  9A220D9304        call 0x493:0xd22
00002E7E  58                pop ax
00002E7F  5B                pop bx
00002E80  59                pop cx
00002E81  5A                pop dx
00002E82  1F                pop ds
00002E83  C3                ret
00002E84  1E                push ds
00002E85  50                push ax
00002E86  52                push dx
00002E87  51                push cx
00002E88  BA1000            mov dx,0x10
00002E8B  52                push dx
00002E8C  B800A0            mov ax,0xa000
00002E8F  8EC0              mov es,ax
00002E91  833E960000        cmp word [0x96],byte +0x0
00002E96  7D0E              jnl 0x2ea6
00002E98  A19600            mov ax,[0x96]
00002E9B  5A                pop dx
00002E9C  F7D8              neg ax
00002E9E  2BD0              sub dx,ax
00002EA0  52                push dx
00002EA1  33C0              xor ax,ax
00002EA3  EB04              jmp short 0x2ea9
00002EA5  90                nop
00002EA6  A19600            mov ax,[0x96]
00002EA9  B94001            mov cx,0x140
00002EAC  F7E1              mul cx
00002EAE  03069400          add ax,[0x94]
00002EB2  8BF8              mov di,ax
00002EB4  8BF7              mov si,di
00002EB6  8E1E9404          mov ds,[0x494]
00002EBA  5A                pop dx
00002EBB  B91000            mov cx,0x10
00002EBE  F3A4              rep movsb
00002EC0  81C63001          add si,0x130
00002EC4  81C73001          add di,0x130
00002EC8  4A                dec dx
00002EC9  75F0              jnz 0x2ebb
00002ECB  59                pop cx
00002ECC  5A                pop dx
00002ECD  58                pop ax
00002ECE  1F                pop ds
00002ECF  C3                ret
00002ED0  51                push cx
00002ED1  B10C              mov cl,0xc
00002ED3  D3E0              shl ax,cl
00002ED5  B104              mov cl,0x4
00002ED7  53                push bx
00002ED8  D3EB              shr bx,cl
00002EDA  03C3              add ax,bx
00002EDC  5B                pop bx
00002EDD  83E30F            and bx,byte +0xf
00002EE0  59                pop cx
00002EE1  C3                ret
00002EE2  55                push bp
00002EE3  8BEC              mov bp,sp
00002EE5  51                push cx
00002EE6  59                pop cx
00002EE7  C7069400A000      mov word [0x94],0xa0
00002EED  C7069600FCFF      mov word [0x96],0xfffc
00002EF3  8BE9              mov bp,cx
00002EF5  C606470601        mov byte [0x647],0x1
00002EFA  C60645063F        mov byte [0x645],0x3f
00002EFF  C606460600        mov byte [0x646],0x0
00002F04  C606480600        mov byte [0x648],0x0
00002F09  C60649063F        mov byte [0x649],0x3f
00002F0E  C6064A0601        mov byte [0x64a],0x1
00002F13  8B4604            mov ax,[bp+0x4]
00002F16  0BC0              or ax,ax
00002F18  7507              jnz 0x2f21
00002F1A  50                push ax
00002F1B  9A74064207        call 0x742:0x674
00002F20  58                pop ax
00002F21  0BC0              or ax,ax
00002F23  7405              jz 0x2f2a
00002F25  C606470602        mov byte [0x647],0x2
00002F2A  8B5E00            mov bx,[bp+0x0]
00002F2D  8B4602            mov ax,[bp+0x2]
00002F30  E89DFF            call 0x2ed0
00002F33  B90100            mov cx,0x1
00002F36  E8CD0B            call 0x3b06
00002F39  A19204            mov ax,[0x492]
00002F3C  3D0500            cmp ax,0x5
00002F3F  7403              jz 0x2f44
00002F41  E93301            jmp 0x3077
00002F44  B800A0            mov ax,0xa000
00002F47  8EC0              mov es,ax
00002F49  8B4604            mov ax,[bp+0x4]
00002F4C  0BC0              or ax,ax
00002F4E  7414              jz 0x2f64
00002F50  1E                push ds
00002F51  B8420A            mov ax,0xa42
00002F54  8ED8              mov ds,ax
00002F56  8D367408          lea si,[0x874]
00002F5A  1F                pop ds
00002F5B  BF3D01            mov di,0x13d
00002F5E  B93200            mov cx,0x32
00002F61  EB11              jmp short 0x2f74
00002F63  90                nop
00002F64  B8420A            mov ax,0xa42
00002F67  1E                push ds
00002F68  8ED8              mov ds,ax
00002F6A  8D361008          lea si,[0x810]
00002F6E  1F                pop ds
00002F6F  33FF              xor di,di
00002F71  B93200            mov cx,0x32
00002F74  51                push cx
00002F75  1E                push ds
00002F76  B8420A            mov ax,0xa42
00002F79  8ED8              mov ds,ax
00002F7B  8A0C              mov cl,[si]
00002F7D  8A5432            mov dl,[si+0x32]
00002F80  1F                pop ds
00002F81  0AC9              or cl,cl
00002F83  740A              jz 0x2f8f
00002F85  80F903            cmp cl,0x3
00002F88  7504              jnz 0x2f8e
00002F8A  4F                dec di
00002F8B  EB02              jmp short 0x2f8f
00002F8D  90                nop
00002F8E  47                inc di
00002F8F  0AD2              or dl,dl
00002F91  7410              jz 0x2fa3
00002F93  80FA01            cmp dl,0x1
00002F96  7507              jnz 0x2f9f
00002F98  81C74001          add di,0x140
00002F9C  EB05              jmp short 0x2fa3
00002F9E  90                nop
00002F9F  81EF4001          sub di,0x140
00002FA3  57                push di
00002FA4  1E                push ds
00002FA5  8E1E9404          mov ds,[0x494]
00002FA9  56                push si
00002FAA  33DB              xor bx,bx
00002FAC  83FF00            cmp di,byte +0x0
00002FAF  7D0E              jnl 0x2fbf
00002FB1  B94001            mov cx,0x140
00002FB4  8A07              mov al,[bx]
00002FB6  268807            mov [es:bx],al
00002FB9  43                inc bx
00002FBA  47                inc di
00002FBB  E2F7              loop 0x2fb4
00002FBD  EBED              jmp short 0x2fac
00002FBF  E80B00            call 0x2fcd
00002FC2  E81500            call 0x2fda
00002FC5  E80500            call 0x2fcd
00002FC8  E80F00            call 0x2fda
00002FCB  EBF2              jmp short 0x2fbf
00002FCD  81FF00FA          cmp di,0xfa00
00002FD1  734F              jnc 0x3022
00002FD3  81FB00FA          cmp bx,0xfa00
00002FD7  735D              jnc 0x3036
00002FD9  C3                ret
00002FDA  8BC3              mov ax,bx
00002FDC  33D2              xor dx,dx
00002FDE  B94001            mov cx,0x140
00002FE1  F7F1              div cx
00002FE3  BA00FA            mov dx,0xfa00
00002FE6  2BD7              sub dx,di
00002FE8  81FA4001          cmp dx,0x140
00002FEC  7305              jnc 0x2ff3
00002FEE  8BCA              mov cx,dx
00002FF0  83C104            add cx,byte +0x4
00002FF3  D1E9              shr cx,1
00002FF5  250100            and ax,0x1
00002FF8  0AC0              or al,al
00002FFA  7514              jnz 0x3010
00002FFC  47                inc di
00002FFD  8A07              mov al,[bx]
00002FFF  268807            mov [es:bx],al
00003002  43                inc bx
00003003  8A05              mov al,[di]
00003005  268807            mov [es:bx],al
00003008  83C702            add di,byte +0x2
0000300B  43                inc bx
0000300C  E2EF              loop 0x2ffd
0000300E  4F                dec di
0000300F  C3                ret
00003010  8A05              mov al,[di]
00003012  268807            mov [es:bx],al
00003015  43                inc bx
00003016  83C702            add di,byte +0x2
00003019  8A07              mov al,[bx]
0000301B  268807            mov [es:bx],al
0000301E  43                inc bx
0000301F  E2EF              loop 0x3010
00003021  C3                ret
00003022  59                pop cx
00003023  81FB00FA          cmp bx,0xfa00
00003027  730E              jnc 0x3037
00003029  B94001            mov cx,0x140
0000302C  8A07              mov al,[bx]
0000302E  268807            mov [es:bx],al
00003031  43                inc bx
00003032  E2F8              loop 0x302c
00003034  EBED              jmp short 0x3023
00003036  59                pop cx
00003037  5E                pop si
00003038  1F                pop ds
00003039  5F                pop di
0000303A  46                inc si
0000303B  59                pop cx
0000303C  49                dec cx
0000303D  0BC9              or cx,cx
0000303F  7436              jz 0x3077
00003041  50                push ax
00003042  52                push dx
00003043  53                push bx
00003044  51                push cx
00003045  57                push di
00003046  41                inc cx
00003047  8BC1              mov ax,cx
00003049  BB4000            mov bx,0x40
0000304C  F7E3              mul bx
0000304E  BB3200            mov bx,0x32
00003051  F7F3              div bx
00003053  8BF8              mov di,ax
00003055  8BC1              mov ax,cx
00003057  48                dec ax
00003058  BB4000            mov bx,0x40
0000305B  F7E3              mul bx
0000305D  BB3200            mov bx,0x32
00003060  F7F3              div bx
00003062  2BF8              sub di,ax
00003064  8BCF              mov cx,di
00003066  51                push cx
00003067  9A890E9304        call 0x493:0xe89
0000306C  59                pop cx
0000306D  E2F7              loop 0x3066
0000306F  5F                pop di
00003070  59                pop cx
00003071  5B                pop bx
00003072  5A                pop dx
00003073  58                pop ax
00003074  E9FDFE            jmp 0x2f74
00003077  A19204            mov ax,[0x492]
0000307A  3C05              cmp al,0x5
0000307C  7451              jz 0x30cf
0000307E  8B4604            mov ax,[bp+0x4]
00003081  0BC0              or ax,ax
00003083  7541              jnz 0x30c6
00003085  803E750601        cmp byte [0x675],0x1
0000308A  7407              jz 0x3093
0000308C  803E0F2800        cmp byte [0x280f],0x0
00003091  74F2              jz 0x3085
00003093  B91000            mov cx,0x10
00003096  8E06DC00          mov es,[0xdc]
0000309A  8B36DE00          mov si,[0xde]
0000309E  B91000            mov cx,0x10
000030A1  E84B00            call 0x30ef
000030A4  8E06E000          mov es,[0xe0]
000030A8  8B36E200          mov si,[0xe2]
000030AC  B91000            mov cx,0x10
000030AF  E83D00            call 0x30ef
000030B2  8E067B01          mov es,[0x17b]
000030B6  8B367D01          mov si,[0x17d]
000030BA  B90800            mov cx,0x8
000030BD  E82F00            call 0x30ef
000030C0  E80E00            call 0x30d1
000030C3  EB0A              jmp short 0x30cf
000030C5  90                nop
000030C6  B94000            mov cx,0x40
000030C9  E8320A            call 0x3afe
000030CC  E80200            call 0x30d1
000030CF  5D                pop bp
000030D0  CB                retf
000030D1  C7069E000000      mov word [0x9e],0x0
000030D7  C706A4000000      mov word [0xa4],0x0
000030DD  C706A0003F01      mov word [0xa0],0x13f
000030E3  C706A200C700      mov word [0xa2],0xc7
000030E9  9A750D9304        call 0x493:0xd75
000030EE  C3                ret
000030EF  33C0              xor ax,ax
000030F1  268904            mov [es:si],ax
000030F4  83C602            add si,byte +0x2
000030F7  E2F8              loop 0x30f1
000030F9  C3                ret
000030FA  55                push bp
000030FB  8BEC              mov bp,sp
000030FD  8BE9              mov bp,cx
000030FF  8B5E14            mov bx,[bp+0x14]
00003102  8B4616            mov ax,[bp+0x16]
00003105  E8C8FD            call 0x2ed0
00003108  8B5E00            mov bx,[bp+0x0]
0000310B  8B4602            mov ax,[bp+0x2]
0000310E  E8BFFD            call 0x2ed0
00003111  50                push ax
00003112  53                push bx
00003113  1E                push ds
00003114  8B5E0C            mov bx,[bp+0xc]
00003117  8B460E            mov ax,[bp+0xe]
0000311A  E8B3FD            call 0x2ed0
0000311D  8B5604            mov dx,[bp+0x4]
00003120  52                push dx
00003121  8B4E08            mov cx,[bp+0x8]
00003124  51                push cx
00003125  8B0E9404          mov cx,[0x494]
00003129  51                push cx
0000312A  53                push bx
0000312B  50                push ax
0000312C  1E                push ds
0000312D  06                push es
0000312E  56                push si
0000312F  57                push di
00003130  833E5F0621        cmp word [0x65f],byte +0x21
00003135  7540              jnz 0x3177
00003137  8EC0              mov es,ax
00003139  8BF3              mov si,bx
0000313B  268A04            mov al,[es:si]
0000313E  3C01              cmp al,0x1
00003140  7435              jz 0x3177
00003142  833E920405        cmp word [0x492],byte +0x5
00003147  7412              jz 0x315b
00003149  03366D06          add si,[0x66d]
0000314D  83EE22            sub si,byte +0x22
00003150  8CC0              mov ax,es
00003152  8BDE              mov bx,si
00003154  9AFE0C8400        call 0x84:0xcfe
00003159  EB1C              jmp short 0x3177
0000315B  83C602            add si,byte +0x2
0000315E  A14B06            mov ax,[0x64b]
00003161  8B3E4D06          mov di,[0x64d]
00003165  8ED8              mov ds,ax
00003167  B91000            mov cx,0x10
0000316A  268B04            mov ax,[es:si]
0000316D  8905              mov [di],ax
0000316F  83C702            add di,byte +0x2
00003172  83C602            add si,byte +0x2
00003175  E2F3              loop 0x316a
00003177  5F                pop di
00003178  5E                pop si
00003179  07                pop es
0000317A  1F                pop ds
0000317B  9A00009304        call 0x493:0x0
00003180  83C40A            add sp,byte +0xa
00003183  1F                pop ds
00003184  50                push ax
00003185  53                push bx
00003186  8B5E14            mov bx,[bp+0x14]
00003189  8B4616            mov ax,[bp+0x16]
0000318C  E841FD            call 0x2ed0
0000318F  0BC0              or ax,ax
00003191  7435              jz 0x31c8
00003193  5F                pop di
00003194  5E                pop si
00003195  8B4616            mov ax,[bp+0x16]
00003198  50                push ax
00003199  8B5E14            mov bx,[bp+0x14]
0000319C  53                push bx
0000319D  8BDF              mov bx,di
0000319F  8BC6              mov ax,si
000031A1  33FF              xor di,di
000031A3  03DA              add bx,dx
000031A5  4B                dec bx
000031A6  57                push di
000031A7  53                push bx
000031A8  03C8              add cx,ax
000031AA  49                dec cx
000031AB  57                push di
000031AC  51                push cx
000031AD  2BC8              sub cx,ax
000031AF  41                inc cx
000031B0  2BDA              sub bx,dx
000031B2  42                inc dx
000031B3  57                push di
000031B4  53                push bx
000031B5  57                push di
000031B6  51                push cx
000031B7  57                push di
000031B8  57                push di
000031B9  57                push di
000031BA  57                push di
000031BB  8BCC              mov cx,sp
000031BD  9A100E9304        call 0x493:0xe10
000031C2  83C41C            add sp,byte +0x1c
000031C5  EB03              jmp short 0x31ca
000031C7  90                nop
000031C8  5B                pop bx
000031C9  58                pop ax
000031CA  5B                pop bx
000031CB  58                pop ax
000031CC  0BC0              or ax,ax
000031CE  751D              jnz 0x31ed
000031D0  C7069E000801      mov word [0x9e],0x108
000031D6  C706A0003E01      mov word [0xa0],0x13e
000031DC  C706A4006D00      mov word [0xa4],0x6d
000031E2  C706A200B200      mov word [0xa2],0xb2
000031E8  9A750D9304        call 0x493:0xd75
000031ED  5D                pop bp
000031EE  CB                retf
000031EF  55                push bp
000031F0  8BEC              mov bp,sp
000031F2  56                push si
000031F3  57                push di
000031F4  06                push es
000031F5  1E                push ds
000031F6  E84301            call 0x333c
000031F9  B8420A            mov ax,0xa42
000031FC  8EC0              mov es,ax
000031FE  8D363209          lea si,[0x932]
00003202  8B460C            mov ax,[bp+0xc]
00003205  D1E0              shl ax,1
00003207  03F0              add si,ax
00003209  268B04            mov ax,[es:si]
0000320C  BB420A            mov bx,0xa42
0000320F  8EC3              mov es,bx
00003211  8D36440A          lea si,[0xa44]
00003215  BA0100            mov dx,0x1
00003218  33C9              xor cx,cx
0000321A  268B04            mov ax,[es:si]
0000321D  3DFFFF            cmp ax,0xffff
00003220  7504              jnz 0x3226
00003222  42                inc dx
00003223  EB0A              jmp short 0x322f
00003225  90                nop
00003226  3B460C            cmp ax,[bp+0xc]
00003229  740B              jz 0x3236
0000322B  41                inc cx
0000322C  EB03              jmp short 0x3231
0000322E  90                nop
0000322F  33C9              xor cx,cx
00003231  83C602            add si,byte +0x2
00003234  EBE4              jmp short 0x321a
00003236  83FA01            cmp dx,byte +0x1
00003239  750E              jnz 0x3249
0000323B  B8420A            mov ax,0xa42
0000323E  8EC0              mov es,ax
00003240  8D368C09          lea si,[0x98c]
00003244  8BC1              mov ax,cx
00003246  EB5B              jmp short 0x32a3
00003248  90                nop
00003249  83FA02            cmp dx,byte +0x2
0000324C  750E              jnz 0x325c
0000324E  B8420A            mov ax,0xa42
00003251  8EC0              mov es,ax
00003253  8D36E009          lea si,[0x9e0]
00003257  8BC1              mov ax,cx
00003259  EB48              jmp short 0x32a3
0000325B  90                nop
0000325C  83FA03            cmp dx,byte +0x3
0000325F  750E              jnz 0x326f
00003261  B8420A            mov ax,0xa42
00003264  8EC0              mov es,ax
00003266  8D36F809          lea si,[0x9f8]
0000326A  8BC1              mov ax,cx
0000326C  EB35              jmp short 0x32a3
0000326E  90                nop
0000326F  83FA04            cmp dx,byte +0x4
00003272  750E              jnz 0x3282
00003274  B8420A            mov ax,0xa42
00003277  8EC0              mov es,ax
00003279  8D360C0A          lea si,[0xa0c]
0000327D  8BC1              mov ax,cx
0000327F  EB22              jmp short 0x32a3
00003281  90                nop
00003282  83FA05            cmp dx,byte +0x5
00003285  750E              jnz 0x3295
00003287  B8420A            mov ax,0xa42
0000328A  8EC0              mov es,ax
0000328C  8D36240A          lea si,[0xa24]
00003290  8BC1              mov ax,cx
00003292  EB0F              jmp short 0x32a3
00003294  90                nop
00003295  B8420A            mov ax,0xa42
00003298  8EC0              mov es,ax
0000329A  8D36300A          lea si,[0xa30]
0000329E  8BC1              mov ax,cx
000032A0  EB01              jmp short 0x32a3
000032A2  90                nop
000032A3  8B5E0C            mov bx,[bp+0xc]
000032A6  891E5F06          mov [0x65f],bx
000032AA  B102              mov cl,0x2
000032AC  D3E0              shl ax,cl
000032AE  03F0              add si,ax
000032B0  268B04            mov ax,[es:si]
000032B3  268B5402          mov dx,[es:si+0x2]
000032B7  8B5E0A            mov bx,[bp+0xa]
000032BA  D3E3              shl bx,cl
000032BC  03C3              add ax,bx
000032BE  7301              jnc 0x32c1
000032C0  42                inc dx
000032C1  8BCA              mov cx,dx
000032C3  8BD0              mov dx,ax
000032C5  E86700            call 0x332f
000032C8  B43F              mov ah,0x3f
000032CA  8B1E4306          mov bx,[0x643]
000032CE  B9420A            mov cx,0xa42
000032D1  1E                push ds
000032D2  8ED9              mov ds,cx
000032D4  8D3EA00A          lea di,[0xaa0]
000032D8  8BD7              mov dx,di
000032DA  B90800            mov cx,0x8
000032DD  CD21              int 0x21
000032DF  268B04            mov ax,[es:si]
000032E2  268B5402          mov dx,[es:si+0x2]
000032E6  8B1D              mov bx,[di]
000032E8  8B4D04            mov cx,[di+0x4]
000032EB  2BCB              sub cx,bx
000032ED  1E                push ds
000032EE  50                push ax
000032EF  B8420A            mov ax,0xa42
000032F2  8ED8              mov ds,ax
000032F4  890E6D06          mov [0x66d],cx
000032F8  58                pop ax
000032F9  1F                pop ds
000032FA  03C3              add ax,bx
000032FC  7301              jnc 0x32ff
000032FE  42                inc dx
000032FF  51                push cx
00003300  8BCA              mov cx,dx
00003302  8BD0              mov dx,ax
00003304  E82800            call 0x332f
00003307  59                pop cx
00003308  1F                pop ds
00003309  0BC9              or cx,cx
0000330B  741A              jz 0x3327
0000330D  1E                push ds
0000330E  B43F              mov ah,0x3f
00003310  8B1E4306          mov bx,[0x643]
00003314  8E5E08            mov ds,[bp+0x8]
00003317  8B5606            mov dx,[bp+0x6]
0000331A  CD21              int 0x21
0000331C  1F                pop ds
0000331D  50                push ax
0000331E  8B1E4306          mov bx,[0x643]
00003322  B43E              mov ah,0x3e
00003324  CD21              int 0x21
00003326  58                pop ax
00003327  8BC1              mov ax,cx
00003329  1F                pop ds
0000332A  07                pop es
0000332B  5F                pop di
0000332C  5E                pop si
0000332D  5D                pop bp
0000332E  CB                retf
0000332F  B442              mov ah,0x42
00003331  32C0              xor al,al
00003333  8B1E4306          mov bx,[0x643]
00003337  CD21              int 0x21
00003339  7300              jnc 0x333b
0000333B  C3                ret
0000333C  B8420A            mov ax,0xa42
0000333F  8EC0              mov es,ax
00003341  8D36C40A          lea si,[0xac4]
00003345  46                inc si
00003346  B035              mov al,0x35
00003348  268804            mov [es:si],al
0000334B  8B5E0C            mov bx,[bp+0xc]
0000334E  891E5F06          mov [0x65f],bx
00003352  1E                push ds
00003353  B8420A            mov ax,0xa42
00003356  8EC0              mov es,ax
00003358  8D363209          lea si,[0x932]
0000335C  8B460C            mov ax,[bp+0xc]
0000335F  D1E0              shl ax,1
00003361  03F0              add si,ax
00003363  268B04            mov ax,[es:si]
00003366  48                dec ax
00003367  BB420A            mov bx,0xa42
0000336A  8BCB              mov cx,bx
0000336C  8D3EA80A          lea di,[0xaa8]
00003370  BE0700            mov si,0x7
00003373  F7E6              mul si
00003375  03F8              add di,ax
00003377  803E720602        cmp byte [0x672],0x2
0000337C  7503              jnz 0x3381
0000337E  E98600            jmp 0x3407
00003381  803E720601        cmp byte [0x672],0x1
00003386  740C              jz 0x3394
00003388  B8420A            mov ax,0xa42
0000338B  8EC0              mov es,ax
0000338D  8D36D808          lea si,[0x8d8]
00003391  EB0A              jmp short 0x339d
00003393  90                nop
00003394  B8420A            mov ax,0xa42
00003397  8EC0              mov es,ax
00003399  8D360509          lea si,[0x905]
0000339D  8B460C            mov ax,[bp+0xc]
000033A0  03F0              add si,ax
000033A2  268A04            mov al,[es:si]
000033A5  803E720600        cmp byte [0x672],0x0
000033AA  7533              jnz 0x33df
000033AC  837E0C20          cmp word [bp+0xc],byte +0x20
000033B0  752D              jnz 0x33df
000033B2  803E710602        cmp byte [0x671],0x2
000033B7  7526              jnz 0x33df
000033B9  837E0A04          cmp word [bp+0xa],byte +0x4
000033BD  7D03              jnl 0x33c2
000033BF  EB07              jmp short 0x33c8
000033C1  90                nop
000033C2  837E0A09          cmp word [bp+0xa],byte +0x9
000033C6  7E17              jng 0x33df
000033C8  50                push ax
000033C9  06                push es
000033CA  56                push si
000033CB  B8420A            mov ax,0xa42
000033CE  8EC0              mov es,ax
000033D0  8D36C40A          lea si,[0xac4]
000033D4  46                inc si
000033D5  B037              mov al,0x37
000033D7  268804            mov [es:si],al
000033DA  5E                pop si
000033DB  07                pop es
000033DC  58                pop ax
000033DD  B002              mov al,0x2
000033DF  38067106          cmp [0x671],al
000033E3  7422              jz 0x3407
000033E5  57                push di
000033E6  51                push cx
000033E7  50                push ax
000033E8  3C01              cmp al,0x1
000033EA  7506              jnz 0x33f2
000033EC  B80800            mov ax,0x8
000033EF  EB0E              jmp short 0x33ff
000033F1  90                nop
000033F2  3C03              cmp al,0x3
000033F4  7506              jnz 0x33fc
000033F6  B80603            mov ax,0x306
000033F9  EB04              jmp short 0x33ff
000033FB  90                nop
000033FC  B80600            mov ax,0x6
000033FF  9A67135901        call 0x159:0x1367
00003404  58                pop ax
00003405  59                pop cx
00003406  5F                pop di
00003407  50                push ax
00003408  8ED9              mov ds,cx
0000340A  8BD7              mov dx,di
0000340C  B8803D            mov ax,0x3d80
0000340F  CD21              int 0x21
00003411  720C              jc 0x341f
00003413  8BD8              mov bx,ax
00003415  58                pop ax
00003416  1F                pop ds
00003417  A27106            mov [0x671],al
0000341A  891E4306          mov [0x643],bx
0000341E  C3                ret
0000341F  58                pop ax
00003420  1F                pop ds
00003421  C606710600        mov byte [0x671],0x0
00003426  E913FF            jmp 0x333c
00003429  55                push bp
0000342A  8BEC              mov bp,sp
0000342C  8BE9              mov bp,cx
0000342E  8B5E04            mov bx,[bp+0x4]
00003431  8B4606            mov ax,[bp+0x6]
00003434  E899FA            call 0x2ed0
00003437  50                push ax
00003438  53                push bx
00003439  B8803D            mov ax,0x3d80
0000343C  1E                push ds
0000343D  B9420A            mov cx,0xa42
00003440  8ED9              mov ds,cx
00003442  8D16D20A          lea dx,[0xad2]
00003446  CD21              int 0x21
00003448  7204              jc 0x344e
0000344A  1F                pop ds
0000344B  EB1D              jmp short 0x346a
0000344D  90                nop
0000344E  1F                pop ds
0000344F  803E720601        cmp byte [0x672],0x1
00003454  750A              jnz 0x3460
00003456  B80600            mov ax,0x6
00003459  9A67135901        call 0x159:0x1367
0000345E  EBD9              jmp short 0x3439
00003460  B80800            mov ax,0x8
00003463  9A67135901        call 0x159:0x1367
00003468  EBCF              jmp short 0x3439
0000346A  8BD8              mov bx,ax
0000346C  B43F              mov ah,0x3f
0000346E  B9A309            mov cx,0x9a3
00003471  8CDF              mov di,ds
00003473  5A                pop dx
00003474  1F                pop ds
00003475  57                push di
00003476  53                push bx
00003477  CD21              int 0x21
00003479  5B                pop bx
0000347A  1F                pop ds
0000347B  B43E              mov ah,0x3e
0000347D  CD21              int 0x21
0000347F  B8803D            mov ax,0x3d80
00003482  1E                push ds
00003483  BB420A            mov bx,0xa42
00003486  8EDB              mov ds,bx
00003488  8D16DB0A          lea dx,[0xadb]
0000348C  CD21              int 0x21
0000348E  8BD8              mov bx,ax
00003490  53                push bx
00003491  B43F              mov ah,0x3f
00003493  B97F03            mov cx,0x37f
00003496  BA420A            mov dx,0xa42
00003499  8EDA              mov ds,dx
0000349B  8D16E60A          lea dx,[0xae6]
0000349F  CD21              int 0x21
000034A1  5B                pop bx
000034A2  B43E              mov ah,0x3e
000034A4  CD21              int 0x21
000034A6  1F                pop ds
000034A7  8B5E04            mov bx,[bp+0x4]
000034AA  8B4606            mov ax,[bp+0x6]
000034AD  E820FA            call 0x2ed0
000034B0  1E                push ds
000034B1  8ED8              mov ds,ax
000034B3  8BF3              mov si,bx
000034B5  81C69B09          add si,0x99b
000034B9  BF420A            mov di,0xa42
000034BC  8EC7              mov es,di
000034BE  BF3528            mov di,0x2835
000034C1  B90800            mov cx,0x8
000034C4  F3A4              rep movsb
000034C6  1F                pop ds
000034C7  803E720600        cmp byte [0x672],0x0
000034CC  7507              jnz 0x34d5
000034CE  C606710601        mov byte [0x671],0x1
000034D3  5D                pop bp
000034D4  CB                retf
000034D5  C606710602        mov byte [0x671],0x2
000034DA  5D                pop bp
000034DB  CB                retf
000034DC  55                push bp
000034DD  8BEC              mov bp,sp
000034DF  C606270600        mov byte [0x627],0x0
000034E4  C606560600        mov byte [0x656],0x0
000034E9  C606730600        mov byte [0x673],0x0
000034EE  8BE9              mov bp,cx
000034F0  1E                push ds
000034F1  B8DB02            mov ax,0x2db
000034F4  8ED8              mov ds,ax
000034F6  8D3EF006          lea di,[0x6f0]
000034FA  1F                pop ds
000034FB  A3CA00            mov [0xca],ax
000034FE  893ECC00          mov [0xcc],di
00003502  C606280600        mov byte [0x628],0x0
00003507  C70694000000      mov word [0x94],0x0
0000350D  C7069600FCFF      mov word [0x96],0xfffc
00003513  1E                push ds
00003514  BA4000            mov dx,0x40
00003517  8E06BA00          mov es,[0xba]
0000351B  8B3EB800          mov di,[0xb8]
0000351F  33F6              xor si,si
00003521  8E1E9404          mov ds,[0x494]
00003525  B9A000            mov cx,0xa0
00003528  F3A5              rep movsw
0000352A  FECA              dec dl
0000352C  75F7              jnz 0x3525
0000352E  1F                pop ds
0000352F  8B5E00            mov bx,[bp+0x0]
00003532  8B4602            mov ax,[bp+0x2]
00003535  E898F9            call 0x2ed0
00003538  A39800            mov [0x98],ax
0000353B  891E9A00          mov [0x9a],bx
0000353F  8EC0              mov es,ax
00003541  8BF3              mov si,bx
00003543  A19400            mov ax,[0x94]
00003546  86E0              xchg ah,al
00003548  26894402          mov [es:si+0x2],ax
0000354C  A19600            mov ax,[0x96]
0000354F  86E0              xchg ah,al
00003551  26894404          mov [es:si+0x4],ax
00003555  83C61A            add si,byte +0x1a
00003558  33C0              xor ax,ax
0000355A  268904            mov [es:si],ax
0000355D  26884402          mov [es:si+0x2],al
00003561  1E                push ds
00003562  B8DB02            mov ax,0x2db
00003565  8ED8              mov ds,ax
00003567  8D16DE15          lea dx,[0x15de]
0000356B  B425              mov ah,0x25
0000356D  B024              mov al,0x24
0000356F  CD21              int 0x21
00003571  1F                pop ds
00003572  1E                push ds
00003573  B425              mov ah,0x25
00003575  B01C              mov al,0x1c
00003577  8B16CC00          mov dx,[0xcc]
0000357B  8E1ECA00          mov ds,[0xca]
0000357F  CD21              int 0x21
00003581  1F                pop ds
00003582  833E660100        cmp word [0x166],byte +0x0
00003587  7510              jnz 0x3599
00003589  33C0              xor ax,ax
0000358B  CD33              int 0x33
0000358D  0BC0              or ax,ax
0000358F  7408              jz 0x3599
00003591  E80700            call 0x359b
00003594  C606280601        mov byte [0x628],0x1
00003599  5D                pop bp
0000359A  CB                retf
0000359B  1E                push ds
0000359C  57                push di
0000359D  56                push si
0000359E  B80700            mov ax,0x7
000035A1  B90000            mov cx,0x0
000035A4  BA3F01            mov dx,0x13f
000035A7  CD33              int 0x33
000035A9  B80800            mov ax,0x8
000035AC  B90000            mov cx,0x0
000035AF  BAC700            mov dx,0xc7
000035B2  CD33              int 0x33
000035B4  B80400            mov ax,0x4
000035B7  8E069800          mov es,[0x98]
000035BB  8B369A00          mov si,[0x9a]
000035BF  8B0E9400          mov cx,[0x94]
000035C3  8B169600          mov dx,[0x96]
000035C7  CD33              int 0x33
000035C9  B81A00            mov ax,0x1a
000035CC  BB4000            mov bx,0x40
000035CF  B94000            mov cx,0x40
000035D2  BA7017            mov dx,0x1770
000035D5  CD33              int 0x33
000035D7  5E                pop si
000035D8  5F                pop di
000035D9  1F                pop ds
000035DA  C3                ret
000035DB  55                push bp
000035DC  8BEC              mov bp,sp
000035DE  FB                sti
000035DF  9AA6125901        call 0x159:0x12a6
000035E4  B001              mov al,0x1
000035E6  CF                iret
000035E7  55                push bp
000035E8  8BEC              mov bp,sp
000035EA  50                push ax
000035EB  53                push bx
000035EC  51                push cx
000035ED  52                push dx
000035EE  57                push di
000035EF  56                push si
000035F0  06                push es
000035F1  1E                push ds
000035F2  B8420A            mov ax,0xa42
000035F5  8ED8              mov ds,ax
000035F7  833E920405        cmp word [0x492],byte +0x5
000035FC  7403              jz 0x3601
000035FE  E9C401            jmp 0x37c5
00003601  803E480601        cmp byte [0x648],0x1
00003606  7503              jnz 0x360b
00003608  E91F01            jmp 0x372a
0000360B  C606480601        mov byte [0x648],0x1
00003610  A04706            mov al,[0x647]
00003613  1E                push ds
00003614  C60649063F        mov byte [0x649],0x3f
00003619  C6064A0601        mov byte [0x64a],0x1
0000361E  BB420A            mov bx,0xa42
00003621  8EDB              mov ds,bx
00003623  8D3E9E06          lea di,[0x69e]
00003627  3C02              cmp al,0x2
00003629  7407              jz 0x3632
0000362B  3C01              cmp al,0x1
0000362D  7406              jz 0x3635
0000362F  EB10              jmp short 0x3641
00003631  90                nop
00003632  83C720            add di,byte +0x20
00003635  B91000            mov cx,0x10
00003638  33C0              xor ax,ax
0000363A  8905              mov [di],ax
0000363C  83C702            add di,byte +0x2
0000363F  E2F9              loop 0x363a
00003641  8D36DE06          lea si,[0x6de]
00003645  8D3E9E06          lea di,[0x69e]
00003649  8D1E7606          lea bx,[0x676]
0000364D  32E4              xor ah,ah
0000364F  B110              mov cl,0x10
00003651  53                push bx
00003652  53                push bx
00003653  8A4520            mov al,[di+0x20]
00003656  2407              and al,0x7
00003658  03D8              add bx,ax
0000365A  8A07              mov al,[bx]
0000365C  8804              mov [si],al
0000365E  5B                pop bx
0000365F  53                push bx
00003660  8A05              mov al,[di]
00003662  2407              and al,0x7
00003664  03D8              add bx,ax
00003666  8A2F              mov ch,[bx]
00003668  5B                pop bx
00003669  886C30            mov [si+0x30],ch
0000366C  46                inc si
0000366D  47                inc di
0000366E  83C308            add bx,byte +0x8
00003671  8A4520            mov al,[di+0x20]
00003674  D0E8              shr al,1
00003676  D0E8              shr al,1
00003678  D0E8              shr al,1
0000367A  D0E8              shr al,1
0000367C  53                push bx
0000367D  03D8              add bx,ax
0000367F  8A07              mov al,[bx]
00003681  8804              mov [si],al
00003683  5B                pop bx
00003684  8A05              mov al,[di]
00003686  D0E8              shr al,1
00003688  D0E8              shr al,1
0000368A  D0E8              shr al,1
0000368C  D0E8              shr al,1
0000368E  53                push bx
0000368F  03D8              add bx,ax
00003691  8A2F              mov ch,[bx]
00003693  5B                pop bx
00003694  886C30            mov [si+0x30],ch
00003697  83C308            add bx,byte +0x8
0000369A  46                inc si
0000369B  8A4520            mov al,[di+0x20]
0000369E  2407              and al,0x7
000036A0  53                push bx
000036A1  03D8              add bx,ax
000036A3  8A07              mov al,[bx]
000036A5  8804              mov [si],al
000036A7  5B                pop bx
000036A8  53                push bx
000036A9  8A05              mov al,[di]
000036AB  2407              and al,0x7
000036AD  03D8              add bx,ax
000036AF  8A2F              mov ch,[bx]
000036B1  5B                pop bx
000036B2  886C30            mov [si+0x30],ch
000036B5  47                inc di
000036B6  46                inc si
000036B7  5B                pop bx
000036B8  FEC9              dec cl
000036BA  7402              jz 0x36be
000036BC  EB93              jmp short 0x3651
000036BE  8D3E8E06          lea di,[0x68e]
000036C2  8D1EDE06          lea bx,[0x6de]
000036C6  8D360E07          lea si,[0x70e]
000036CA  32ED              xor ch,ch
000036CC  B110              mov cl,0x10
000036CE  51                push cx
000036CF  32E4              xor ah,ah
000036D1  8A05              mov al,[di]
000036D3  B103              mov cl,0x3
000036D5  F6E1              mul cl
000036D7  8B0F              mov cx,[bx]
000036D9  83C302            add bx,byte +0x2
000036DC  8A37              mov dh,[bx]
000036DE  53                push bx
000036DF  8D1E3E07          lea bx,[0x73e]
000036E3  03D8              add bx,ax
000036E5  890F              mov [bx],cx
000036E7  83C302            add bx,byte +0x2
000036EA  8837              mov [bx],dh
000036EC  5B                pop bx
000036ED  43                inc bx
000036EE  32E4              xor ah,ah
000036F0  8A05              mov al,[di]
000036F2  B103              mov cl,0x3
000036F4  F6E1              mul cl
000036F6  8B0C              mov cx,[si]
000036F8  83C602            add si,byte +0x2
000036FB  8A34              mov dh,[si]
000036FD  56                push si
000036FE  8D366E07          lea si,[0x76e]
00003702  03F0              add si,ax
00003704  890C              mov [si],cx
00003706  83C602            add si,byte +0x2
00003709  8834              mov [si],dh
0000370B  5E                pop si
0000370C  46                inc si
0000370D  47                inc di
0000370E  59                pop cx
0000370F  E2BD              loop 0x36ce
00003711  1F                pop ds
00003712  BB420A            mov bx,0xa42
00003715  8EC3              mov es,bx
00003717  8D1E9E06          lea bx,[0x69e]
0000371B  B91000            mov cx,0x10
0000371E  268B07            mov ax,[es:bx]
00003721  26894720          mov [es:bx+0x20],ax
00003725  83C302            add bx,byte +0x2
00003728  E2F4              loop 0x371e
0000372A  A19204            mov ax,[0x492]
0000372D  3D0500            cmp ax,0x5
00003730  7403              jz 0x3735
00003732  EB7A              jmp short 0x37ae
00003734  90                nop
00003735  8A2E4906          mov ch,[0x649]
00003739  8A0E4A06          mov cl,[0x64a]
0000373D  1E                push ds
0000373E  BB420A            mov bx,0xa42
00003741  8EC3              mov es,bx
00003743  8D1E3E07          lea bx,[0x73e]
00003747  8D36DE06          lea si,[0x6de]
0000374B  B610              mov dh,0x10
0000374D  B203              mov dl,0x3
0000374F  32E4              xor ah,ah
00003751  268A07            mov al,[es:bx]
00003754  F6E5              mul ch
00003756  8BF8              mov di,ax
00003758  32E4              xor ah,ah
0000375A  268A4730          mov al,[es:bx+0x30]
0000375E  F6E1              mul cl
00003760  03C7              add ax,di
00003762  D1E8              shr ax,1
00003764  D1E8              shr ax,1
00003766  D1E8              shr ax,1
00003768  D1E8              shr ax,1
0000376A  D1E8              shr ax,1
0000376C  D1E8              shr ax,1
0000376E  268804            mov [es:si],al
00003771  46                inc si
00003772  43                inc bx
00003773  FECA              dec dl
00003775  75D8              jnz 0x374f
00003777  FECE              dec dh
00003779  75D2              jnz 0x374d
0000377B  FE0E4906          dec byte [0x649]
0000377F  FE064A06          inc byte [0x64a]
00003783  B8420A            mov ax,0xa42
00003786  8EC0              mov es,ax
00003788  8D1EDE06          lea bx,[0x6de]
0000378C  33C9              xor cx,cx
0000378E  BAC803            mov dx,0x3c8
00003791  8AC1              mov al,cl
00003793  EE                out dx,al
00003794  42                inc dx
00003795  268A07            mov al,[es:bx]
00003798  EE                out dx,al
00003799  268A4701          mov al,[es:bx+0x1]
0000379D  EE                out dx,al
0000379E  268A4702          mov al,[es:bx+0x2]
000037A2  EE                out dx,al
000037A3  83C303            add bx,byte +0x3
000037A6  41                inc cx
000037A7  4A                dec dx
000037A8  83F910            cmp cx,byte +0x10
000037AB  75E4              jnz 0x3791
000037AD  1F                pop ds
000037AE  FE064606          inc byte [0x646]
000037B2  A04506            mov al,[0x645]
000037B5  FEC0              inc al
000037B7  3A064606          cmp al,[0x646]
000037BB  755D              jnz 0x381a
000037BD  A19204            mov ax,[0x492]
000037C0  3D0500            cmp ax,0x5
000037C3  743C              jz 0x3801
000037C5  1E                push ds
000037C6  8E06DC00          mov es,[0xdc]
000037CA  8B3EDE00          mov di,[0xde]
000037CE  8B36F400          mov si,[0xf4]
000037D2  8E1EF200          mov ds,[0xf2]
000037D6  B91000            mov cx,0x10
000037D9  F3A5              rep movsw
000037DB  1F                pop ds
000037DC  1E                push ds
000037DD  8E067B01          mov es,[0x17b]
000037E1  8B3E7D01          mov di,[0x17d]
000037E5  8B367901          mov si,[0x179]
000037E9  8E1E7701          mov ds,[0x177]
000037ED  B91000            mov cx,0x10
000037F0  F3A4              rep movsb
000037F2  1F                pop ds
000037F3  1E                push ds
000037F4  833E920404        cmp word [0x492],byte +0x4
000037F9  7505              jnz 0x3800
000037FB  9A3B0C9304        call 0x493:0xc3b
00003800  1F                pop ds
00003801  C606480600        mov byte [0x648],0x0
00003806  C60649063F        mov byte [0x649],0x3f
0000380B  C6064A0601        mov byte [0x64a],0x1
00003810  C60645063F        mov byte [0x645],0x3f
00003815  C606460600        mov byte [0x646],0x0
0000381A  1F                pop ds
0000381B  07                pop es
0000381C  5E                pop si
0000381D  5F                pop di
0000381E  5A                pop dx
0000381F  59                pop cx
00003820  5B                pop bx
00003821  58                pop ax
00003822  5D                pop bp
00003823  CB                retf
00003824  55                push bp
00003825  8BEC              mov bp,sp
00003827  1E                push ds
00003828  06                push es
00003829  56                push si
0000382A  57                push di
0000382B  52                push dx
0000382C  1E                push ds
0000382D  51                push cx
0000382E  53                push bx
0000382F  8EC0              mov es,ax
00003831  8BF3              mov si,bx
00003833  B8420A            mov ax,0xa42
00003836  8ED8              mov ds,ax
00003838  8D3E9E06          lea di,[0x69e]
0000383C  E85F00            call 0x389e
0000383F  5E                pop si
00003840  59                pop cx
00003841  80F901            cmp cl,0x1
00003844  743C              jz 0x3882
00003846  80F904            cmp cl,0x4
00003849  751D              jnz 0x3868
0000384B  56                push si
0000384C  8D3E9E07          lea di,[0x79e]
00003850  E84B00            call 0x389e
00003853  5E                pop si
00003854  56                push si
00003855  8D3EBE07          lea di,[0x7be]
00003859  E84200            call 0x389e
0000385C  5E                pop si
0000385D  8D3EDE07          lea di,[0x7de]
00003861  E83A00            call 0x389e
00003864  1F                pop ds
00003865  EB30              jmp short 0x3897
00003867  90                nop
00003868  56                push si
00003869  8D3E9E07          lea di,[0x79e]
0000386D  E82E00            call 0x389e
00003870  5E                pop si
00003871  83EE42            sub si,byte +0x42
00003874  8D3EBE07          lea di,[0x7be]
00003878  E82300            call 0x389e
0000387B  8D3EDE07          lea di,[0x7de]
0000387F  E81C00            call 0x389e
00003882  1F                pop ds
00003883  8B3E4D06          mov di,[0x64d]
00003887  8E1E4B06          mov ds,[0x64b]
0000388B  B8420A            mov ax,0xa42
0000388E  8EC0              mov es,ax
00003890  8D369E06          lea si,[0x69e]
00003894  E80700            call 0x389e
00003897  5A                pop dx
00003898  5F                pop di
00003899  5E                pop si
0000389A  07                pop es
0000389B  1F                pop ds
0000389C  5D                pop bp
0000389D  CB                retf
0000389E  B91000            mov cx,0x10
000038A1  268B04            mov ax,[es:si]
000038A4  8905              mov [di],ax
000038A6  83C702            add di,byte +0x2
000038A9  83C602            add si,byte +0x2
000038AC  E2F3              loop 0x38a1
000038AE  C3                ret
000038AF  55                push bp
000038B0  8BEC              mov bp,sp
000038B2  51                push cx
000038B3  8BE9              mov bp,cx
000038B5  8B4604            mov ax,[bp+0x4]
000038B8  9A08004207        call 0x742:0x8
000038BD  59                pop cx
000038BE  8BE9              mov bp,cx
000038C0  B8420A            mov ax,0xa42
000038C3  8EC0              mov es,ax
000038C5  8D369E06          lea si,[0x69e]
000038C9  C606470600        mov byte [0x647],0x0
000038CE  8B4600            mov ax,[bp+0x0]
000038D1  8B5E08            mov bx,[bp+0x8]
000038D4  8B4604            mov ax,[bp+0x4]
000038D7  D1E8              shr ax,1
000038D9  B118              mov cl,0x18
000038DB  F6F9              idiv cl
000038DD  86E0              xchg ah,al
000038DF  32E4              xor ah,ah
000038E1  3D0800            cmp ax,0x8
000038E4  7D0B              jnl 0x38f1
000038E6  3D0600            cmp ax,0x6
000038E9  7C1C              jl 0x3907
000038EB  E81E00            call 0x390c
000038EE  EB1A              jmp short 0x390a
000038F0  90                nop
000038F1  3D1200            cmp ax,0x12
000038F4  7D06              jnl 0x38fc
000038F6  E84F00            call 0x3948
000038F9  EB0F              jmp short 0x390a
000038FB  90                nop
000038FC  3D1400            cmp ax,0x14
000038FF  7D06              jnl 0x3907
00003901  E80800            call 0x390c
00003904  EB04              jmp short 0x390a
00003906  90                nop
00003907  E87700            call 0x3981
0000390A  5D                pop bp
0000390B  CB                retf
0000390C  B91000            mov cx,0x10
0000390F  268B842001        mov ax,[es:si+0x120]
00003914  268904            mov [es:si],ax
00003917  83C602            add si,byte +0x2
0000391A  E2F3              loop 0x390f
0000391C  833E920405        cmp word [0x492],byte +0x5
00003921  7421              jz 0x3944
00003923  8B367101          mov si,[0x171]
00003927  83C620            add si,byte +0x20
0000392A  E8BE00            call 0x39eb
0000392D  8B366D01          mov si,[0x16d]
00003931  E8CB00            call 0x39ff
00003934  9AE715DB02        call 0x2db:0x15e7
00003939  833E5F0623        cmp word [0x65f],byte +0x23
0000393E  7407              jz 0x3947
00003940  E88EF7            call 0x30d1
00003943  C3                ret
00003944  E87600            call 0x39bd
00003947  C3                ret
00003948  B91000            mov cx,0x10
0000394B  268B840001        mov ax,[es:si+0x100]
00003950  268904            mov [es:si],ax
00003953  83C602            add si,byte +0x2
00003956  E2F3              loop 0x394b
00003958  833E920405        cmp word [0x492],byte +0x5
0000395D  741E              jz 0x397d
0000395F  8B367101          mov si,[0x171]
00003963  E88500            call 0x39eb
00003966  8B366D01          mov si,[0x16d]
0000396A  E89200            call 0x39ff
0000396D  9AE715DB02        call 0x2db:0x15e7
00003972  833E5F0623        cmp word [0x65f],byte +0x23
00003977  7407              jz 0x3980
00003979  E855F7            call 0x30d1
0000397C  C3                ret
0000397D  E83D00            call 0x39bd
00003980  C3                ret
00003981  B91000            mov cx,0x10
00003984  268B844001        mov ax,[es:si+0x140]
00003989  268904            mov [es:si],ax
0000398C  83C602            add si,byte +0x2
0000398F  E2F3              loop 0x3984
00003991  833E920405        cmp word [0x492],byte +0x5
00003996  7421              jz 0x39b9
00003998  8B367101          mov si,[0x171]
0000399C  83C620            add si,byte +0x20
0000399F  E84900            call 0x39eb
000039A2  8B366D01          mov si,[0x16d]
000039A6  E85600            call 0x39ff
000039A9  9AE715DB02        call 0x2db:0x15e7
000039AE  833E5F0623        cmp word [0x65f],byte +0x23
000039B3  7407              jz 0x39bc
000039B5  E819F7            call 0x30d1
000039B8  C3                ret
000039B9  E80100            call 0x39bd
000039BC  C3                ret
000039BD  B94000            mov cx,0x40
000039C0  C606480600        mov byte [0x648],0x0
000039C5  51                push cx
000039C6  9AE715DB02        call 0x2db:0x15e7
000039CB  B9204E            mov cx,0x4e20
000039CE  E2FE              loop 0x39ce
000039D0  59                pop cx
000039D1  E2F2              loop 0x39c5
000039D3  A19204            mov ax,[0x492]
000039D6  3C05              cmp al,0x5
000039D8  740A              jz 0x39e4
000039DA  833E5F0623        cmp word [0x65f],byte +0x23
000039DF  7403              jz 0x39e4
000039E1  E8EDF6            call 0x30d1
000039E4  C3                ret
000039E5  B8420A            mov ax,0xa42
000039E8  8ED8              mov ds,ax
000039EA  C3                ret
000039EB  1E                push ds
000039EC  8B3EF400          mov di,[0xf4]
000039F0  8E06F200          mov es,[0xf2]
000039F4  8E1E6F01          mov ds,[0x16f]
000039F8  B91000            mov cx,0x10
000039FB  F3A5              rep movsw
000039FD  1F                pop ds
000039FE  C3                ret
000039FF  1E                push ds
00003A00  8B3E7901          mov di,[0x179]
00003A04  8E067701          mov es,[0x177]
00003A08  8E1E6B01          mov ds,[0x16b]
00003A0C  B91000            mov cx,0x10
00003A0F  F3A4              rep movsb
00003A11  1F                pop ds
00003A12  C3                ret
00003A13  55                push bp
00003A14  8BEC              mov bp,sp
00003A16  8BE9              mov bp,cx
00003A18  8B4608            mov ax,[bp+0x8]
00003A1B  8B5E04            mov bx,[bp+0x4]
00003A1E  8B4606            mov ax,[bp+0x6]
00003A21  E8ACF4            call 0x2ed0
00003A24  A34B06            mov [0x64b],ax
00003A27  891E4D06          mov [0x64d],bx
00003A2B  8EC0              mov es,ax
00003A2D  8BF3              mov si,bx
00003A2F  B8420A            mov ax,0xa42
00003A32  8ED8              mov ds,ax
00003A34  8D3E9E07          lea di,[0x79e]
00003A38  8B460C            mov ax,[bp+0xc]
00003A3B  D1E8              shr ax,1
00003A3D  B118              mov cl,0x18
00003A3F  F6F9              idiv cl
00003A41  86E0              xchg ah,al
00003A43  32E4              xor ah,ah
00003A45  3D0800            cmp ax,0x8
00003A48  7D0B              jnl 0x3a55
00003A4A  3D0600            cmp ax,0x6
00003A4D  7C1C              jl 0x3a6b
00003A4F  E83E00            call 0x3a90
00003A52  EB1A              jmp short 0x3a6e
00003A54  90                nop
00003A55  3D1200            cmp ax,0x12
00003A58  7D06              jnl 0x3a60
00003A5A  E81300            call 0x3a70
00003A5D  EB0F              jmp short 0x3a6e
00003A5F  90                nop
00003A60  3D1400            cmp ax,0x14
00003A63  7D06              jnl 0x3a6b
00003A65  E82800            call 0x3a90
00003A68  EB04              jmp short 0x3a6e
00003A6A  90                nop
00003A6B  E84800            call 0x3ab6
00003A6E  5D                pop bp
00003A6F  CB                retf
00003A70  833E920405        cmp word [0x492],byte +0x5
00003A75  7412              jz 0x3a89
00003A77  E86BFF            call 0x39e5
00003A7A  8B367101          mov si,[0x171]
00003A7E  E86AFF            call 0x39eb
00003A81  8B366D01          mov si,[0x16d]
00003A85  E877FF            call 0x39ff
00003A88  C3                ret
00003A89  E85000            call 0x3adc
00003A8C  E86200            call 0x3af1
00003A8F  C3                ret
00003A90  83C720            add di,byte +0x20
00003A93  833E920405        cmp word [0x492],byte +0x5
00003A98  7415              jz 0x3aaf
00003A9A  E848FF            call 0x39e5
00003A9D  8B367101          mov si,[0x171]
00003AA1  83C620            add si,byte +0x20
00003AA4  E844FF            call 0x39eb
00003AA7  8B366D01          mov si,[0x16d]
00003AAB  E851FF            call 0x39ff
00003AAE  C3                ret
00003AAF  E82A00            call 0x3adc
00003AB2  E83C00            call 0x3af1
00003AB5  C3                ret
00003AB6  83C740            add di,byte +0x40
00003AB9  833E920405        cmp word [0x492],byte +0x5
00003ABE  7415              jz 0x3ad5
00003AC0  E822FF            call 0x39e5
00003AC3  8B367101          mov si,[0x171]
00003AC7  83C620            add si,byte +0x20
00003ACA  E81EFF            call 0x39eb
00003ACD  8B366D01          mov si,[0x16d]
00003AD1  E82BFF            call 0x39ff
00003AD4  C3                ret
00003AD5  E80400            call 0x3adc
00003AD8  E81600            call 0x3af1
00003ADB  C3                ret
00003ADC  1E                push ds
00003ADD  57                push di
00003ADE  B91000            mov cx,0x10
00003AE1  8B05              mov ax,[di]
00003AE3  268904            mov [es:si],ax
00003AE6  83C602            add si,byte +0x2
00003AE9  83C702            add di,byte +0x2
00003AEC  E2F3              loop 0x3ae1
00003AEE  5F                pop di
00003AEF  1F                pop ds
00003AF0  C3                ret
00003AF1  B8420A            mov ax,0xa42
00003AF4  8EC0              mov es,ax
00003AF6  8D369E06          lea si,[0x69e]
00003AFA  E8DFFF            call 0x3adc
00003AFD  C3                ret
00003AFE  9AE715DB02        call 0x2db:0x15e7
00003B03  E2F9              loop 0x3afe
00003B05  C3                ret
00003B06  9A2418DB02        call 0x2db:0x1824
00003B0B  C3                ret
00003B0C  55                push bp
00003B0D  8BEC              mov bp,sp
00003B0F  803E720600        cmp byte [0x672],0x0
00003B14  743C              jz 0x3b52
00003B16  C606730601        mov byte [0x673],0x1
00003B1B  803E610601        cmp byte [0x661],0x1
00003B20  7407              jz 0x3b29
00003B22  803E610602        cmp byte [0x661],0x2
00003B27  7529              jnz 0x3b52
00003B29  FA                cli
00003B2A  B8420A            mov ax,0xa42
00003B2D  A36506            mov [0x665],ax
00003B30  8D1EE60A          lea bx,[0xae6]
00003B34  891E6706          mov [0x667],bx
00003B38  891E6906          mov [0x669],bx
00003B3C  8EC0              mov es,ax
00003B3E  268A07            mov al,[es:bx]
00003B41  32E4              xor ah,ah
00003B43  B112              mov cl,0x12
00003B45  F6E1              mul cl
00003B47  A36306            mov [0x663],ax
00003B4A  C606610601        mov byte [0x661],0x1
00003B4F  FB                sti
00003B50  EB05              jmp short 0x3b57
00003B52  C606610600        mov byte [0x661],0x0
00003B57  5D                pop bp
00003B58  CB                retf
00003B59  55                push bp
00003B5A  8BEC              mov bp,sp
00003B5C  1E                push ds
00003B5D  B8DB02            mov ax,0x2db
00003B60  8ED8              mov ds,ax
00003B62  8D3E1905          lea di,[0x519]
00003B66  1F                pop ds
00003B67  A3B000            mov [0xb0],ax
00003B6A  893EB200          mov [0xb2],di
00003B6E  1E                push ds
00003B6F  B425              mov ah,0x25
00003B71  B009              mov al,0x9
00003B73  8B16B200          mov dx,[0xb2]
00003B77  8E1EB000          mov ds,[0xb0]
00003B7B  CD21              int 0x21
00003B7D  1F                pop ds
00003B7E  5D                pop bp
00003B7F  CB                retf
00003B80  55                push bp
00003B81  8BEC              mov bp,sp
00003B83  1E                push ds
00003B84  55                push bp
00003B85  81EC1601          sub sp,0x116
00003B89  C786F0FE0000      mov word [bp-0x110],0x0
00003B8F  803E200601        cmp byte [0x620],0x1
00003B94  7534              jnz 0x3bca
00003B96  A19404            mov ax,[0x494]
00003B99  8986F2FE          mov [bp-0x10e],ax
00003B9D  8B460A            mov ax,[bp+0xa]
00003BA0  8EC0              mov es,ax
00003BA2  33F6              xor si,si
00003BA4  B9005F            mov cx,0x5f00
00003BA7  1E                push ds
00003BA8  57                push di
00003BA9  8B4606            mov ax,[bp+0x6]
00003BAC  8ED8              mov ds,ax
00003BAE  8B7E08            mov di,[bp+0x8]
00003BB1  8A05              mov al,[di]
00003BB3  0AC0              or al,al
00003BB5  740B              jz 0x3bc2
00003BB7  83C702            add di,byte +0x2
00003BBA  8A05              mov al,[di]
00003BBC  268804            mov [es:si],al
00003BBF  46                inc si
00003BC0  E2FA              loop 0x3bbc
00003BC2  5F                pop di
00003BC3  1F                pop ds
00003BC4  C786F0FEFFFF      mov word [bp-0x110],0xffff
00003BCA  8CD8              mov ax,ds
00003BCC  8986ECFE          mov [bp-0x114],ax
00003BD0  33C0              xor ax,ax
00003BD2  8986EEFE          mov [bp-0x112],ax
00003BD6  8B4606            mov ax,[bp+0x6]
00003BD9  8ED8              mov ds,ax
00003BDB  8B7608            mov si,[bp+0x8]
00003BDE  33C0              xor ax,ax
00003BE0  8946CE            mov [bp-0x32],ax
00003BE3  8946CC            mov [bp-0x34],ax
00003BE6  8A04              mov al,[si]
00003BE8  46                inc si
00003BE9  8A24              mov ah,[si]
00003BEB  46                inc si
00003BEC  8866FE            mov [bp-0x2],ah
00003BEF  0AC0              or al,al
00003BF1  750B              jnz 0x3bfe
00003BF3  B5FF              mov ch,0xff
00003BF5  886EFF            mov [bp-0x1],ch
00003BF8  83C620            add si,byte +0x20
00003BFB  EB08              jmp short 0x3c05
00003BFD  90                nop
00003BFE  8A2C              mov ch,[si]
00003C00  886EFF            mov [bp-0x1],ch
00003C03  46                inc si
00003C04  46                inc si
00003C05  8B4404            mov ax,[si+0x4]
00003C08  86E0              xchg ah,al
00003C0A  8946CA            mov [bp-0x36],ax
00003C0D  8B4406            mov ax,[si+0x6]
00003C10  86E0              xchg ah,al
00003C12  8946C8            mov [bp-0x38],ax
00003C15  56                push si
00003C16  8A4EFE            mov cl,[bp-0x2]
00003C19  32ED              xor ch,ch
00003C1B  8B4404            mov ax,[si+0x4]
00003C1E  86E0              xchg ah,al
00003C20  3946CA            cmp [bp-0x36],ax
00003C23  7203              jc 0x3c28
00003C25  8946CA            mov [bp-0x36],ax
00003C28  8B4406            mov ax,[si+0x6]
00003C2B  86E0              xchg ah,al
00003C2D  3946C8            cmp [bp-0x38],ax
00003C30  7203              jc 0x3c35
00003C32  8946C8            mov [bp-0x38],ax
00003C35  8B04              mov ax,[si]
00003C37  86E0              xchg ah,al
00003C39  8B5C02            mov bx,[si+0x2]
00003C3C  86FB              xchg bh,bl
00003C3E  03C3              add ax,bx
00003C40  A90100            test ax,0x1
00003C43  7401              jz 0x3c46
00003C45  40                inc ax
00003C46  03F0              add si,ax
00003C48  83C60E            add si,byte +0xe
00003C4B  E2CE              loop 0x3c1b
00003C4D  5E                pop si
00003C4E  8B04              mov ax,[si]
00003C50  86E0              xchg ah,al
00003C52  8946FC            mov [bp-0x4],ax
00003C55  8B4402            mov ax,[si+0x2]
00003C58  86E0              xchg ah,al
00003C5A  8946FA            mov [bp-0x6],ax
00003C5D  8B4404            mov ax,[si+0x4]
00003C60  86E0              xchg ah,al
00003C62  03460C            add ax,[bp+0xc]
00003C65  8946F8            mov [bp-0x8],ax
00003C68  8B4406            mov ax,[si+0x6]
00003C6B  86E0              xchg ah,al
00003C6D  03460E            add ax,[bp+0xe]
00003C70  8946F6            mov [bp-0xa],ax
00003C73  83C608            add si,byte +0x8
00003C76  8B04              mov ax,[si]
00003C78  86E0              xchg ah,al
00003C7A  8946F4            mov [bp-0xc],ax
00003C7D  8B5402            mov dx,[si+0x2]
00003C80  86F2              xchg dh,dl
00003C82  42                inc dx
00003C83  8996F4FE          mov [bp-0x10c],dx
00003C87  8956F2            mov [bp-0xe],dx
00003C8A  8B5404            mov dx,[si+0x4]
00003C8D  86F2              xchg dh,dl
00003C8F  42                inc dx
00003C90  8956F0            mov [bp-0x10],dx
00003C93  8996F6FE          mov [bp-0x10a],dx
00003C97  E8EF08            call 0x4589
00003C9A  83C606            add si,byte +0x6
00003C9D  33FF              xor di,di
00003C9F  897EEA            mov [bp-0x16],di
00003CA2  897EE8            mov [bp-0x18],di
00003CA5  0AE4              or ah,ah
00003CA7  7503              jnz 0x3cac
00003CA9  E97401            jmp 0x3e20
00003CAC  BB0100            mov bx,0x1
00003CAF  83BEF0FE00        cmp word [bp-0x110],byte +0x0
00003CB4  7407              jz 0x3cbd
00003CB6  8B96F2FE          mov dx,[bp-0x10e]
00003CBA  EB04              jmp short 0x3cc0
00003CBC  90                nop
00003CBD  8B560A            mov dx,[bp+0xa]
00003CC0  81C2A00F          add dx,0xfa0
00003CC4  8EC2              mov es,dx
00003CC6  A801              test al,0x1
00003CC8  7515              jnz 0x3cdf
00003CCA  8B4EFC            mov cx,[bp-0x4]
00003CCD  D1E1              shl cx,1
00003CCF  E80D05            call 0x41df
00003CD2  268811            mov [es:bx+di],dl
00003CD5  47                inc di
00003CD6  89BEEEFE          mov [bp-0x112],di
00003CDA  E2F3              loop 0x3ccf
00003CDC  EB43              jmp short 0x3d21
00003CDE  90                nop
00003CDF  E8DF04            call 0x41c1
00003CE2  8946EE            mov [bp-0x12],ax
00003CE5  E8D904            call 0x41c1
00003CE8  8946EC            mov [bp-0x14],ax
00003CEB  8A46EB            mov al,[bp-0x15]
00003CEE  50                push ax
00003CEF  FF76E8            push word [bp-0x18]
00003CF2  56                push si
00003CF3  5E                pop si
00003CF4  8F46E8            pop word [bp-0x18]
00003CF7  58                pop ax
00003CF8  8846EB            mov [bp-0x15],al
00003CFB  50                push ax
00003CFC  FF76E8            push word [bp-0x18]
00003CFF  56                push si
00003D00  8B4EEC            mov cx,[bp-0x14]
00003D03  E8D904            call 0x41df
00003D06  268811            mov [es:bx+di],dl
00003D09  47                inc di
00003D0A  89BEEEFE          mov [bp-0x112],di
00003D0E  E2F3              loop 0x3d03
00003D10  FF4EEE            dec word [bp-0x12]
00003D13  75DE              jnz 0x3cf3
00003D15  83C406            add sp,byte +0x6
00003D18  8B46FC            mov ax,[bp-0x4]
00003D1B  48                dec ax
00003D1C  3946E8            cmp [bp-0x18],ax
00003D1F  72BE              jc 0x3cdf
00003D21  8A46EB            mov al,[bp-0x15]
00003D24  0AC0              or al,al
00003D26  7406              jz 0x3d2e
00003D28  46                inc si
00003D29  32C0              xor al,al
00003D2B  8846EB            mov [bp-0x15],al
00003D2E  8B46FC            mov ax,[bp-0x4]
00003D31  0346FA            add ax,[bp-0x6]
00003D34  250100            and ax,0x1
00003D37  7401              jz 0x3d3a
00003D39  46                inc si
00003D3A  8B9EEEFE          mov bx,[bp-0x112]
00003D3E  43                inc bx
00003D3F  33FF              xor di,di
00003D41  897EE8            mov [bp-0x18],di
00003D44  8A46F4            mov al,[bp-0xc]
00003D47  2402              and al,0x2
00003D49  750F              jnz 0x3d5a
00003D4B  8B4EFA            mov cx,[bp-0x6]
00003D4E  8A04              mov al,[si]
00003D50  46                inc si
00003D51  268801            mov [es:bx+di],al
00003D54  47                inc di
00003D55  E2F7              loop 0x3d4e
00003D57  EB3E              jmp short 0x3d97
00003D59  90                nop
00003D5A  E86404            call 0x41c1
00003D5D  8946EE            mov [bp-0x12],ax
00003D60  E85E04            call 0x41c1
00003D63  8946EC            mov [bp-0x14],ax
00003D66  0146E8            add [bp-0x18],ax
00003D69  8A46EB            mov al,[bp-0x15]
00003D6C  A801              test al,0x1
00003D6E  7409              jz 0x3d79
00003D70  46                inc si
00003D71  FF46E8            inc word [bp-0x18]
00003D74  32C0              xor al,al
00003D76  8846EB            mov [bp-0x15],al
00003D79  8BC6              mov ax,si
00003D7B  8BF0              mov si,ax
00003D7D  8B4EEC            mov cx,[bp-0x14]
00003D80  8A14              mov dl,[si]
00003D82  46                inc si
00003D83  268811            mov [es:bx+di],dl
00003D86  47                inc di
00003D87  E2F7              loop 0x3d80
00003D89  FF4EEE            dec word [bp-0x12]
00003D8C  75ED              jnz 0x3d7b
00003D8E  8B46FA            mov ax,[bp-0x6]
00003D91  48                dec ax
00003D92  3946E8            cmp [bp-0x18],ax
00003D95  72C3              jc 0x3d5a
00003D97  90                nop
00003D98  8A46EB            mov al,[bp-0x15]
00003D9B  0AC0              or al,al
00003D9D  7401              jz 0x3da0
00003D9F  46                inc si
00003DA0  8976D4            mov [bp-0x2c],si
00003DA3  06                push es
00003DA4  1F                pop ds
00003DA5  8B460A            mov ax,[bp+0xa]
00003DA8  8EC0              mov es,ax
00003DAA  8B7EF8            mov di,[bp-0x8]
00003DAD  89BEF8FE          mov [bp-0x108],di
00003DB1  BB4001            mov bx,0x140
00003DB4  8B46F6            mov ax,[bp-0xa]
00003DB7  8986FAFE          mov [bp-0x106],ax
00003DBB  F7E3              mul bx
00003DBD  03F8              add di,ax
00003DBF  BB0100            mov bx,0x1
00003DC2  4B                dec bx
00003DC3  8BB6EEFE          mov si,[bp-0x112]
00003DC7  46                inc si
00003DC8  33C0              xor ax,ax
00003DCA  8946E6            mov [bp-0x1a],ax
00003DCD  8946E8            mov [bp-0x18],ax
00003DD0  8946EA            mov [bp-0x16],ax
00003DD3  8A46F5            mov al,[bp-0xb]
00003DD6  8AE0              mov ah,al
00003DD8  D0E0              shl al,1
00003DDA  02C4              add al,ah
00003DDC  32E4              xor ah,ah
00003DDE  E83900            call 0x3e1a
00003DE1  EB3D              jmp short 0x3e20
00003DE3  90                nop
00003DE4  E98800            jmp 0x3e6f
00003DE7  E9C900            jmp 0x3eb3
00003DEA  E9FC00            jmp 0x3ee9
00003DED  E90401            jmp 0x3ef4
00003DF0  E90C01            jmp 0x3eff
00003DF3  E91401            jmp 0x3f0a
00003DF6  E91C01            jmp 0x3f15
00003DF9  E94401            jmp 0x3f40
00003DFC  E96101            jmp 0x3f60
00003DFF  E96901            jmp 0x3f6b
00003E02  E97101            jmp 0x3f76
00003E05  E96702            jmp 0x406f
00003E08  E98802            jmp 0x4093
00003E0B  E9AC02            jmp 0x40ba
00003E0E  E9CA02            jmp 0x40db
00003E11  E9EE02            jmp 0x4102
00003E14  E90F03            jmp 0x4126
00003E17  E93303            jmp 0x414d
00003E1A  59                pop cx
00003E1B  03C8              add cx,ax
00003E1D  0E                push cs
00003E1E  51                push cx
00003E1F  C3                ret
00003E20  8B460A            mov ax,[bp+0xa]
00003E23  8EC0              mov es,ax
00003E25  8B7EF8            mov di,[bp-0x8]
00003E28  BB4001            mov bx,0x140
00003E2B  8B46F6            mov ax,[bp-0xa]
00003E2E  F7E3              mul bx
00003E30  03F8              add di,ax
00003E32  8976D4            mov [bp-0x2c],si
00003E35  8B46F0            mov ax,[bp-0x10]
00003E38  8B4EF2            mov cx,[bp-0xe]
00003E3B  57                push di
00003E3C  E8A003            call 0x41df
00003E3F  3A56FF            cmp dl,[bp-0x1]
00003E42  7403              jz 0x3e47
00003E44  268815            mov [es:di],dl
00003E47  47                inc di
00003E48  E2F2              loop 0x3e3c
00003E4A  8B4EF2            mov cx,[bp-0xe]
00003E4D  83E101            and cx,byte +0x1
00003E50  7403              jz 0x3e55
00003E52  E88A03            call 0x41df
00003E55  5F                pop di
00003E56  81C74001          add di,0x140
00003E5A  48                dec ax
00003E5B  75DB              jnz 0x3e38
00003E5D  8B46D4            mov ax,[bp-0x2c]
00003E60  0346FC            add ax,[bp-0x4]
00003E63  A90100            test ax,0x1
00003E66  7401              jz 0x3e69
00003E68  40                inc ax
00003E69  8946D4            mov [bp-0x2c],ax
00003E6C  E90503            jmp 0x4174
00003E6F  8B46F0            mov ax,[bp-0x10]
00003E72  8B4EF2            mov cx,[bp-0xe]
00003E75  E88C03            call 0x4204
00003E78  3A56FF            cmp dl,[bp-0x1]
00003E7B  7403              jz 0x3e80
00003E7D  268815            mov [es:di],dl
00003E80  47                inc di
00003E81  E2F2              loop 0x3e75
00003E83  8B4EF2            mov cx,[bp-0xe]
00003E86  83E101            and cx,byte +0x1
00003E89  7406              jz 0x3e91
00003E8B  E87603            call 0x4204
00003E8E  E87303            call 0x4204
00003E91  81C74001          add di,0x140
00003E95  48                dec ax
00003E96  7418              jz 0x3eb0
00003E98  8B4EF2            mov cx,[bp-0xe]
00003E9B  E86603            call 0x4204
00003E9E  4F                dec di
00003E9F  3A56FF            cmp dl,[bp-0x1]
00003EA2  7403              jz 0x3ea7
00003EA4  268815            mov [es:di],dl
00003EA7  E2F2              loop 0x3e9b
00003EA9  81C74001          add di,0x140
00003EAD  48                dec ax
00003EAE  75C2              jnz 0x3e72
00003EB0  E9C102            jmp 0x4174
00003EB3  8B46F2            mov ax,[bp-0xe]
00003EB6  8B4EF0            mov cx,[bp-0x10]
00003EB9  E84803            call 0x4204
00003EBC  3A56FF            cmp dl,[bp-0x1]
00003EBF  7403              jz 0x3ec4
00003EC1  268815            mov [es:di],dl
00003EC4  81C74001          add di,0x140
00003EC8  E2EF              loop 0x3eb9
00003ECA  47                inc di
00003ECB  48                dec ax
00003ECC  7418              jz 0x3ee6
00003ECE  8B4EF0            mov cx,[bp-0x10]
00003ED1  E83003            call 0x4204
00003ED4  81EF4001          sub di,0x140
00003ED8  3A56FF            cmp dl,[bp-0x1]
00003EDB  7403              jz 0x3ee0
00003EDD  268815            mov [es:di],dl
00003EE0  E2EF              loop 0x3ed1
00003EE2  47                inc di
00003EE3  48                dec ax
00003EE4  75D0              jnz 0x3eb6
00003EE6  E98B02            jmp 0x4174
00003EE9  C746E40200        mov word [bp-0x1c],0x2
00003EEE  E88704            call 0x4378
00003EF1  E98002            jmp 0x4174
00003EF4  C746E40200        mov word [bp-0x1c],0x2
00003EF9  E89205            call 0x448e
00003EFC  E97502            jmp 0x4174
00003EFF  C746E40300        mov word [bp-0x1c],0x3
00003F04  E87104            call 0x4378
00003F07  E96A02            jmp 0x4174
00003F0A  C746E40400        mov word [bp-0x1c],0x4
00003F0F  E87C05            call 0x448e
00003F12  E95F02            jmp 0x4174
00003F15  8B46F0            mov ax,[bp-0x10]
00003F18  57                push di
00003F19  8B4EF2            mov cx,[bp-0xe]
00003F1C  E8E502            call 0x4204
00003F1F  3A56FF            cmp dl,[bp-0x1]
00003F22  7403              jz 0x3f27
00003F24  268815            mov [es:di],dl
00003F27  47                inc di
00003F28  E2F2              loop 0x3f1c
00003F2A  8B4EF2            mov cx,[bp-0xe]
00003F2D  83E101            and cx,byte +0x1
00003F30  7403              jz 0x3f35
00003F32  E8CF02            call 0x4204
00003F35  5F                pop di
00003F36  81C74001          add di,0x140
00003F3A  48                dec ax
00003F3B  75DB              jnz 0x3f18
00003F3D  E93402            jmp 0x4174
00003F40  8B46F2            mov ax,[bp-0xe]
00003F43  57                push di
00003F44  8B4EF0            mov cx,[bp-0x10]
00003F47  E8BA02            call 0x4204
00003F4A  3A56FF            cmp dl,[bp-0x1]
00003F4D  7403              jz 0x3f52
00003F4F  268815            mov [es:di],dl
00003F52  81C74001          add di,0x140
00003F56  E2EF              loop 0x3f47
00003F58  5F                pop di
00003F59  47                inc di
00003F5A  48                dec ax
00003F5B  75E6              jnz 0x3f43
00003F5D  E91402            jmp 0x4174
00003F60  C746E40400        mov word [bp-0x1c],0x4
00003F65  E81004            call 0x4378
00003F68  E90902            jmp 0x4174
00003F6B  C746E40600        mov word [bp-0x1c],0x6
00003F70  E80504            call 0x4378
00003F73  E9FE01            jmp 0x4174
00003F76  33C0              xor ax,ax
00003F78  8946DA            mov [bp-0x26],ax
00003F7B  8946D8            mov [bp-0x28],ax
00003F7E  C746E24001        mov word [bp-0x1e],0x140
00003F83  C746DEFFFF        mov word [bp-0x22],0xffff
00003F88  FF4EF2            dec word [bp-0xe]
00003F8B  FF4EF0            dec word [bp-0x10]
00003F8E  EB73              jmp short 0x4003
00003F90  90                nop
00003F91  E87002            call 0x4204
00003F94  3A56FF            cmp dl,[bp-0x1]
00003F97  7403              jz 0x3f9c
00003F99  268815            mov [es:di],dl
00003F9C  E8DB02            call 0x427a
00003F9F  8B46DA            mov ax,[bp-0x26]
00003FA2  0BC0              or ax,ax
00003FA4  7411              jz 0x3fb7
00003FA6  8B46D8            mov ax,[bp-0x28]
00003FA9  3B46F2            cmp ax,[bp-0xe]
00003FAC  7422              jz 0x3fd0
00003FAE  40                inc ax
00003FAF  8946D8            mov [bp-0x28],ax
00003FB2  FF4EDA            dec word [bp-0x26]
00003FB5  EBDA              jmp short 0x3f91
00003FB7  E86A02            call 0x4224
00003FBA  E87202            call 0x422f
00003FBD  8B46D8            mov ax,[bp-0x28]
00003FC0  3B46F2            cmp ax,[bp-0xe]
00003FC3  7431              jz 0x3ff6
00003FC5  40                inc ax
00003FC6  8946D8            mov [bp-0x28],ax
00003FC9  81C74001          add di,0x140
00003FCD  EB34              jmp short 0x4003
00003FCF  90                nop
00003FD0  81C74001          add di,0x140
00003FD4  FF46DA            inc word [bp-0x26]
00003FD7  E84A02            call 0x4224
00003FDA  E85202            call 0x422f
00003FDD  E89A02            call 0x427a
00003FE0  E82102            call 0x4204
00003FE3  3A56FF            cmp dl,[bp-0x1]
00003FE6  7403              jz 0x3feb
00003FE8  268815            mov [es:di],dl
00003FEB  8B46DA            mov ax,[bp-0x26]
00003FEE  3B46F0            cmp ax,[bp-0x10]
00003FF1  7436              jz 0x4029
00003FF3  EB19              jmp short 0x400e
00003FF5  90                nop
00003FF6  E88102            call 0x427a
00003FF9  81C74001          add di,0x140
00003FFD  FF46DA            inc word [bp-0x26]
00004000  EB01              jmp short 0x4003
00004002  90                nop
00004003  E8FE01            call 0x4204
00004006  3A56FF            cmp dl,[bp-0x1]
00004009  7403              jz 0x400e
0000400B  268815            mov [es:di],dl
0000400E  E86902            call 0x427a
00004011  8B46D8            mov ax,[bp-0x28]
00004014  0BC0              or ax,ax
00004016  7414              jz 0x402c
00004018  8B46DA            mov ax,[bp-0x26]
0000401B  3B46F0            cmp ax,[bp-0x10]
0000401E  7422              jz 0x4042
00004020  40                inc ax
00004021  8946DA            mov [bp-0x26],ax
00004024  FF4ED8            dec word [bp-0x28]
00004027  EBDA              jmp short 0x4003
00004029  E94801            jmp 0x4174
0000402C  E8F501            call 0x4224
0000402F  E8FD01            call 0x422f
00004032  8B46DA            mov ax,[bp-0x26]
00004035  3B46F0            cmp ax,[bp-0x10]
00004038  742B              jz 0x4065
0000403A  40                inc ax
0000403B  8946DA            mov [bp-0x26],ax
0000403E  47                inc di
0000403F  E94FFF            jmp 0x3f91
00004042  E8DF01            call 0x4224
00004045  E8E701            call 0x422f
00004048  E82F02            call 0x427a
0000404B  47                inc di
0000404C  FF46D8            inc word [bp-0x28]
0000404F  E8B201            call 0x4204
00004052  3A56FF            cmp dl,[bp-0x1]
00004055  7403              jz 0x405a
00004057  268815            mov [es:di],dl
0000405A  8B46D8            mov ax,[bp-0x28]
0000405D  3B46F2            cmp ax,[bp-0xe]
00004060  74C7              jz 0x4029
00004062  E937FF            jmp 0x3f9c
00004065  E81202            call 0x427a
00004068  47                inc di
00004069  FF46D8            inc word [bp-0x28]
0000406C  E922FF            jmp 0x3f91
0000406F  E80105            call 0x4573
00004072  B80100            mov ax,0x1
00004075  8946E4            mov [bp-0x1c],ax
00004078  8946DE            mov [bp-0x22],ax
0000407B  B84001            mov ax,0x140
0000407E  8946E2            mov [bp-0x1e],ax
00004081  8B46F0            mov ax,[bp-0x10]
00004084  8946E0            mov [bp-0x20],ax
00004087  8B46F2            mov ax,[bp-0xe]
0000408A  8946DC            mov [bp-0x24],ax
0000408D  E8F101            call 0x4281
00004090  E9E100            jmp 0x4174
00004093  E8DD04            call 0x4573
00004096  8B46F2            mov ax,[bp-0xe]
00004099  8946E4            mov [bp-0x1c],ax
0000409C  B80100            mov ax,0x1
0000409F  8946E2            mov [bp-0x1e],ax
000040A2  8B46F2            mov ax,[bp-0xe]
000040A5  8946E0            mov [bp-0x20],ax
000040A8  B84001            mov ax,0x140
000040AB  8946DE            mov [bp-0x22],ax
000040AE  8B46F0            mov ax,[bp-0x10]
000040B1  8946DC            mov [bp-0x24],ax
000040B4  E8CA01            call 0x4281
000040B7  E9BA00            jmp 0x4174
000040BA  B80100            mov ax,0x1
000040BD  8946E4            mov [bp-0x1c],ax
000040C0  8946E2            mov [bp-0x1e],ax
000040C3  8B46F2            mov ax,[bp-0xe]
000040C6  8946E0            mov [bp-0x20],ax
000040C9  B84001            mov ax,0x140
000040CC  8946DE            mov [bp-0x22],ax
000040CF  8B46F0            mov ax,[bp-0x10]
000040D2  8946DC            mov [bp-0x24],ax
000040D5  E8A901            call 0x4281
000040D8  E99900            jmp 0x4174
000040DB  E89504            call 0x4573
000040DE  B80200            mov ax,0x2
000040E1  8946E4            mov [bp-0x1c],ax
000040E4  B84001            mov ax,0x140
000040E7  8946E2            mov [bp-0x1e],ax
000040EA  8B46F0            mov ax,[bp-0x10]
000040ED  8946E0            mov [bp-0x20],ax
000040F0  B80100            mov ax,0x1
000040F3  8946DE            mov [bp-0x22],ax
000040F6  8B46F2            mov ax,[bp-0xe]
000040F9  8946DC            mov [bp-0x24],ax
000040FC  E88201            call 0x4281
000040FF  EB73              jmp short 0x4174
00004101  90                nop
00004102  B80300            mov ax,0x3
00004105  8946E4            mov [bp-0x1c],ax
00004108  B80100            mov ax,0x1
0000410B  8946E2            mov [bp-0x1e],ax
0000410E  8B46F2            mov ax,[bp-0xe]
00004111  8946E0            mov [bp-0x20],ax
00004114  B84001            mov ax,0x140
00004117  8946DE            mov [bp-0x22],ax
0000411A  8B46F0            mov ax,[bp-0x10]
0000411D  8946DC            mov [bp-0x24],ax
00004120  E85E01            call 0x4281
00004123  EB4F              jmp short 0x4174
00004125  90                nop
00004126  E84A04            call 0x4573
00004129  B80300            mov ax,0x3
0000412C  8946E4            mov [bp-0x1c],ax
0000412F  B84001            mov ax,0x140
00004132  8946E2            mov [bp-0x1e],ax
00004135  8B46F0            mov ax,[bp-0x10]
00004138  8946E0            mov [bp-0x20],ax
0000413B  B80100            mov ax,0x1
0000413E  8946DE            mov [bp-0x22],ax
00004141  8B46F2            mov ax,[bp-0xe]
00004144  8946DC            mov [bp-0x24],ax
00004147  E83701            call 0x4281
0000414A  EB28              jmp short 0x4174
0000414C  90                nop
0000414D  E82304            call 0x4573
00004150  B80500            mov ax,0x5
00004153  8946E4            mov [bp-0x1c],ax
00004156  B84001            mov ax,0x140
00004159  8946E2            mov [bp-0x1e],ax
0000415C  8B46F0            mov ax,[bp-0x10]
0000415F  8946E0            mov [bp-0x20],ax
00004162  B80100            mov ax,0x1
00004165  8946DE            mov [bp-0x22],ax
00004168  8B46F2            mov ax,[bp-0xe]
0000416B  8946DC            mov [bp-0x24],ax
0000416E  E81001            call 0x4281
00004171  EB01              jmp short 0x4174
00004173  90                nop
00004174  FE4EFE            dec byte [bp-0x2]
00004177  740B              jz 0x4184
00004179  8B76D4            mov si,[bp-0x2c]
0000417C  8B4606            mov ax,[bp+0x6]
0000417F  8ED8              mov ds,ax
00004181  E9CAFA            jmp 0x3c4e
00004184  8B86ECFE          mov ax,[bp-0x114]
00004188  8ED8              mov ds,ax
0000418A  8B46CE            mov ax,[bp-0x32]
0000418D  8B46CC            mov ax,[bp-0x34]
00004190  8B46CA            mov ax,[bp-0x36]
00004193  8B46C8            mov ax,[bp-0x38]
00004196  8BE5              mov sp,bp
00004198  83EC02            sub sp,byte +0x2
0000419B  1F                pop ds
0000419C  8B86ECFE          mov ax,[bp-0x114]
000041A0  8ED8              mov ds,ax
000041A2  833E200600        cmp word [0x620],byte +0x0
000041A7  7406              jz 0x41af
000041A9  8A46FF            mov al,[bp-0x1]
000041AC  A27D0E            mov [0xe7d],al
000041AF  8B86F4FE          mov ax,[bp-0x10c]
000041B3  8B96F6FE          mov dx,[bp-0x10a]
000041B7  8B8EF8FE          mov cx,[bp-0x108]
000041BB  8B9EFAFE          mov bx,[bp-0x106]
000041BF  5D                pop bp
000041C0  CB                retf
000041C1  33C0              xor ax,ax
000041C3  E81900            call 0x41df
000041C6  80FA0F            cmp dl,0xf
000041C9  7511              jnz 0x41dc
000041CB  E81100            call 0x41df
000041CE  03C2              add ax,dx
000041D0  80FA0F            cmp dl,0xf
000041D3  74F6              jz 0x41cb
000041D5  B20F              mov dl,0xf
000041D7  F6E2              mul dl
000041D9  E80300            call 0x41df
000041DC  03C2              add ax,dx
000041DE  C3                ret
000041DF  8A14              mov dl,[si]
000041E1  8A76EB            mov dh,[bp-0x15]
000041E4  0AF6              or dh,dh
000041E6  740C              jz 0x41f4
000041E8  80E20F            and dl,0xf
000041EB  46                inc si
000041EC  FF46E8            inc word [bp-0x18]
000041EF  32F6              xor dh,dh
000041F1  EB0B              jmp short 0x41fe
000041F3  90                nop
000041F4  D0EA              shr dl,1
000041F6  D0EA              shr dl,1
000041F8  D0EA              shr dl,1
000041FA  D0EA              shr dl,1
000041FC  F6D6              not dh
000041FE  8876EB            mov [bp-0x15],dh
00004201  32F6              xor dh,dh
00004203  C3                ret
00004204  8B56E6            mov dx,[bp-0x1a]
00004207  0BD2              or dx,dx
00004209  7409              jz 0x4214
0000420B  4A                dec dx
0000420C  8956E6            mov [bp-0x1a],dx
0000420F  8A17              mov dl,[bx]
00004211  32F6              xor dh,dh
00004213  C3                ret
00004214  E8C8FF            call 0x41df
00004217  32F6              xor dh,dh
00004219  0156E6            add [bp-0x1a],dx
0000421C  80FA0F            cmp dl,0xf
0000421F  74F3              jz 0x4214
00004221  43                inc bx
00004222  EBE0              jmp short 0x4204
00004224  50                push ax
00004225  8B46DE            mov ax,[bp-0x22]
00004228  F7D8              neg ax
0000422A  8946DE            mov [bp-0x22],ax
0000422D  58                pop ax
0000422E  C3                ret
0000422F  50                push ax
00004230  8B46E2            mov ax,[bp-0x1e]
00004233  F7D8              neg ax
00004235  8946E2            mov [bp-0x1e],ax
00004238  58                pop ax
00004239  C3                ret
0000423A  8B46E2            mov ax,[bp-0x1e]
0000423D  8B56E4            mov dx,[bp-0x1c]
00004240  42                inc dx
00004241  0156DA            add [bp-0x26],dx
00004244  F7E2              mul dx
00004246  03F8              add di,ax
00004248  C3                ret
00004249  8B4EE4            mov cx,[bp-0x1c]
0000424C  41                inc cx
0000424D  014EDA            add [bp-0x26],cx
00004250  E8B1FF            call 0x4204
00004253  3A56FF            cmp dl,[bp-0x1]
00004256  7403              jz 0x425b
00004258  268815            mov [es:di],dl
0000425B  037EE2            add di,[bp-0x1e]
0000425E  E2F0              loop 0x4250
00004260  50                push ax
00004261  8B46E0            mov ax,[bp-0x20]
00004264  2B46DA            sub ax,[bp-0x26]
00004267  740E              jz 0x4277
00004269  8B4EE4            mov cx,[bp-0x1c]
0000426C  41                inc cx
0000426D  3BC1              cmp ax,cx
0000426F  7304              jnc 0x4275
00004271  48                dec ax
00004272  8946E4            mov [bp-0x1c],ax
00004275  58                pop ax
00004276  C3                ret
00004277  58                pop ax
00004278  58                pop ax
00004279  C3                ret
0000427A  037EDE            add di,[bp-0x22]
0000427D  037EE2            add di,[bp-0x1e]
00004280  C3                ret
00004281  C786FEFEFFFF      mov word [bp-0x102],0xffff
00004287  80BEFCFEFF        cmp byte [bp-0x104],0xff
0000428C  750A              jnz 0x4298
0000428E  57                push di
0000428F  037EF2            add di,[bp-0xe]
00004292  4F                dec di
00004293  89BEFEFE          mov [bp-0x102],di
00004297  5F                pop di
00004298  33C0              xor ax,ax
0000429A  8946DA            mov [bp-0x26],ax
0000429D  8946D8            mov [bp-0x28],ax
000042A0  FF4EDC            dec word [bp-0x24]
000042A3  E8BAFF            call 0x4260
000042A6  8B4EE4            mov cx,[bp-0x1c]
000042A9  41                inc cx
000042AA  E877FF            call 0x4224
000042AD  E854FF            call 0x4204
000042B0  3A56FF            cmp dl,[bp-0x1]
000042B3  7403              jz 0x42b8
000042B5  268815            mov [es:di],dl
000042B8  E869FF            call 0x4224
000042BB  E8BCFF            call 0x427a
000042BE  E2ED              loop 0x42ad
000042C0  E86CFF            call 0x422f
000042C3  037EE2            add di,[bp-0x1e]
000042C6  8B4EE4            mov cx,[bp-0x1c]
000042C9  41                inc cx
000042CA  E837FF            call 0x4204
000042CD  3A56FF            cmp dl,[bp-0x1]
000042D0  7403              jz 0x42d5
000042D2  268815            mov [es:di],dl
000042D5  E84CFF            call 0x4224
000042D8  E89FFF            call 0x427a
000042DB  E2ED              loop 0x42ca
000042DD  E844FF            call 0x4224
000042E0  E84CFF            call 0x422f
000042E3  E894FF            call 0x427a
000042E6  FF46D8            inc word [bp-0x28]
000042E9  8B46D8            mov ax,[bp-0x28]
000042EC  40                inc ax
000042ED  3946DC            cmp [bp-0x24],ax
000042F0  7306              jnc 0x42f8
000042F2  E845FF            call 0x423a
000042F5  EB15              jmp short 0x430c
000042F7  90                nop
000042F8  037EDE            add di,[bp-0x22]
000042FB  8946D8            mov [bp-0x28],ax
000042FE  40                inc ax
000042FF  3946DC            cmp [bp-0x24],ax
00004302  7306              jnc 0x430a
00004304  E842FF            call 0x4249
00004307  EB03              jmp short 0x430c
00004309  90                nop
0000430A  EB9A              jmp short 0x42a6
0000430C  E851FF            call 0x4260
0000430F  8B4EE4            mov cx,[bp-0x1c]
00004312  41                inc cx
00004313  E8EEFE            call 0x4204
00004316  3A56FF            cmp dl,[bp-0x1]
00004319  7403              jz 0x431e
0000431B  268815            mov [es:di],dl
0000431E  E803FF            call 0x4224
00004321  E856FF            call 0x427a
00004324  E2ED              loop 0x4313
00004326  E806FF            call 0x422f
00004329  037EE2            add di,[bp-0x1e]
0000432C  8B4EE4            mov cx,[bp-0x1c]
0000432F  41                inc cx
00004330  E8D1FE            call 0x4204
00004333  3A56FF            cmp dl,[bp-0x1]
00004336  7403              jz 0x433b
00004338  268815            mov [es:di],dl
0000433B  E8E6FE            call 0x4224
0000433E  E839FF            call 0x427a
00004341  E2ED              loop 0x4330
00004343  E8DEFE            call 0x4224
00004346  E8E6FE            call 0x422f
00004349  E82EFF            call 0x427a
0000434C  FF4ED8            dec word [bp-0x28]
0000434F  8B46D8            mov ax,[bp-0x28]
00004352  0BC0              or ax,ax
00004354  7410              jz 0x4366
00004356  037EDE            add di,[bp-0x22]
00004359  48                dec ax
0000435A  8946D8            mov [bp-0x28],ax
0000435D  0BC0              or ax,ax
0000435F  740E              jz 0x436f
00004361  E8C0FE            call 0x4224
00004364  EBA9              jmp short 0x430f
00004366  E8D1FE            call 0x423a
00004369  E8B8FE            call 0x4224
0000436C  E934FF            jmp 0x42a3
0000436F  E8D7FE            call 0x4249
00004372  E8AFFE            call 0x4224
00004375  E92BFF            jmp 0x42a3
00004378  E8F801            call 0x4573
0000437B  8B46F0            mov ax,[bp-0x10]
0000437E  48                dec ax
0000437F  B94001            mov cx,0x140
00004382  F7E1              mul cx
00004384  0346F2            add ax,[bp-0xe]
00004387  03C7              add ax,di
00004389  8946D0            mov [bp-0x30],ax
0000438C  8B46E4            mov ax,[bp-0x1c]
0000438F  48                dec ax
00004390  F7E1              mul cx
00004392  03C7              add ax,di
00004394  3B46D0            cmp ax,[bp-0x30]
00004397  7206              jc 0x439f
00004399  FF4EE4            dec word [bp-0x1c]
0000439C  75EE              jnz 0x438c
0000439E  C3                ret
0000439F  8B4EF2            mov cx,[bp-0xe]
000043A2  51                push cx
000043A3  50                push ax
000043A4  8BC1              mov ax,cx
000043A6  8B4EE4            mov cx,[bp-0x1c]
000043A9  E858FE            call 0x4204
000043AC  3A56FF            cmp dl,[bp-0x1]
000043AF  7403              jz 0x43b4
000043B1  268815            mov [es:di],dl
000043B4  81C74001          add di,0x140
000043B8  E2EF              loop 0x43a9
000043BA  58                pop ax
000043BB  59                pop cx
000043BC  47                inc di
000043BD  49                dec cx
000043BE  7503              jnz 0x43c3
000043C0  E9A000            jmp 0x4463
000043C3  51                push cx
000043C4  50                push ax
000043C5  8BC1              mov ax,cx
000043C7  8B4EE4            mov cx,[bp-0x1c]
000043CA  E837FE            call 0x4204
000043CD  81EF4001          sub di,0x140
000043D1  80BEFCFEFF        cmp byte [bp-0x104],0xff
000043D6  7504              jnz 0x43dc
000043D8  3C01              cmp al,0x1
000043DA  7408              jz 0x43e4
000043DC  3A56FF            cmp dl,[bp-0x1]
000043DF  7403              jz 0x43e4
000043E1  268815            mov [es:di],dl
000043E4  E2E4              loop 0x43ca
000043E6  58                pop ax
000043E7  59                pop cx
000043E8  49                dec cx
000043E9  7503              jnz 0x43ee
000043EB  E98B00            jmp 0x4479
000043EE  47                inc di
000043EF  EBB1              jmp short 0x43a2
000043F1  51                push cx
000043F2  50                push ax
000043F3  8BC1              mov ax,cx
000043F5  8B4EE4            mov cx,[bp-0x1c]
000043F8  E809FE            call 0x4204
000043FB  80BEFCFEFF        cmp byte [bp-0x104],0xff
00004400  7505              jnz 0x4407
00004402  3B46F2            cmp ax,[bp-0xe]
00004405  7408              jz 0x440f
00004407  3A56FF            cmp dl,[bp-0x1]
0000440A  7403              jz 0x440f
0000440C  268815            mov [es:di],dl
0000440F  81C74001          add di,0x140
00004413  E2E3              loop 0x43f8
00004415  58                pop ax
00004416  59                pop cx
00004417  4F                dec di
00004418  49                dec cx
00004419  742C              jz 0x4447
0000441B  51                push cx
0000441C  50                push ax
0000441D  8BC1              mov ax,cx
0000441F  8B4EE4            mov cx,[bp-0x1c]
00004422  E8DFFD            call 0x4204
00004425  81EF4001          sub di,0x140
00004429  3A56FF            cmp dl,[bp-0x1]
0000442C  7403              jz 0x4431
0000442E  268815            mov [es:di],dl
00004431  E2EF              loop 0x4422
00004433  4F                dec di
00004434  58                pop ax
00004435  59                pop cx
00004436  49                dec cx
00004437  75B8              jnz 0x43f1
00004439  B94001            mov cx,0x140
0000443C  47                inc di
0000443D  8B46E4            mov ax,[bp-0x1c]
00004440  F7E1              mul cx
00004442  03F8              add di,ax
00004444  E945FF            jmp 0x438c
00004447  B94001            mov cx,0x140
0000444A  47                inc di
0000444B  8B46E4            mov ax,[bp-0x1c]
0000444E  48                dec ax
0000444F  F7E1              mul cx
00004451  03C7              add ax,di
00004453  3B46D0            cmp ax,[bp-0x30]
00004456  7303              jnc 0x445b
00004458  E944FF            jmp 0x439f
0000445B  E93BFF            jmp 0x4399
0000445E  8B4EF2            mov cx,[bp-0xe]
00004461  EB8E              jmp short 0x43f1
00004463  B94001            mov cx,0x140
00004466  8B46E4            mov ax,[bp-0x1c]
00004469  48                dec ax
0000446A  F7E1              mul cx
0000446C  03C7              add ax,di
0000446E  3B46D0            cmp ax,[bp-0x30]
00004471  72EB              jc 0x445e
00004473  FF4EE4            dec word [bp-0x1c]
00004476  75EE              jnz 0x4466
00004478  C3                ret
00004479  B94001            mov cx,0x140
0000447C  8B46E4            mov ax,[bp-0x1c]
0000447F  F7E1              mul cx
00004481  03F8              add di,ax
00004483  2BC1              sub ax,cx
00004485  03C7              add ax,di
00004487  3946D0            cmp [bp-0x30],ax
0000448A  73D2              jnc 0x445e
0000448C  EBE5              jmp short 0x4473
0000448E  33C0              xor ax,ax
00004490  8946D8            mov [bp-0x28],ax
00004493  8B46F0            mov ax,[bp-0x10]
00004496  48                dec ax
00004497  B94001            mov cx,0x140
0000449A  F7E1              mul cx
0000449C  0346F2            add ax,[bp-0xe]
0000449F  03C7              add ax,di
000044A1  8946D0            mov [bp-0x30],ax
000044A4  8B4EF0            mov cx,[bp-0x10]
000044A7  8B46D8            mov ax,[bp-0x28]
000044AA  0346E4            add ax,[bp-0x1c]
000044AD  3B46F2            cmp ax,[bp-0xe]
000044B0  7606              jna 0x44b8
000044B2  FF4EE4            dec word [bp-0x1c]
000044B5  75F0              jnz 0x44a7
000044B7  C3                ret
000044B8  51                push cx
000044B9  8B4EE4            mov cx,[bp-0x1c]
000044BC  014ED8            add [bp-0x28],cx
000044BF  E842FD            call 0x4204
000044C2  3A56FF            cmp dl,[bp-0x1]
000044C5  7403              jz 0x44ca
000044C7  268815            mov [es:di],dl
000044CA  47                inc di
000044CB  E2F2              loop 0x44bf
000044CD  59                pop cx
000044CE  49                dec cx
000044CF  7423              jz 0x44f4
000044D1  81C74001          add di,0x140
000044D5  51                push cx
000044D6  8B4EE4            mov cx,[bp-0x1c]
000044D9  294ED8            sub [bp-0x28],cx
000044DC  E825FD            call 0x4204
000044DF  4F                dec di
000044E0  3A56FF            cmp dl,[bp-0x1]
000044E3  7403              jz 0x44e8
000044E5  268815            mov [es:di],dl
000044E8  E2F2              loop 0x44dc
000044EA  59                pop cx
000044EB  49                dec cx
000044EC  7461              jz 0x454f
000044EE  81C74001          add di,0x140
000044F2  EBC4              jmp short 0x44b8
000044F4  8B4EF0            mov cx,[bp-0x10]
000044F7  8B46D8            mov ax,[bp-0x28]
000044FA  0346E4            add ax,[bp-0x1c]
000044FD  3946F2            cmp [bp-0xe],ax
00004500  7306              jnc 0x4508
00004502  FF4EE4            dec word [bp-0x1c]
00004505  75F0              jnz 0x44f7
00004507  C3                ret
00004508  51                push cx
00004509  8B4EE4            mov cx,[bp-0x1c]
0000450C  014ED8            add [bp-0x28],cx
0000450F  E8F2FC            call 0x4204
00004512  3A56FF            cmp dl,[bp-0x1]
00004515  7403              jz 0x451a
00004517  268815            mov [es:di],dl
0000451A  47                inc di
0000451B  E2F2              loop 0x450f
0000451D  59                pop cx
0000451E  49                dec cx
0000451F  7483              jz 0x44a4
00004521  81EF4001          sub di,0x140
00004525  51                push cx
00004526  8B4EE4            mov cx,[bp-0x1c]
00004529  294ED8            sub [bp-0x28],cx
0000452C  E8D5FC            call 0x4204
0000452F  4F                dec di
00004530  3A56FF            cmp dl,[bp-0x1]
00004533  7403              jz 0x4538
00004535  268815            mov [es:di],dl
00004538  E2F2              loop 0x452c
0000453A  59                pop cx
0000453B  49                dec cx
0000453C  7406              jz 0x4544
0000453E  81EF4001          sub di,0x140
00004542  EBC4              jmp short 0x4508
00004544  8B46E4            mov ax,[bp-0x1c]
00004547  03F8              add di,ax
00004549  0146D8            add [bp-0x28],ax
0000454C  E955FF            jmp 0x44a4
0000454F  8B46E4            mov ax,[bp-0x1c]
00004552  03F8              add di,ax
00004554  0146D8            add [bp-0x28],ax
00004557  EB9B              jmp short 0x44f4
00004559  56                push si
0000455A  50                push ax
0000455B  8BB6EEFE          mov si,[bp-0x112]
0000455F  46                inc si
00004560  8A04              mov al,[si]
00004562  46                inc si
00004563  3CFF              cmp al,0xff
00004565  74F9              jz 0x4560
00004567  4E                dec si
00004568  3CFE              cmp al,0xfe
0000456A  7404              jz 0x4570
0000456C  FEC0              inc al
0000456E  8804              mov [si],al
00004570  58                pop ax
00004571  5E                pop si
00004572  C3                ret
00004573  C686FCFE00        mov byte [bp-0x104],0x0
00004578  8B46F2            mov ax,[bp-0xe]
0000457B  250100            and ax,0x1
0000457E  7408              jz 0x4588
00004580  FF46F2            inc word [bp-0xe]
00004583  C686FCFEFF        mov byte [bp-0x104],0xff
00004588  C3                ret
00004589  8B56F6            mov dx,[bp-0xa]
0000458C  0BD2              or dx,dx
0000458E  7506              jnz 0x4596
00004590  8B56F2            mov dx,[bp-0xe]
00004593  0156CE            add [bp-0x32],dx
00004596  8B56F8            mov dx,[bp-0x8]
00004599  0BD2              or dx,dx
0000459B  7506              jnz 0x45a3
0000459D  8B56F0            mov dx,[bp-0x10]
000045A0  0156CC            add [bp-0x34],dx
000045A3  C3                ret
000045A4  55                push bp
000045A5  8BEC              mov bp,sp
000045A7  8BE9              mov bp,cx
000045A9  8B4606            mov ax,[bp+0x6]
000045AC  A3700E            mov [0xe70],ax
000045AF  B10C              mov cl,0xc
000045B1  D3E0              shl ax,cl
000045B3  8B7604            mov si,[bp+0x4]
000045B6  8936720E          mov [0xe72],si
000045BA  B104              mov cl,0x4
000045BC  D3EE              shr si,cl
000045BE  03C6              add ax,si
000045C0  8EC0              mov es,ax
000045C2  8B7604            mov si,[bp+0x4]
000045C5  83E60F            and si,byte +0xf
000045C8  BA420A            mov dx,0xa42
000045CB  8EDA              mov ds,dx
000045CD  8D3E8A0E          lea di,[0xe8a]
000045D1  8A05              mov al,[di]
000045D3  0AC0              or al,al
000045D5  7505              jnz 0x45dc
000045D7  56                push si
000045D8  E83200            call 0x460d
000045DB  5E                pop si
000045DC  8B4E00            mov cx,[bp+0x0]
000045DF  81F9C700          cmp cx,0xc7
000045E3  7506              jnz 0x45eb
000045E5  E84C00            call 0x4634
000045E8  EB0D              jmp short 0x45f7
000045EA  90                nop
000045EB  81F9C800          cmp cx,0xc8
000045EF  7506              jnz 0x45f7
000045F1  E86100            call 0x4655
000045F4  EB01              jmp short 0x45f7
000045F6  90                nop
000045F7  D1E1              shl cx,1
000045F9  03F1              add si,cx
000045FB  268B0C            mov cx,[es:si]
000045FE  86E9              xchg ch,cl
00004600  8B4604            mov ax,[bp+0x4]
00004603  8B5606            mov dx,[bp+0x6]
00004606  03C1              add ax,cx
00004608  7301              jnc 0x460b
0000460A  42                inc dx
0000460B  5D                pop bp
0000460C  CB                retf
0000460D  268B14            mov dx,[es:si]
00004610  86F2              xchg dh,dl
00004612  8BCA              mov cx,dx
00004614  83E902            sub cx,byte +0x2
00004617  D1E9              shr cx,1
00004619  83C602            add si,byte +0x2
0000461C  268B04            mov ax,[es:si]
0000461F  86E0              xchg ah,al
00004621  03D0              add dx,ax
00004623  86F2              xchg dh,dl
00004625  268914            mov [es:si],dx
00004628  86F2              xchg dh,dl
0000462A  83C602            add si,byte +0x2
0000462D  E2ED              loop 0x461c
0000462F  B0FF              mov al,0xff
00004631  8805              mov [di],al
00004633  C3                ret
00004634  1E                push ds
00004635  06                push es
00004636  57                push di
00004637  56                push si
00004638  51                push cx
00004639  50                push ax
0000463A  B8420A            mov ax,0xa42
0000463D  8ED8              mov ds,ax
0000463F  8E06770E          mov es,[0xe77]
00004643  8B3E750E          mov di,[0xe75]
00004647  8D36DF0E          lea si,[0xedf]
0000464B  E82800            call 0x4676
0000464E  58                pop ax
0000464F  59                pop cx
00004650  5E                pop si
00004651  5F                pop di
00004652  07                pop es
00004653  1F                pop ds
00004654  C3                ret
00004655  1E                push ds
00004656  06                push es
00004657  57                push di
00004658  56                push si
00004659  51                push cx
0000465A  50                push ax
0000465B  B8420A            mov ax,0xa42
0000465E  8ED8              mov ds,ax
00004660  8E06770E          mov es,[0xe77]
00004664  8B3E750E          mov di,[0xe75]
00004668  8D36BF0E          lea si,[0xebf]
0000466C  E80700            call 0x4676
0000466F  58                pop ax
00004670  59                pop cx
00004671  5E                pop si
00004672  5F                pop di
00004673  07                pop es
00004674  1F                pop ds
00004675  C3                ret
00004676  1E                push ds
00004677  B8420A            mov ax,0xa42
0000467A  8ED8              mov ds,ax
0000467C  B91000            mov cx,0x10
0000467F  F3A5              rep movsw
00004681  1F                pop ds
00004682  1E                push ds
00004683  8E06F200          mov es,[0xf2]
00004687  8B3EF400          mov di,[0xf4]
0000468B  8B36750E          mov si,[0xe75]
0000468F  8E1E770E          mov ds,[0xe77]
00004693  B91000            mov cx,0x10
00004696  F3A5              rep movsw
00004698  1F                pop ds
00004699  1E                push ds
0000469A  8E067B0E          mov es,[0xe7b]
0000469E  8B3E790E          mov di,[0xe79]
000046A2  8D36FF0E          lea si,[0xeff]
000046A6  B8420A            mov ax,0xa42
000046A9  8ED8              mov ds,ax
000046AB  B91000            mov cx,0x10
000046AE  F3A4              rep movsb
000046B0  1F                pop ds
000046B1  1E                push ds
000046B2  8E067B01          mov es,[0x17b]
000046B6  8B3E7D01          mov di,[0x17d]
000046BA  8B36790E          mov si,[0xe79]
000046BE  8E1E7B0E          mov ds,[0xe7b]
000046C2  B91000            mov cx,0x10
000046C5  F3A4              rep movsb
000046C7  1F                pop ds
000046C8  C3                ret
000046C9  55                push bp
000046CA  8BEC              mov bp,sp
000046CC  8BE9              mov bp,cx
000046CE  8B4606            mov ax,[bp+0x6]
000046D1  B10C              mov cl,0xc
000046D3  D3E0              shl ax,cl
000046D5  8B5E04            mov bx,[bp+0x4]
000046D8  B104              mov cl,0x4
000046DA  D3EB              shr bx,cl
000046DC  03C3              add ax,bx
000046DE  8EC0              mov es,ax
000046E0  8B5E04            mov bx,[bp+0x4]
000046E3  83E30F            and bx,byte +0xf
000046E6  8B4E00            mov cx,[bp+0x0]
000046E9  B8420A            mov ax,0xa42
000046EC  8ED8              mov ds,ax
000046EE  8D368B0E          lea si,[0xe8b]
000046F2  0BC9              or cx,cx
000046F4  7517              jnz 0x470d
000046F6  268A37            mov dh,[es:bx]
000046F9  32D2              xor dl,dl
000046FB  32F6              xor dh,dh
000046FD  8914              mov [si],dx
000046FF  32F6              xor dh,dh
00004701  887402            mov [si+0x2],dh
00004704  268A37            mov dh,[es:bx]
00004707  887403            mov [si+0x3],dh
0000470A  EB1D              jmp short 0x4729
0000470C  90                nop
0000470D  33C0              xor ax,ax
0000470F  32F6              xor dh,dh
00004711  268A17            mov dl,[es:bx]
00004714  03C2              add ax,dx
00004716  43                inc bx
00004717  49                dec cx
00004718  0BC9              or cx,cx
0000471A  75F5              jnz 0x4711
0000471C  8824              mov [si],ah
0000471E  884401            mov [si+0x1],al
00004721  32D2              xor dl,dl
00004723  268A37            mov dh,[es:bx]
00004726  895402            mov [si+0x2],dx
00004729  8CDA              mov dx,ds
0000472B  B10C              mov cl,0xc
0000472D  D3EA              shr dx,cl
0000472F  8CD8              mov ax,ds
00004731  B104              mov cl,0x4
00004733  D3E0              shl ax,cl
00004735  03C6              add ax,si
00004737  7301              jnc 0x473a
00004739  42                inc dx
0000473A  5D                pop bp
0000473B  CB                retf
0000473C  55                push bp
0000473D  8BEC              mov bp,sp
0000473F  8BE9              mov bp,cx
00004741  8B4606            mov ax,[bp+0x6]
00004744  B10C              mov cl,0xc
00004746  D3E0              shl ax,cl
00004748  8B5E04            mov bx,[bp+0x4]
0000474B  B104              mov cl,0x4
0000474D  D3EB              shr bx,cl
0000474F  03C3              add ax,bx
00004751  8EC0              mov es,ax
00004753  8B5E04            mov bx,[bp+0x4]
00004756  83E30F            and bx,byte +0xf
00004759  B8420A            mov ax,0xa42
0000475C  8ED8              mov ds,ax
0000475E  8D368F0E          lea si,[0xe8f]
00004762  8B4E00            mov cx,[bp+0x0]
00004765  0BC9              or cx,cx
00004767  7515              jnz 0x477e
00004769  33D2              xor dx,dx
0000476B  8914              mov [si],dx
0000476D  895402            mov [si+0x2],dx
00004770  33D2              xor dx,dx
00004772  895404            mov [si+0x4],dx
00004775  268B17            mov dx,[es:bx]
00004778  895406            mov [si+0x6],dx
0000477B  EB2B              jmp short 0x47a8
0000477D  90                nop
0000477E  33C0              xor ax,ax
00004780  33FF              xor di,di
00004782  268B17            mov dx,[es:bx]
00004785  86F2              xchg dh,dl
00004787  43                inc bx
00004788  43                inc bx
00004789  03C2              add ax,dx
0000478B  7301              jnc 0x478e
0000478D  47                inc di
0000478E  49                dec cx
0000478F  75F1              jnz 0x4782
00004791  8BCF              mov cx,di
00004793  33D2              xor dx,dx
00004795  8814              mov [si],dl
00004797  884C01            mov [si+0x1],cl
0000479A  86E0              xchg ah,al
0000479C  894402            mov [si+0x2],ax
0000479F  895404            mov [si+0x4],dx
000047A2  268B17            mov dx,[es:bx]
000047A5  895406            mov [si+0x6],dx
000047A8  8CDA              mov dx,ds
000047AA  B10C              mov cl,0xc
000047AC  D3EA              shr dx,cl
000047AE  8CD8              mov ax,ds
000047B0  B104              mov cl,0x4
000047B2  D3E0              shl ax,cl
000047B4  03C6              add ax,si
000047B6  7301              jnc 0x47b9
000047B8  42                inc dx
000047B9  5D                pop bp
000047BA  CB                retf
000047BB  55                push bp
000047BC  8BEC              mov bp,sp
000047BE  1E                push ds
000047BF  56                push si
000047C0  57                push di
000047C1  8E06DC00          mov es,[0xdc]
000047C5  8B36DE00          mov si,[0xde]
000047C9  8B3EE200          mov di,[0xe2]
000047CD  8E1EE000          mov ds,[0xe0]
000047D1  B91000            mov cx,0x10
000047D4  51                push cx
000047D5  268B04            mov ax,[es:si]
000047D8  8BD8              mov bx,ax
000047DA  B104              mov cl,0x4
000047DC  D3EB              shr bx,cl
000047DE  81E3F000          and bx,0xf0
000047E2  250F00            and ax,0xf
000047E5  03C3              add ax,bx
000047E7  8805              mov [di],al
000047E9  8BD8              mov bx,ax
000047EB  D3E3              shl bx,cl
000047ED  D3E8              shr ax,cl
000047EF  81E3F000          and bx,0xf0
000047F3  250F00            and ax,0xf
000047F6  03C3              add ax,bx
000047F8  884510            mov [di+0x10],al
000047FB  884510            mov [di+0x10],al
000047FE  83C602            add si,byte +0x2
00004801  47                inc di
00004802  59                pop cx
00004803  E2CF              loop 0x47d4
00004805  83EF10            sub di,byte +0x10
00004808  83C705            add di,byte +0x5
0000480B  8A05              mov al,[di]
0000480D  24F0              and al,0xf0
0000480F  8AD8              mov bl,al
00004811  B104              mov cl,0x4
00004813  D2EB              shr bl,cl
00004815  02C3              add al,bl
00004817  8805              mov [di],al
00004819  884510            mov [di+0x10],al
0000481C  5F                pop di
0000481D  5E                pop si
0000481E  1F                pop ds
0000481F  5D                pop bp
00004820  CB                retf
00004821  55                push bp
00004822  8BEC              mov bp,sp
00004824  8BE9              mov bp,cx
00004826  8B5E00            mov bx,[bp+0x0]
00004829  2B5E04            sub bx,[bp+0x4]
0000482C  43                inc bx
0000482D  33D2              xor dx,dx
0000482F  A13F06            mov ax,[0x63f]
00004832  F7FB              idiv bx
00004834  035604            add dx,[bp+0x4]
00004837  8BC2              mov ax,dx
00004839  33D2              xor dx,dx
0000483B  5D                pop bp
0000483C  CB                retf
0000483D  5D                pop bp
0000483E  CB                retf
0000483F  55                push bp
00004840  8BEC              mov bp,sp
00004842  803E740E01        cmp byte [0xe74],0x1
00004847  7457              jz 0x48a0
00004849  803E560600        cmp byte [0x656],0x0
0000484E  7C4C              jl 0x489c
00004850  C606270600        mov byte [0x627],0x0
00004855  FF36DC00          push word [0xdc]
00004859  FF36DE00          push word [0xde]
0000485D  B91000            mov cx,0x10
00004860  833E960000        cmp word [0x96],byte +0x0
00004865  7D0C              jnl 0x4873
00004867  A19600            mov ax,[0x96]
0000486A  F7D8              neg ax
0000486C  2BC8              sub cx,ax
0000486E  33C0              xor ax,ax
00004870  EB04              jmp short 0x4876
00004872  90                nop
00004873  A19600            mov ax,[0x96]
00004876  8BF8              mov di,ax
00004878  BB4001            mov bx,0x140
0000487B  F7E3              mul bx
0000487D  03069400          add ax,[0x94]
00004881  50                push ax
00004882  FF369404          push word [0x494]
00004886  33C0              xor ax,ax
00004888  50                push ax
00004889  50                push ax
0000488A  B81000            mov ax,0x10
0000488D  51                push cx
0000488E  50                push ax
0000488F  57                push di
00004890  FF369400          push word [0x94]
00004894  9A0D048400        call 0x84:0x40d
00004899  83C414            add sp,byte +0x14
0000489C  FE0E5606          dec byte [0x656]
000048A0  5D                pop bp
000048A1  CB                retf
000048A2  55                push bp
000048A3  8BEC              mov bp,sp
000048A5  FF36DC00          push word [0xdc]
000048A9  FF36DE00          push word [0xde]
000048AD  B91000            mov cx,0x10
000048B0  83FA10            cmp dx,byte +0x10
000048B3  7C13              jl 0x48c8
000048B5  833E960000        cmp word [0x96],byte +0x0
000048BA  7D0E              jnl 0x48ca
000048BC  A19600            mov ax,[0x96]
000048BF  F7D8              neg ax
000048C1  2BC8              sub cx,ax
000048C3  33C0              xor ax,ax
000048C5  EB06              jmp short 0x48cd
000048C7  90                nop
000048C8  8BCA              mov cx,dx
000048CA  A19600            mov ax,[0x96]
000048CD  8BF8              mov di,ax
000048CF  BB4001            mov bx,0x140
000048D2  F7E3              mul bx
000048D4  03069400          add ax,[0x94]
000048D8  50                push ax
000048D9  FF369404          push word [0x494]
000048DD  33C0              xor ax,ax
000048DF  50                push ax
000048E0  50                push ax
000048E1  B81000            mov ax,0x10
000048E4  51                push cx
000048E5  50                push ax
000048E6  57                push di
000048E7  FF369400          push word [0x94]
000048EB  9A0D048400        call 0x84:0x40d
000048F0  83C414            add sp,byte +0x14
000048F3  5D                pop bp
000048F4  CB                retf
000048F5  55                push bp
000048F6  8BEC              mov bp,sp
000048F8  FF36DC00          push word [0xdc]
000048FC  FF36DE00          push word [0xde]
00004900  A1A400            mov ax,[0xa4]
00004903  BB4001            mov bx,0x140
00004906  F7E3              mul bx
00004908  03069E00          add ax,[0x9e]
0000490C  50                push ax
0000490D  FF369404          push word [0x494]
00004911  33C0              xor ax,ax
00004913  50                push ax
00004914  50                push ax
00004915  A1A200            mov ax,[0xa2]
00004918  8B1EA400          mov bx,[0xa4]
0000491C  2BC3              sub ax,bx
0000491E  40                inc ax
0000491F  50                push ax
00004920  A1A000            mov ax,[0xa0]
00004923  8B1E9E00          mov bx,[0x9e]
00004927  2BC3              sub ax,bx
00004929  40                inc ax
0000492A  50                push ax
0000492B  FF36A400          push word [0xa4]
0000492F  FF369E00          push word [0x9e]
00004933  9A0D048400        call 0x84:0x40d
00004938  83C414            add sp,byte +0x14
0000493B  5D                pop bp
0000493C  CB                retf
0000493D  55                push bp
0000493E  8BEC              mov bp,sp
00004940  8BE9              mov bp,cx
00004942  FF36DC00          push word [0xdc]
00004946  FF36DE00          push word [0xde]
0000494A  8B4608            mov ax,[bp+0x8]
0000494D  BB4001            mov bx,0x140
00004950  F7E3              mul bx
00004952  03460C            add ax,[bp+0xc]
00004955  50                push ax
00004956  FF369404          push word [0x494]
0000495A  33C0              xor ax,ax
0000495C  50                push ax
0000495D  50                push ax
0000495E  8B4600            mov ax,[bp+0x0]
00004961  2B4608            sub ax,[bp+0x8]
00004964  40                inc ax
00004965  50                push ax
00004966  8B4604            mov ax,[bp+0x4]
00004969  2B460C            sub ax,[bp+0xc]
0000496C  40                inc ax
0000496D  50                push ax
0000496E  FF7608            push word [bp+0x8]
00004971  FF760C            push word [bp+0xc]
00004974  9A0D048400        call 0x84:0x40d
00004979  83C414            add sp,byte +0x14
0000497C  5D                pop bp
0000497D  CB                retf
0000497E  51                push cx
0000497F  B10C              mov cl,0xc
00004981  D3E0              shl ax,cl
00004983  B104              mov cl,0x4
00004985  53                push bx
00004986  D3EB              shr bx,cl
00004988  03C3              add ax,bx
0000498A  5B                pop bx
0000498B  83E30F            and bx,byte +0xf
0000498E  59                pop cx
0000498F  C3                ret
00004990  55                push bp
00004991  8BEC              mov bp,sp
00004993  8BE9              mov bp,cx
00004995  B8420A            mov ax,0xa42
00004998  A3770E            mov [0xe77],ax
0000499B  8D360F0F          lea si,[0xf0f]
0000499F  8936750E          mov [0xe75],si
000049A3  8B5E18            mov bx,[bp+0x18]
000049A6  8B461A            mov ax,[bp+0x1a]
000049A9  E8D2FF            call 0x497e
000049AC  8EC0              mov es,ax
000049AE  8BF3              mov si,bx
000049B0  8B460C            mov ax,[bp+0xc]
000049B3  B94001            mov cx,0x140
000049B6  F7E1              mul cx
000049B8  8BF8              mov di,ax
000049BA  037E08            add di,[bp+0x8]
000049BD  8E1E9404          mov ds,[0x494]
000049C1  8B5614            mov dx,[bp+0x14]
000049C4  2B560C            sub dx,[bp+0xc]
000049C7  42                inc dx
000049C8  8B4E10            mov cx,[bp+0x10]
000049CB  2B4E08            sub cx,[bp+0x8]
000049CE  41                inc cx
000049CF  51                push cx
000049D0  32E4              xor ah,ah
000049D2  8A05              mov al,[di]
000049D4  1E                push ds
000049D5  57                push di
000049D6  52                push dx
000049D7  32FF              xor bh,bh
000049D9  BA420A            mov dx,0xa42
000049DC  8EDA              mov ds,dx
000049DE  8D3EAF0E          lea di,[0xeaf]
000049E2  03F8              add di,ax
000049E4  8A15              mov dl,[di]
000049E6  2BF8              sub di,ax
000049E8  32F6              xor dh,dh
000049EA  03F2              add si,dx
000049EC  268A1C            mov bl,[es:si]
000049EF  2BF2              sub si,dx
000049F1  03FB              add di,bx
000049F3  8A1D              mov bl,[di]
000049F5  5A                pop dx
000049F6  5F                pop di
000049F7  1F                pop ds
000049F8  881D              mov [di],bl
000049FA  47                inc di
000049FB  E2D5              loop 0x49d2
000049FD  59                pop cx
000049FE  2BF9              sub di,cx
00004A00  81C74001          add di,0x140
00004A04  4A                dec dx
00004A05  75C8              jnz 0x49cf
00004A07  5D                pop bp
00004A08  CB                retf
00004A09  55                push bp
00004A0A  8BEC              mov bp,sp
00004A0C  9AE715DB02        call 0x2db:0x15e7
00004A11  5D                pop bp
00004A12  CB                retf
00004A13  55                push bp
00004A14  8BEC              mov bp,sp
00004A16  8BE9              mov bp,cx
00004A18  C706D0000000      mov word [0xd0],0x0
00004A1E  8B4602            mov ax,[bp+0x2]
00004A21  A3CE00            mov [0xce],ax
00004A24  8B460C            mov ax,[bp+0xc]
00004A27  A3D400            mov [0xd4],ax
00004A2A  8B460E            mov ax,[bp+0xe]
00004A2D  A3C400            mov [0xc4],ax
00004A30  8B4618            mov ax,[bp+0x18]
00004A33  A3D800            mov [0xd8],ax
00004A36  A36E0E            mov [0xe6e],ax
00004A39  8B461C            mov ax,[bp+0x1c]
00004A3C  A3D600            mov [0xd6],ax
00004A3F  A36C0E            mov [0xe6c],ax
00004A42  8B5E2C            mov bx,[bp+0x2c]
00004A45  8B462E            mov ax,[bp+0x2e]
00004A48  E833FF            call 0x497e
00004A4B  3D0000            cmp ax,0x0
00004A4E  7E2E              jng 0x4a7e
00004A50  1E                push ds
00004A51  8BC8              mov cx,ax
00004A53  8BD3              mov dx,bx
00004A55  8B4600            mov ax,[bp+0x0]
00004A58  48                dec ax
00004A59  50                push ax
00004A5A  8B5E28            mov bx,[bp+0x28]
00004A5D  8B462A            mov ax,[bp+0x2a]
00004A60  E81BFF            call 0x497e
00004A63  50                push ax
00004A64  53                push bx
00004A65  51                push cx
00004A66  52                push dx
00004A67  8B5E30            mov bx,[bp+0x30]
00004A6A  8B4632            mov ax,[bp+0x32]
00004A6D  E80EFF            call 0x497e
00004A70  50                push ax
00004A71  53                push bx
00004A72  9AC20B8400        call 0x84:0xbc2
00004A77  83C40E            add sp,byte +0xe
00004A7A  1F                pop ds
00004A7B  EB34              jmp short 0x4ab1
00004A7D  90                nop
00004A7E  1E                push ds
00004A7F  8B4630            mov ax,[bp+0x30]
00004A82  50                push ax
00004A83  8B5E28            mov bx,[bp+0x28]
00004A86  8B462A            mov ax,[bp+0x2a]
00004A89  E8F2FE            call 0x497e
00004A8C  50                push ax
00004A8D  53                push bx
00004A8E  9AAB0C8400        call 0x84:0xcab
00004A93  83C406            add sp,byte +0x6
00004A96  51                push cx
00004A97  8BC8              mov cx,ax
00004A99  8B5E28            mov bx,[bp+0x28]
00004A9C  8B462A            mov ax,[bp+0x2a]
00004A9F  E8DCFE            call 0x497e
00004AA2  8EC0              mov es,ax
00004AA4  8BF3              mov si,bx
00004AA6  03F1              add si,cx
00004AA8  32FF              xor bh,bh
00004AAA  26883C            mov [es:si],bh
00004AAD  8BC1              mov ax,cx
00004AAF  59                pop cx
00004AB0  1F                pop ds
00004AB1  833ECE0000        cmp word [0xce],byte +0x0
00004AB6  745C              jz 0x4b14
00004AB8  833ECE0000        cmp word [0xce],byte +0x0
00004ABD  7C4B              jl 0x4b0a
00004ABF  50                push ax
00004AC0  50                push ax
00004AC1  8B5E28            mov bx,[bp+0x28]
00004AC4  8B462A            mov ax,[bp+0x2a]
00004AC7  E8B4FE            call 0x497e
00004ACA  8EC0              mov es,ax
00004ACC  58                pop ax
00004ACD  03D8              add bx,ax
00004ACF  43                inc bx
00004AD0  895E1A            mov [bp+0x1a],bx
00004AD3  8CC1              mov cx,es
00004AD5  894E18            mov [bp+0x18],cx
00004AD8  1E                push ds
00004AD9  8B0ECE00          mov cx,[0xce]
00004ADD  49                dec cx
00004ADE  51                push cx
00004ADF  06                push es
00004AE0  53                push bx
00004AE1  8B5E2C            mov bx,[bp+0x2c]
00004AE4  8B462E            mov ax,[bp+0x2e]
00004AE7  E894FE            call 0x497e
00004AEA  50                push ax
00004AEB  53                push bx
00004AEC  8B5E30            mov bx,[bp+0x30]
00004AEF  8B4632            mov ax,[bp+0x32]
00004AF2  E889FE            call 0x497e
00004AF5  50                push ax
00004AF6  53                push bx
00004AF7  9AC20B8400        call 0x84:0xbc2
00004AFC  83C40E            add sp,byte +0xe
00004AFF  1F                pop ds
00004B00  C706D0000100      mov word [0xd0],0x1
00004B06  58                pop ax
00004B07  EB0B              jmp short 0x4b14
00004B09  90                nop
00004B0A  8B1ECE00          mov bx,[0xce]
00004B0E  F7DB              neg bx
00004B10  891ECE00          mov [0xce],bx
00004B14  89462C            mov [bp+0x2c],ax
00004B17  C7460C0000        mov word [bp+0xc],0x0
00004B1C  C7460E0000        mov word [bp+0xe],0x0
00004B21  C746000000        mov word [bp+0x0],0x0
00004B26  1E                push ds
00004B27  8E06B400          mov es,[0xb4]
00004B2B  8B36B600          mov si,[0xb6]
00004B2F  26037466          add si,[es:si+0x66]
00004B33  8B5E28            mov bx,[bp+0x28]
00004B36  8B462A            mov ax,[bp+0x2a]
00004B39  E842FE            call 0x497e
00004B3C  8ED8              mov ds,ax
00004B3E  8BFB              mov di,bx
00004B40  32E4              xor ah,ah
00004B42  33DB              xor bx,bx
00004B44  32ED              xor ch,ch
00004B46  FF460E            inc word [bp+0xe]
00004B49  8A05              mov al,[di]
00004B4B  0AC0              or al,al
00004B4D  744D              jz 0x4b9c
00004B4F  3C65              cmp al,0x65
00004B51  7510              jnz 0x4b63
00004B53  FF460C            inc word [bp+0xc]
00004B56  895E0E            mov [bp+0xe],bx
00004B59  C746000000        mov word [bp+0x0],0x0
00004B5E  33C9              xor cx,cx
00004B60  EB23              jmp short 0x4b85
00004B62  90                nop
00004B63  3C4C              cmp al,0x4c
00004B65  7503              jnz 0x4b6a
00004B67  895E0E            mov [bp+0xe],bx
00004B6A  3C65              cmp al,0x65
00004B6C  7417              jz 0x4b85
00004B6E  0AC0              or al,al
00004B70  7413              jz 0x4b85
00004B72  FEC8              dec al
00004B74  D1E0              shl ax,1
00004B76  03F0              add si,ax
00004B78  32ED              xor ch,ch
00004B7A  268A0C            mov cl,[es:si]
00004B7D  2BF0              sub si,ax
00004B7F  034E00            add cx,[bp+0x0]
00004B82  894E00            mov [bp+0x0],cx
00004B85  3B4E14            cmp cx,[bp+0x14]
00004B88  7E0F              jng 0x4b99
00004B8A  FF460C            inc word [bp+0xc]
00004B8D  8B460E            mov ax,[bp+0xe]
00004B90  2BF8              sub di,ax
00004B92  B065              mov al,0x65
00004B94  8805              mov [di],al
00004B96  895E00            mov [bp+0x0],bx
00004B99  47                inc di
00004B9A  EBAA              jmp short 0x4b46
00004B9C  4F                dec di
00004B9D  8A05              mov al,[di]
00004B9F  3C65              cmp al,0x65
00004BA1  7504              jnz 0x4ba7
00004BA3  32C0              xor al,al
00004BA5  8805              mov [di],al
00004BA7  1F                pop ds
00004BA8  FF460C            inc word [bp+0xc]
00004BAB  8B4634            mov ax,[bp+0x34]
00004BAE  3DFFFF            cmp ax,0xffff
00004BB1  750E              jnz 0x4bc1
00004BB3  8B4E10            mov cx,[bp+0x10]
00004BB6  8B460C            mov ax,[bp+0xc]
00004BB9  F7E1              mul cx
00004BBB  894634            mov [bp+0x34],ax
00004BBE  EB05              jmp short 0x4bc5
00004BC0  90                nop
00004BC1  FF06D800          inc word [0xd8]
00004BC5  8B5E34            mov bx,[bp+0x34]
00004BC8  8B4E10            mov cx,[bp+0x10]
00004BCB  8B460C            mov ax,[bp+0xc]
00004BCE  F7E1              mul cx
00004BD0  2BD8              sub bx,ax
00004BD2  D1EB              shr bx,1
00004BD4  011ED800          add [0xd8],bx
00004BD8  33DB              xor bx,bx
00004BDA  8B4608            mov ax,[bp+0x8]
00004BDD  3D0000            cmp ax,0x0
00004BE0  740E              jz 0x4bf0
00004BE2  3D0000            cmp ax,0x0
00004BE5  7F06              jg 0x4bed
00004BE7  BB0100            mov bx,0x1
00004BEA  EB04              jmp short 0x4bf0
00004BEC  90                nop
00004BED  BB0200            mov bx,0x2
00004BF0  A1D000            mov ax,[0xd0]
00004BF3  1E                push ds
00004BF4  50                push ax
00004BF5  53                push bx
00004BF6  8B4610            mov ax,[bp+0x10]
00004BF9  50                push ax
00004BFA  8B4614            mov ax,[bp+0x14]
00004BFD  50                push ax
00004BFE  8B4618            mov ax,[bp+0x18]
00004C01  8B5E1A            mov bx,[bp+0x1a]
00004C04  50                push ax
00004C05  53                push bx
00004C06  8B5E28            mov bx,[bp+0x28]
00004C09  8B462A            mov ax,[bp+0x2a]
00004C0C  E86FFD            call 0x497e
00004C0F  803EA20400        cmp byte [0x4a2],0x0
00004C14  740F              jz 0x4c25
00004C16  06                push es
00004C17  56                push si
00004C18  8EC0              mov es,ax
00004C1A  8BF3              mov si,bx
00004C1C  83C615            add si,byte +0x15
00004C1F  26C60438          mov byte [es:si],0x38
00004C23  5E                pop si
00004C24  07                pop es
00004C25  50                push ax
00004C26  53                push bx
00004C27  9AFC025901        call 0x159:0x2fc
00004C2C  83C410            add sp,byte +0x10
00004C2F  1F                pop ds
00004C30  8B5E24            mov bx,[bp+0x24]
00004C33  8B4626            mov ax,[bp+0x26]
00004C36  E845FD            call 0x497e
00004C39  0BC0              or ax,ax
00004C3B  7549              jnz 0x4c86
00004C3D  8B3E6C0E          mov di,[0xe6c]
00004C41  8B166E0E          mov dx,[0xe6e]
00004C45  893E9E00          mov [0x9e],di
00004C49  8916A400          mov [0xa4],dx
00004C4D  52                push dx
00004C4E  8B460C            mov ax,[bp+0xc]
00004C51  8B4E10            mov cx,[bp+0x10]
00004C54  F6E1              mul cl
00004C56  8BD8              mov bx,ax
00004C58  8B460C            mov ax,[bp+0xc]
00004C5B  56                push si
00004C5C  06                push es
00004C5D  8E06B400          mov es,[0xb4]
00004C61  8B36B600          mov si,[0xb6]
00004C65  83C64E            add si,byte +0x4e
00004C68  268A0C            mov cl,[es:si]
00004C6B  F6E1              mul cl
00004C6D  07                pop es
00004C6E  5E                pop si
00004C6F  03D8              add bx,ax
00004C71  5A                pop dx
00004C72  03D3              add dx,bx
00004C74  8916A200          mov [0xa2],dx
00004C78  8B4614            mov ax,[bp+0x14]
00004C7B  03F8              add di,ax
00004C7D  893EA000          mov [0xa0],di
00004C81  9A750D9304        call 0x493:0xd75
00004C86  5D                pop bp
00004C87  CB                retf
00004C88  55                push bp
00004C89  8BEC              mov bp,sp
00004C8B  8BE9              mov bp,cx
00004C8D  8B4630            mov ax,[bp+0x30]
00004C90  A3D400            mov [0xd4],ax
00004C93  8B4628            mov ax,[bp+0x28]
00004C96  A3D600            mov [0xd6],ax
00004C99  A3680E            mov [0xe68],ax
00004C9C  8B4624            mov ax,[bp+0x24]
00004C9F  A3D800            mov [0xd8],ax
00004CA2  A36A0E            mov [0xe6a],ax
00004CA5  C706C0000000      mov word [0xc0],0x0
00004CAB  C746240000        mov word [bp+0x24],0x0
00004CB0  C746260000        mov word [bp+0x26],0x0
00004CB5  8B5E0C            mov bx,[bp+0xc]
00004CB8  8B460E            mov ax,[bp+0xe]
00004CBB  E8C0FC            call 0x497e
00004CBE  3D0000            cmp ax,0x0
00004CC1  7F03              jg 0x4cc6
00004CC3  E98600            jmp 0x4d4c
00004CC6  1E                push ds
00004CC7  8B5E1C            mov bx,[bp+0x1c]
00004CCA  8B461E            mov ax,[bp+0x1e]
00004CCD  E8AEFC            call 0x497e
00004CD0  8EC0              mov es,ax
00004CD2  8BF3              mov si,bx
00004CD4  46                inc si
00004CD5  8B5E08            mov bx,[bp+0x8]
00004CD8  8B460A            mov ax,[bp+0xa]
00004CDB  E8A0FC            call 0x497e
00004CDE  8BD0              mov dx,ax
00004CE0  8BFB              mov di,bx
00004CE2  8B4E20            mov cx,[bp+0x20]
00004CE5  0BC9              or cx,cx
00004CE7  7504              jnz 0x4ced
00004CE9  1F                pop ds
00004CEA  E98002            jmp 0x4f6d
00004CED  33C9              xor cx,cx
00004CEF  51                push cx
00004CF0  56                push si
00004CF1  06                push es
00004CF2  52                push dx
00004CF3  57                push di
00004CF4  32E4              xor ah,ah
00004CF6  268A04            mov al,[es:si]
00004CF9  FEC8              dec al
00004CFB  50                push ax
00004CFC  52                push dx
00004CFD  57                push di
00004CFE  8B5E0C            mov bx,[bp+0xc]
00004D01  8B460E            mov ax,[bp+0xe]
00004D04  E877FC            call 0x497e
00004D07  50                push ax
00004D08  53                push bx
00004D09  8B5E10            mov bx,[bp+0x10]
00004D0C  8B4612            mov ax,[bp+0x12]
00004D0F  E86CFC            call 0x497e
00004D12  50                push ax
00004D13  53                push bx
00004D14  9AC20B8400        call 0x84:0xbc2
00004D19  83C40E            add sp,byte +0xe
00004D1C  5F                pop di
00004D1D  5A                pop dx
00004D1E  07                pop es
00004D1F  5E                pop si
00004D20  59                pop cx
00004D21  83C602            add si,byte +0x2
00004D24  03F8              add di,ax
00004D26  B365              mov bl,0x65
00004D28  1E                push ds
00004D29  8EDA              mov ds,dx
00004D2B  881D              mov [di],bl
00004D2D  47                inc di
00004D2E  1F                pop ds
00004D2F  8B5E24            mov bx,[bp+0x24]
00004D32  40                inc ax
00004D33  03D8              add bx,ax
00004D35  895E24            mov [bp+0x24],bx
00004D38  41                inc cx
00004D39  3B4E2C            cmp cx,[bp+0x2c]
00004D3C  7503              jnz 0x4d41
00004D3E  895E26            mov [bp+0x26],bx
00004D41  3B4E20            cmp cx,[bp+0x20]
00004D44  7402              jz 0x4d48
00004D46  EBA7              jmp short 0x4cef
00004D48  1F                pop ds
00004D49  EB33              jmp short 0x4d7e
00004D4B  90                nop
00004D4C  1E                push ds
00004D4D  C706C0000100      mov word [0xc0],0x1
00004D53  8B5E08            mov bx,[bp+0x8]
00004D56  8B460A            mov ax,[bp+0xa]
00004D59  E822FC            call 0x497e
00004D5C  8EC0              mov es,ax
00004D5E  8BF3              mov si,bx
00004D60  56                push si
00004D61  06                push es
00004D62  8B4610            mov ax,[bp+0x10]
00004D65  50                push ax
00004D66  06                push es
00004D67  56                push si
00004D68  9AAB0C8400        call 0x84:0xcab
00004D6D  83C406            add sp,byte +0x6
00004D70  07                pop es
00004D71  5E                pop si
00004D72  03F0              add si,ax
00004D74  B365              mov bl,0x65
00004D76  26881C            mov [es:si],bl
00004D79  40                inc ax
00004D7A  014624            add [bp+0x24],ax
00004D7D  1F                pop ds
00004D7E  C746280000        mov word [bp+0x28],0x0
00004D83  C746300000        mov word [bp+0x30],0x0
00004D88  C7462A0000        mov word [bp+0x2a],0x0
00004D8D  8B5E08            mov bx,[bp+0x8]
00004D90  8B460A            mov ax,[bp+0xa]
00004D93  E8E8FB            call 0x497e
00004D96  8EC0              mov es,ax
00004D98  8BF3              mov si,bx
00004D9A  8B462C            mov ax,[bp+0x2c]
00004D9D  0BC0              or ax,ax
00004D9F  7503              jnz 0x4da4
00004DA1  E9C200            jmp 0x4e66
00004DA4  A16A0E            mov ax,[0xe6a]
00004DA7  A3D800            mov [0xd8],ax
00004DAA  8B4E26            mov cx,[bp+0x26]
00004DAD  1E                push ds
00004DAE  32FF              xor bh,bh
00004DB0  8B3EB600          mov di,[0xb6]
00004DB4  8E1EB400          mov ds,[0xb4]
00004DB8  037D66            add di,[di+0x66]
00004DBB  268A04            mov al,[es:si]
00004DBE  3C65              cmp al,0x65
00004DC0  7416              jz 0x4dd8
00004DC2  FF4630            inc word [bp+0x30]
00004DC5  FEC8              dec al
00004DC7  32E4              xor ah,ah
00004DC9  D1E0              shl ax,1
00004DCB  03F8              add di,ax
00004DCD  8A1D              mov bl,[di]
00004DCF  015E28            add [bp+0x28],bx
00004DD2  2BF8              sub di,ax
00004DD4  46                inc si
00004DD5  49                dec cx
00004DD6  EBE3              jmp short 0x4dbb
00004DD8  1F                pop ds
00004DD9  51                push cx
00004DDA  A1680E            mov ax,[0xe68]
00004DDD  2D1A00            sub ax,0x1a
00004DE0  2B4628            sub ax,[bp+0x28]
00004DE3  A3D600            mov [0xd6],ax
00004DE6  8B4628            mov ax,[bp+0x28]
00004DE9  3B462A            cmp ax,[bp+0x2a]
00004DEC  7E03              jng 0x4df1
00004DEE  89462A            mov [bp+0x2a],ax
00004DF1  1E                push ds
00004DF2  06                push es
00004DF3  56                push si
00004DF4  57                push di
00004DF5  50                push ax
00004DF6  8B1E3F06          mov bx,[0x63f]
00004DFA  031ED600          add bx,[0xd6]
00004DFE  031ED800          add bx,[0xd8]
00004E02  891E660E          mov [0xe66],bx
00004E06  83E307            and bx,byte +0x7
00004E09  53                push bx
00004E0A  8B5E18            mov bx,[bp+0x18]
00004E0D  53                push bx
00004E0E  50                push ax
00004E0F  9A5B015901        call 0x159:0x15b
00004E14  83C406            add sp,byte +0x6
00004E17  58                pop ax
00004E18  5F                pop di
00004E19  5E                pop si
00004E1A  07                pop es
00004E1B  1F                pop ds
00004E1C  8B1E680E          mov bx,[0xe68]
00004E20  83EB10            sub bx,byte +0x10
00004E23  2BD8              sub bx,ax
00004E25  891ED600          mov [0xd6],bx
00004E29  8306D80002        add word [0xd8],byte +0x2
00004E2E  1E                push ds
00004E2F  06                push es
00004E30  57                push di
00004E31  56                push si
00004E32  2B7630            sub si,[bp+0x30]
00004E35  33C0              xor ax,ax
00004E37  50                push ax
00004E38  06                push es
00004E39  56                push si
00004E3A  9AC8025901        call 0x159:0x2c8
00004E3F  83C406            add sp,byte +0x6
00004E42  5E                pop si
00004E43  46                inc si
00004E44  5F                pop di
00004E45  07                pop es
00004E46  1F                pop ds
00004E47  C746300000        mov word [bp+0x30],0x0
00004E4C  C746280000        mov word [bp+0x28],0x0
00004E51  8306D8000A        add word [0xd8],byte +0xa
00004E56  59                pop cx
00004E57  49                dec cx
00004E58  7403              jz 0x4e5d
00004E5A  E950FF            jmp 0x4dad
00004E5D  8B4624            mov ax,[bp+0x24]
00004E60  2B4626            sub ax,[bp+0x26]
00004E63  894624            mov [bp+0x24],ax
00004E66  C746280000        mov word [bp+0x28],0x0
00004E6B  C746320000        mov word [bp+0x32],0x0
00004E70  C746300000        mov word [bp+0x30],0x0
00004E75  A16A0E            mov ax,[0xe6a]
00004E78  A3D800            mov [0xd8],ax
00004E7B  8B4E24            mov cx,[bp+0x24]
00004E7E  1E                push ds
00004E7F  32FF              xor bh,bh
00004E81  8B3EB600          mov di,[0xb6]
00004E85  8E1EB400          mov ds,[0xb4]
00004E89  037D66            add di,[di+0x66]
00004E8C  268A04            mov al,[es:si]
00004E8F  3C65              cmp al,0x65
00004E91  7416              jz 0x4ea9
00004E93  FF4630            inc word [bp+0x30]
00004E96  FEC8              dec al
00004E98  32E4              xor ah,ah
00004E9A  D1E0              shl ax,1
00004E9C  03F8              add di,ax
00004E9E  8A1D              mov bl,[di]
00004EA0  015E28            add [bp+0x28],bx
00004EA3  2BF8              sub di,ax
00004EA5  46                inc si
00004EA6  49                dec cx
00004EA7  EBE3              jmp short 0x4e8c
00004EA9  1F                pop ds
00004EAA  51                push cx
00004EAB  A1680E            mov ax,[0xe68]
00004EAE  A3D600            mov [0xd6],ax
00004EB1  8B4628            mov ax,[bp+0x28]
00004EB4  3B4632            cmp ax,[bp+0x32]
00004EB7  7E03              jng 0x4ebc
00004EB9  894632            mov [bp+0x32],ax
00004EBC  1E                push ds
00004EBD  06                push es
00004EBE  56                push si
00004EBF  57                push di
00004EC0  50                push ax
00004EC1  8B1E3F06          mov bx,[0x63f]
00004EC5  031ED800          add bx,[0xd8]
00004EC9  031ED600          add bx,[0xd6]
00004ECD  891E660E          mov [0xe66],bx
00004ED1  83E307            and bx,byte +0x7
00004ED4  53                push bx
00004ED5  8B5E18            mov bx,[bp+0x18]
00004ED8  53                push bx
00004ED9  50                push ax
00004EDA  9A5B015901        call 0x159:0x15b
00004EDF  83C406            add sp,byte +0x6
00004EE2  58                pop ax
00004EE3  5F                pop di
00004EE4  5E                pop si
00004EE5  07                pop es
00004EE6  1F                pop ds
00004EE7  8B1E680E          mov bx,[0xe68]
00004EEB  83C30A            add bx,byte +0xa
00004EEE  891ED600          mov [0xd6],bx
00004EF2  8306D80002        add word [0xd8],byte +0x2
00004EF7  1E                push ds
00004EF8  06                push es
00004EF9  57                push di
00004EFA  56                push si
00004EFB  2B7630            sub si,[bp+0x30]
00004EFE  33C0              xor ax,ax
00004F00  50                push ax
00004F01  06                push es
00004F02  56                push si
00004F03  9AC8025901        call 0x159:0x2c8
00004F08  83C406            add sp,byte +0x6
00004F0B  5E                pop si
00004F0C  46                inc si
00004F0D  5F                pop di
00004F0E  07                pop es
00004F0F  1F                pop ds
00004F10  C746300000        mov word [bp+0x30],0x0
00004F15  C746280000        mov word [bp+0x28],0x0
00004F1A  8306D8000A        add word [0xd8],byte +0xa
00004F1F  59                pop cx
00004F20  49                dec cx
00004F21  7403              jz 0x4f26
00004F23  E958FF            jmp 0x4e7e
00004F26  8B4E2A            mov cx,[bp+0x2a]
00004F29  034E32            add cx,[bp+0x32]
00004F2C  83C11A            add cx,byte +0x1a
00004F2F  837E2C00          cmp word [bp+0x2c],byte +0x0
00004F33  740F              jz 0x4f44
00004F35  83C11A            add cx,byte +0x1a
00004F38  A1680E            mov ax,[0xe68]
00004F3B  2B462A            sub ax,[bp+0x2a]
00004F3E  2D1A00            sub ax,0x1a
00004F41  A3680E            mov [0xe68],ax
00004F44  8B5E14            mov bx,[bp+0x14]
00004F47  8B4616            mov ax,[bp+0x16]
00004F4A  E831FA            call 0x497e
00004F4D  0BC0              or ax,ax
00004F4F  751C              jnz 0x4f6d
00004F51  A1680E            mov ax,[0xe68]
00004F54  A39E00            mov [0x9e],ax
00004F57  03C1              add ax,cx
00004F59  A3A000            mov [0xa0],ax
00004F5C  A16A0E            mov ax,[0xe6a]
00004F5F  A3A400            mov [0xa4],ax
00004F62  A1D800            mov ax,[0xd8]
00004F65  A3A200            mov [0xa2],ax
00004F68  9A750D9304        call 0x493:0xd75
00004F6D  5D                pop bp
00004F6E  CB                retf
00004F6F  55                push bp
00004F70  8BEC              mov bp,sp
00004F72  C70620060100      mov word [0x620],0x1
00004F78  56                push si
00004F79  57                push di
00004F7A  1E                push ds
00004F7B  1E                push ds
00004F7C  8BE9              mov bp,cx
00004F7E  8B5E04            mov bx,[bp+0x4]
00004F81  8B4606            mov ax,[bp+0x6]
00004F84  E8F7F9            call 0x497e
00004F87  8EC0              mov es,ax
00004F89  8BFB              mov di,bx
00004F8B  06                push es
00004F8C  57                push di
00004F8D  8B461C            mov ax,[bp+0x1c]
00004F90  8B5E18            mov bx,[bp+0x18]
00004F93  E85402            call 0x51ea
00004F96  8B0E9404          mov cx,[0x494]
00004F9A  8BF0              mov si,ax
00004F9C  51                push cx
00004F9D  56                push si
00004F9E  8B5E08            mov bx,[bp+0x8]
00004FA1  8B460C            mov ax,[bp+0xc]
00004FA4  E84302            call 0x51ea
00004FA7  8BF0              mov si,ax
00004FA9  8E1E9404          mov ds,[0x494]
00004FAD  8B460C            mov ax,[bp+0xc]
00004FB0  8B5E08            mov bx,[bp+0x8]
00004FB3  8B4E10            mov cx,[bp+0x10]
00004FB6  8B5614            mov dx,[bp+0x14]
00004FB9  2BD0              sub dx,ax
00004FBB  42                inc dx
00004FBC  2BCB              sub cx,bx
00004FBE  83C102            add cx,byte +0x2
00004FC1  52                push dx
00004FC2  51                push cx
00004FC3  51                push cx
00004FC4  F3A4              rep movsb
00004FC6  59                pop cx
00004FC7  2BF1              sub si,cx
00004FC9  81C64001          add si,0x140
00004FCD  4A                dec dx
00004FCE  75F3              jnz 0x4fc3
00004FD0  59                pop cx
00004FD1  5A                pop dx
00004FD2  5E                pop si
00004FD3  1F                pop ds
00004FD4  5F                pop di
00004FD5  07                pop es
00004FD6  51                push cx
00004FD7  56                push si
00004FD8  268A05            mov al,[es:di]
00004FDB  8804              mov [si],al
00004FDD  81C64001          add si,0x140
00004FE1  8804              mov [si],al
00004FE3  46                inc si
00004FE4  8804              mov [si],al
00004FE6  81EE4001          sub si,0x140
00004FEA  8804              mov [si],al
00004FEC  46                inc si
00004FED  47                inc di
00004FEE  E2E8              loop 0x4fd8
00004FF0  5E                pop si
00004FF1  81C68002          add si,0x280
00004FF5  59                pop cx
00004FF6  4A                dec dx
00004FF7  75DD              jnz 0x4fd6
00004FF9  1F                pop ds
00004FFA  33C9              xor cx,cx
00004FFC  8B5E34            mov bx,[bp+0x34]
00004FFF  8B4636            mov ax,[bp+0x36]
00005002  E879F9            call 0x497e
00005005  8EC0              mov es,ax
00005007  8BF3              mov si,bx
00005009  06                push es
0000500A  56                push si
0000500B  51                push cx
0000500C  268B04            mov ax,[es:si]
0000500F  86E0              xchg ah,al
00005011  268B5C02          mov bx,[es:si+0x2]
00005015  86FB              xchg bh,bl
00005017  E864F9            call 0x497e
0000501A  3D0000            cmp ax,0x0
0000501D  7C2A              jl 0x5049
0000501F  33C0              xor ax,ax
00005021  50                push ax
00005022  50                push ax
00005023  8B5E04            mov bx,[bp+0x4]
00005026  8B4606            mov ax,[bp+0x6]
00005029  E852F9            call 0x497e
0000502C  40                inc ax
0000502D  50                push ax
0000502E  268B04            mov ax,[es:si]
00005031  86E0              xchg ah,al
00005033  268B5C02          mov bx,[es:si+0x2]
00005037  86FB              xchg bh,bl
00005039  E842F9            call 0x497e
0000503C  53                push bx
0000503D  50                push ax
0000503E  9A00009304        call 0x493:0x0
00005043  83C40A            add sp,byte +0xa
00005046  EB18              jmp short 0x5060
00005048  90                nop
00005049  59                pop cx
0000504A  5E                pop si
0000504B  07                pop es
0000504C  83C604            add si,byte +0x4
0000504F  41                inc cx
00005050  83F905            cmp cx,byte +0x5
00005053  75B4              jnz 0x5009
00005055  1F                pop ds
00005056  C70620060000      mov word [0x620],0x0
0000505C  5F                pop di
0000505D  5E                pop si
0000505E  5D                pop bp
0000505F  CB                retf
00005060  59                pop cx
00005061  51                push cx
00005062  A3860E            mov [0xe86],ax
00005065  8916880E          mov [0xe88],dx
00005069  C7067E0E0000      mov word [0xe7e],0x0
0000506F  C706800E0000      mov word [0xe80],0x0
00005075  A3840E            mov [0xe84],ax
00005078  8916820E          mov [0xe82],dx
0000507C  8B5E34            mov bx,[bp+0x34]
0000507F  8B4636            mov ax,[bp+0x36]
00005082  E8F9F8            call 0x497e
00005085  8EC0              mov es,ax
00005087  8BF3              mov si,bx
00005089  83C614            add si,byte +0x14
0000508C  D1E1              shl cx,1
0000508E  03F1              add si,cx
00005090  268B04            mov ax,[es:si]
00005093  86E0              xchg ah,al
00005095  268B5C0A          mov bx,[es:si+0xa]
00005099  86FB              xchg bh,bl
0000509B  8B0E860E          mov cx,[0xe86]
0000509F  D1E9              shr cx,1
000050A1  8B16880E          mov dx,[0xe88]
000050A5  D1EA              shr dx,1
000050A7  03C8              add cx,ax
000050A9  03D3              add dx,bx
000050AB  3B4E08            cmp cx,[bp+0x8]
000050AE  7D03              jnl 0x50b3
000050B0  E90B01            jmp 0x51be
000050B3  3B560C            cmp dx,[bp+0xc]
000050B6  7D03              jnl 0x50bb
000050B8  E90301            jmp 0x51be
000050BB  3B4610            cmp ax,[bp+0x10]
000050BE  7E03              jng 0x50c3
000050C0  E9FB00            jmp 0x51be
000050C3  3B5E14            cmp bx,[bp+0x14]
000050C6  7E03              jng 0x50cb
000050C8  E9F300            jmp 0x51be
000050CB  2B4608            sub ax,[bp+0x8]
000050CE  2B5E0C            sub bx,[bp+0xc]
000050D1  50                push ax
000050D2  53                push bx
000050D3  8BC1              mov ax,cx
000050D5  8BDA              mov bx,dx
000050D7  8B4E10            mov cx,[bp+0x10]
000050DA  8B5614            mov dx,[bp+0x14]
000050DD  2BC8              sub cx,ax
000050DF  2BD3              sub dx,bx
000050E1  5B                pop bx
000050E2  58                pop ax
000050E3  8B7E18            mov di,[bp+0x18]
000050E6  8B761C            mov si,[bp+0x1c]
000050E9  3D0000            cmp ax,0x0
000050EC  7C07              jl 0x50f5
000050EE  D1E0              shl ax,1
000050F0  03F8              add di,ax
000050F2  EB14              jmp short 0x5108
000050F4  90                nop
000050F5  F7D8              neg ax
000050F7  D1E0              shl ax,1
000050F9  A37E0E            mov [0xe7e],ax
000050FC  53                push bx
000050FD  8B1E860E          mov bx,[0xe86]
00005101  2BD8              sub bx,ax
00005103  891E840E          mov [0xe84],bx
00005107  5B                pop bx
00005108  83FB00            cmp bx,byte +0x0
0000510B  7C07              jl 0x5114
0000510D  D1E3              shl bx,1
0000510F  03F3              add si,bx
00005111  EB11              jmp short 0x5124
00005113  90                nop
00005114  F7DB              neg bx
00005116  D1E3              shl bx,1
00005118  891E800E          mov [0xe80],bx
0000511C  A1880E            mov ax,[0xe88]
0000511F  2BC3              sub ax,bx
00005121  A3820E            mov [0xe82],ax
00005124  83F900            cmp cx,byte +0x0
00005127  7D0F              jnl 0x5138
00005129  F7D9              neg cx
0000512B  D1E1              shl cx,1
0000512D  A1860E            mov ax,[0xe86]
00005130  2BC1              sub ax,cx
00005132  050300            add ax,0x3
00005135  A3840E            mov [0xe84],ax
00005138  83FA00            cmp dx,byte +0x0
0000513B  7D26              jnl 0x5163
0000513D  A1880E            mov ax,[0xe88]
00005140  F7DA              neg dx
00005142  D1E2              shl dx,1
00005144  2BC2              sub ax,dx
00005146  A3820E            mov [0xe82],ax
00005149  833E820E22        cmp word [0xe82],byte +0x22
0000514E  7E06              jng 0x5156
00005150  C706820E2200      mov word [0xe82],0x22
00005156  833E840E3E        cmp word [0xe84],byte +0x3e
0000515B  7E06              jng 0x5163
0000515D  C706840E3E00      mov word [0xe84],0x3e
00005163  1E                push ds
00005164  8BC6              mov ax,si
00005166  8BDF              mov bx,di
00005168  B94001            mov cx,0x140
0000516B  F7E1              mul cx
0000516D  03C3              add ax,bx
0000516F  8BF8              mov di,ax
00005171  A1800E            mov ax,[0xe80]
00005174  8B1E7E0E          mov bx,[0xe7e]
00005178  B94001            mov cx,0x140
0000517B  F7E1              mul cx
0000517D  03C3              add ax,bx
0000517F  8BF0              mov si,ax
00005181  8B5E04            mov bx,[bp+0x4]
00005184  8B4606            mov ax,[bp+0x6]
00005187  E8F4F7            call 0x497e
0000518A  33DB              xor bx,bx
0000518C  40                inc ax
0000518D  8B0E840E          mov cx,[0xe84]
00005191  0BC9              or cx,cx
00005193  7428              jz 0x51bd
00005195  8B16820E          mov dx,[0xe82]
00005199  0BD2              or dx,dx
0000519B  7420              jz 0x51bd
0000519D  8E069404          mov es,[0x494]
000051A1  803E7D0EFF        cmp byte [0xe7d],0xff
000051A6  751A              jnz 0x51c2
000051A8  8ED8              mov ds,ax
000051AA  51                push cx
000051AB  F3A4              rep movsb
000051AD  59                pop cx
000051AE  2BF1              sub si,cx
000051B0  2BF9              sub di,cx
000051B2  81C74001          add di,0x140
000051B6  81C64001          add si,0x140
000051BA  4A                dec dx
000051BB  75ED              jnz 0x51aa
000051BD  1F                pop ds
000051BE  59                pop cx
000051BF  E988FE            jmp 0x504a
000051C2  8A1E7D0E          mov bl,[0xe7d]
000051C6  8ED8              mov ds,ax
000051C8  8AC3              mov al,bl
000051CA  51                push cx
000051CB  8A24              mov ah,[si]
000051CD  3AE0              cmp ah,al
000051CF  7403              jz 0x51d4
000051D1  268825            mov [es:di],ah
000051D4  47                inc di
000051D5  46                inc si
000051D6  E2F3              loop 0x51cb
000051D8  59                pop cx
000051D9  2BF1              sub si,cx
000051DB  2BF9              sub di,cx
000051DD  81C74001          add di,0x140
000051E1  81C64001          add si,0x140
000051E5  4A                dec dx
000051E6  75E2              jnz 0x51ca
000051E8  EBD3              jmp short 0x51bd
000051EA  51                push cx
000051EB  52                push dx
000051EC  33D2              xor dx,dx
000051EE  B94001            mov cx,0x140
000051F1  F7E1              mul cx
000051F3  03C3              add ax,bx
000051F5  5A                pop dx
000051F6  59                pop cx
000051F7  C3                ret
000051F8  55                push bp
000051F9  8BEC              mov bp,sp
000051FB  9AD300E808        call 0x8e8:0xd3
00005200  803EF60001        cmp byte [0xf6],0x1
00005205  7503              jnz 0x520a
00005207  E87906            call 0x5883
0000520A  55                push bp
0000520B  1E                push ds
0000520C  81EC1202          sub sp,0x212
00005210  8BEC              mov bp,sp
00005212  83EC1A            sub sp,byte +0x1a
00005215  8B861202          mov ax,[bp+0x212]
00005219  894600            mov [bp+0x0],ax
0000521C  8B861402          mov ax,[bp+0x214]
00005220  894602            mov [bp+0x2],ax
00005223  8B861C02          mov ax,[bp+0x21c]
00005227  894606            mov [bp+0x6],ax
0000522A  8B861E02          mov ax,[bp+0x21e]
0000522E  894608            mov [bp+0x8],ax
00005231  8B862202          mov ax,[bp+0x222]
00005235  8ED8              mov ds,ax
00005237  8B862002          mov ax,[bp+0x220]
0000523B  57                push di
0000523C  56                push si
0000523D  53                push bx
0000523E  8BF8              mov di,ax
00005240  BE0A00            mov si,0xa
00005243  1E                push ds
00005244  BB420A            mov bx,0xa42
00005247  8EDB              mov ds,bx
00005249  8A1EF600          mov bl,[0xf6]
0000524D  1F                pop ds
0000524E  80FB01            cmp bl,0x1
00005251  7503              jnz 0x5256
00005253  EB25              jmp short 0x527a
00005255  90                nop
00005256  8D1E1213          lea bx,[0x1312]
0000525A  57                push di
0000525B  1E                push ds
0000525C  50                push ax
0000525D  B8420A            mov ax,0xa42
00005260  8ED8              mov ds,ax
00005262  8A07              mov al,[bx]
00005264  32E4              xor ah,ah
00005266  03F8              add di,ax
00005268  58                pop ax
00005269  1F                pop ds
0000526A  8B05              mov ax,[di]
0000526C  5F                pop di
0000526D  8802              mov [bp+si],al
0000526F  46                inc si
00005270  43                inc bx
00005271  81FE0A01          cmp si,0x10a
00005275  75E3              jnz 0x525a
00005277  EB18              jmp short 0x5291
00005279  90                nop
0000527A  8D1E1214          lea bx,[0x1412]
0000527E  1E                push ds
0000527F  B8420A            mov ax,0xa42
00005282  8ED8              mov ds,ax
00005284  8A07              mov al,[bx]
00005286  1F                pop ds
00005287  8802              mov [bp+si],al
00005289  46                inc si
0000528A  43                inc bx
0000528B  81FE0A01          cmp si,0x10a
0000528F  75ED              jnz 0x527e
00005291  5B                pop bx
00005292  5E                pop si
00005293  5F                pop di
00005294  33C0              xor ax,ax
00005296  8946F6            mov [bp-0xa],ax
00005299  A12015            mov ax,[0x1520]
0000529C  8ED8              mov ds,ax
0000529E  1E                push ds
0000529F  B8420A            mov ax,0xa42
000052A2  8ED8              mov ds,ax
000052A4  A11C15            mov ax,[0x151c]
000052A7  1F                pop ds
000052A8  8EC0              mov es,ax
000052AA  33FF              xor di,di
000052AC  33F6              xor si,si
000052AE  33C0              xor ax,ax
000052B0  268A04            mov al,[es:si]
000052B3  46                inc si
000052B4  3D0000            cmp ax,0x0
000052B7  7458              jz 0x5311
000052B9  3D0200            cmp ax,0x2
000052BC  7456              jz 0x5314
000052BE  3D0600            cmp ax,0x6
000052C1  7454              jz 0x5317
000052C3  3D0400            cmp ax,0x4
000052C6  7452              jz 0x531a
000052C8  3D3E00            cmp ax,0x3e
000052CB  74E1              jz 0x52ae
000052CD  1E                push ds
000052CE  50                push ax
000052CF  B8420A            mov ax,0xa42
000052D2  8ED8              mov ds,ax
000052D4  58                pop ax
000052D5  8B0E1E15          mov cx,[0x151e]
000052D9  8ED9              mov ds,cx
000052DB  8B7EF6            mov di,[bp-0xa]
000052DE  8905              mov [di],ax
000052E0  47                inc di
000052E1  47                inc di
000052E2  897EF6            mov [bp-0xa],di
000052E5  1F                pop ds
000052E6  3D2300            cmp ax,0x23
000052E9  7402              jz 0x52ed
000052EB  EBC1              jmp short 0x52ae
000052ED  1E                push ds
000052EE  50                push ax
000052EF  B8420A            mov ax,0xa42
000052F2  8ED8              mov ds,ax
000052F4  803EF60002        cmp byte [0xf6],0x2
000052F9  7505              jnz 0x5300
000052FB  58                pop ax
000052FC  1F                pop ds
000052FD  E91603            jmp 0x5616
00005300  803EF60000        cmp byte [0xf6],0x0
00005305  7405              jz 0x530c
00005307  58                pop ax
00005308  1F                pop ds
00005309  E98F04            jmp 0x579b
0000530C  58                pop ax
0000530D  1F                pop ds
0000530E  E98401            jmp 0x5495
00005311  EB0A              jmp short 0x531d
00005313  90                nop
00005314  E9AF00            jmp 0x53c6
00005317  E9C200            jmp 0x53dc
0000531A  E9D500            jmp 0x53f2
0000531D  268A04            mov al,[es:si]
00005320  46                inc si
00005321  32E4              xor ah,ah
00005323  B306              mov bl,0x6
00005325  F6E3              mul bl
00005327  268A14            mov dl,[es:si]
0000532A  46                inc si
0000532B  32F6              xor dh,dh
0000532D  8BF8              mov di,ax
0000532F  0BD2              or dx,dx
00005331  7412              jz 0x5345
00005333  4A                dec dx
00005334  7412              jz 0x5348
00005336  4A                dec dx
00005337  7412              jz 0x534b
00005339  4A                dec dx
0000533A  7412              jz 0x534e
0000533C  4A                dec dx
0000533D  7412              jz 0x5351
0000533F  4A                dec dx
00005340  7412              jz 0x5354
00005342  E94C02            jmp 0x5591
00005345  EB10              jmp short 0x5357
00005347  90                nop
00005348  EB1F              jmp short 0x5369
0000534A  90                nop
0000534B  EB2E              jmp short 0x537b
0000534D  90                nop
0000534E  EB3E              jmp short 0x538e
00005350  90                nop
00005351  EB4D              jmp short 0x53a0
00005353  90                nop
00005354  EB5D              jmp short 0x53b3
00005356  90                nop
00005357  8B05              mov ax,[di]
00005359  86E0              xchg ah,al
0000535B  8946FE            mov [bp-0x2],ax
0000535E  8B4506            mov ax,[di+0x6]
00005361  86E0              xchg ah,al
00005363  8946FC            mov [bp-0x4],ax
00005366  E9B000            jmp 0x5419
00005369  8B05              mov ax,[di]
0000536B  86E0              xchg ah,al
0000536D  8946FE            mov [bp-0x2],ax
00005370  8B4504            mov ax,[di+0x4]
00005373  86E0              xchg ah,al
00005375  8946FC            mov [bp-0x4],ax
00005378  E99E00            jmp 0x5419
0000537B  8B4502            mov ax,[di+0x2]
0000537E  86E0              xchg ah,al
00005380  8946FE            mov [bp-0x2],ax
00005383  8B4506            mov ax,[di+0x6]
00005386  86E0              xchg ah,al
00005388  8946FC            mov [bp-0x4],ax
0000538B  E98B00            jmp 0x5419
0000538E  8B05              mov ax,[di]
00005390  86E0              xchg ah,al
00005392  8946FE            mov [bp-0x2],ax
00005395  8B4502            mov ax,[di+0x2]
00005398  86E0              xchg ah,al
0000539A  8946FC            mov [bp-0x4],ax
0000539D  EB7A              jmp short 0x5419
0000539F  90                nop
000053A0  8B4502            mov ax,[di+0x2]
000053A3  86E0              xchg ah,al
000053A5  8946FE            mov [bp-0x2],ax
000053A8  8B4504            mov ax,[di+0x4]
000053AB  86E0              xchg ah,al
000053AD  8946FC            mov [bp-0x4],ax
000053B0  EB67              jmp short 0x5419
000053B2  90                nop
000053B3  8B4504            mov ax,[di+0x4]
000053B6  86E0              xchg ah,al
000053B8  8946FE            mov [bp-0x2],ax
000053BB  8B4506            mov ax,[di+0x6]
000053BE  86E0              xchg ah,al
000053C0  8946FC            mov [bp-0x4],ax
000053C3  EB54              jmp short 0x5419
000053C5  90                nop
000053C6  268A04            mov al,[es:si]
000053C9  32E4              xor ah,ah
000053CB  46                inc si
000053CC  B306              mov bl,0x6
000053CE  F6E3              mul bl
000053D0  268A14            mov dl,[es:si]
000053D3  32F6              xor dh,dh
000053D5  46                inc si
000053D6  058600            add ax,0x86
000053D9  E951FF            jmp 0x532d
000053DC  268A04            mov al,[es:si]
000053DF  32E4              xor ah,ah
000053E1  46                inc si
000053E2  B306              mov bl,0x6
000053E4  F6E3              mul bl
000053E6  268A14            mov dl,[es:si]
000053E9  32F6              xor dh,dh
000053EB  46                inc si
000053EC  055A01            add ax,0x15a
000053EF  E93BFF            jmp 0x532d
000053F2  268A1C            mov bl,[es:si]
000053F5  32FF              xor bh,bh
000053F7  46                inc si
000053F8  268A04            mov al,[es:si]
000053FB  32E4              xor ah,ah
000053FD  46                inc si
000053FE  B20E              mov dl,0xe
00005400  F6E2              mul dl
00005402  03D8              add bx,ax
00005404  D1E3              shl bx,1
00005406  81C32E02          add bx,0x22e
0000540A  8B07              mov ax,[bx]
0000540C  86E0              xchg ah,al
0000540E  8946FE            mov [bp-0x2],ax
00005411  8B4702            mov ax,[bx+0x2]
00005414  86E0              xchg ah,al
00005416  8946FC            mov [bp-0x4],ax
00005419  50                push ax
0000541A  1E                push ds
0000541B  B8420A            mov ax,0xa42
0000541E  8ED8              mov ds,ax
00005420  8B1E2015          mov bx,[0x1520]
00005424  83C350            add bx,byte +0x50
00005427  1F                pop ds
00005428  58                pop ax
00005429  8B7EFE            mov di,[bp-0x2]
0000542C  83C708            add di,byte +0x8
0000542F  8B56FC            mov dx,[bp-0x4]
00005432  83C208            add dx,byte +0x8
00005435  E86E01            call 0x55a6
00005438  E973FE            jmp 0x52ae
0000543B  59                pop cx
0000543C  1E                push ds
0000543D  33DB              xor bx,bx
0000543F  8EDB              mov ds,bx
00005441  BB2000            mov bx,0x20
00005444  8B07              mov ax,[bx]
00005446  8B5702            mov dx,[bx+0x2]
00005449  8946EC            mov [bp-0x14],ax
0000544C  8956EA            mov [bp-0x16],dx
0000544F  FA                cli
00005450  33DB              xor bx,bx
00005452  8EDB              mov ds,bx
00005454  BB2000            mov bx,0x20
00005457  890F              mov [bx],cx
00005459  8C4F02            mov [bx+0x2],cs
0000545C  B036              mov al,0x36
0000545E  E643              out 0x43,al
00005460  8B4606            mov ax,[bp+0x6]
00005463  E640              out 0x40,al
00005465  86E0              xchg ah,al
00005467  E640              out 0x40,al
00005469  B0FE              mov al,0xfe
0000546B  E621              out 0x21,al
0000546D  1F                pop ds
0000546E  C3                ret
0000546F  FA                cli
00005470  33C0              xor ax,ax
00005472  8ED8              mov ds,ax
00005474  BB2000            mov bx,0x20
00005477  8B46EC            mov ax,[bp-0x14]
0000547A  8B56EA            mov dx,[bp-0x16]
0000547D  8907              mov [bx],ax
0000547F  895702            mov [bx+0x2],dx
00005482  B036              mov al,0x36
00005484  E643              out 0x43,al
00005486  33C0              xor ax,ax
00005488  B8FFFF            mov ax,0xffff
0000548B  E640              out 0x40,al
0000548D  E640              out 0x40,al
0000548F  32C0              xor al,al
00005491  E621              out 0x21,al
00005493  FB                sti
00005494  C3                ret
00005495  E82E00            call 0x54c6
00005498  E83301            call 0x55ce
0000549B  B0B0              mov al,0xb0
0000549D  E643              out 0x43,al
0000549F  33C0              xor ax,ax
000054A1  E642              out 0x42,al
000054A3  E642              out 0x42,al
000054A5  B090              mov al,0x90
000054A7  E643              out 0x43,al
000054A9  BA2000            mov dx,0x20
000054AC  1E                push ds
000054AD  B8420A            mov ax,0xa42
000054B0  8ED8              mov ds,ax
000054B2  A11E15            mov ax,[0x151e]
000054B5  1F                pop ds
000054B6  8EC0              mov es,ax
000054B8  33DB              xor bx,bx
000054BA  83C50A            add bp,byte +0xa
000054BD  895EFE            mov [bp-0x2],bx
000054C0  8C46FC            mov [bp-0x4],es
000054C3  EB7A              jmp short 0x553f
000054C5  90                nop
000054C6  E872FF            call 0x543b
000054C9  E642              out 0x42,al
000054CB  8AC2              mov al,dl
000054CD  EE                out dx,al
000054CE  83C406            add sp,byte +0x6
000054D1  EB68              jmp short 0x553b
000054D3  90                nop
000054D4  53                push bx
000054D5  06                push es
000054D6  8E46FC            mov es,[bp-0x4]
000054D9  8B5EFE            mov bx,[bp-0x2]
000054DC  8ED8              mov ds,ax
000054DE  268B07            mov ax,[es:bx]
000054E1  8BF8              mov di,ax
000054E3  43                inc bx
000054E4  43                inc bx
000054E5  268B07            mov ax,[es:bx]
000054E8  43                inc bx
000054E9  43                inc bx
000054EA  8C46FC            mov [bp-0x4],es
000054ED  895EFE            mov [bp-0x2],bx
000054F0  07                pop es
000054F1  5B                pop bx
000054F2  8BC8              mov cx,ax
000054F4  2BCF              sub cx,di
000054F6  7503              jnz 0x54fb
000054F8  EB45              jmp short 0x553f
000054FA  90                nop
000054FB  D1E1              shl cx,1
000054FD  32E4              xor ah,ah
000054FF  8A05              mov al,[di]
00005501  24F0              and al,0xf0
00005503  8BF3              mov si,bx
00005505  03D8              add bx,ax
00005507  268A07            mov al,[es:bx]
0000550A  0246FA            add al,[bp-0x6]
0000550D  8846FA            mov [bp-0x6],al
00005510  8BDE              mov bx,si
00005512  8BF0              mov si,ax
00005514  8A02              mov al,[bp+si]
00005516  49                dec cx
00005517  FB                sti
00005518  F4                hlt
00005519  8A05              mov al,[di]
0000551B  F6C101            test cl,0x1
0000551E  7504              jnz 0x5524
00005520  24F0              and al,0xf0
00005522  EB03              jmp short 0x5527
00005524  240F              and al,0xf
00005526  47                inc di
00005527  8BF3              mov si,bx
00005529  03D8              add bx,ax
0000552B  268A07            mov al,[es:bx]
0000552E  0246FA            add al,[bp-0x6]
00005531  8846FA            mov [bp-0x6],al
00005534  8BDE              mov bx,si
00005536  8BF0              mov si,ax
00005538  8A02              mov al,[bp+si]
0000553A  F4                hlt
0000553B  FB                sti
0000553C  E2DB              loop 0x5519
0000553E  FA                cli
0000553F  C646FA80          mov byte [bp-0x6],0x80
00005543  8B5EFE            mov bx,[bp-0x2]
00005546  8E46FC            mov es,[bp-0x4]
00005549  268B07            mov ax,[es:bx]
0000554C  43                inc bx
0000554D  43                inc bx
0000554E  8C46FC            mov [bp-0x4],es
00005551  895EFE            mov [bp-0x2],bx
00005554  50                push ax
00005555  B8420A            mov ax,0xa42
00005558  8EC0              mov es,ax
0000555A  8D1E1212          lea bx,[0x1212]
0000555E  58                pop ax
0000555F  0AE4              or ah,ah
00005561  7403              jz 0x5566
00005563  E96EFF            jmp 0x54d4
00005566  50                push ax
00005567  B096              mov al,0x96
00005569  E643              out 0x43,al
0000556B  B032              mov al,0x32
0000556D  E642              out 0x42,al
0000556F  58                pop ax
00005570  3C20              cmp al,0x20
00005572  750E              jnz 0x5582
00005574  B8F401            mov ax,0x1f4
00005577  B91400            mov cx,0x14
0000557A  E2FE              loop 0x557a
0000557C  48                dec ax
0000557D  75F8              jnz 0x5577
0000557F  EB0A              jmp short 0x558b
00005581  90                nop
00005582  3C2E              cmp al,0x2e
00005584  750B              jnz 0x5591
00005586  B88813            mov ax,0x1388
00005589  EBEC              jmp short 0x5577
0000558B  B090              mov al,0x90
0000558D  E643              out 0x43,al
0000558F  EBAE              jmp short 0x553f
00005591  E83300            call 0x55c7
00005594  83ED0A            sub bp,byte +0xa
00005597  E8D5FE            call 0x546f
0000559A  8BE5              mov sp,bp
0000559C  81C41202          add sp,0x212
000055A0  1F                pop ds
000055A1  83C402            add sp,byte +0x2
000055A4  5D                pop bp
000055A5  CB                retf
000055A6  1E                push ds
000055A7  B8420A            mov ax,0xa42
000055AA  8ED8              mov ds,ax
000055AC  A11E15            mov ax,[0x151e]
000055AF  8ED8              mov ds,ax
000055B1  8BC7              mov ax,di
000055B3  8B7EF6            mov di,[bp-0xa]
000055B6  891D              mov [di],bx
000055B8  47                inc di
000055B9  47                inc di
000055BA  8905              mov [di],ax
000055BC  47                inc di
000055BD  47                inc di
000055BE  8915              mov [di],dx
000055C0  47                inc di
000055C1  47                inc di
000055C2  897EF6            mov [bp-0xa],di
000055C5  1F                pop ds
000055C6  C3                ret
000055C7  E461              in al,0x61
000055C9  24FC              and al,0xfc
000055CB  E661              out 0x61,al
000055CD  C3                ret
000055CE  B0B0              mov al,0xb0
000055D0  E643              out 0x43,al
000055D2  B80A00            mov ax,0xa
000055D5  E642              out 0x42,al
000055D7  86C4              xchg al,ah
000055D9  E642              out 0x42,al
000055DB  E461              in al,0x61
000055DD  0C03              or al,0x3
000055DF  E661              out 0x61,al
000055E1  C3                ret
000055E2  59                pop cx
000055E3  1E                push ds
000055E4  33DB              xor bx,bx
000055E6  8EDB              mov ds,bx
000055E8  BB2000            mov bx,0x20
000055EB  8B07              mov ax,[bx]
000055ED  8B5702            mov dx,[bx+0x2]
000055F0  8946EC            mov [bp-0x14],ax
000055F3  8956EA            mov [bp-0x16],dx
000055F6  FA                cli
000055F7  33DB              xor bx,bx
000055F9  8EDB              mov ds,bx
000055FB  BB2000            mov bx,0x20
000055FE  890F              mov [bx],cx
00005600  8C4F02            mov [bx+0x2],cs
00005603  B036              mov al,0x36
00005605  E643              out 0x43,al
00005607  8B4606            mov ax,[bp+0x6]
0000560A  E640              out 0x40,al
0000560C  86E0              xchg ah,al
0000560E  E640              out 0x40,al
00005610  B0FE              mov al,0xfe
00005612  E621              out 0x21,al
00005614  1F                pop ds
00005615  C3                ret
00005616  E82D00            call 0x5646
00005619  E83201            call 0x574e
0000561C  1E                push ds
0000561D  50                push ax
0000561E  B8420A            mov ax,0xa42
00005621  8ED8              mov ds,ax
00005623  8B16F700          mov dx,[0xf7]
00005627  58                pop ax
00005628  1F                pop ds
00005629  83C20C            add dx,byte +0xc
0000562C  1E                push ds
0000562D  B8420A            mov ax,0xa42
00005630  8ED8              mov ds,ax
00005632  A11E15            mov ax,[0x151e]
00005635  1F                pop ds
00005636  8EC0              mov es,ax
00005638  33DB              xor bx,bx
0000563A  83C50A            add bp,byte +0xa
0000563D  895EFE            mov [bp-0x2],bx
00005640  8C46FC            mov [bp-0x4],es
00005643  E99900            jmp 0x56df
00005646  E899FF            call 0x55e2
00005649  B020              mov al,0x20
0000564B  E620              out 0x20,al
0000564D  CF                iret
0000564E  53                push bx
0000564F  06                push es
00005650  8E46FC            mov es,[bp-0x4]
00005653  8B5EFE            mov bx,[bp-0x2]
00005656  8ED8              mov ds,ax
00005658  268B07            mov ax,[es:bx]
0000565B  8BF8              mov di,ax
0000565D  43                inc bx
0000565E  43                inc bx
0000565F  268B07            mov ax,[es:bx]
00005662  43                inc bx
00005663  43                inc bx
00005664  895EFE            mov [bp-0x2],bx
00005667  07                pop es
00005668  5B                pop bx
00005669  8BC8              mov cx,ax
0000566B  2BCF              sub cx,di
0000566D  7503              jnz 0x5672
0000566F  EB6E              jmp short 0x56df
00005671  90                nop
00005672  D1E1              shl cx,1
00005674  32E4              xor ah,ah
00005676  8A05              mov al,[di]
00005678  24F0              and al,0xf0
0000567A  8BF3              mov si,bx
0000567C  03F0              add si,ax
0000567E  EC                in al,dx
0000567F  0AC0              or al,al
00005681  78FB              js 0x567e
00005683  B010              mov al,0x10
00005685  EE                out dx,al
00005686  EC                in al,dx
00005687  0AC0              or al,al
00005689  78FB              js 0x5686
0000568B  26AC              es lodsb
0000568D  0246FA            add al,[bp-0x6]
00005690  8846FA            mov [bp-0x6],al
00005693  EE                out dx,al
00005694  49                dec cx
00005695  FB                sti
00005696  F4                hlt
00005697  8A05              mov al,[di]
00005699  F6C101            test cl,0x1
0000569C  7520              jnz 0x56be
0000569E  24F0              and al,0xf0
000056A0  8BF3              mov si,bx
000056A2  03F0              add si,ax
000056A4  EC                in al,dx
000056A5  0AC0              or al,al
000056A7  78FB              js 0x56a4
000056A9  B010              mov al,0x10
000056AB  EE                out dx,al
000056AC  EC                in al,dx
000056AD  0AC0              or al,al
000056AF  78FB              js 0x56ac
000056B1  26AC              es lodsb
000056B3  0246FA            add al,[bp-0x6]
000056B6  8846FA            mov [bp-0x6],al
000056B9  EE                out dx,al
000056BA  F4                hlt
000056BB  EB1F              jmp short 0x56dc
000056BD  90                nop
000056BE  240F              and al,0xf
000056C0  47                inc di
000056C1  8BF3              mov si,bx
000056C3  03F0              add si,ax
000056C5  EC                in al,dx
000056C6  0AC0              or al,al
000056C8  78FB              js 0x56c5
000056CA  B010              mov al,0x10
000056CC  EE                out dx,al
000056CD  EC                in al,dx
000056CE  0AC0              or al,al
000056D0  78FB              js 0x56cd
000056D2  26AC              es lodsb
000056D4  0246FA            add al,[bp-0x6]
000056D7  8846FA            mov [bp-0x6],al
000056DA  EE                out dx,al
000056DB  F4                hlt
000056DC  E2B9              loop 0x5697
000056DE  FA                cli
000056DF  C646FA80          mov byte [bp-0x6],0x80
000056E3  8B5EFE            mov bx,[bp-0x2]
000056E6  8E46FC            mov es,[bp-0x4]
000056E9  268B07            mov ax,[es:bx]
000056EC  43                inc bx
000056ED  43                inc bx
000056EE  895EFE            mov [bp-0x2],bx
000056F1  50                push ax
000056F2  B8420A            mov ax,0xa42
000056F5  8EC0              mov es,ax
000056F7  8D1E1212          lea bx,[0x1212]
000056FB  58                pop ax
000056FC  0AE4              or ah,ah
000056FE  7403              jz 0x5703
00005700  E94BFF            jmp 0x564e
00005703  3C20              cmp al,0x20
00005705  750E              jnz 0x5715
00005707  B8F401            mov ax,0x1f4
0000570A  B91400            mov cx,0x14
0000570D  E2FE              loop 0x570d
0000570F  48                dec ax
00005710  75F8              jnz 0x570a
00005712  EB0A              jmp short 0x571e
00005714  90                nop
00005715  3C2E              cmp al,0x2e
00005717  7507              jnz 0x5720
00005719  B88813            mov ax,0x1388
0000571C  EBEC              jmp short 0x570a
0000571E  EBBF              jmp short 0x56df
00005720  E81200            call 0x5735
00005723  83ED0A            sub bp,byte +0xa
00005726  E846FD            call 0x546f
00005729  8BE5              mov sp,bp
0000572B  81C41202          add sp,0x212
0000572F  1F                pop ds
00005730  83C402            add sp,byte +0x2
00005733  5D                pop bp
00005734  CB                retf
00005735  52                push dx
00005736  1E                push ds
00005737  BA420A            mov dx,0xa42
0000573A  8EDA              mov ds,dx
0000573C  8B16F700          mov dx,[0xf7]
00005740  1F                pop ds
00005741  83C20C            add dx,byte +0xc
00005744  EC                in al,dx
00005745  0AC0              or al,al
00005747  78FB              js 0x5744
00005749  B0D3              mov al,0xd3
0000574B  EE                out dx,al
0000574C  5A                pop dx
0000574D  C3                ret
0000574E  52                push dx
0000574F  1E                push ds
00005750  BA420A            mov dx,0xa42
00005753  8EDA              mov ds,dx
00005755  8B16F700          mov dx,[0xf7]
00005759  1F                pop ds
0000575A  83C20C            add dx,byte +0xc
0000575D  EC                in al,dx
0000575E  0AC0              or al,al
00005760  78FB              js 0x575d
00005762  B0D1              mov al,0xd1
00005764  EE                out dx,al
00005765  5A                pop dx
00005766  C3                ret
00005767  59                pop cx
00005768  1E                push ds
00005769  33DB              xor bx,bx
0000576B  8EDB              mov ds,bx
0000576D  BB2000            mov bx,0x20
00005770  8B07              mov ax,[bx]
00005772  8B5702            mov dx,[bx+0x2]
00005775  8946EC            mov [bp-0x14],ax
00005778  8956EA            mov [bp-0x16],dx
0000577B  FA                cli
0000577C  33DB              xor bx,bx
0000577E  8EDB              mov ds,bx
00005780  BB2000            mov bx,0x20
00005783  890F              mov [bx],cx
00005785  8C4F02            mov [bx+0x2],cs
00005788  B036              mov al,0x36
0000578A  E643              out 0x43,al
0000578C  8B4606            mov ax,[bp+0x6]
0000578F  E640              out 0x40,al
00005791  86E0              xchg ah,al
00005793  E640              out 0x40,al
00005795  B0FE              mov al,0xfe
00005797  E621              out 0x21,al
00005799  1F                pop ds
0000579A  C3                ret
0000579B  E81D00            call 0x57bb
0000579E  BA8903            mov dx,0x389
000057A1  1E                push ds
000057A2  B8420A            mov ax,0xa42
000057A5  8ED8              mov ds,ax
000057A7  A11E15            mov ax,[0x151e]
000057AA  1F                pop ds
000057AB  8EC0              mov es,ax
000057AD  33DB              xor bx,bx
000057AF  83C50A            add bp,byte +0xa
000057B2  895EFE            mov [bp-0x2],bx
000057B5  8C46FC            mov [bp-0x4],es
000057B8  EB71              jmp short 0x582b
000057BA  90                nop
000057BB  E8A9FF            call 0x5767
000057BE  EE                out dx,al
000057BF  B020              mov al,0x20
000057C1  E620              out 0x20,al
000057C3  CF                iret
000057C4  53                push bx
000057C5  06                push es
000057C6  8E46FC            mov es,[bp-0x4]
000057C9  8B5EFE            mov bx,[bp-0x2]
000057CC  8ED8              mov ds,ax
000057CE  268B07            mov ax,[es:bx]
000057D1  8BF8              mov di,ax
000057D3  43                inc bx
000057D4  43                inc bx
000057D5  268B07            mov ax,[es:bx]
000057D8  43                inc bx
000057D9  43                inc bx
000057DA  895EFE            mov [bp-0x2],bx
000057DD  07                pop es
000057DE  5B                pop bx
000057DF  8BC8              mov cx,ax
000057E1  2BCF              sub cx,di
000057E3  7503              jnz 0x57e8
000057E5  EB44              jmp short 0x582b
000057E7  90                nop
000057E8  D1E1              shl cx,1
000057EA  32E4              xor ah,ah
000057EC  8A05              mov al,[di]
000057EE  24F0              and al,0xf0
000057F0  8BF3              mov si,bx
000057F2  03D8              add bx,ax
000057F4  268A07            mov al,[es:bx]
000057F7  0246FA            add al,[bp-0x6]
000057FA  8846FA            mov [bp-0x6],al
000057FD  8BDE              mov bx,si
000057FF  8BF0              mov si,ax
00005801  8A02              mov al,[bp+si]
00005803  49                dec cx
00005804  FB                sti
00005805  F4                hlt
00005806  8A05              mov al,[di]
00005808  F6C101            test cl,0x1
0000580B  7504              jnz 0x5811
0000580D  24F0              and al,0xf0
0000580F  EB03              jmp short 0x5814
00005811  240F              and al,0xf
00005813  47                inc di
00005814  8BF3              mov si,bx
00005816  03D8              add bx,ax
00005818  268A07            mov al,[es:bx]
0000581B  0246FA            add al,[bp-0x6]
0000581E  8846FA            mov [bp-0x6],al
00005821  8BDE              mov bx,si
00005823  8BF0              mov si,ax
00005825  8A02              mov al,[bp+si]
00005827  F4                hlt
00005828  E2DC              loop 0x5806
0000582A  FA                cli
0000582B  C646FA80          mov byte [bp-0x6],0x80
0000582F  8B5EFE            mov bx,[bp-0x2]
00005832  8E46FC            mov es,[bp-0x4]
00005835  268B07            mov ax,[es:bx]
00005838  43                inc bx
00005839  43                inc bx
0000583A  895EFE            mov [bp-0x2],bx
0000583D  50                push ax
0000583E  B8420A            mov ax,0xa42
00005841  8EC0              mov es,ax
00005843  8D1E1212          lea bx,[0x1212]
00005847  58                pop ax
00005848  0AE4              or ah,ah
0000584A  7403              jz 0x584f
0000584C  E975FF            jmp 0x57c4
0000584F  3C20              cmp al,0x20
00005851  750E              jnz 0x5861
00005853  B8F401            mov ax,0x1f4
00005856  B91400            mov cx,0x14
00005859  E2FE              loop 0x5859
0000585B  48                dec ax
0000585C  75F8              jnz 0x5856
0000585E  EB0A              jmp short 0x586a
00005860  90                nop
00005861  3C2E              cmp al,0x2e
00005863  7507              jnz 0x586c
00005865  B88813            mov ax,0x1388
00005868  EBEC              jmp short 0x5856
0000586A  EBBF              jmp short 0x582b
0000586C  E81200            call 0x5881
0000586F  83ED0A            sub bp,byte +0xa
00005872  E8FAFB            call 0x546f
00005875  8BE5              mov sp,bp
00005877  81C41202          add sp,0x212
0000587B  1F                pop ds
0000587C  83C402            add sp,byte +0x2
0000587F  5D                pop bp
00005880  CB                retf
00005881  C3                ret
00005882  C3                ret
00005883  E85400            call 0x58da
00005886  7250              jc 0x58d8
00005888  B82F20            mov ax,0x202f
0000588B  E89300            call 0x5921
0000588E  B8F060            mov ax,0x60f0
00005891  E88D00            call 0x5921
00005894  B8F080            mov ax,0x80f0
00005897  E88700            call 0x5921
0000589A  B801C0            mov ax,0xc001
0000589D  E88100            call 0x5921
000058A0  B800E0            mov ax,0xe000
000058A3  E87B00            call 0x5921
000058A6  B83F43            mov ax,0x433f
000058A9  E87500            call 0x5921
000058AC  B800B0            mov ax,0xb000
000058AF  E86F00            call 0x5921
000058B2  B800A0            mov ax,0xa000
000058B5  E86900            call 0x5921
000058B8  B88FA0            mov ax,0xa08f
000058BB  E86300            call 0x5921
000058BE  B82EB0            mov ax,0xb02e
000058C1  E85D00            call 0x5921
000058C4  B820B0            mov ax,0xb020
000058C7  E85700            call 0x5921
000058CA  B800A0            mov ax,0xa000
000058CD  E85100            call 0x5921
000058D0  B80040            mov ax,0x4000
000058D3  E84B00            call 0x5921
000058D6  F9                stc
000058D7  C3                ret
000058D8  F8                clc
000058D9  C3                ret
000058DA  B86004            mov ax,0x460
000058DD  E84100            call 0x5921
000058E0  B88004            mov ax,0x480
000058E3  E83B00            call 0x5921
000058E6  BA8803            mov dx,0x388
000058E9  EC                in al,dx
000058EA  8ADC              mov bl,ah
000058EC  B8FF02            mov ax,0x2ff
000058EF  E82F00            call 0x5921
000058F2  B82104            mov ax,0x421
000058F5  E82900            call 0x5921
000058F8  B9C800            mov cx,0xc8
000058FB  BA8803            mov dx,0x388
000058FE  EC                in al,dx
000058FF  E2FA              loop 0x58fb
00005901  EC                in al,dx
00005902  8AF8              mov bh,al
00005904  B86004            mov ax,0x460
00005907  E81700            call 0x5921
0000590A  B88004            mov ax,0x480
0000590D  E81100            call 0x5921
00005910  F6C3E0            test bl,0xe0
00005913  750A              jnz 0x591f
00005915  80E7E0            and bh,0xe0
00005918  80FFC0            cmp bh,0xc0
0000591B  7502              jnz 0x591f
0000591D  F8                clc
0000591E  C3                ret
0000591F  F9                stc
00005920  C3                ret
00005921  51                push cx
00005922  BA8803            mov dx,0x388
00005925  86E0              xchg ah,al
00005927  EE                out dx,al
00005928  B90400            mov cx,0x4
0000592B  EC                in al,dx
0000592C  E2FD              loop 0x592b
0000592E  42                inc dx
0000592F  86E0              xchg ah,al
00005931  EE                out dx,al
00005932  BA8803            mov dx,0x388
00005935  B91100            mov cx,0x11
00005938  EC                in al,dx
00005939  E2FD              loop 0x5938
0000593B  59                pop cx
0000593C  C3                ret
0000593D  55                push bp
0000593E  8BEC              mov bp,sp
00005940  55                push bp
00005941  1E                push ds
00005942  56                push si
00005943  57                push di
00005944  803EF60002        cmp byte [0xf6],0x2
00005949  7513              jnz 0x595e
0000594B  833E10280C        cmp word [0x2810],byte +0xc
00005950  7D0C              jnl 0x595e
00005952  C70612156E00      mov word [0x1512],0x6e
00005958  C70614156E00      mov word [0x1514],0x6e
0000595E  803E8F0401        cmp byte [0x48f],0x1
00005963  7406              jz 0x596b
00005965  E8E007            call 0x6148
00005968  E9B700            jmp 0x5a22
0000596B  8BE9              mov bp,cx
0000596D  8B4E24            mov cx,[bp+0x24]
00005970  8B5626            mov dx,[bp+0x26]
00005973  8B7E20            mov di,[bp+0x20]
00005976  8B7622            mov si,[bp+0x22]
00005979  8B4600            mov ax,[bp+0x0]
0000597C  8B5E04            mov bx,[bp+0x4]
0000597F  83EC3C            sub sp,byte +0x3c
00005982  8BEC              mov bp,sp
00005984  83EC3C            sub sp,byte +0x3c
00005987  894E32            mov [bp+0x32],cx
0000598A  895634            mov [bp+0x34],dx
0000598D  897E36            mov [bp+0x36],di
00005990  897638            mov [bp+0x38],si
00005993  48                dec ax
00005994  894630            mov [bp+0x30],ax
00005997  A11215            mov ax,[0x1512]
0000599A  83FB00            cmp bx,byte +0x0
0000599D  7F03              jg 0x59a2
0000599F  A11415            mov ax,[0x1514]
000059A2  A31815            mov [0x1518],ax
000059A5  2D0800            sub ax,0x8
000059A8  BB420A            mov bx,0xa42
000059AB  8EC3              mov es,bx
000059AD  8D361211          lea si,[0x1112]
000059B1  81C6FF00          add si,0xff
000059B5  33C9              xor cx,cx
000059B7  50                push ax
000059B8  8BD9              mov bx,cx
000059BA  F7E3              mul bx
000059BC  BB0001            mov bx,0x100
000059BF  F7F3              div bx
000059C1  40                inc ax
000059C2  268804            mov [es:si],al
000059C5  4E                dec si
000059C6  41                inc cx
000059C7  58                pop ax
000059C8  81F90001          cmp cx,0x100
000059CC  75E9              jnz 0x59b7
000059CE  8B5E36            mov bx,[bp+0x36]
000059D1  8B4638            mov ax,[bp+0x38]
000059D4  E85F07            call 0x6136
000059D7  40                inc ax
000059D8  A32015            mov [0x1520],ax
000059DB  8B5E32            mov bx,[bp+0x32]
000059DE  8B4634            mov ax,[bp+0x34]
000059E1  E85207            call 0x6136
000059E4  894602            mov [bp+0x2],ax
000059E7  895E04            mov [bp+0x4],bx
000059EA  A19404            mov ax,[0x494]
000059ED  05A00F            add ax,0xfa0
000059F0  A31C15            mov [0x151c],ax
000059F3  89462C            mov [bp+0x2c],ax
000059F6  C7462E0000        mov word [bp+0x2e],0x0
000059FB  056000            add ax,0x60
000059FE  A31E15            mov [0x151e],ax
00005A01  E82400            call 0x5a28
00005A04  B8420A            mov ax,0xa42
00005A07  50                push ax
00005A08  8D361211          lea si,[0x1112]
00005A0C  56                push si
00005A0D  FF361615          push word [0x1516]
00005A11  FF361815          push word [0x1518]
00005A15  9A0800FA05        call 0x5fa:0x8
00005A1A  83C408            add sp,byte +0x8
00005A1D  8BE5              mov sp,bp
00005A1F  83C43C            add sp,byte +0x3c
00005A22  5F                pop di
00005A23  5E                pop si
00005A24  1F                pop ds
00005A25  5D                pop bp
00005A26  5D                pop bp
00005A27  CB                retf
00005A28  8B4630            mov ax,[bp+0x30]
00005A2B  D1E0              shl ax,1
00005A2D  8E4602            mov es,[bp+0x2]
00005A30  8B7604            mov si,[bp+0x4]
00005A33  56                push si
00005A34  03F0              add si,ax
00005A36  268B1C            mov bx,[es:si]
00005A39  86FB              xchg bh,bl
00005A3B  81C39803          add bx,0x398
00005A3F  268B4C02          mov cx,[es:si+0x2]
00005A43  86E9              xchg ch,cl
00005A45  81C19803          add cx,0x398
00005A49  034E04            add cx,[bp+0x4]
00005A4C  5E                pop si
00005A4D  03F3              add si,bx
00005A4F  E81900            call 0x5a6b
00005A52  E82C00            call 0x5a81
00005A55  E87000            call 0x5ac8
00005A58  E88B01            call 0x5be6
00005A5B  3BF1              cmp si,cx
00005A5D  7CF3              jl 0x5a52
00005A5F  E81F00            call 0x5a81
00005A62  E88101            call 0x5be6
00005A65  B023              mov al,0x23
00005A67  E8BB06            call 0x6125
00005A6A  C3                ret
00005A6B  C746060000        mov word [bp+0x6],0x0
00005A70  C746080000        mov word [bp+0x8],0x0
00005A75  C7460A0000        mov word [bp+0xa],0x0
00005A7A  E80400            call 0x5a81
00005A7D  E80100            call 0x5a81
00005A80  C3                ret
00005A81  8B460C            mov ax,[bp+0xc]
00005A84  894612            mov [bp+0x12],ax
00005A87  8B460E            mov ax,[bp+0xe]
00005A8A  894614            mov [bp+0x14],ax
00005A8D  8B4610            mov ax,[bp+0x10]
00005A90  894616            mov [bp+0x16],ax
00005A93  8B461A            mov ax,[bp+0x1a]
00005A96  894618            mov [bp+0x18],ax
00005A99  8B4620            mov ax,[bp+0x20]
00005A9C  89461E            mov [bp+0x1e],ax
00005A9F  8B4606            mov ax,[bp+0x6]
00005AA2  89460C            mov [bp+0xc],ax
00005AA5  8B4608            mov ax,[bp+0x8]
00005AA8  89460E            mov [bp+0xe],ax
00005AAB  8B460A            mov ax,[bp+0xa]
00005AAE  894610            mov [bp+0x10],ax
00005AB1  8B461C            mov ax,[bp+0x1c]
00005AB4  89461A            mov [bp+0x1a],ax
00005AB7  8B4622            mov ax,[bp+0x22]
00005ABA  894620            mov [bp+0x20],ax
00005ABD  C746222000        mov word [bp+0x22],0x20
00005AC2  C7461C0900        mov word [bp+0x1c],0x9
00005AC7  C3                ret
00005AC8  268B04            mov ax,[es:si]
00005ACB  86E0              xchg ah,al
00005ACD  894624            mov [bp+0x24],ax
00005AD0  8BD8              mov bx,ax
00005AD2  83E33F            and bx,byte +0x3f
00005AD5  895E26            mov [bp+0x26],bx
00005AD8  80FB3C            cmp bl,0x3c
00005ADB  750D              jnz 0x5aea
00005ADD  C746222000        mov word [bp+0x22],0x20
00005AE2  C7461C0900        mov word [bp+0x1c],0x9
00005AE7  EB7D              jmp short 0x5b66
00005AE9  90                nop
00005AEA  80FB3D            cmp bl,0x3d
00005AED  750D              jnz 0x5afc
00005AEF  C746222E00        mov word [bp+0x22],0x2e
00005AF4  C7461C0900        mov word [bp+0x1c],0x9
00005AF9  EB6B              jmp short 0x5b66
00005AFB  90                nop
00005AFC  80FB3E            cmp bl,0x3e
00005AFF  750D              jnz 0x5b0e
00005B01  C746222300        mov word [bp+0x22],0x23
00005B06  C7461C0900        mov word [bp+0x1c],0x9
00005B0B  EB59              jmp short 0x5b66
00005B0D  90                nop
00005B0E  80FB16            cmp bl,0x16
00005B11  7C3B              jl 0x5b4e
00005B13  80FB2F            cmp bl,0x2f
00005B16  7F23              jg 0x5b3b
00005B18  83EB16            sub bx,byte +0x16
00005B1B  895E26            mov [bp+0x26],bx
00005B1E  895E22            mov [bp+0x22],bx
00005B21  06                push es
00005B22  56                push si
00005B23  B8420A            mov ax,0xa42
00005B26  8EC0              mov es,ax
00005B28  8D36720F          lea si,[0xf72]
00005B2C  03F3              add si,bx
00005B2E  268A04            mov al,[es:si]
00005B31  5E                pop si
00005B32  07                pop es
00005B33  32E4              xor ah,ah
00005B35  89461C            mov [bp+0x1c],ax
00005B38  EB2C              jmp short 0x5b66
00005B3A  90                nop
00005B3B  80FB38            cmp bl,0x38
00005B3E  7F26              jg 0x5b66
00005B40  83EB16            sub bx,byte +0x16
00005B43  895E22            mov [bp+0x22],bx
00005B46  C7461C0400        mov word [bp+0x1c],0x4
00005B4B  EB19              jmp short 0x5b66
00005B4D  90                nop
00005B4E  80FB0D            cmp bl,0xd
00005B51  7F0B              jg 0x5b5e
00005B53  895E22            mov [bp+0x22],bx
00005B56  C7461C0500        mov word [bp+0x1c],0x5
00005B5B  EB09              jmp short 0x5b66
00005B5D  90                nop
00005B5E  895E22            mov [bp+0x22],bx
00005B61  C7461C0600        mov word [bp+0x1c],0x6
00005B66  8B4624            mov ax,[bp+0x24]
00005B69  E80400            call 0x5b70
00005B6C  83C602            add si,byte +0x2
00005B6F  C3                ret
00005B70  51                push cx
00005B71  B10C              mov cl,0xc
00005B73  50                push ax
00005B74  D3E8              shr ax,cl
00005B76  894606            mov [bp+0x6],ax
00005B79  833E161500        cmp word [0x1516],byte +0x0
00005B7E  754D              jnz 0x5bcd
00005B80  837E1C09          cmp word [bp+0x1c],byte +0x9
00005B84  7447              jz 0x5bcd
00005B86  33C0              xor ax,ax
00005B88  3B061215          cmp ax,[0x1512]
00005B8C  753F              jnz 0x5bcd
00005B8E  837E1C04          cmp word [bp+0x1c],byte +0x4
00005B92  7E18              jng 0x5bac
00005B94  837E2214          cmp word [bp+0x22],byte +0x14
00005B98  7412              jz 0x5bac
00005B9A  837E0603          cmp word [bp+0x6],byte +0x3
00005B9E  740C              jz 0x5bac
00005BA0  837E0606          cmp word [bp+0x6],byte +0x6
00005BA4  7406              jz 0x5bac
00005BA6  837E0609          cmp word [bp+0x6],byte +0x9
00005BAA  751E              jnz 0x5bca
00005BAC  837E1C05          cmp word [bp+0x1c],byte +0x5
00005BB0  7D1B              jnl 0x5bcd
00005BB2  837E2213          cmp word [bp+0x22],byte +0x13
00005BB6  7415              jz 0x5bcd
00005BB8  837E2216          cmp word [bp+0x22],byte +0x16
00005BBC  740F              jz 0x5bcd
00005BBE  837E0604          cmp word [bp+0x6],byte +0x4
00005BC2  7409              jz 0x5bcd
00005BC4  837E0609          cmp word [bp+0x6],byte +0x9
00005BC8  7403              jz 0x5bcd
00005BCA  FF4606            inc word [bp+0x6]
00005BCD  58                pop ax
00005BCE  B106              mov cl,0x6
00005BD0  50                push ax
00005BD1  D3E8              shr ax,cl
00005BD3  250700            and ax,0x7
00005BD6  894608            mov [bp+0x8],ax
00005BD9  58                pop ax
00005BDA  B109              mov cl,0x9
00005BDC  D3E8              shr ax,cl
00005BDE  250700            and ax,0x7
00005BE1  89460A            mov [bp+0xa],ax
00005BE4  59                pop cx
00005BE5  C3                ret
00005BE6  51                push cx
00005BE7  8B461A            mov ax,[bp+0x1a]
00005BEA  3D0900            cmp ax,0x9
00005BED  7403              jz 0x5bf2
00005BEF  EB17              jmp short 0x5c08
00005BF1  90                nop
00005BF2  8B5E20            mov bx,[bp+0x20]
00005BF5  80FB23            cmp bl,0x23
00005BF8  740B              jz 0x5c05
00005BFA  8B4E0C            mov cx,[bp+0xc]
00005BFD  41                inc cx
00005BFE  8BC3              mov ax,bx
00005C00  E82205            call 0x6125
00005C03  E2FB              loop 0x5c00
00005C05  E91B05            jmp 0x6123
00005C08  3D0600            cmp ax,0x6
00005C0B  7524              jnz 0x5c31
00005C0D  50                push ax
00005C0E  06                push es
00005C0F  56                push si
00005C10  B8420A            mov ax,0xa42
00005C13  8EC0              mov es,ax
00005C15  8D36620F          lea si,[0xf62]
00005C19  8B5E20            mov bx,[bp+0x20]
00005C1C  83EB0E            sub bx,byte +0xe
00005C1F  D1E3              shl bx,1
00005C21  03F3              add si,bx
00005C23  268A04            mov al,[es:si]
00005C26  32E4              xor ah,ah
00005C28  884628            mov [bp+0x28],al
00005C2B  5E                pop si
00005C2C  07                pop es
00005C2D  58                pop ax
00005C2E  EB0D              jmp short 0x5c3d
00005C30  90                nop
00005C31  3D0500            cmp ax,0x5
00005C34  7403              jz 0x5c39
00005C36  E99901            jmp 0x5dd2
00005C39  C64628FF          mov byte [bp+0x28],0xff
00005C3D  837E1805          cmp word [bp+0x18],byte +0x5
00005C41  7C24              jl 0x5c67
00005C43  837E1809          cmp word [bp+0x18],byte +0x9
00005C47  751E              jnz 0x5c67
00005C49  B004              mov al,0x4
00005C4B  E8D704            call 0x6125
00005C4E  807E28FF          cmp byte [bp+0x28],0xff
00005C52  7508              jnz 0x5c5c
00005C54  8B4620            mov ax,[bp+0x20]
00005C57  E8CB04            call 0x6125
00005C5A  EB06              jmp short 0x5c62
00005C5C  8A4628            mov al,[bp+0x28]
00005C5F  E8C304            call 0x6125
00005C62  B016              mov al,0x16
00005C64  E8BE04            call 0x6125
00005C67  8B460C            mov ax,[bp+0xc]
00005C6A  3D0000            cmp ax,0x0
00005C6D  7403              jz 0x5c72
00005C6F  EB3E              jmp short 0x5caf
00005C71  90                nop
00005C72  32C0              xor al,al
00005C74  E8AE04            call 0x6125
00005C77  8B4620            mov ax,[bp+0x20]
00005C7A  E8A804            call 0x6125
00005C7D  807E28FF          cmp byte [bp+0x28],0xff
00005C81  7516              jnz 0x5c99
00005C83  837E1C09          cmp word [bp+0x1c],byte +0x9
00005C87  7508              jnz 0x5c91
00005C89  B002              mov al,0x2
00005C8B  E89704            call 0x6125
00005C8E  E99204            jmp 0x6123
00005C91  B004              mov al,0x4
00005C93  E88F04            call 0x6125
00005C96  E98A04            jmp 0x6123
00005C99  837E1C09          cmp word [bp+0x1c],byte +0x9
00005C9D  7508              jnz 0x5ca7
00005C9F  32C0              xor al,al
00005CA1  E88104            call 0x6125
00005CA4  E97C04            jmp 0x6123
00005CA7  B001              mov al,0x1
00005CA9  E87904            call 0x6125
00005CAC  E97404            jmp 0x6123
00005CAF  3D0500            cmp ax,0x5
00005CB2  740D              jz 0x5cc1
00005CB4  3D0600            cmp ax,0x6
00005CB7  7408              jz 0x5cc1
00005CB9  3D0400            cmp ax,0x4
00005CBC  7433              jz 0x5cf1
00005CBE  EB44              jmp short 0x5d04
00005CC0  90                nop
00005CC1  8BC8              mov cx,ax
00005CC3  83E905            sub cx,byte +0x5
00005CC6  83F900            cmp cx,byte +0x0
00005CC9  7C26              jl 0x5cf1
00005CCB  49                dec cx
00005CCC  32C0              xor al,al
00005CCE  E85404            call 0x6125
00005CD1  807E28FF          cmp byte [bp+0x28],0xff
00005CD5  750D              jnz 0x5ce4
00005CD7  8B4620            mov ax,[bp+0x20]
00005CDA  E84804            call 0x6125
00005CDD  B003              mov al,0x3
00005CDF  E84304            call 0x6125
00005CE2  EBE2              jmp short 0x5cc6
00005CE4  8A4628            mov al,[bp+0x28]
00005CE7  E83B04            call 0x6125
00005CEA  B003              mov al,0x3
00005CEC  E83604            call 0x6125
00005CEF  EBD5              jmp short 0x5cc6
00005CF1  32C0              xor al,al
00005CF3  E82F04            call 0x6125
00005CF6  8B4620            mov ax,[bp+0x20]
00005CF9  E82904            call 0x6125
00005CFC  B003              mov al,0x3
00005CFE  E82404            call 0x6125
00005D01  E91F04            jmp 0x6123
00005D04  3D0800            cmp ax,0x8
00005D07  740D              jz 0x5d16
00005D09  3D0900            cmp ax,0x9
00005D0C  7408              jz 0x5d16
00005D0E  3D0700            cmp ax,0x7
00005D11  7433              jz 0x5d46
00005D13  EB5A              jmp short 0x5d6f
00005D15  90                nop
00005D16  8BC8              mov cx,ax
00005D18  83E908            sub cx,byte +0x8
00005D1B  83F900            cmp cx,byte +0x0
00005D1E  7C26              jl 0x5d46
00005D20  49                dec cx
00005D21  32C0              xor al,al
00005D23  E8FF03            call 0x6125
00005D26  807E28FF          cmp byte [bp+0x28],0xff
00005D2A  750D              jnz 0x5d39
00005D2C  8B4620            mov ax,[bp+0x20]
00005D2F  E8F303            call 0x6125
00005D32  B003              mov al,0x3
00005D34  E8EE03            call 0x6125
00005D37  EBE2              jmp short 0x5d1b
00005D39  8A4628            mov al,[bp+0x28]
00005D3C  E8E603            call 0x6125
00005D3F  B003              mov al,0x3
00005D41  E8E103            call 0x6125
00005D44  EBD5              jmp short 0x5d1b
00005D46  807E28FF          cmp byte [bp+0x28],0xff
00005D4A  7513              jnz 0x5d5f
00005D4C  32C0              xor al,al
00005D4E  E8D403            call 0x6125
00005D51  8B4620            mov ax,[bp+0x20]
00005D54  E8CE03            call 0x6125
00005D57  B002              mov al,0x2
00005D59  E8C903            call 0x6125
00005D5C  E9C403            jmp 0x6123
00005D5F  32C0              xor al,al
00005D61  E8C103            call 0x6125
00005D64  8B4620            mov ax,[bp+0x20]
00005D67  E8BB03            call 0x6125
00005D6A  32C0              xor al,al
00005D6C  E8B603            call 0x6125
00005D6F  3D0100            cmp ax,0x1
00005D72  743D              jz 0x5db1
00005D74  3D0200            cmp ax,0x2
00005D77  7408              jz 0x5d81
00005D79  3D0300            cmp ax,0x3
00005D7C  7403              jz 0x5d81
00005D7E  EB52              jmp short 0x5dd2
00005D80  90                nop
00005D81  8BC8              mov cx,ax
00005D83  83E902            sub cx,byte +0x2
00005D86  83F900            cmp cx,byte +0x0
00005D89  7C26              jl 0x5db1
00005D8B  49                dec cx
00005D8C  32C0              xor al,al
00005D8E  E89403            call 0x6125
00005D91  807E28FF          cmp byte [bp+0x28],0xff
00005D95  750D              jnz 0x5da4
00005D97  8B4620            mov ax,[bp+0x20]
00005D9A  E88803            call 0x6125
00005D9D  B003              mov al,0x3
00005D9F  E88303            call 0x6125
00005DA2  EBE2              jmp short 0x5d86
00005DA4  8A4628            mov al,[bp+0x28]
00005DA7  E87B03            call 0x6125
00005DAA  B003              mov al,0x3
00005DAC  E87603            call 0x6125
00005DAF  EBD5              jmp short 0x5d86
00005DB1  32C0              xor al,al
00005DB3  E86F03            call 0x6125
00005DB6  8B4620            mov ax,[bp+0x20]
00005DB9  E86903            call 0x6125
00005DBC  837E1C09          cmp word [bp+0x1c],byte +0x9
00005DC0  7508              jnz 0x5dca
00005DC2  32C0              xor al,al
00005DC4  E85E03            call 0x6125
00005DC7  E95903            jmp 0x6123
00005DCA  B001              mov al,0x1
00005DCC  E85603            call 0x6125
00005DCF  E95103            jmp 0x6123
00005DD2  3D0200            cmp ax,0x2
00005DD5  7408              jz 0x5ddf
00005DD7  3D0300            cmp ax,0x3
00005DDA  7403              jz 0x5ddf
00005DDC  E99100            jmp 0x5e70
00005DDF  8B461A            mov ax,[bp+0x1a]
00005DE2  050500            add ax,0x5
00005DE5  884628            mov [bp+0x28],al
00005DE8  837E1809          cmp word [bp+0x18],byte +0x9
00005DEC  7510              jnz 0x5dfe
00005DEE  B004              mov al,0x4
00005DF0  E83203            call 0x6125
00005DF3  8A4628            mov al,[bp+0x28]
00005DF6  E82C03            call 0x6125
00005DF9  B016              mov al,0x16
00005DFB  E82703            call 0x6125
00005DFE  8B4E0C            mov cx,[bp+0xc]
00005E01  0BC9              or cx,cx
00005E03  7418              jz 0x5e1d
00005E05  83F900            cmp cx,byte +0x0
00005E08  7E13              jng 0x5e1d
00005E0A  49                dec cx
00005E0B  32C0              xor al,al
00005E0D  E81503            call 0x6125
00005E10  8A4628            mov al,[bp+0x28]
00005E13  E80F03            call 0x6125
00005E16  B003              mov al,0x3
00005E18  E80A03            call 0x6125
00005E1B  EBE8              jmp short 0x5e05
00005E1D  837E1C06          cmp word [bp+0x1c],byte +0x6
00005E21  752B              jnz 0x5e4e
00005E23  B004              mov al,0x4
00005E25  E8FD02            call 0x6125
00005E28  06                push es
00005E29  56                push si
00005E2A  B8420A            mov ax,0xa42
00005E2D  8EC0              mov es,ax
00005E2F  8D36620F          lea si,[0xf62]
00005E33  8B4622            mov ax,[bp+0x22]
00005E36  2D0E00            sub ax,0xe
00005E39  D1E0              shl ax,1
00005E3B  03F0              add si,ax
00005E3D  268A04            mov al,[es:si]
00005E40  5E                pop si
00005E41  07                pop es
00005E42  E8E002            call 0x6125
00005E45  8B4620            mov ax,[bp+0x20]
00005E48  E8DA02            call 0x6125
00005E4B  E9D502            jmp 0x6123
00005E4E  B004              mov al,0x4
00005E50  E8D202            call 0x6125
00005E53  837E2204          cmp word [bp+0x22],byte +0x4
00005E57  7508              jnz 0x5e61
00005E59  B003              mov al,0x3
00005E5B  E8C702            call 0x6125
00005E5E  EB07              jmp short 0x5e67
00005E60  90                nop
00005E61  8B4622            mov ax,[bp+0x22]
00005E64  E8BE02            call 0x6125
00005E67  8B4620            mov ax,[bp+0x20]
00005E6A  E8B802            call 0x6125
00005E6D  E9B302            jmp 0x6123
00005E70  3D0400            cmp ax,0x4
00005E73  7503              jnz 0x5e78
00005E75  E9BD01            jmp 0x6035
00005E78  8B461C            mov ax,[bp+0x1c]
00005E7B  3D0200            cmp ax,0x2
00005E7E  7508              jnz 0x5e88
00005E80  C7462A0700        mov word [bp+0x2a],0x7
00005E85  EB45              jmp short 0x5ecc
00005E87  90                nop
00005E88  3D0300            cmp ax,0x3
00005E8B  7508              jnz 0x5e95
00005E8D  C7462A0800        mov word [bp+0x2a],0x8
00005E92  EB38              jmp short 0x5ecc
00005E94  90                nop
00005E95  3D0600            cmp ax,0x6
00005E98  7522              jnz 0x5ebc
00005E9A  06                push es
00005E9B  56                push si
00005E9C  B8420A            mov ax,0xa42
00005E9F  8EC0              mov es,ax
00005EA1  8D36620F          lea si,[0xf62]
00005EA5  8B4622            mov ax,[bp+0x22]
00005EA8  2D0E00            sub ax,0xe
00005EAB  D1E0              shl ax,1
00005EAD  03F0              add si,ax
00005EAF  268A04            mov al,[es:si]
00005EB2  32E4              xor ah,ah
00005EB4  89462A            mov [bp+0x2a],ax
00005EB7  5E                pop si
00005EB8  07                pop es
00005EB9  EB11              jmp short 0x5ecc
00005EBB  90                nop
00005EBC  3D0500            cmp ax,0x5
00005EBF  7506              jnz 0x5ec7
00005EC1  8B4622            mov ax,[bp+0x22]
00005EC4  89462A            mov [bp+0x2a],ax
00005EC7  C7462A0A00        mov word [bp+0x2a],0xa
00005ECC  8B462A            mov ax,[bp+0x2a]
00005ECF  B11A              mov cl,0x1a
00005ED1  F6E1              mul cl
00005ED3  034620            add ax,[bp+0x20]
00005ED6  89462A            mov [bp+0x2a],ax
00005ED9  06                push es
00005EDA  56                push si
00005EDB  BB420A            mov bx,0xa42
00005EDE  8EC3              mov es,bx
00005EE0  8D36A60F          lea si,[0xfa6]
00005EE4  03F0              add si,ax
00005EE6  268A04            mov al,[es:si]
00005EE9  5E                pop si
00005EEA  07                pop es
00005EEB  0AC0              or al,al
00005EED  7507              jnz 0x5ef6
00005EEF  C6462802          mov byte [bp+0x28],0x2
00005EF3  EB05              jmp short 0x5efa
00005EF5  90                nop
00005EF6  C6462806          mov byte [bp+0x28],0x6
00005EFA  837E0C05          cmp word [bp+0xc],byte +0x5
00005EFE  7C0E              jl 0x5f0e
00005F00  836E0C05          sub word [bp+0xc],byte +0x5
00005F04  8A4628            mov al,[bp+0x28]
00005F07  B308              mov bl,0x8
00005F09  2AD8              sub bl,al
00005F0B  895E28            mov [bp+0x28],bx
00005F0E  837E1A00          cmp word [bp+0x1a],byte +0x0
00005F12  752F              jnz 0x5f43
00005F14  8B4E0C            mov cx,[bp+0xc]
00005F17  0BC9              or cx,cx
00005F19  7414              jz 0x5f2f
00005F1B  49                dec cx
00005F1C  8A4628            mov al,[bp+0x28]
00005F1F  E80302            call 0x6125
00005F22  8B4620            mov ax,[bp+0x20]
00005F25  E8FD01            call 0x6125
00005F28  B003              mov al,0x3
00005F2A  E8F801            call 0x6125
00005F2D  EBE8              jmp short 0x5f17
00005F2F  8A4628            mov al,[bp+0x28]
00005F32  E8F001            call 0x6125
00005F35  8B4620            mov ax,[bp+0x20]
00005F38  E8EA01            call 0x6125
00005F3B  B004              mov al,0x4
00005F3D  E8E501            call 0x6125
00005F40  EB2D              jmp short 0x5f6f
00005F42  90                nop
00005F43  8A4628            mov al,[bp+0x28]
00005F46  E8DC01            call 0x6125
00005F49  8B4620            mov ax,[bp+0x20]
00005F4C  E8D601            call 0x6125
00005F4F  B003              mov al,0x3
00005F51  E8D101            call 0x6125
00005F54  8B4E0C            mov cx,[bp+0xc]
00005F57  0BC9              or cx,cx
00005F59  7414              jz 0x5f6f
00005F5B  49                dec cx
00005F5C  8A4628            mov al,[bp+0x28]
00005F5F  E8C301            call 0x6125
00005F62  8B4620            mov ax,[bp+0x20]
00005F65  E8BD01            call 0x6125
00005F68  B004              mov al,0x4
00005F6A  E8B801            call 0x6125
00005F6D  EBE8              jmp short 0x5f57
00005F6F  837E1C09          cmp word [bp+0x1c],byte +0x9
00005F73  7514              jnz 0x5f89
00005F75  8A4628            mov al,[bp+0x28]
00005F78  E8AA01            call 0x6125
00005F7B  8B4620            mov ax,[bp+0x20]
00005F7E  E8A401            call 0x6125
00005F81  B005              mov al,0x5
00005F83  E89F01            call 0x6125
00005F86  E99A01            jmp 0x6123
00005F89  8B461C            mov ax,[bp+0x1c]
00005F8C  0BC0              or ax,ax
00005F8E  74F6              jz 0x5f86
00005F90  3D0100            cmp ax,0x1
00005F93  74F1              jz 0x5f86
00005F95  3D0400            cmp ax,0x4
00005F98  74EC              jz 0x5f86
00005F9A  8B461C            mov ax,[bp+0x1c]
00005F9D  3D0300            cmp ax,0x3
00005FA0  7508              jnz 0x5faa
00005FA2  C7462A0800        mov word [bp+0x2a],0x8
00005FA7  EB3B              jmp short 0x5fe4
00005FA9  90                nop
00005FAA  3D0600            cmp ax,0x6
00005FAD  7522              jnz 0x5fd1
00005FAF  06                push es
00005FB0  56                push si
00005FB1  B8420A            mov ax,0xa42
00005FB4  8EC0              mov es,ax
00005FB6  8D36620F          lea si,[0xf62]
00005FBA  8B4622            mov ax,[bp+0x22]
00005FBD  2D0E00            sub ax,0xe
00005FC0  D1E0              shl ax,1
00005FC2  03F0              add si,ax
00005FC4  268A04            mov al,[es:si]
00005FC7  32E4              xor ah,ah
00005FC9  89462A            mov [bp+0x2a],ax
00005FCC  5E                pop si
00005FCD  07                pop es
00005FCE  EB14              jmp short 0x5fe4
00005FD0  90                nop
00005FD1  3D0500            cmp ax,0x5
00005FD4  7509              jnz 0x5fdf
00005FD6  8B4622            mov ax,[bp+0x22]
00005FD9  89462A            mov [bp+0x2a],ax
00005FDC  EB06              jmp short 0x5fe4
00005FDE  90                nop
00005FDF  C7462A0700        mov word [bp+0x2a],0x7
00005FE4  837E2A04          cmp word [bp+0x2a],byte +0x4
00005FE8  7505              jnz 0x5fef
00005FEA  C7462A0300        mov word [bp+0x2a],0x3
00005FEF  06                push es
00005FF0  56                push si
00005FF1  B8420A            mov ax,0xa42
00005FF4  8EC0              mov es,ax
00005FF6  8D368C0F          lea si,[0xf8c]
00005FFA  8B4620            mov ax,[bp+0x20]
00005FFD  03F0              add si,ax
00005FFF  268A04            mov al,[es:si]
00006002  5E                pop si
00006003  07                pop es
00006004  0AC0              or al,al
00006006  7403              jz 0x600b
00006008  FF4620            inc word [bp+0x20]
0000600B  837E2011          cmp word [bp+0x20],byte +0x11
0000600F  7505              jnz 0x6016
00006011  C746201000        mov word [bp+0x20],0x10
00006016  837E2012          cmp word [bp+0x20],byte +0x12
0000601A  7505              jnz 0x6021
0000601C  C746201000        mov word [bp+0x20],0x10
00006021  B004              mov al,0x4
00006023  E8FF00            call 0x6125
00006026  8B462A            mov ax,[bp+0x2a]
00006029  E8F900            call 0x6125
0000602C  8B4620            mov ax,[bp+0x20]
0000602F  E8F300            call 0x6125
00006032  E9EE00            jmp 0x6123
00006035  8B4E0C            mov cx,[bp+0xc]
00006038  0BC9              or cx,cx
0000603A  7413              jz 0x604f
0000603C  49                dec cx
0000603D  B002              mov al,0x2
0000603F  E8E300            call 0x6125
00006042  8B4620            mov ax,[bp+0x20]
00006045  E8DD00            call 0x6125
00006048  B003              mov al,0x3
0000604A  E8D800            call 0x6125
0000604D  EBE9              jmp short 0x6038
0000604F  B002              mov al,0x2
00006051  E8D100            call 0x6125
00006054  8B4620            mov ax,[bp+0x20]
00006057  E8CB00            call 0x6125
0000605A  B004              mov al,0x4
0000605C  E8C600            call 0x6125
0000605F  837E1C09          cmp word [bp+0x1c],byte +0x9
00006063  7513              jnz 0x6078
00006065  B002              mov al,0x2
00006067  E8BB00            call 0x6125
0000606A  8B4620            mov ax,[bp+0x20]
0000606D  E8B500            call 0x6125
00006070  B005              mov al,0x5
00006072  E8B000            call 0x6125
00006075  E9AB00            jmp 0x6123
00006078  8B461C            mov ax,[bp+0x1c]
0000607B  0BC0              or ax,ax
0000607D  74F6              jz 0x6075
0000607F  3D0100            cmp ax,0x1
00006082  74F1              jz 0x6075
00006084  3D0400            cmp ax,0x4
00006087  74EC              jz 0x6075
00006089  8B461C            mov ax,[bp+0x1c]
0000608C  3D0300            cmp ax,0x3
0000608F  7508              jnz 0x6099
00006091  C7462A0800        mov word [bp+0x2a],0x8
00006096  EB3B              jmp short 0x60d3
00006098  90                nop
00006099  3D0600            cmp ax,0x6
0000609C  7522              jnz 0x60c0
0000609E  06                push es
0000609F  56                push si
000060A0  B8420A            mov ax,0xa42
000060A3  8EC0              mov es,ax
000060A5  8D36620F          lea si,[0xf62]
000060A9  8B4622            mov ax,[bp+0x22]
000060AC  2D0E00            sub ax,0xe
000060AF  D1E0              shl ax,1
000060B1  03F0              add si,ax
000060B3  268A04            mov al,[es:si]
000060B6  32E4              xor ah,ah
000060B8  89462A            mov [bp+0x2a],ax
000060BB  5E                pop si
000060BC  07                pop es
000060BD  EB14              jmp short 0x60d3
000060BF  90                nop
000060C0  3D0500            cmp ax,0x5
000060C3  7509              jnz 0x60ce
000060C5  8B4622            mov ax,[bp+0x22]
000060C8  89462A            mov [bp+0x2a],ax
000060CB  EB06              jmp short 0x60d3
000060CD  90                nop
000060CE  C7462A0700        mov word [bp+0x2a],0x7
000060D3  837E2A04          cmp word [bp+0x2a],byte +0x4
000060D7  7505              jnz 0x60de
000060D9  C7462A0300        mov word [bp+0x2a],0x3
000060DE  06                push es
000060DF  56                push si
000060E0  B8420A            mov ax,0xa42
000060E3  8EC0              mov es,ax
000060E5  8D368C0F          lea si,[0xf8c]
000060E9  8B4620            mov ax,[bp+0x20]
000060EC  03F0              add si,ax
000060EE  268A04            mov al,[es:si]
000060F1  5E                pop si
000060F2  07                pop es
000060F3  0AC0              or al,al
000060F5  7403              jz 0x60fa
000060F7  FF4620            inc word [bp+0x20]
000060FA  B004              mov al,0x4
000060FC  E82600            call 0x6125
000060FF  8B462A            mov ax,[bp+0x2a]
00006102  E82000            call 0x6125
00006105  06                push es
00006106  56                push si
00006107  B8420A            mov ax,0xa42
0000610A  8EC0              mov es,ax
0000610C  8D36500F          lea si,[0xf50]
00006110  8B4620            mov ax,[bp+0x20]
00006113  2D1A00            sub ax,0x1a
00006116  D1E0              shl ax,1
00006118  40                inc ax
00006119  03F0              add si,ax
0000611B  268A04            mov al,[es:si]
0000611E  5E                pop si
0000611F  07                pop es
00006120  E80200            call 0x6125
00006123  59                pop cx
00006124  C3                ret
00006125  06                push es
00006126  56                push si
00006127  8E462C            mov es,[bp+0x2c]
0000612A  8B762E            mov si,[bp+0x2e]
0000612D  268804            mov [es:si],al
00006130  FF462E            inc word [bp+0x2e]
00006133  5E                pop si
00006134  07                pop es
00006135  C3                ret
00006136  51                push cx
00006137  B10C              mov cl,0xc
00006139  D3E0              shl ax,cl
0000613B  B104              mov cl,0x4
0000613D  53                push bx
0000613E  D3EB              shr bx,cl
00006140  03C3              add ax,bx
00006142  5B                pop bx
00006143  83E30F            and bx,byte +0xf
00006146  59                pop cx
00006147  C3                ret
00006148  BA5000            mov dx,0x50
0000614B  B9FFFF            mov cx,0xffff
0000614E  E2FE              loop 0x614e
00006150  4A                dec dx
00006151  75F8              jnz 0x614b
00006153  C3                ret
00006154  55                push bp
00006155  8BEC              mov bp,sp
00006157  56                push si
00006158  57                push di
00006159  1E                push ds
0000615A  C606122801        mov byte [0x2812],0x1
0000615F  A19404            mov ax,[0x494]
00006162  2DA404            sub ax,0x4a4
00006165  A31828            mov [0x2818],ax
00006168  33DB              xor bx,bx
0000616A  891E1A28          mov [0x281a],bx
0000616E  056504            add ax,0x465
00006171  A31428            mov [0x2814],ax
00006174  891E1628          mov [0x2816],bx
00006178  C606342800        mov byte [0x2834],0x0
0000617D  B8420A            mov ax,0xa42
00006180  8EC0              mov es,ax
00006182  8D362215          lea si,[0x1522]
00006186  2603745C          add si,[es:si+0x5c]
0000618A  B92002            mov cx,0x220
0000618D  D1E9              shr cx,1
0000618F  E8FA03            call 0x658c
00006192  B8420A            mov ax,0xa42
00006195  A34B06            mov [0x64b],ax
00006198  8D06CB27          lea ax,[0x27cb]
0000619C  A34D06            mov [0x64d],ax
0000619F  A19404            mov ax,[0x494]
000061A2  2D4414            sub ax,0x1444
000061A5  A30B28            mov [0x280b],ax
000061A8  2D740C            sub ax,0xc74
000061AB  A3DA00            mov [0xda],ax
000061AE  B8420A            mov ax,0xa42
000061B1  8D1E2215          lea bx,[0x1522]
000061B5  A3B400            mov [0xb4],ax
000061B8  891EB600          mov [0xb6],bx
000061BC  833E920405        cmp word [0x492],byte +0x5
000061C1  7513              jnz 0x61d6
000061C3  33DB              xor bx,bx
000061C5  B91000            mov cx,0x10
000061C8  51                push cx
000061C9  33C9              xor cx,cx
000061CB  33D2              xor dx,dx
000061CD  B81010            mov ax,0x1010
000061D0  CD10              int 0x10
000061D2  43                inc bx
000061D3  59                pop cx
000061D4  E2F2              loop 0x61c8
000061D6  B82700            mov ax,0x27
000061D9  50                push ax
000061DA  B80200            mov ax,0x2
000061DD  50                push ax
000061DE  FF36DA00          push word [0xda]
000061E2  33C0              xor ax,ax
000061E4  50                push ax
000061E5  9AEF11DB02        call 0x2db:0x11ef
000061EA  83C408            add sp,byte +0x8
000061ED  33C0              xor ax,ax
000061EF  50                push ax
000061F0  50                push ax
000061F1  FF369404          push word [0x494]
000061F5  50                push ax
000061F6  FF36DA00          push word [0xda]
000061FA  9A00009304        call 0x493:0x0
000061FF  83C40A            add sp,byte +0xa
00006202  1E                push ds
00006203  33F6              xor si,si
00006205  33FF              xor di,di
00006207  8E060B28          mov es,[0x280b]
0000620B  8E1E9404          mov ds,[0x494]
0000620F  B9007D            mov cx,0x7d00
00006212  F3A5              rep movsw
00006214  1F                pop ds
00006215  A1DA00            mov ax,[0xda]
00006218  BB0200            mov bx,0x2
0000621B  833E920405        cmp word [0x492],byte +0x5
00006220  7411              jz 0x6233
00006222  33DB              xor bx,bx
00006224  031E6D06          add bx,[0x66d]
00006228  83EB33            sub bx,byte +0x33
0000622B  9AFE0C8400        call 0x84:0xcfe
00006230  EB09              jmp short 0x623b
00006232  90                nop
00006233  B90100            mov cx,0x1
00006236  9A2418DB02        call 0x2db:0x1824
0000623B  9AE5034207        call 0x742:0x3e5
00006240  C606470600        mov byte [0x647],0x0
00006245  33DB              xor bx,bx
00006247  53                push bx
00006248  B80400            mov ax,0x4
0000624B  50                push ax
0000624C  B80000            mov ax,0x0
0000624F  53                push bx
00006250  50                push ax
00006251  A14B06            mov ax,[0x64b]
00006254  8B164D06          mov dx,[0x64d]
00006258  E81403            call 0x656f
0000625B  50                push ax
0000625C  52                push dx
0000625D  53                push bx
0000625E  53                push bx
0000625F  53                push bx
00006260  53                push bx
00006261  53                push bx
00006262  53                push bx
00006263  53                push bx
00006264  53                push bx
00006265  53                push bx
00006266  B83F01            mov ax,0x13f
00006269  50                push ax
0000626A  B8C800            mov ax,0xc8
0000626D  53                push bx
0000626E  50                push ax
0000626F  8BCC              mov cx,sp
00006271  9A0800AB07        call 0x7ab:0x8
00006276  83C424            add sp,byte +0x24
00006279  B8420A            mov ax,0xa42
0000627C  8EC0              mov es,ax
0000627E  8D36251C          lea si,[0x1c25]
00006282  A19C00            mov ax,[0x9c]
00006285  3C39              cmp al,0x39
00006287  744E              jz 0x62d7
00006289  3C3D              cmp al,0x3d
0000628B  744A              jz 0x62d7
0000628D  268A04            mov al,[es:si]
00006290  3CFF              cmp al,0xff
00006292  7511              jnz 0x62a5
00006294  803E750601        cmp byte [0x675],0x1
00006299  743C              jz 0x62d7
0000629B  803E0F2800        cmp byte [0x280f],0x0
000062A0  74E0              jz 0x6282
000062A2  EB33              jmp short 0x62d7
000062A4  90                nop
000062A5  0AC0              or al,al
000062A7  7505              jnz 0x62ae
000062A9  E8AB00            call 0x6357
000062AC  EBD4              jmp short 0x6282
000062AE  3C04              cmp al,0x4
000062B0  7505              jnz 0x62b7
000062B2  E8C100            call 0x6376
000062B5  EBCB              jmp short 0x6282
000062B7  3C08              cmp al,0x8
000062B9  7505              jnz 0x62c0
000062BB  E8FD00            call 0x63bb
000062BE  EBC2              jmp short 0x6282
000062C0  3C0C              cmp al,0xc
000062C2  7505              jnz 0x62c9
000062C4  E82D01            call 0x63f4
000062C7  EBB9              jmp short 0x6282
000062C9  3C10              cmp al,0x10
000062CB  7505              jnz 0x62d2
000062CD  E85702            call 0x6527
000062D0  EBB0              jmp short 0x6282
000062D2  E89602            call 0x656b
000062D5  EBAB              jmp short 0x6282
000062D7  9AD300E808        call 0x8e8:0xd3
000062DC  833E660100        cmp word [0x166],byte +0x0
000062E1  7520              jnz 0x6303
000062E3  33C0              xor ax,ax
000062E5  CD33              int 0x33
000062E7  0BC0              or ax,ax
000062E9  7509              jnz 0x62f4
000062EB  C70666010100      mov word [0x166],0x1
000062F1  EB10              jmp short 0x6303
000062F3  90                nop
000062F4  1E                push ds
000062F5  B80925            mov ax,0x2509
000062F8  8B16E800          mov dx,[0xe8]
000062FC  8E1EE600          mov ds,[0xe6]
00006300  CD21              int 0x21
00006302  1F                pop ds
00006303  803E720600        cmp byte [0x672],0x0
00006308  7443              jz 0x634d
0000630A  803E720602        cmp byte [0x672],0x2
0000630F  743C              jz 0x634d
00006311  B81010            mov ax,0x1010
00006314  BB0500            mov bx,0x5
00006317  B63A              mov dh,0x3a
00006319  B52B              mov ch,0x2b
0000631B  B11D              mov cl,0x1d
0000631D  CD10              int 0x10
0000631F  8E06DC00          mov es,[0xdc]
00006323  8B36DE00          mov si,[0xde]
00006327  83C60A            add si,byte +0xa
0000632A  268B44FC          mov ax,[es:si-0x4]
0000632E  268904            mov [es:si],ax
00006331  8E06E000          mov es,[0xe0]
00006335  8B36E200          mov si,[0xe2]
00006339  83C605            add si,byte +0x5
0000633C  268A44FE          mov al,[es:si-0x2]
00006340  268804            mov [es:si],al
00006343  83C610            add si,byte +0x10
00006346  268A44FE          mov al,[es:si-0x2]
0000634A  268804            mov [es:si],al
0000634D  C606122800        mov byte [0x2812],0x0
00006352  1F                pop ds
00006353  5F                pop di
00006354  5E                pop si
00006355  5D                pop bp
00006356  CB                retf
00006357  83C604            add si,byte +0x4
0000635A  06                push es
0000635B  56                push si
0000635C  1E                push ds
0000635D  33F6              xor si,si
0000635F  33FF              xor di,di
00006361  8E069404          mov es,[0x494]
00006365  A1DA00            mov ax,[0xda]
00006368  05740C            add ax,0xc74
0000636B  8ED8              mov ds,ax
0000636D  B9007D            mov cx,0x7d00
00006370  F3A5              rep movsw
00006372  1F                pop ds
00006373  5E                pop si
00006374  07                pop es
00006375  C3                ret
00006376  83C604            add si,byte +0x4
00006379  06                push es
0000637A  56                push si
0000637B  B82700            mov ax,0x27
0000637E  50                push ax
0000637F  268B04            mov ax,[es:si]
00006382  50                push ax
00006383  FF36DA00          push word [0xda]
00006387  33C0              xor ax,ax
00006389  50                push ax
0000638A  9AEF11DB02        call 0x2db:0x11ef
0000638F  83C408            add sp,byte +0x8
00006392  5E                pop si
00006393  07                pop es
00006394  83C604            add si,byte +0x4
00006397  56                push si
00006398  06                push es
00006399  268B4404          mov ax,[es:si+0x4]
0000639D  50                push ax
0000639E  268B04            mov ax,[es:si]
000063A1  50                push ax
000063A2  33C0              xor ax,ax
000063A4  FF369404          push word [0x494]
000063A8  50                push ax
000063A9  FF36DA00          push word [0xda]
000063AD  9A00009304        call 0x493:0x0
000063B2  83C40A            add sp,byte +0xa
000063B5  07                pop es
000063B6  5E                pop si
000063B7  83C608            add si,byte +0x8
000063BA  C3                ret
000063BB  83C604            add si,byte +0x4
000063BE  06                push es
000063BF  56                push si
000063C0  33DB              xor bx,bx
000063C2  53                push bx
000063C3  B80500            mov ax,0x5
000063C6  50                push ax
000063C7  53                push bx
000063C8  53                push bx
000063C9  53                push bx
000063CA  53                push bx
000063CB  53                push bx
000063CC  53                push bx
000063CD  53                push bx
000063CE  53                push bx
000063CF  53                push bx
000063D0  B83000            mov ax,0x30
000063D3  50                push ax
000063D4  53                push bx
000063D5  268B04            mov ax,[es:si]
000063D8  50                push ax
000063D9  53                push bx
000063DA  B80F01            mov ax,0x10f
000063DD  50                push ax
000063DE  268B4404          mov ax,[es:si+0x4]
000063E2  53                push bx
000063E3  50                push ax
000063E4  8BCC              mov cx,sp
000063E6  9A0800AB07        call 0x7ab:0x8
000063EB  83C424            add sp,byte +0x24
000063EE  5E                pop si
000063EF  07                pop es
000063F0  83C608            add si,byte +0x8
000063F3  C3                ret
000063F4  83C604            add si,byte +0x4
000063F7  06                push es
000063F8  56                push si
000063F9  33DB              xor bx,bx
000063FB  53                push bx
000063FC  B8FFFF            mov ax,0xffff
000063FF  50                push ax
00006400  B8420A            mov ax,0xa42
00006403  8D16061B          lea dx,[0x1b06]
00006407  E86501            call 0x656f
0000640A  50                push ax
0000640B  52                push dx
0000640C  B8420A            mov ax,0xa42
0000640F  8D16FD1B          lea dx,[0x1bfd]
00006413  E85901            call 0x656f
00006416  50                push ax
00006417  52                push dx
00006418  B8420A            mov ax,0xa42
0000641B  8D168B27          lea dx,[0x278b]
0000641F  E84D01            call 0x656f
00006422  50                push ax
00006423  52                push dx
00006424  B80700            mov ax,0x7
00006427  50                push ax
00006428  50                push ax
00006429  53                push bx
0000642A  53                push bx
0000642B  53                push bx
0000642C  B80100            mov ax,0x1
0000642F  50                push ax
00006430  53                push bx
00006431  268B4404          mov ax,[es:si+0x4]
00006435  50                push ax
00006436  53                push bx
00006437  B83F01            mov ax,0x13f
0000643A  50                push ax
0000643B  53                push bx
0000643C  B80D00            mov ax,0xd
0000643F  50                push ax
00006440  53                push bx
00006441  53                push bx
00006442  B80100            mov ax,0x1
00006445  53                push bx
00006446  50                push ax
00006447  53                push bx
00006448  53                push bx
00006449  53                push bx
0000644A  268B04            mov ax,[es:si]
0000644D  50                push ax
0000644E  8BCC              mov cx,sp
00006450  9A930E9304        call 0x493:0xe93
00006455  83C438            add sp,byte +0x38
00006458  5E                pop si
00006459  07                pop es
0000645A  06                push es
0000645B  56                push si
0000645C  33DB              xor bx,bx
0000645E  53                push bx
0000645F  B8FFFF            mov ax,0xffff
00006462  50                push ax
00006463  B8420A            mov ax,0xa42
00006466  8D16061B          lea dx,[0x1b06]
0000646A  E80201            call 0x656f
0000646D  50                push ax
0000646E  52                push dx
0000646F  B8420A            mov ax,0xa42
00006472  8D16FD1B          lea dx,[0x1bfd]
00006476  E8F600            call 0x656f
00006479  50                push ax
0000647A  52                push dx
0000647B  B8420A            mov ax,0xa42
0000647E  8D168B27          lea dx,[0x278b]
00006482  E8EA00            call 0x656f
00006485  50                push ax
00006486  52                push dx
00006487  B80700            mov ax,0x7
0000648A  50                push ax
0000648B  50                push ax
0000648C  53                push bx
0000648D  53                push bx
0000648E  53                push bx
0000648F  B80000            mov ax,0x0
00006492  50                push ax
00006493  53                push bx
00006494  268B4404          mov ax,[es:si+0x4]
00006498  50                push ax
00006499  53                push bx
0000649A  B83F01            mov ax,0x13f
0000649D  50                push ax
0000649E  53                push bx
0000649F  B80D00            mov ax,0xd
000064A2  50                push ax
000064A3  53                push bx
000064A4  53                push bx
000064A5  B80100            mov ax,0x1
000064A8  53                push bx
000064A9  50                push ax
000064AA  53                push bx
000064AB  53                push bx
000064AC  53                push bx
000064AD  268B04            mov ax,[es:si]
000064B0  50                push ax
000064B1  8BCC              mov cx,sp
000064B3  9A930E9304        call 0x493:0xe93
000064B8  83C438            add sp,byte +0x38
000064BB  5E                pop si
000064BC  07                pop es
000064BD  06                push es
000064BE  56                push si
000064BF  33DB              xor bx,bx
000064C1  53                push bx
000064C2  B8FFFF            mov ax,0xffff
000064C5  50                push ax
000064C6  B8420A            mov ax,0xa42
000064C9  8D16061B          lea dx,[0x1b06]
000064CD  E89F00            call 0x656f
000064D0  50                push ax
000064D1  52                push dx
000064D2  B8420A            mov ax,0xa42
000064D5  8D16FD1B          lea dx,[0x1bfd]
000064D9  E89300            call 0x656f
000064DC  50                push ax
000064DD  52                push dx
000064DE  B8420A            mov ax,0xa42
000064E1  8D168B27          lea dx,[0x278b]
000064E5  E88700            call 0x656f
000064E8  50                push ax
000064E9  52                push dx
000064EA  B80700            mov ax,0x7
000064ED  50                push ax
000064EE  50                push ax
000064EF  53                push bx
000064F0  53                push bx
000064F1  53                push bx
000064F2  33C0              xor ax,ax
000064F4  50                push ax
000064F5  53                push bx
000064F6  268B4404          mov ax,[es:si+0x4]
000064FA  48                dec ax
000064FB  50                push ax
000064FC  53                push bx
000064FD  B83F01            mov ax,0x13f
00006500  50                push ax
00006501  53                push bx
00006502  B80D00            mov ax,0xd
00006505  50                push ax
00006506  B80F00            mov ax,0xf
00006509  53                push bx
0000650A  50                push ax
0000650B  B80100            mov ax,0x1
0000650E  53                push bx
0000650F  50                push ax
00006510  53                push bx
00006511  53                push bx
00006512  53                push bx
00006513  268B04            mov ax,[es:si]
00006516  50                push ax
00006517  8BCC              mov cx,sp
00006519  9A930E9304        call 0x493:0xe93
0000651E  83C438            add sp,byte +0x38
00006521  5E                pop si
00006522  07                pop es
00006523  83C608            add si,byte +0x8
00006526  C3                ret
00006527  268B4404          mov ax,[es:si+0x4]
0000652B  268B5406          mov dx,[es:si+0x6]
0000652F  B9F401            mov cx,0x1f4
00006532  F7F1              div cx
00006534  8B0E1028          mov cx,[0x2810]
00006538  D1E9              shr cx,1
0000653A  F7E1              mul cx
0000653C  B9F401            mov cx,0x1f4
0000653F  F7E1              mul cx
00006541  B9FFFF            mov cx,0xffff
00006544  F7F1              div cx
00006546  8BD0              mov dx,ax
00006548  B9FFFF            mov cx,0xffff
0000654B  51                push cx
0000654C  A19C00            mov ax,[0x9c]
0000654F  3C39              cmp al,0x39
00006551  750E              jnz 0x6561
00006553  59                pop cx
00006554  83C608            add si,byte +0x8
00006557  C3                ret
00006558  3C3D              cmp al,0x3d
0000655A  7505              jnz 0x6561
0000655C  59                pop cx
0000655D  83C608            add si,byte +0x8
00006560  C3                ret
00006561  E2FE              loop 0x6561
00006563  59                pop cx
00006564  4A                dec dx
00006565  75E4              jnz 0x654b
00006567  83C608            add si,byte +0x8
0000656A  C3                ret
0000656B  83C604            add si,byte +0x4
0000656E  C3                ret
0000656F  50                push ax
00006570  B10C              mov cl,0xc
00006572  D3E8              shr ax,cl
00006574  8BC8              mov cx,ax
00006576  58                pop ax
00006577  25FFFF            and ax,0xffff
0000657A  D1E0              shl ax,1
0000657C  D1E0              shl ax,1
0000657E  D1E0              shl ax,1
00006580  D1E0              shl ax,1
00006582  03D0              add dx,ax
00006584  9C                pushf
00006585  8BC1              mov ax,cx
00006587  9D                popf
00006588  7301              jnc 0x658b
0000658A  40                inc ax
0000658B  C3                ret
0000658C  268B04            mov ax,[es:si]
0000658F  86E0              xchg ah,al
00006591  268904            mov [es:si],ax
00006594  83C602            add si,byte +0x2
00006597  E2F3              loop 0x658c
00006599  C3                ret
0000659A  55                push bp
0000659B  8BEC              mov bp,sp
0000659D  B8420A            mov ax,0xa42
000065A0  8EC0              mov es,ax
000065A2  8D36111F          lea si,[0x1f11]
000065A6  8C06B400          mov [0xb4],es
000065AA  8936B600          mov [0xb6],si
000065AE  2603745C          add si,[es:si+0x5c]
000065B2  B9C400            mov cx,0xc4
000065B5  E8D4FF            call 0x658c
000065B8  B8420A            mov ax,0xa42
000065BB  8EC0              mov es,ax
000065BD  8D365724          lea si,[0x2457]
000065C1  A3AA00            mov [0xaa],ax
000065C4  8936A800          mov [0xa8],si
000065C8  B8420A            mov ax,0xa42
000065CB  8EC0              mov es,ax
000065CD  8D361D26          lea si,[0x261d]
000065D1  B9B700            mov cx,0xb7
000065D4  E8B5FF            call 0x658c
000065D7  5D                pop bp
000065D8  CB                retf
000065D9  0000              add [bx+si],al
000065DB  0000              add [bx+si],al
000065DD  0000              add [bx+si],al
000065DF  0000              add [bx+si],al
000065E1  55                push bp
000065E2  8BEC              mov bp,sp
000065E4  56                push si
000065E5  57                push di
000065E6  FA                cli
000065E7  B036              mov al,0x36
000065E9  E643              out 0x43,al
000065EB  B09B              mov al,0x9b
000065ED  E640              out 0x40,al
000065EF  B02E              mov al,0x2e
000065F1  E640              out 0x40,al
000065F3  B0FE              mov al,0xfe
000065F5  E621              out 0x21,al
000065F7  BA2000            mov dx,0x20
000065FA  8AC2              mov al,dl
000065FC  EB26              jmp short 0x6624
000065FE  90                nop
000065FF  33C9              xor cx,cx
00006601  8EC1              mov es,cx
00006603  BE2000            mov si,0x20
00006606  59                pop cx
00006607  268B3C            mov di,[es:si]
0000660A  2E893E8F04        mov [cs:0x48f],di
0000660F  26890C            mov [es:si],cx
00006612  0E                push cs
00006613  59                pop cx
00006614  268B7C02          mov di,[es:si+0x2]
00006618  2E893E8D04        mov [cs:0x48d],di
0000661D  26894C02          mov [es:si+0x2],cx
00006621  EB4C              jmp short 0x666f
00006623  90                nop
00006624  E8D8FF            call 0x65ff
00006627  43                inc bx
00006628  EE                out dx,al
00006629  83FB02            cmp bx,byte +0x2
0000662C  7401              jz 0x662f
0000662E  CF                iret
0000662F  FA                cli
00006630  83C406            add sp,byte +0x6
00006633  33C0              xor ax,ax
00006635  8EC0              mov es,ax
00006637  BE2000            mov si,0x20
0000663A  2EA18F04          mov ax,[cs:0x48f]
0000663E  268904            mov [es:si],ax
00006641  2EA18D04          mov ax,[cs:0x48d]
00006645  26894402          mov [es:si+0x2],ax
00006649  B036              mov al,0x36
0000664B  E643              out 0x43,al
0000664D  33C0              xor ax,ax
0000664F  E640              out 0x40,al
00006651  E640              out 0x40,al
00006653  E621              out 0x21,al
00006655  FB                sti
00006656  B8FFFF            mov ax,0xffff
00006659  2BC1              sub ax,cx
0000665B  8BC8              mov cx,ax
0000665D  B81000            mov ax,0x10
00006660  F7E1              mul cx
00006662  B91027            mov cx,0x2710
00006665  F7F1              div cx
00006667  40                inc ax
00006668  A31028            mov [0x2810],ax
0000666B  5F                pop di
0000666C  5E                pop si
0000666D  5D                pop bp
0000666E  CB                retf
0000666F  B9FFFF            mov cx,0xffff
00006672  33DB              xor bx,bx
00006674  FB                sti
00006675  F4                hlt
00006676  E2FE              loop 0x6676
00006678  55                push bp
00006679  8BEC              mov bp,sp
0000667B  3D4500            cmp ax,0x45
0000667E  7411              jz 0x6691
00006680  833E6B0606        cmp word [0x66b],byte +0x6
00006685  7E6F              jng 0x66f6
00006687  833E6B060C        cmp word [0x66b],byte +0xc
0000668C  7468              jz 0x66f6
0000668E  E9CD00            jmp 0x675e
00006691  803E3A2801        cmp byte [0x283a],0x1
00006696  7503              jnz 0x669b
00006698  E9C300            jmp 0x675e
0000669B  C6061F2800        mov byte [0x281f],0x0
000066A0  9AD300E808        call 0x8e8:0xd3
000066A5  803EF60001        cmp byte [0xf6],0x1
000066AA  751D              jnz 0x66c9
000066AC  B81B00            mov ax,0x1b
000066AF  E8BB01            call 0x686d
000066B2  C6061E2800        mov byte [0x281e],0x0
000066B7  C606342800        mov byte [0x2834],0x0
000066BC  9A7F07E808        call 0x8e8:0x77f
000066C1  C6063A2801        mov byte [0x283a],0x1
000066C6  E99500            jmp 0x675e
000066C9  B81C00            mov ax,0x1c
000066CC  E89E01            call 0x686d
000066CF  BE6800            mov si,0x68
000066D2  B98407            mov cx,0x784
000066D5  8E061828          mov es,[0x2818]
000066D9  803EF60000        cmp byte [0xf6],0x0
000066DE  750B              jnz 0x66eb
000066E0  E8D203            call 0x6ab5
000066E3  C6063A2801        mov byte [0x283a],0x1
000066E8  EB74              jmp short 0x675e
000066EA  90                nop
000066EB  E84204            call 0x6b30
000066EE  C6063A2801        mov byte [0x283a],0x1
000066F3  EB69              jmp short 0x675e
000066F5  90                nop
000066F6  33C9              xor cx,cx
000066F8  32F6              xor dh,dh
000066FA  BB420A            mov bx,0xa42
000066FD  8EC3              mov es,bx
000066FF  8D363029          lea si,[0x2930]
00006703  56                push si
00006704  06                push es
00006705  268A14            mov dl,[es:si]
00006708  3AC2              cmp al,dl
0000670A  7547              jnz 0x6753
0000670C  268A4401          mov al,[es:si+0x1]
00006710  32E4              xor ah,ah
00006712  50                push ax
00006713  51                push cx
00006714  C6061F2800        mov byte [0x281f],0x0
00006719  BB420A            mov bx,0xa42
0000671C  8EC3              mov es,bx
0000671E  BE3528            mov si,0x2835
00006721  59                pop cx
00006722  03F1              add si,cx
00006724  268A1C            mov bl,[es:si]
00006727  80FB01            cmp bl,0x1
0000672A  7434              jz 0x6760
0000672C  58                pop ax
0000672D  06                push es
0000672E  56                push si
0000672F  50                push ax
00006730  9AD300E808        call 0x8e8:0xd3
00006735  58                pop ax
00006736  E83401            call 0x686d
00006739  C6061E2800        mov byte [0x281e],0x0
0000673E  C606342800        mov byte [0x2834],0x0
00006743  9A7F07E808        call 0x8e8:0x77f
00006748  5E                pop si
00006749  07                pop es
0000674A  26C60401          mov byte [es:si],0x1
0000674E  07                pop es
0000674F  5E                pop si
00006750  EB0C              jmp short 0x675e
00006752  90                nop
00006753  07                pop es
00006754  5E                pop si
00006755  83C602            add si,byte +0x2
00006758  41                inc cx
00006759  83F905            cmp cx,byte +0x5
0000675C  75A5              jnz 0x6703
0000675E  5D                pop bp
0000675F  CB                retf
00006760  58                pop ax
00006761  07                pop es
00006762  5E                pop si
00006763  5D                pop bp
00006764  CB                retf
00006765  55                push bp
00006766  8BEC              mov bp,sp
00006768  C6061F2800        mov byte [0x281f],0x0
0000676D  9AD300E808        call 0x8e8:0xd3
00006772  C6061E2800        mov byte [0x281e],0x0
00006777  C606342800        mov byte [0x2834],0x0
0000677C  8BE9              mov bp,cx
0000677E  8B4600            mov ax,[bp+0x0]
00006781  E8E900            call 0x686d
00006784  9A7F07E808        call 0x8e8:0x77f
00006789  5D                pop bp
0000678A  CB                retf
0000678B  55                push bp
0000678C  8BEC              mov bp,sp
0000678E  C6061F2800        mov byte [0x281f],0x0
00006793  9AD300E808        call 0x8e8:0xd3
00006798  5D                pop bp
00006799  CB                retf
0000679A  55                push bp
0000679B  8BEC              mov bp,sp
0000679D  8BE9              mov bp,cx
0000679F  8B4600            mov ax,[bp+0x0]
000067A2  9A08004207        call 0x742:0x8
000067A7  803E1E2801        cmp byte [0x281e],0x1
000067AC  7512              jnz 0x67c0
000067AE  C6061F2800        mov byte [0x281f],0x0
000067B3  9AD300E808        call 0x8e8:0xd3
000067B8  9A7F07E808        call 0x8e8:0x77f
000067BD  EB0B              jmp short 0x67ca
000067BF  90                nop
000067C0  C6061F2800        mov byte [0x281f],0x0
000067C5  9AD300E808        call 0x8e8:0xd3
000067CA  5D                pop bp
000067CB  CB                retf
000067CC  55                push bp
000067CD  8BEC              mov bp,sp
000067CF  C6063428FF        mov byte [0x2834],0xff
000067D4  C6061E2800        mov byte [0x281e],0x0
000067D9  833E6B061E        cmp word [0x66b],byte +0x1e
000067DE  7423              jz 0x6803
000067E0  833E6B0619        cmp word [0x66b],byte +0x19
000067E5  740A              jz 0x67f1
000067E7  833E6B061F        cmp word [0x66b],byte +0x1f
000067EC  7428              jz 0x6816
000067EE  EB40              jmp short 0x6830
000067F0  90                nop
000067F1  A12428            mov ax,[0x2824]
000067F4  E83B00            call 0x6832
000067F7  250100            and ax,0x1
000067FA  050F00            add ax,0xf
000067FD  A32428            mov [0x2824],ax
00006800  EB2E              jmp short 0x6830
00006802  90                nop
00006803  A12228            mov ax,[0x2822]
00006806  E82900            call 0x6832
00006809  40                inc ax
0000680A  250300            and ax,0x3
0000680D  051400            add ax,0x14
00006810  A32228            mov [0x2822],ax
00006813  EB1B              jmp short 0x6830
00006815  90                nop
00006816  A12628            mov ax,[0x2826]
00006819  E81600            call 0x6832
0000681C  40                inc ax
0000681D  250300            and ax,0x3
00006820  3D0300            cmp ax,0x3
00006823  7502              jnz 0x6827
00006825  33C0              xor ax,ax
00006827  051800            add ax,0x18
0000682A  A32628            mov [0x2826],ax
0000682D  E80200            call 0x6832
00006830  5D                pop bp
00006831  CB                retf
00006832  C6061E2801        mov byte [0x281e],0x1
00006837  50                push ax
00006838  E83200            call 0x686d
0000683B  58                pop ax
0000683C  C3                ret
0000683D  55                push bp
0000683E  8BEC              mov bp,sp
00006840  833E6B0619        cmp word [0x66b],byte +0x19
00006845  7424              jz 0x686b
00006847  C6063E2801        mov byte [0x283e],0x1
0000684C  C6063428FF        mov byte [0x2834],0xff
00006851  A12828            mov ax,[0x2828]
00006854  E8DBFF            call 0x6832
00006857  9A7F07E808        call 0x8e8:0x77f
0000685C  C6063E2800        mov byte [0x283e],0x0
00006861  40                inc ax
00006862  250100            and ax,0x1
00006865  051100            add ax,0x11
00006868  A32828            mov [0x2828],ax
0000686B  5D                pop bp
0000686C  CB                retf
0000686D  C6063F2801        mov byte [0x283f],0x1
00006872  803EF60000        cmp byte [0xf6],0x0
00006877  7510              jnz 0x6889
00006879  BB420A            mov bx,0xa42
0000687C  8EC3              mov es,bx
0000687E  8D1E3A29          lea bx,[0x293a]
00006882  D1E0              shl ax,1
00006884  03D8              add bx,ax
00006886  268B07            mov ax,[es:bx]
00006889  50                push ax
0000688A  1E                push ds
0000688B  8D167429          lea dx,[0x2974]
0000688F  B8420A            mov ax,0xa42
00006892  8ED8              mov ds,ax
00006894  B8803D            mov ax,0x3d80
00006897  CD21              int 0x21
00006899  7204              jc 0x689f
0000689B  1F                pop ds
0000689C  EB05              jmp short 0x68a3
0000689E  90                nop
0000689F  1F                pop ds
000068A0  E97B01            jmp 0x6a1e
000068A3  A32028            mov [0x2820],ax
000068A6  58                pop ax
000068A7  50                push ax
000068A8  D1E0              shl ax,1
000068AA  D1E0              shl ax,1
000068AC  BB420A            mov bx,0xa42
000068AF  8EC3              mov es,bx
000068B1  8D1E4028          lea bx,[0x2840]
000068B5  03D8              add bx,ax
000068B7  268B17            mov dx,[es:bx]
000068BA  268B4F02          mov cx,[es:bx+0x2]
000068BE  06                push es
000068BF  53                push bx
000068C0  8B1E2028          mov bx,[0x2820]
000068C4  B80042            mov ax,0x4200
000068C7  CD21              int 0x21
000068C9  5B                pop bx
000068CA  07                pop es
000068CB  268B4706          mov ax,[es:bx+0x6]
000068CF  53                push bx
000068D0  268B5F04          mov bx,[es:bx+0x4]
000068D4  E86C01            call 0x6a43
000068D7  8BC8              mov cx,ax
000068D9  8BD3              mov dx,bx
000068DB  5B                pop bx
000068DC  268B4702          mov ax,[es:bx+0x2]
000068E0  268B1F            mov bx,[es:bx]
000068E3  E85D01            call 0x6a43
000068E6  2BD3              sub dx,bx
000068E8  2BC8              sub cx,ax
000068EA  D1E1              shl cx,1
000068EC  D1E1              shl cx,1
000068EE  D1E1              shl cx,1
000068F0  D1E1              shl cx,1
000068F2  03D1              add dx,cx
000068F4  89161C28          mov [0x281c],dx
000068F8  1E                push ds
000068F9  B8003F            mov ax,0x3f00
000068FC  8B1E2028          mov bx,[0x2820]
00006900  8B0E1C28          mov cx,[0x281c]
00006904  8B169404          mov dx,[0x494]
00006908  81C2A00F          add dx,0xfa0
0000690C  8EDA              mov ds,dx
0000690E  33D2              xor dx,dx
00006910  CD21              int 0x21
00006912  1F                pop ds
00006913  A31C28            mov [0x281c],ax
00006916  B43E              mov ah,0x3e
00006918  8B1E2028          mov bx,[0x2820]
0000691C  CD21              int 0x21
0000691E  E89500            call 0x69b6
00006921  58                pop ax
00006922  50                push ax
00006923  1E                push ds
00006924  8D167C29          lea dx,[0x297c]
00006928  B8420A            mov ax,0xa42
0000692B  8ED8              mov ds,ax
0000692D  B8803D            mov ax,0x3d80
00006930  CD21              int 0x21
00006932  1F                pop ds
00006933  A32028            mov [0x2820],ax
00006936  58                pop ax
00006937  D1E0              shl ax,1
00006939  D1E0              shl ax,1
0000693B  BB420A            mov bx,0xa42
0000693E  8EC3              mov es,bx
00006940  8D1EB828          lea bx,[0x28b8]
00006944  03D8              add bx,ax
00006946  268B17            mov dx,[es:bx]
00006949  268B4F02          mov cx,[es:bx+0x2]
0000694D  06                push es
0000694E  53                push bx
0000694F  8B1E2028          mov bx,[0x2820]
00006953  B80042            mov ax,0x4200
00006956  CD21              int 0x21
00006958  5B                pop bx
00006959  07                pop es
0000695A  268B4706          mov ax,[es:bx+0x6]
0000695E  53                push bx
0000695F  268B5F04          mov bx,[es:bx+0x4]
00006963  E8DD00            call 0x6a43
00006966  8BC8              mov cx,ax
00006968  8BD3              mov dx,bx
0000696A  5B                pop bx
0000696B  0BD2              or dx,dx
0000696D  7505              jnz 0x6974
0000696F  0BC9              or cx,cx
00006971  7501              jnz 0x6974
00006973  C3                ret
00006974  268B4702          mov ax,[es:bx+0x2]
00006978  268B1F            mov bx,[es:bx]
0000697B  E8C500            call 0x6a43
0000697E  2BD3              sub dx,bx
00006980  2BC8              sub cx,ax
00006982  D1E1              shl cx,1
00006984  D1E1              shl cx,1
00006986  D1E1              shl cx,1
00006988  D1E1              shl cx,1
0000698A  03D1              add dx,cx
0000698C  1E                push ds
0000698D  B8003F            mov ax,0x3f00
00006990  8B1E2028          mov bx,[0x2820]
00006994  8BCA              mov cx,dx
00006996  8B169404          mov dx,[0x494]
0000699A  81C2A00F          add dx,0xfa0
0000699E  8EDA              mov ds,dx
000069A0  33D2              xor dx,dx
000069A2  CD21              int 0x21
000069A4  1F                pop ds
000069A5  B43E              mov ah,0x3e
000069A7  8B1E2028          mov bx,[0x2820]
000069AB  CD21              int 0x21
000069AD  E83D00            call 0x69ed
000069B0  C6063F2800        mov byte [0x283f],0x0
000069B5  C3                ret
000069B6  A19404            mov ax,[0x494]
000069B9  05A00F            add ax,0xfa0
000069BC  A32C28            mov [0x282c],ax
000069BF  33C0              xor ax,ax
000069C1  A32A28            mov [0x282a],ax
000069C4  A11828            mov ax,[0x2818]
000069C7  A33028            mov [0x2830],ax
000069CA  A11A28            mov ax,[0x281a]
000069CD  A32E28            mov [0x282e],ax
000069D0  A19404            mov ax,[0x494]
000069D3  05A00F            add ax,0xfa0
000069D6  8EC0              mov es,ax
000069D8  33DB              xor bx,bx
000069DA  268B07            mov ax,[es:bx]
000069DD  268B5702          mov dx,[es:bx+0x2]
000069E1  9AA2057F09        call 0x97f:0x5a2
000069E6  A13228            mov ax,[0x2832]
000069E9  A31C28            mov [0x281c],ax
000069EC  C3                ret
000069ED  A19404            mov ax,[0x494]
000069F0  05A00F            add ax,0xfa0
000069F3  A32C28            mov [0x282c],ax
000069F6  33C0              xor ax,ax
000069F8  A32A28            mov [0x282a],ax
000069FB  A11428            mov ax,[0x2814]
000069FE  A33028            mov [0x2830],ax
00006A01  A11628            mov ax,[0x2816]
00006A04  A32E28            mov [0x282e],ax
00006A07  A19404            mov ax,[0x494]
00006A0A  05A00F            add ax,0xfa0
00006A0D  8EC0              mov es,ax
00006A0F  33DB              xor bx,bx
00006A11  268B07            mov ax,[es:bx]
00006A14  268B5702          mov dx,[es:bx+0x2]
00006A18  9AA2057F09        call 0x97f:0x5a2
00006A1D  C3                ret
00006A1E  8A1E7106          mov bl,[0x671]
00006A22  80FB01            cmp bl,0x1
00006A25  7506              jnz 0x6a2d
00006A27  B80800            mov ax,0x8
00006A2A  EB0F              jmp short 0x6a3b
00006A2C  90                nop
00006A2D  80FB02            cmp bl,0x2
00006A30  7506              jnz 0x6a38
00006A32  B80600            mov ax,0x6
00006A35  EB04              jmp short 0x6a3b
00006A37  90                nop
00006A38  B80603            mov ax,0x306
00006A3B  9A67135901        call 0x159:0x1367
00006A40  E947FE            jmp 0x688a
00006A43  51                push cx
00006A44  B10C              mov cl,0xc
00006A46  D3E0              shl ax,cl
00006A48  B104              mov cl,0x4
00006A4A  53                push bx
00006A4B  D3EB              shr bx,cl
00006A4D  03C3              add ax,bx
00006A4F  5B                pop bx
00006A50  83E30F            and bx,byte +0xf
00006A53  59                pop cx
00006A54  C3                ret
00006A55  55                push bp
00006A56  8BEC              mov bp,sp
00006A58  803EF60000        cmp byte [0xf6],0x0
00006A5D  750D              jnz 0x6a6c
00006A5F  B80F00            mov ax,0xf
00006A62  E808FE            call 0x686d
00006A65  9A7F07E808        call 0x8e8:0x77f
00006A6A  5D                pop bp
00006A6B  CB                retf
00006A6C  B82700            mov ax,0x27
00006A6F  50                push ax
00006A70  B80900            mov ax,0x9
00006A73  50                push ax
00006A74  A19404            mov ax,[0x494]
00006A77  05A00F            add ax,0xfa0
00006A7A  50                push ax
00006A7B  33DB              xor bx,bx
00006A7D  53                push bx
00006A7E  9AEF11DB02        call 0x2db:0x11ef
00006A83  83C408            add sp,byte +0x8
00006A86  E82DFF            call 0x69b6
00006A89  B82700            mov ax,0x27
00006A8C  50                push ax
00006A8D  B80A00            mov ax,0xa
00006A90  50                push ax
00006A91  A19404            mov ax,[0x494]
00006A94  05A00F            add ax,0xfa0
00006A97  50                push ax
00006A98  33DB              xor bx,bx
00006A9A  53                push bx
00006A9B  9AEF11DB02        call 0x2db:0x11ef
00006AA0  83C408            add sp,byte +0x8
00006AA3  E847FF            call 0x69ed
00006AA6  9A7F07E808        call 0x8e8:0x77f
00006AAB  5D                pop bp
00006AAC  CB                retf
00006AAD  0000              add [bx+si],al
00006AAF  0000              add [bx+si],al
00006AB1  0000              add [bx+si],al
00006AB3  0000              add [bx+si],al
00006AB5  06                push es
00006AB6  56                push si
00006AB7  51                push cx
00006AB8  FA                cli
00006AB9  B80835            mov ax,0x3508
00006ABC  CD21              int 0x21
00006ABE  2E8C064304        mov [cs:0x443],es
00006AC3  2E891E4104        mov [cs:0x441],bx
00006AC8  B0B0              mov al,0xb0
00006ACA  E643              out 0x43,al
00006ACC  B090              mov al,0x90
00006ACE  E640              out 0x40,al
00006AD0  32C0              xor al,al
00006AD2  E640              out 0x40,al
00006AD4  B80825            mov ax,0x2508
00006AD7  1E                push ds
00006AD8  0E                push cs
00006AD9  1F                pop ds
00006ADA  BAB504            mov dx,0x4b5
00006ADD  CD21              int 0x21
00006ADF  1F                pop ds
00006AE0  59                pop cx
00006AE1  5E                pop si
00006AE2  07                pop es
00006AE3  E83100            call 0x6b17
00006AE6  268A04            mov al,[es:si]
00006AE9  46                inc si
00006AEA  49                dec cx
00006AEB  FB                sti
00006AEC  F4                hlt
00006AED  268A04            mov al,[es:si]
00006AF0  46                inc si
00006AF1  F4                hlt
00006AF2  E2F9              loop 0x6aed
00006AF4  FA                cli
00006AF5  E82600            call 0x6b1e
00006AF8  B036              mov al,0x36
00006AFA  E643              out 0x43,al
00006AFC  B0FF              mov al,0xff
00006AFE  E640              out 0x40,al
00006B00  E640              out 0x40,al
00006B02  B80825            mov ax,0x2508
00006B05  1E                push ds
00006B06  2E8B164104        mov dx,[cs:0x441]
00006B0B  2E8B1E4304        mov bx,[cs:0x443]
00006B10  8EDB              mov ds,bx
00006B12  CD21              int 0x21
00006B14  1F                pop ds
00006B15  FB                sti
00006B16  C3                ret
00006B17  E461              in al,0x61
00006B19  0C03              or al,0x3
00006B1B  E661              out 0x61,al
00006B1D  C3                ret
00006B1E  E461              in al,0x61
00006B20  24FC              and al,0xfc
00006B22  E661              out 0x61,al
00006B24  C3                ret
00006B25  E642              out 0x42,al
00006B27  32C0              xor al,al
00006B29  E642              out 0x42,al
00006B2B  B020              mov al,0x20
00006B2D  E620              out 0x20,al
00006B2F  CF                iret
00006B30  06                push es
00006B31  56                push si
00006B32  51                push cx
00006B33  FA                cli
00006B34  B036              mov al,0x36
00006B36  E643              out 0x43,al
00006B38  B090              mov al,0x90
00006B3A  E640              out 0x40,al
00006B3C  2AC0              sub al,al
00006B3E  E640              out 0x40,al
00006B40  B0FE              mov al,0xfe
00006B42  E621              out 0x21,al
00006B44  EB26              jmp short 0x6b6c
00006B46  90                nop
00006B47  33C9              xor cx,cx
00006B49  8EC1              mov es,cx
00006B4B  BE2000            mov si,0x20
00006B4E  59                pop cx
00006B4F  268B3C            mov di,[es:si]
00006B52  2E893E4104        mov [cs:0x441],di
00006B57  26890C            mov [es:si],cx
00006B5A  0E                push cs
00006B5B  59                pop cx
00006B5C  268B7C02          mov di,[es:si+0x2]
00006B60  2E893E4304        mov [cs:0x443],di
00006B65  26894C02          mov [es:si+0x2],cx
00006B69  EB09              jmp short 0x6b74
00006B6B  90                nop
00006B6C  E8D8FF            call 0x6b47
00006B6F  B020              mov al,0x20
00006B71  E620              out 0x20,al
00006B73  CF                iret
00006B74  8B16F700          mov dx,[0xf7]
00006B78  83C20C            add dx,byte +0xc
00006B7B  59                pop cx
00006B7C  5E                pop si
00006B7D  07                pop es
00006B7E  FB                sti
00006B7F  F4                hlt
00006B80  EC                in al,dx
00006B81  0AC0              or al,al
00006B83  78FB              js 0x6b80
00006B85  B010              mov al,0x10
00006B87  EE                out dx,al
00006B88  EC                in al,dx
00006B89  0AC0              or al,al
00006B8B  78FB              js 0x6b88
00006B8D  26AC              es lodsb
00006B8F  3480              xor al,0x80
00006B91  EE                out dx,al
00006B92  F4                hlt
00006B93  E2EB              loop 0x6b80
00006B95  FA                cli
00006B96  B036              mov al,0x36
00006B98  E643              out 0x43,al
00006B9A  32C0              xor al,al
00006B9C  E640              out 0x40,al
00006B9E  E640              out 0x40,al
00006BA0  E621              out 0x21,al
00006BA2  B80825            mov ax,0x2508
00006BA5  1E                push ds
00006BA6  2E8B164104        mov dx,[cs:0x441]
00006BAB  2E8B1E4304        mov bx,[cs:0x443]
00006BB0  8EDB              mov ds,bx
00006BB2  CD21              int 0x21
00006BB4  1F                pop ds
00006BB5  FB                sti
00006BB6  C3                ret
00006BB7  55                push bp
00006BB8  8BEC              mov bp,sp
00006BBA  B80600            mov ax,0x6
00006BBD  8B0E1028          mov cx,[0x2810]
00006BC1  F7E1              mul cx
00006BC3  8BD0              mov dx,ax
00006BC5  B9FFFF            mov cx,0xffff
00006BC8  51                push cx
00006BC9  E2FE              loop 0x6bc9
00006BCB  59                pop cx
00006BCC  4A                dec dx
00006BCD  0BD2              or dx,dx
00006BCF  75F4              jnz 0x6bc5
00006BD1  5D                pop bp
00006BD2  CB                retf
00006BD3  55                push bp
00006BD4  8BEC              mov bp,sp
00006BD6  8BE9              mov bp,cx
00006BD8  833E6B060F        cmp word [0x66b],byte +0xf
00006BDD  7409              jz 0x6be8
00006BDF  833E6B061D        cmp word [0x66b],byte +0x1d
00006BE4  740B              jz 0x6bf1
00006BE6  5D                pop bp
00006BE7  CB                retf
00006BE8  8B4600            mov ax,[bp+0x0]
00006BEB  0BC0              or ax,ax
00006BED  750B              jnz 0x6bfa
00006BEF  5D                pop bp
00006BF0  CB                retf
00006BF1  8B4600            mov ax,[bp+0x0]
00006BF4  0BC0              or ax,ax
00006BF6  741F              jz 0x6c17
00006BF8  5D                pop bp
00006BF9  CB                retf
00006BFA  32ED              xor ch,ch
00006BFC  8A0E3B28          mov cl,[0x283b]
00006C00  FEC1              inc cl
00006C02  80E101            and cl,0x1
00006C05  880E3B28          mov [0x283b],cl
00006C09  83C102            add cx,byte +0x2
00006C0C  BFF1FF            mov di,0xfff1
00006C0F  E82200            call 0x6c34
00006C12  E85800            call 0x6c6d
00006C15  5D                pop bp
00006C16  CB                retf
00006C17  32ED              xor ch,ch
00006C19  8A0E3C28          mov cl,[0x283c]
00006C1D  FEC1              inc cl
00006C1F  80E101            and cl,0x1
00006C22  880E3C28          mov [0x283c],cl
00006C26  83C102            add cx,byte +0x2
00006C29  BFFFFF            mov di,0xffff
00006C2C  E80500            call 0x6c34
00006C2F  E83B00            call 0x6c6d
00006C32  5D                pop bp
00006C33  CB                retf
00006C34  33D2              xor dx,dx
00006C36  A11828            mov ax,[0x2818]
00006C39  2D7102            sub ax,0x271
00006C3C  33DB              xor bx,bx
00006C3E  E84A00            call 0x6c8b
00006C41  50                push ax
00006C42  53                push bx
00006C43  52                push dx
00006C44  51                push cx
00006C45  52                push dx
00006C46  57                push di
00006C47  8BCC              mov cx,sp
00006C49  9A440E5901        call 0x159:0xe44
00006C4E  83C40C            add sp,byte +0xc
00006C51  33D2              xor dx,dx
00006C53  52                push dx
00006C54  52                push dx
00006C55  8B0E9404          mov cx,[0x494]
00006C59  51                push cx
00006C5A  33DB              xor bx,bx
00006C5C  53                push bx
00006C5D  A11828            mov ax,[0x2818]
00006C60  2D7102            sub ax,0x271
00006C63  50                push ax
00006C64  9A00009304        call 0x493:0x0
00006C69  83C40A            add sp,byte +0xa
00006C6C  C3                ret
00006C6D  C7069E000000      mov word [0x9e],0x0
00006C73  C706A4000000      mov word [0xa4],0x0
00006C79  C706A0003F01      mov word [0xa0],0x13f
00006C7F  C706A200C700      mov word [0xa2],0xc7
00006C85  9A750D9304        call 0x493:0xd75
00006C8A  C3                ret
00006C8B  51                push cx
00006C8C  50                push ax
00006C8D  B10C              mov cl,0xc
00006C8F  D3E8              shr ax,cl
00006C91  8AE8              mov ch,al
00006C93  58                pop ax
00006C94  B104              mov cl,0x4
00006C96  D3E0              shl ax,cl
00006C98  03D8              add bx,ax
00006C9A  7302              jnc 0x6c9e
00006C9C  FEC5              inc ch
00006C9E  8AC5              mov al,ch
00006CA0  32E4              xor ah,ah
00006CA2  59                pop cx
00006CA3  C3                ret
00006CA4  55                push bp
00006CA5  8BEC              mov bp,sp
00006CA7  50                push ax
00006CA8  53                push bx
00006CA9  51                push cx
00006CAA  833E6B060F        cmp word [0x66b],byte +0xf
00006CAF  740A              jz 0x6cbb
00006CB1  833E6B061D        cmp word [0x66b],byte +0x1d
00006CB6  7415              jz 0x6ccd
00006CB8  EB25              jmp short 0x6cdf
00006CBA  90                nop
00006CBB  32ED              xor ch,ch
00006CBD  8A0E3B28          mov cl,[0x283b]
00006CC1  83C102            add cx,byte +0x2
00006CC4  BFF1FF            mov di,0xfff1
00006CC7  E86AFF            call 0x6c34
00006CCA  EB13              jmp short 0x6cdf
00006CCC  90                nop
00006CCD  32ED              xor ch,ch
00006CCF  8A0E3C28          mov cl,[0x283c]
00006CD3  83C102            add cx,byte +0x2
00006CD6  BFFFFF            mov di,0xffff
00006CD9  E858FF            call 0x6c34
00006CDC  EB01              jmp short 0x6cdf
00006CDE  90                nop
00006CDF  59                pop cx
00006CE0  5B                pop bx
00006CE1  58                pop ax
00006CE2  5D                pop bp
00006CE3  CB                retf
00006CE4  55                push bp
00006CE5  8BEC              mov bp,sp
00006CE7  C6061F2800        mov byte [0x281f],0x0
00006CEC  9AD300E808        call 0x8e8:0xd3
00006CF1  B81300            mov ax,0x13
00006CF4  E876FB            call 0x686d
00006CF7  C606342800        mov byte [0x2834],0x0
00006CFC  C6061E2801        mov byte [0x281e],0x1
00006D01  9A7F07E808        call 0x8e8:0x77f
00006D06  5D                pop bp
00006D07  CB                retf
00006D08  55                push bp
00006D09  8BEC              mov bp,sp
00006D0B  1E                push ds
00006D0C  56                push si
00006D0D  57                push di
00006D0E  803E842901        cmp byte [0x2984],0x1
00006D13  7420              jz 0x6d35
00006D15  51                push cx
00006D16  1E                push ds
00006D17  B8420A            mov ax,0xa42
00006D1A  8ED8              mov ds,ax
00006D1C  8D3E8529          lea di,[0x2985]
00006D20  B9C000            mov cx,0xc0
00006D23  8B05              mov ax,[di]
00006D25  86E0              xchg ah,al
00006D27  8905              mov [di],ax
00006D29  83C702            add di,byte +0x2
00006D2C  E2F5              loop 0x6d23
00006D2E  C606842901        mov byte [0x2984],0x1
00006D33  1F                pop ds
00006D34  59                pop cx
00006D35  8BE9              mov bp,cx
00006D37  8B5E18            mov bx,[bp+0x18]
00006D3A  8B461A            mov ax,[bp+0x1a]
00006D3D  E83705            call 0x7277
00006D40  8B4E20            mov cx,[bp+0x20]
00006D43  83F904            cmp cx,byte +0x4
00006D46  7500              jnz 0x6d48
00006D48  8A4E20            mov cl,[bp+0x20]
00006D4B  80F902            cmp cl,0x2
00006D4E  7503              jnz 0x6d53
00006D50  E98902            jmp 0x6fdc
00006D53  80F903            cmp cl,0x3
00006D56  7503              jnz 0x6d5b
00006D58  E90703            jmp 0x7062
00006D5B  0AC9              or cl,cl
00006D5D  7503              jnz 0x6d62
00006D5F  E93204            jmp 0x7194
00006D62  80F901            cmp cl,0x1
00006D65  7503              jnz 0x6d6a
00006D67  E94004            jmp 0x71aa
00006D6A  80F906            cmp cl,0x6
00006D6D  7503              jnz 0x6d72
00006D6F  E98A04            jmp 0x71fc
00006D72  8B4600            mov ax,[bp+0x0]
00006D75  8B5E04            mov bx,[bp+0x4]
00006D78  83E3F0            and bx,byte -0x10
00006D7B  83C30F            add bx,byte +0xf
00006D7E  895E04            mov [bp+0x4],bx
00006D81  8B4E08            mov cx,[bp+0x8]
00006D84  8B560C            mov dx,[bp+0xc]
00006D87  83E2F0            and dx,byte -0x10
00006D8A  89560C            mov [bp+0xc],dx
00006D8D  3DC700            cmp ax,0xc7
00006D90  7E06              jng 0x6d98
00006D92  B8C700            mov ax,0xc7
00006D95  894600            mov [bp+0x0],ax
00006D98  A19204            mov ax,[0x492]
00006D9B  3D0500            cmp ax,0x5
00006D9E  7503              jnz 0x6da3
00006DA0  E9F300            jmp 0x6e96
00006DA3  833E920405        cmp word [0x492],byte +0x5
00006DA8  747F              jz 0x6e29
00006DAA  8A4620            mov al,[bp+0x20]
00006DAD  3C04              cmp al,0x4
00006DAF  7514              jnz 0x6dc5
00006DB1  C70647060000      mov word [0x647],0x0
00006DB7  8B5E18            mov bx,[bp+0x18]
00006DBA  8B461A            mov ax,[bp+0x1a]
00006DBD  E8B704            call 0x7277
00006DC0  9AE715DB02        call 0x2db:0x15e7
00006DC5  C7069E000000      mov word [0x9e],0x0
00006DCB  C706A0003F01      mov word [0xa0],0x13f
00006DD1  C706A4000000      mov word [0xa4],0x0
00006DD7  C706A2000C00      mov word [0xa2],0xc
00006DDD  9A750D9304        call 0x493:0xd75
00006DE2  8B460C            mov ax,[bp+0xc]
00006DE5  A39E00            mov [0x9e],ax
00006DE8  8B4604            mov ax,[bp+0x4]
00006DEB  A3A000            mov [0xa0],ax
00006DEE  8B4608            mov ax,[bp+0x8]
00006DF1  A3A400            mov [0xa4],ax
00006DF4  8B4600            mov ax,[bp+0x0]
00006DF7  A3A200            mov [0xa2],ax
00006DFA  9A750D9304        call 0x493:0xd75
00006DFF  803E122801        cmp byte [0x2812],0x1
00006E04  7503              jnz 0x6e09
00006E06  E9BE02            jmp 0x70c7
00006E09  C7069E000000      mov word [0x9e],0x0
00006E0F  C706A0003F01      mov word [0xa0],0x13f
00006E15  C706A400AE00      mov word [0xa4],0xae
00006E1B  C706A200C700      mov word [0xa2],0xc7
00006E21  9A750D9304        call 0x493:0xd75
00006E26  E99E02            jmp 0x70c7
00006E29  8A4620            mov al,[bp+0x20]
00006E2C  3C04              cmp al,0x4
00006E2E  7517              jnz 0x6e47
00006E30  C60645063F        mov byte [0x645],0x3f
00006E35  C606460600        mov byte [0x646],0x0
00006E3A  C606480600        mov byte [0x648],0x0
00006E3F  C606470601        mov byte [0x647],0x1
00006E44  E81204            call 0x7259
00006E47  8B460C            mov ax,[bp+0xc]
00006E4A  A39E00            mov [0x9e],ax
00006E4D  8B4604            mov ax,[bp+0x4]
00006E50  A3A000            mov [0xa0],ax
00006E53  8B4608            mov ax,[bp+0x8]
00006E56  A3A400            mov [0xa4],ax
00006E59  8B4600            mov ax,[bp+0x0]
00006E5C  A3A200            mov [0xa2],ax
00006E5F  9A750D9304        call 0x493:0xd75
00006E64  8A4620            mov al,[bp+0x20]
00006E67  3C04              cmp al,0x4
00006E69  7528              jnz 0x6e93
00006E6B  8B5E18            mov bx,[bp+0x18]
00006E6E  8B461A            mov ax,[bp+0x1a]
00006E71  E80304            call 0x7277
00006E74  B90100            mov cx,0x1
00006E77  9A2418DB02        call 0x2db:0x1824
00006E7C  C60645063F        mov byte [0x645],0x3f
00006E81  C606460600        mov byte [0x646],0x0
00006E86  C606480600        mov byte [0x648],0x0
00006E8B  C606470602        mov byte [0x647],0x2
00006E90  E8C603            call 0x7259
00006E93  E93102            jmp 0x70c7
00006E96  833E10280C        cmp word [0x2810],byte +0xc
00006E9B  7F03              jg 0x6ea0
00006E9D  E903FF            jmp 0x6da3
00006EA0  8B5E1C            mov bx,[bp+0x1c]
00006EA3  83FB06            cmp bx,byte +0x6
00006EA6  7C03              jl 0x6eab
00006EA8  83EB06            sub bx,byte +0x6
00006EAB  B106              mov cl,0x6
00006EAD  D3E3              shl bx,cl
00006EAF  C60645063F        mov byte [0x645],0x3f
00006EB4  C606460600        mov byte [0x646],0x0
00006EB9  C606480600        mov byte [0x648],0x0
00006EBE  C606470600        mov byte [0x647],0x0
00006EC3  8A4620            mov al,[bp+0x20]
00006EC6  3C04              cmp al,0x4
00006EC8  7517              jnz 0x6ee1
00006ECA  53                push bx
00006ECB  50                push ax
00006ECC  51                push cx
00006ECD  8B5E18            mov bx,[bp+0x18]
00006ED0  8B461A            mov ax,[bp+0x1a]
00006ED3  E8A103            call 0x7277
00006ED6  B90100            mov cx,0x1
00006ED9  9A2418DB02        call 0x2db:0x1824
00006EDE  59                pop cx
00006EDF  58                pop ax
00006EE0  5B                pop bx
00006EE1  8B169404          mov dx,[0x494]
00006EE5  52                push dx
00006EE6  B8420A            mov ax,0xa42
00006EE9  8ED8              mov ds,ax
00006EEB  8D3E8529          lea di,[0x2985]
00006EEF  03FB              add di,bx
00006EF1  A19404            mov ax,[0x494]
00006EF4  05A00F            add ax,0xfa0
00006EF7  8EC0              mov es,ax
00006EF9  33F6              xor si,si
00006EFB  BA2000            mov dx,0x20
00006EFE  52                push dx
00006EFF  B91000            mov cx,0x10
00006F02  BB0080            mov bx,0x8000
00006F05  8B05              mov ax,[di]
00006F07  32D2              xor dl,dl
00006F09  85C3              test bx,ax
00006F0B  7402              jz 0x6f0f
00006F0D  FECA              dec dl
00006F0F  268814            mov [es:si],dl
00006F12  46                inc si
00006F13  D1EB              shr bx,1
00006F15  E2EE              loop 0x6f05
00006F17  83C702            add di,byte +0x2
00006F1A  5A                pop dx
00006F1B  4A                dec dx
00006F1C  75E0              jnz 0x6efe
00006F1E  33FF              xor di,di
00006F20  A19404            mov ax,[0x494]
00006F23  05A00F            add ax,0xfa0
00006F26  8ED8              mov ds,ax
00006F28  B800A0            mov ax,0xa000
00006F2B  8EC0              mov es,ax
00006F2D  8B4604            mov ax,[bp+0x4]
00006F30  2B460C            sub ax,[bp+0xc]
00006F33  40                inc ax
00006F34  B104              mov cl,0x4
00006F36  D3E8              shr ax,cl
00006F38  894602            mov [bp+0x2],ax
00006F3B  8B4600            mov ax,[bp+0x0]
00006F3E  2B4608            sub ax,[bp+0x8]
00006F41  40                inc ax
00006F42  B110              mov cl,0x10
00006F44  F6F9              idiv cl
00006F46  0AE4              or ah,ah
00006F48  7402              jz 0x6f4c
00006F4A  FEC0              inc al
00006F4C  884606            mov [bp+0x6],al
00006F4F  886607            mov [bp+0x7],ah
00006F52  8B4608            mov ax,[bp+0x8]
00006F55  B94001            mov cx,0x140
00006F58  F7E1              mul cx
00006F5A  8BF0              mov si,ax
00006F5C  03760C            add si,[bp+0xc]
00006F5F  5A                pop dx
00006F60  BB1000            mov bx,0x10
00006F63  53                push bx
00006F64  56                push si
00006F65  57                push di
00006F66  32FF              xor bh,bh
00006F68  8A5E06            mov bl,[bp+0x6]
00006F6B  53                push bx
00006F6C  56                push si
00006F6D  57                push di
00006F6E  80FB01            cmp bl,0x1
00006F71  750C              jnz 0x6f7f
00006F73  32FF              xor bh,bh
00006F75  8A5E07            mov bl,[bp+0x7]
00006F78  0ADB              or bl,bl
00006F7A  7403              jz 0x6f7f
00006F7C  EB04              jmp short 0x6f82
00006F7E  90                nop
00006F7F  BB1000            mov bx,0x10
00006F82  56                push si
00006F83  8A05              mov al,[di]
00006F85  B91000            mov cx,0x10
00006F88  51                push cx
00006F89  56                push si
00006F8A  1E                push ds
00006F8B  8EDA              mov ds,dx
00006F8D  8B4E02            mov cx,[bp+0x2]
00006F90  0AC0              or al,al
00006F92  7405              jz 0x6f99
00006F94  8A24              mov ah,[si]
00006F96  268824            mov [es:si],ah
00006F99  83C610            add si,byte +0x10
00006F9C  E2F2              loop 0x6f90
00006F9E  1F                pop ds
00006F9F  5E                pop si
00006FA0  46                inc si
00006FA1  47                inc di
00006FA2  8A05              mov al,[di]
00006FA4  59                pop cx
00006FA5  E2E1              loop 0x6f88
00006FA7  5E                pop si
00006FA8  81C64001          add si,0x140
00006FAC  4B                dec bx
00006FAD  75D3              jnz 0x6f82
00006FAF  5F                pop di
00006FB0  5E                pop si
00006FB1  81C60014          add si,0x1400
00006FB5  5B                pop bx
00006FB6  4B                dec bx
00006FB7  75B2              jnz 0x6f6b
00006FB9  5F                pop di
00006FBA  83C710            add di,byte +0x10
00006FBD  50                push ax
00006FBE  8A4620            mov al,[bp+0x20]
00006FC1  3C04              cmp al,0x4
00006FC3  750C              jnz 0x6fd1
00006FC5  51                push cx
00006FC6  B90400            mov cx,0x4
00006FC9  9AE715DB02        call 0x2db:0x15e7
00006FCE  E2F9              loop 0x6fc9
00006FD0  59                pop cx
00006FD1  58                pop ax
00006FD2  5E                pop si
00006FD3  5B                pop bx
00006FD4  4B                dec bx
00006FD5  7402              jz 0x6fd9
00006FD7  EB8A              jmp short 0x6f63
00006FD9  E9EB00            jmp 0x70c7
00006FDC  A19204            mov ax,[0x492]
00006FDF  3D0500            cmp ax,0x5
00006FE2  7420              jz 0x7004
00006FE4  C7069E000000      mov word [0x9e],0x0
00006FEA  C706A4000000      mov word [0xa4],0x0
00006FF0  C706A200C700      mov word [0xa2],0xc7
00006FF6  C706A0003F01      mov word [0xa0],0x13f
00006FFC  9A750D9304        call 0x493:0xd75
00007001  E9C300            jmp 0x70c7
00007004  C606470602        mov byte [0x647],0x2
00007009  C6460000          mov byte [bp+0x0],0x0
0000700D  BB6300            mov bx,0x63
00007010  B86300            mov ax,0x63
00007013  B97A00            mov cx,0x7a
00007016  BA0200            mov dx,0x2
00007019  50                push ax
0000701A  53                push bx
0000701B  51                push cx
0000701C  52                push dx
0000701D  E8AC00            call 0x70cc
00007020  5A                pop dx
00007021  59                pop cx
00007022  5B                pop bx
00007023  58                pop ax
00007024  2D0200            sub ax,0x2
00007027  83EB02            sub bx,byte +0x2
0000702A  83C104            add cx,byte +0x4
0000702D  83C204            add dx,byte +0x4
00007030  81FACA00          cmp dx,0xca
00007034  75E3              jnz 0x7019
00007036  BB6200            mov bx,0x62
00007039  B86200            mov ax,0x62
0000703C  B97C00            mov cx,0x7c
0000703F  BA0400            mov dx,0x4
00007042  50                push ax
00007043  53                push bx
00007044  51                push cx
00007045  52                push dx
00007046  E88300            call 0x70cc
00007049  5A                pop dx
0000704A  59                pop cx
0000704B  5B                pop bx
0000704C  58                pop ax
0000704D  2D0200            sub ax,0x2
00007050  83EB02            sub bx,byte +0x2
00007053  83C104            add cx,byte +0x4
00007056  83C204            add dx,byte +0x4
00007059  81FACC00          cmp dx,0xcc
0000705D  75E3              jnz 0x7042
0000705F  EB66              jmp short 0x70c7
00007061  90                nop
00007062  A19204            mov ax,[0x492]
00007065  3D0500            cmp ax,0x5
00007068  7403              jz 0x706d
0000706A  EB5B              jmp short 0x70c7
0000706C  90                nop
0000706D  1E                push ds
0000706E  C64600FF          mov byte [bp+0x0],0xff
00007072  33DB              xor bx,bx
00007074  33C0              xor ax,ax
00007076  B94001            mov cx,0x140
00007079  BAC800            mov dx,0xc8
0000707C  50                push ax
0000707D  53                push bx
0000707E  51                push cx
0000707F  52                push dx
00007080  E84900            call 0x70cc
00007083  5A                pop dx
00007084  59                pop cx
00007085  5B                pop bx
00007086  58                pop ax
00007087  050200            add ax,0x2
0000708A  83C302            add bx,byte +0x2
0000708D  83E904            sub cx,byte +0x4
00007090  83EA04            sub dx,byte +0x4
00007093  3D6400            cmp ax,0x64
00007096  75E4              jnz 0x707c
00007098  BB0100            mov bx,0x1
0000709B  B80100            mov ax,0x1
0000709E  B90100            mov cx,0x1
000070A1  B93E01            mov cx,0x13e
000070A4  BAC600            mov dx,0xc6
000070A7  50                push ax
000070A8  53                push bx
000070A9  51                push cx
000070AA  52                push dx
000070AB  E81E00            call 0x70cc
000070AE  5A                pop dx
000070AF  59                pop cx
000070B0  5B                pop bx
000070B1  58                pop ax
000070B2  050200            add ax,0x2
000070B5  83C302            add bx,byte +0x2
000070B8  83E904            sub cx,byte +0x4
000070BB  83EA04            sub dx,byte +0x4
000070BE  3D6500            cmp ax,0x65
000070C1  75E4              jnz 0x70a7
000070C3  EB01              jmp short 0x70c6
000070C5  90                nop
000070C6  1F                pop ds
000070C7  5F                pop di
000070C8  5E                pop si
000070C9  1F                pop ds
000070CA  5D                pop bp
000070CB  CB                retf
000070CC  1E                push ds
000070CD  BE4001            mov si,0x140
000070D0  52                push dx
000070D1  F7E6              mul si
000070D3  5A                pop dx
000070D4  8BF0              mov si,ax
000070D6  03F3              add si,bx
000070D8  8E069404          mov es,[0x494]
000070DC  B800A0            mov ax,0xa000
000070DF  8ED8              mov ds,ax
000070E1  8BFE              mov di,si
000070E3  51                push cx
000070E4  51                push cx
000070E5  52                push dx
000070E6  56                push si
000070E7  57                push di
000070E8  807E0000          cmp byte [bp+0x0],0x0
000070EC  7406              jz 0x70f4
000070EE  E88900            call 0x717a
000070F1  EB04              jmp short 0x70f7
000070F3  90                nop
000070F4  E86700            call 0x715e
000070F7  5F                pop di
000070F8  5E                pop si
000070F9  5A                pop dx
000070FA  59                pop cx
000070FB  51                push cx
000070FC  52                push dx
000070FD  56                push si
000070FE  57                push di
000070FF  807E0000          cmp byte [bp+0x0],0x0
00007103  7406              jz 0x710b
00007105  E88300            call 0x718b
00007108  EB04              jmp short 0x710e
0000710A  90                nop
0000710B  E86200            call 0x7170
0000710E  5F                pop di
0000710F  5E                pop si
00007110  5A                pop dx
00007111  59                pop cx
00007112  49                dec cx
00007113  03F9              add di,cx
00007115  03F1              add si,cx
00007117  807E0000          cmp byte [bp+0x0],0x0
0000711B  7406              jz 0x7123
0000711D  E85A00            call 0x717a
00007120  EB04              jmp short 0x7126
00007122  90                nop
00007123  E83800            call 0x715e
00007126  59                pop cx
00007127  49                dec cx
00007128  81EF4001          sub di,0x140
0000712C  81EE4001          sub si,0x140
00007130  2BF9              sub di,cx
00007132  2BF1              sub si,cx
00007134  41                inc cx
00007135  807E0000          cmp byte [bp+0x0],0x0
00007139  7406              jz 0x7141
0000713B  E84D00            call 0x718b
0000713E  EB04              jmp short 0x7144
00007140  90                nop
00007141  E82C00            call 0x7170
00007144  52                push dx
00007145  50                push ax
00007146  1E                push ds
00007147  B8420A            mov ax,0xa42
0000714A  8ED8              mov ds,ax
0000714C  B8F401            mov ax,0x1f4
0000714F  8B0E1028          mov cx,[0x2810]
00007153  F7E1              mul cx
00007155  8BC8              mov cx,ax
00007157  E2FE              loop 0x7157
00007159  1F                pop ds
0000715A  58                pop ax
0000715B  5A                pop dx
0000715C  1F                pop ds
0000715D  C3                ret
0000715E  8BCA              mov cx,dx
00007160  268A04            mov al,[es:si]
00007163  8805              mov [di],al
00007165  81C74001          add di,0x140
00007169  81C64001          add si,0x140
0000716D  E2F1              loop 0x7160
0000716F  C3                ret
00007170  268A04            mov al,[es:si]
00007173  8805              mov [di],al
00007175  47                inc di
00007176  46                inc si
00007177  E2F7              loop 0x7170
00007179  C3                ret
0000717A  8BCA              mov cx,dx
0000717C  32C0              xor al,al
0000717E  8805              mov [di],al
00007180  81C74001          add di,0x140
00007184  81C64001          add si,0x140
00007188  E2F2              loop 0x717c
0000718A  C3                ret
0000718B  32C0              xor al,al
0000718D  8805              mov [di],al
0000718F  47                inc di
00007190  46                inc si
00007191  E2F8              loop 0x718b
00007193  C3                ret
00007194  C606470602        mov byte [0x647],0x2
00007199  E89700            call 0x7233
0000719C  A19204            mov ax,[0x492]
0000719F  3D0500            cmp ax,0x5
000071A2  7403              jz 0x71a7
000071A4  E93DFE            jmp 0x6fe4
000071A7  E91DFF            jmp 0x70c7
000071AA  C606470601        mov byte [0x647],0x1
000071AF  E88100            call 0x7233
000071B2  A19204            mov ax,[0x492]
000071B5  3D0500            cmp ax,0x5
000071B8  743F              jz 0x71f9
000071BA  A1DC00            mov ax,[0xdc]
000071BD  8EC0              mov es,ax
000071BF  8B3EDE00          mov di,[0xde]
000071C3  33C0              xor ax,ax
000071C5  B91000            mov cx,0x10
000071C8  E82500            call 0x71f0
000071CB  A1E000            mov ax,[0xe0]
000071CE  8EC0              mov es,ax
000071D0  8B3EE200          mov di,[0xe2]
000071D4  33C0              xor ax,ax
000071D6  B91000            mov cx,0x10
000071D9  E81400            call 0x71f0
000071DC  A17B01            mov ax,[0x17b]
000071DF  8EC0              mov es,ax
000071E1  8B3E7D01          mov di,[0x17d]
000071E5  33C0              xor ax,ax
000071E7  B90800            mov cx,0x8
000071EA  E80300            call 0x71f0
000071ED  EB0A              jmp short 0x71f9
000071EF  90                nop
000071F0  268905            mov [es:di],ax
000071F3  83C702            add di,byte +0x2
000071F6  E2F8              loop 0x71f0
000071F8  C3                ret
000071F9  E9CBFE            jmp 0x70c7
000071FC  C60645063F        mov byte [0x645],0x3f
00007201  C606460600        mov byte [0x646],0x0
00007206  C606480600        mov byte [0x648],0x0
0000720B  C606470600        mov byte [0x647],0x0
00007210  8B5E18            mov bx,[bp+0x18]
00007213  8B461A            mov ax,[bp+0x1a]
00007216  E85E00            call 0x7277
00007219  035E1E            add bx,[bp+0x1e]
0000721C  B90100            mov cx,0x1
0000721F  9A2418DB02        call 0x2db:0x1824
00007224  B94000            mov cx,0x40
00007227  51                push cx
00007228  9AE715DB02        call 0x2db:0x15e7
0000722D  59                pop cx
0000722E  E2F7              loop 0x7227
00007230  E994FE            jmp 0x70c7
00007233  C60645063F        mov byte [0x645],0x3f
00007238  C606460600        mov byte [0x646],0x0
0000723D  C606480600        mov byte [0x648],0x0
00007242  8B5E18            mov bx,[bp+0x18]
00007245  8B461A            mov ax,[bp+0x1a]
00007248  E82C00            call 0x7277
0000724B  807E2001          cmp byte [bp+0x20],0x1
0000724F  7408              jz 0x7259
00007251  B90100            mov cx,0x1
00007254  9A2418DB02        call 0x2db:0x1824
00007259  B94000            mov cx,0x40
0000725C  9AE715DB02        call 0x2db:0x15e7
00007261  51                push cx
00007262  52                push dx
00007263  50                push ax
00007264  B8E204            mov ax,0x4e2
00007267  8B0E1028          mov cx,[0x2810]
0000726B  F7E1              mul cx
0000726D  8BC8              mov cx,ax
0000726F  E2FE              loop 0x726f
00007271  58                pop ax
00007272  5A                pop dx
00007273  59                pop cx
00007274  E2E6              loop 0x725c
00007276  C3                ret
00007277  51                push cx
00007278  B10C              mov cl,0xc
0000727A  D3E0              shl ax,cl
0000727C  B104              mov cl,0x4
0000727E  53                push bx
0000727F  D3EB              shr bx,cl
00007281  03C3              add ax,bx
00007283  5B                pop bx
00007284  83E30F            and bx,byte +0xf
00007287  59                pop cx
00007288  C3                ret
00007289  55                push bp
0000728A  8BEC              mov bp,sp
0000728C  8BE9              mov bp,cx
0000728E  8B4600            mov ax,[bp+0x0]
00007291  8B0E1028          mov cx,[0x2810]
00007295  F7E1              mul cx
00007297  8BD0              mov dx,ax
00007299  B9E204            mov cx,0x4e2
0000729C  51                push cx
0000729D  E2FE              loop 0x729d
0000729F  59                pop cx
000072A0  4A                dec dx
000072A1  75F9              jnz 0x729c
000072A3  5D                pop bp
000072A4  CB                retf
000072A5  55                push bp
000072A6  8BEC              mov bp,sp
000072A8  83EC02            sub sp,byte +0x2
000072AB  C746FE0000        mov word [bp-0x2],0x0
000072B0  EB33              jmp short 0x72e5
000072B2  8B5EFE            mov bx,[bp-0x2]
000072B5  80BFDE2B00        cmp byte [bx+0x2bde],0x0
000072BA  7414              jz 0x72d0
000072BC  33C0              xor ax,ax
000072BE  50                push ax
000072BF  1E                push ds
000072C0  B84E2B            mov ax,0x2b4e
000072C3  50                push ax
000072C4  FF76FE            push word [bp-0x2]
000072C7  0E                push cs
000072C8  E8EE03            call 0x76b9
000072CB  83C408            add sp,byte +0x8
000072CE  EB12              jmp short 0x72e2
000072D0  33C0              xor ax,ax
000072D2  50                push ax
000072D3  1E                push ds
000072D4  B8402B            mov ax,0x2b40
000072D7  50                push ax
000072D8  FF76FE            push word [bp-0x2]
000072DB  0E                push cs
000072DC  E8DA03            call 0x76b9
000072DF  83C408            add sp,byte +0x8
000072E2  FF46FE            inc word [bp-0x2]
000072E5  837EFE12          cmp word [bp-0x2],byte +0x12
000072E9  7CC7              jl 0x72b2
000072EB  803EEF3400        cmp byte [0x34ef],0x0
000072F0  7472              jz 0x7364
000072F2  33C0              xor ax,ax
000072F4  50                push ax
000072F5  1E                push ds
000072F6  B85C2B            mov ax,0x2b5c
000072F9  50                push ax
000072FA  B80C00            mov ax,0xc
000072FD  50                push ax
000072FE  0E                push cs
000072FF  E8B703            call 0x76b9
00007302  83C408            add sp,byte +0x8
00007305  33C0              xor ax,ax
00007307  50                push ax
00007308  1E                push ds
00007309  B86A2B            mov ax,0x2b6a
0000730C  50                push ax
0000730D  B80F00            mov ax,0xf
00007310  50                push ax
00007311  0E                push cs
00007312  E8A403            call 0x76b9
00007315  83C408            add sp,byte +0x8
00007318  33C0              xor ax,ax
0000731A  50                push ax
0000731B  1E                push ds
0000731C  B8782B            mov ax,0x2b78
0000731F  50                push ax
00007320  B81000            mov ax,0x10
00007323  50                push ax
00007324  0E                push cs
00007325  E89103            call 0x76b9
00007328  83C408            add sp,byte +0x8
0000732B  33C0              xor ax,ax
0000732D  50                push ax
0000732E  1E                push ds
0000732F  B8862B            mov ax,0x2b86
00007332  50                push ax
00007333  B80E00            mov ax,0xe
00007336  50                push ax
00007337  0E                push cs
00007338  E87E03            call 0x76b9
0000733B  83C408            add sp,byte +0x8
0000733E  33C0              xor ax,ax
00007340  50                push ax
00007341  1E                push ds
00007342  B8942B            mov ax,0x2b94
00007345  50                push ax
00007346  B81100            mov ax,0x11
00007349  50                push ax
0000734A  0E                push cs
0000734B  E86B03            call 0x76b9
0000734E  83C408            add sp,byte +0x8
00007351  33C0              xor ax,ax
00007353  50                push ax
00007354  1E                push ds
00007355  B8A22B            mov ax,0x2ba2
00007358  50                push ax
00007359  B80D00            mov ax,0xd
0000735C  50                push ax
0000735D  0E                push cs
0000735E  E85803            call 0x76b9
00007361  83C408            add sp,byte +0x8
00007364  8BE5              mov sp,bp
00007366  5D                pop bp
00007367  CB                retf
00007368  55                push bp
00007369  8BEC              mov bp,sp
0000736B  83EC02            sub sp,byte +0x2
0000736E  C746FE0000        mov word [bp-0x2],0x0
00007373  EB0B              jmp short 0x7380
00007375  8B5EFE            mov bx,[bp-0x2]
00007378  C68729357F        mov byte [bx+0x3529],0x7f
0000737D  FF46FE            inc word [bp-0x2]
00007380  837EFE12          cmp word [bp-0x2],byte +0x12
00007384  7CEF              jl 0x7375
00007386  8BE5              mov sp,bp
00007388  5D                pop bp
00007389  CB                retf
0000738A  55                push bp
0000738B  8BEC              mov bp,sp
0000738D  83EC0C            sub sp,byte +0xc
00007390  8B4608            mov ax,[bp+0x8]
00007393  BA6400            mov dx,0x64
00007396  F7E2              mul dx
00007398  99                cwd
00007399  8956FE            mov [bp-0x2],dx
0000739C  8946FC            mov [bp-0x4],ax
0000739F  8B4606            mov ax,[bp+0x6]
000073A2  BA0600            mov dx,0x6
000073A5  F7E2              mul dx
000073A7  99                cwd
000073A8  0346FC            add ax,[bp-0x4]
000073AB  1356FE            adc dx,[bp-0x2]
000073AE  33C9              xor cx,cx
000073B0  BB78CB            mov bx,0xcb78
000073B3  9A12040000        call 0x0:0x412
000073B8  8956F6            mov [bp-0xa],dx
000073BB  8946F4            mov [bp-0xc],ax
000073BE  8B56FE            mov dx,[bp-0x2]
000073C1  8B46FC            mov ax,[bp-0x4]
000073C4  33C9              xor cx,cx
000073C6  BB1900            mov bx,0x19
000073C9  9A12040000        call 0x0:0x412
000073CE  52                push dx
000073CF  50                push ax
000073D0  FF76F6            push word [bp-0xa]
000073D3  FF76F4            push word [bp-0xc]
000073D6  9A2B040000        call 0x0:0x42b
000073DB  8956F6            mov [bp-0xa],dx
000073DE  8946F4            mov [bp-0xc],ax
000073E1  8B56F6            mov dx,[bp-0xa]
000073E4  8B46F4            mov ax,[bp-0xc]
000073E7  B10E              mov cl,0xe
000073E9  9AEC040000        call 0x0:0x4ec
000073EE  8956FA            mov [bp-0x6],dx
000073F1  8946F8            mov [bp-0x8],ax
000073F4  8B56FA            mov dx,[bp-0x6]
000073F7  8B46F8            mov ax,[bp-0x8]
000073FA  33C9              xor cx,cx
000073FC  BB0900            mov bx,0x9
000073FF  9A12040000        call 0x0:0x412
00007404  8956FA            mov [bp-0x6],dx
00007407  8946F8            mov [bp-0x8],ax
0000740A  BA0100            mov dx,0x1
0000740D  B803B5            mov ax,0xb503
00007410  52                push dx
00007411  50                push ax
00007412  FF76FA            push word [bp-0x6]
00007415  FF76F8            push word [bp-0x8]
00007418  9A2B040000        call 0x0:0x42b
0000741D  8956FA            mov [bp-0x6],dx
00007420  8946F8            mov [bp-0x8],ax
00007423  8B56FA            mov dx,[bp-0x6]
00007426  8B46F8            mov ax,[bp-0x8]
00007429  EB00              jmp short 0x742b
0000742B  8BE5              mov sp,bp
0000742D  5D                pop bp
0000742E  CB                retf
0000742F  55                push bp
00007430  8BEC              mov bp,sp
00007432  83EC06            sub sp,byte +0x6
00007435  FF760C            push word [bp+0xc]
00007438  FF760A            push word [bp+0xa]
0000743B  0E                push cs
0000743C  E84BFF            call 0x738a
0000743F  59                pop cx
00007440  59                pop cx
00007441  8956FE            mov [bp-0x2],dx
00007444  8946FC            mov [bp-0x4],ax
00007447  050400            add ax,0x4
0000744A  D1E8              shr ax,1
0000744C  D1E8              shr ax,1
0000744E  D1E8              shr ax,1
00007450  C45E06            les bx,[bp+0x6]
00007453  268907            mov [es:bx],ax
00007456  83460602          add word [bp+0x6],byte +0x2
0000745A  C746FA0100        mov word [bp-0x6],0x1
0000745F  EB44              jmp short 0x74a5
00007461  8B56FE            mov dx,[bp-0x2]
00007464  8B46FC            mov ax,[bp-0x4]
00007467  33C9              xor cx,cx
00007469  BB6A00            mov bx,0x6a
0000746C  9A12040000        call 0x0:0x412
00007471  8956FE            mov [bp-0x2],dx
00007474  8946FC            mov [bp-0x4],ax
00007477  33D2              xor dx,dx
00007479  B86400            mov ax,0x64
0000747C  52                push dx
0000747D  50                push ax
0000747E  FF76FE            push word [bp-0x2]
00007481  FF76FC            push word [bp-0x4]
00007484  9A2B040000        call 0x0:0x42b
00007489  8956FE            mov [bp-0x2],dx
0000748C  8946FC            mov [bp-0x4],ax
0000748F  050400            add ax,0x4
00007492  D1E8              shr ax,1
00007494  D1E8              shr ax,1
00007496  D1E8              shr ax,1
00007498  C45E06            les bx,[bp+0x6]
0000749B  268907            mov [es:bx],ax
0000749E  83460602          add word [bp+0x6],byte +0x2
000074A2  FF46FA            inc word [bp-0x6]
000074A5  837EFA0C          cmp word [bp-0x6],byte +0xc
000074A9  7CB6              jl 0x7461
000074AB  8BE5              mov sp,bp
000074AD  5D                pop bp
000074AE  CB                retf
000074AF  55                push bp
000074B0  8BEC              mov bp,sp
000074B2  83EC0C            sub sp,byte +0xc
000074B5  C746FC0400        mov word [bp-0x4],0x4
000074BA  33C0              xor ax,ax
000074BC  8946FE            mov [bp-0x2],ax
000074BF  8946FA            mov [bp-0x6],ax
000074C2  EB24              jmp short 0x74e8
000074C4  B86400            mov ax,0x64
000074C7  50                push ax
000074C8  FF76FA            push word [bp-0x6]
000074CB  1E                push ds
000074CC  8B46FE            mov ax,[bp-0x2]
000074CF  BA1800            mov dx,0x18
000074D2  F7E2              mul dx
000074D4  059B31            add ax,0x319b
000074D7  50                push ax
000074D8  0E                push cs
000074D9  E853FF            call 0x742f
000074DC  83C408            add sp,byte +0x8
000074DF  FF46FE            inc word [bp-0x2]
000074E2  8B46FC            mov ax,[bp-0x4]
000074E5  0146FA            add [bp-0x6],ax
000074E8  837EFE19          cmp word [bp-0x2],byte +0x19
000074EC  72D6              jc 0x74c4
000074EE  C746F40000        mov word [bp-0xc],0x0
000074F3  EB1F              jmp short 0x7514
000074F5  8B5EF4            mov bx,[bp-0xc]
000074F8  D1E3              shl bx,1
000074FA  D1E3              shl bx,1
000074FC  8C9FFF34          mov [bx+0x34ff],ds
00007500  C787FD349B31      mov word [bx+0x34fd],0x319b
00007506  8B5EF4            mov bx,[bp-0xc]
00007509  D1E3              shl bx,1
0000750B  C7873D350000      mov word [bx+0x353d],0x0
00007511  FF46F4            inc word [bp-0xc]
00007514  837EF40B          cmp word [bp-0xc],byte +0xb
00007518  72DB              jc 0x74f5
0000751A  C746F80000        mov word [bp-0x8],0x0
0000751F  C746F40000        mov word [bp-0xc],0x0
00007524  EB2A              jmp short 0x7550
00007526  C746F60000        mov word [bp-0xa],0x0
0000752B  EB1A              jmp short 0x7547
0000752D  8A46F4            mov al,[bp-0xc]
00007530  8B5EF8            mov bx,[bp-0x8]
00007533  8887CA30          mov [bx+0x30ca],al
00007537  8A46F6            mov al,[bp-0xa]
0000753A  8B5EF8            mov bx,[bp-0x8]
0000753D  88872A31          mov [bx+0x312a],al
00007541  FF46F6            inc word [bp-0xa]
00007544  FF46F8            inc word [bp-0x8]
00007547  837EF60C          cmp word [bp-0xa],byte +0xc
0000754B  72E0              jc 0x752d
0000754D  FF46F4            inc word [bp-0xc]
00007550  837EF408          cmp word [bp-0xc],byte +0x8
00007554  72D0              jc 0x7526
00007556  8BE5              mov sp,bp
00007558  5D                pop bp
00007559  CB                retf
0000755A  55                push bp
0000755B  8BEC              mov bp,sp
0000755D  83EC0A            sub sp,byte +0xa
00007560  8B4608            mov ax,[bp+0x8]
00007563  0500E0            add ax,0xe000
00007566  99                cwd
00007567  52                push dx
00007568  50                push ax
00007569  A13B35            mov ax,[0x353b]
0000756C  99                cwd
0000756D  5B                pop bx
0000756E  59                pop cx
0000756F  9A12040000        call 0x0:0x412
00007574  8956FE            mov [bp-0x2],dx
00007577  8946FC            mov [bp-0x4],ax
0000757A  8B16042C          mov dx,[0x2c04]
0000757E  A1022C            mov ax,[0x2c02]
00007581  3B56FE            cmp dx,[bp-0x2]
00007584  752A              jnz 0x75b0
00007586  3B46FC            cmp ax,[bp-0x4]
00007589  7525              jnz 0x75b0
0000758B  8B16C830          mov dx,[0x30c8]
0000758F  A1C630            mov ax,[0x30c6]
00007592  8B5E06            mov bx,[bp+0x6]
00007595  D1E3              shl bx,1
00007597  D1E3              shl bx,1
00007599  8997FF34          mov [bx+0x34ff],dx
0000759D  8987FD34          mov [bx+0x34fd],ax
000075A1  A1C430            mov ax,[0x30c4]
000075A4  8B5E06            mov bx,[bp+0x6]
000075A7  D1E3              shl bx,1
000075A9  89873D35          mov [bx+0x353d],ax
000075AD  E9AC00            jmp 0x765c
000075B0  33D2              xor dx,dx
000075B2  B80020            mov ax,0x2000
000075B5  52                push dx
000075B6  50                push ax
000075B7  FF76FE            push word [bp-0x2]
000075BA  FF76FC            push word [bp-0x4]
000075BD  9A2B040000        call 0x0:0x42b
000075C2  8946F6            mov [bp-0xa],ax
000075C5  837EF600          cmp word [bp-0xa],byte +0x0
000075C9  7D40              jnl 0x760b
000075CB  B81800            mov ax,0x18
000075CE  2B46F6            sub ax,[bp-0xa]
000075D1  8946F8            mov [bp-0x8],ax
000075D4  8B46F8            mov ax,[bp-0x8]
000075D7  BB1900            mov bx,0x19
000075DA  99                cwd
000075DB  F7FB              idiv bx
000075DD  F7D8              neg ax
000075DF  8B5E06            mov bx,[bp+0x6]
000075E2  D1E3              shl bx,1
000075E4  89873D35          mov [bx+0x353d],ax
000075E8  A3C430            mov [0x30c4],ax
000075EB  8B46F8            mov ax,[bp-0x8]
000075EE  05E8FF            add ax,0xffe8
000075F1  BB1900            mov bx,0x19
000075F4  99                cwd
000075F5  F7FB              idiv bx
000075F7  8956FA            mov [bp-0x6],dx
000075FA  837EFA00          cmp word [bp-0x6],byte +0x0
000075FE  7409              jz 0x7609
00007600  B81900            mov ax,0x19
00007603  2B46FA            sub ax,[bp-0x6]
00007606  8946FA            mov [bp-0x6],ax
00007609  EB21              jmp short 0x762c
0000760B  8B46F6            mov ax,[bp-0xa]
0000760E  BB1900            mov bx,0x19
00007611  99                cwd
00007612  F7FB              idiv bx
00007614  8B5E06            mov bx,[bp+0x6]
00007617  D1E3              shl bx,1
00007619  89873D35          mov [bx+0x353d],ax
0000761D  A3C430            mov [0x30c4],ax
00007620  8B46F6            mov ax,[bp-0xa]
00007623  BB1900            mov bx,0x19
00007626  99                cwd
00007627  F7FB              idiv bx
00007629  8956FA            mov [bp-0x6],dx
0000762C  8B46FA            mov ax,[bp-0x6]
0000762F  BA1800            mov dx,0x18
00007632  F7E2              mul dx
00007634  059B31            add ax,0x319b
00007637  8CDA              mov dx,ds
00007639  8B5E06            mov bx,[bp+0x6]
0000763C  D1E3              shl bx,1
0000763E  D1E3              shl bx,1
00007640  8997FF34          mov [bx+0x34ff],dx
00007644  8987FD34          mov [bx+0x34fd],ax
00007648  8916C830          mov [0x30c8],dx
0000764C  A3C630            mov [0x30c6],ax
0000764F  8B56FE            mov dx,[bp-0x2]
00007652  8B46FC            mov ax,[bp-0x4]
00007655  8916042C          mov [0x2c04],dx
00007659  A3022C            mov [0x2c02],ax
0000765C  8BE5              mov sp,bp
0000765E  5D                pop bp
0000765F  CB                retf
00007660  55                push bp
00007661  8BEC              mov bp,sp
00007663  83EC06            sub sp,byte +0x6
00007666  C746FA0000        mov word [bp-0x6],0x0
0000766B  8B4606            mov ax,[bp+0x6]
0000766E  BA0E00            mov dx,0xe
00007671  F7E2              mul dx
00007673  8BD8              mov bx,ax
00007675  81C3F333          add bx,0x33f3
00007679  1E                push ds
0000767A  07                pop es
0000767B  8C46FE            mov [bp-0x2],es
0000767E  895EFC            mov [bp-0x4],bx
00007681  EB16              jmp short 0x7699
00007683  C45E08            les bx,[bp+0x8]
00007686  268A07            mov al,[es:bx]
00007689  C45EFC            les bx,[bp-0x4]
0000768C  268807            mov [es:bx],al
0000768F  83460802          add word [bp+0x8],byte +0x2
00007693  FF46FC            inc word [bp-0x4]
00007696  FF46FA            inc word [bp-0x6]
00007699  837EFA0D          cmp word [bp-0x6],byte +0xd
0000769D  7CE4              jl 0x7683
0000769F  81660C0300        and word [bp+0xc],0x3
000076A4  8B460C            mov ax,[bp+0xc]
000076A7  C45EFC            les bx,[bp-0x4]
000076AA  268807            mov [es:bx],al
000076AD  FF7606            push word [bp+0x6]
000076B0  0E                push cs
000076B1  E84900            call 0x76fd
000076B4  59                pop cx
000076B5  8BE5              mov sp,bp
000076B7  5D                pop bp
000076B8  CB                retf
000076B9  55                push bp
000076BA  8BEC              mov bp,sp
000076BC  83EC1E            sub sp,byte +0x1e
000076BF  C746FE0000        mov word [bp-0x2],0x0
000076C4  EB1B              jmp short 0x76e1
000076C6  C45E08            les bx,[bp+0x8]
000076C9  268A07            mov al,[es:bx]
000076CC  B400              mov ah,0x0
000076CE  8B5EFE            mov bx,[bp-0x2]
000076D1  D1E3              shl bx,1
000076D3  8D56E2            lea dx,[bp-0x1e]
000076D6  03DA              add bx,dx
000076D8  368907            mov [ss:bx],ax
000076DB  FF4608            inc word [bp+0x8]
000076DE  FF46FE            inc word [bp-0x2]
000076E1  837EFE0D          cmp word [bp-0x2],byte +0xd
000076E5  7CDF              jl 0x76c6
000076E7  FF760C            push word [bp+0xc]
000076EA  16                push ss
000076EB  8D46E2            lea ax,[bp-0x1e]
000076EE  50                push ax
000076EF  FF7606            push word [bp+0x6]
000076F2  0E                push cs
000076F3  E86AFF            call 0x7660
000076F6  83C408            add sp,byte +0x8
000076F9  8BE5              mov sp,bp
000076FB  5D                pop bp
000076FC  CB                retf
000076FD  55                push bp
000076FE  8BEC              mov bp,sp
00007700  0E                push cs
00007701  E8BB02            call 0x79bf
00007704  0E                push cs
00007705  E8BA00            call 0x77c2
00007708  FF7606            push word [bp+0x6]
0000770B  0E                push cs
0000770C  E82B00            call 0x773a
0000770F  59                pop cx
00007710  FF7606            push word [bp+0x6]
00007713  0E                push cs
00007714  E8CA00            call 0x77e1
00007717  59                pop cx
00007718  FF7606            push word [bp+0x6]
0000771B  0E                push cs
0000771C  E82B01            call 0x784a
0000771F  59                pop cx
00007720  FF7606            push word [bp+0x6]
00007723  0E                push cs
00007724  E87D01            call 0x78a4
00007727  59                pop cx
00007728  FF7606            push word [bp+0x6]
0000772B  0E                push cs
0000772C  E8CF01            call 0x78fe
0000772F  59                pop cx
00007730  FF7606            push word [bp+0x6]
00007733  0E                push cs
00007734  E8DB02            call 0x7a12
00007737  59                pop cx
00007738  5D                pop bp
00007739  CB                retf
0000773A  55                push bp
0000773B  8BEC              mov bp,sp
0000773D  83EC02            sub sp,byte +0x2
00007740  8B4606            mov ax,[bp+0x6]
00007743  BA0E00            mov dx,0xe
00007746  F7E2              mul dx
00007748  8BD8              mov bx,ax
0000774A  81C3F333          add bx,0x33f3
0000774E  1E                push ds
0000774F  07                pop es
00007750  268A4708          mov al,[es:bx+0x8]
00007754  B400              mov ah,0x0
00007756  253F00            and ax,0x3f
00007759  BA3F00            mov dx,0x3f
0000775C  2BD0              sub dx,ax
0000775E  8956FE            mov [bp-0x2],dx
00007761  8B5E06            mov bx,[bp+0x6]
00007764  8A872935          mov al,[bx+0x3529]
00007768  B400              mov ah,0x0
0000776A  F766FE            mul word [bp-0x2]
0000776D  8946FE            mov [bp-0x2],ax
00007770  8B46FE            mov ax,[bp-0x2]
00007773  057F00            add ax,0x7f
00007776  0146FE            add [bp-0x2],ax
00007779  8B46FE            mov ax,[bp-0x2]
0000777C  BBFE00            mov bx,0xfe
0000777F  33D2              xor dx,dx
00007781  F7F3              div bx
00007783  BA3F00            mov dx,0x3f
00007786  2BD0              sub dx,ax
00007788  8956FE            mov [bp-0x2],dx
0000778B  8B4606            mov ax,[bp+0x6]
0000778E  BA0E00            mov dx,0xe
00007791  F7E2              mul dx
00007793  8BD8              mov bx,ax
00007795  81C3F333          add bx,0x33f3
00007799  1E                push ds
0000779A  07                pop es
0000779B  268A07            mov al,[es:bx]
0000779E  B400              mov ah,0x0
000077A0  B106              mov cl,0x6
000077A2  D3E0              shl ax,cl
000077A4  0946FE            or [bp-0x2],ax
000077A7  FF76FE            push word [bp-0x2]
000077AA  8B5E06            mov bx,[bp+0x6]
000077AD  8A87CC2B          mov al,[bx+0x2bcc]
000077B1  B400              mov ah,0x0
000077B3  054000            add ax,0x40
000077B6  50                push ax
000077B7  9A04006809        call 0x968:0x4
000077BC  59                pop cx
000077BD  59                pop cx
000077BE  8BE5              mov sp,bp
000077C0  5D                pop bp
000077C1  CB                retf
000077C2  55                push bp
000077C3  8BEC              mov bp,sp
000077C5  803E8B3100        cmp byte [0x318b],0x0
000077CA  7405              jz 0x77d1
000077CC  B84000            mov ax,0x40
000077CF  EB02              jmp short 0x77d3
000077D1  33C0              xor ax,ax
000077D3  50                push ax
000077D4  B80800            mov ax,0x8
000077D7  50                push ax
000077D8  9A04006809        call 0x968:0x4
000077DD  59                pop cx
000077DE  59                pop cx
000077DF  5D                pop bp
000077E0  CB                retf
000077E1  55                push bp
000077E2  8BEC              mov bp,sp
000077E4  83EC02            sub sp,byte +0x2
000077E7  8B5E06            mov bx,[bp+0x6]
000077EA  80BFDE2B00        cmp byte [bx+0x2bde],0x0
000077EF  7402              jz 0x77f3
000077F1  EB53              jmp short 0x7846
000077F3  8B4606            mov ax,[bp+0x6]
000077F6  BA0E00            mov dx,0xe
000077F9  F7E2              mul dx
000077FB  8BD8              mov bx,ax
000077FD  81C3F333          add bx,0x33f3
00007801  1E                push ds
00007802  07                pop es
00007803  268A4702          mov al,[es:bx+0x2]
00007807  B400              mov ah,0x0
00007809  D1E0              shl ax,1
0000780B  8946FE            mov [bp-0x2],ax
0000780E  8B4606            mov ax,[bp+0x6]
00007811  BA0E00            mov dx,0xe
00007814  F7E2              mul dx
00007816  8BD8              mov bx,ax
00007818  81C3F333          add bx,0x33f3
0000781C  1E                push ds
0000781D  07                pop es
0000781E  26807F0C00        cmp byte [es:bx+0xc],0x0
00007823  7404              jz 0x7829
00007825  33C0              xor ax,ax
00007827  EB03              jmp short 0x782c
00007829  B80100            mov ax,0x1
0000782C  0946FE            or [bp-0x2],ax
0000782F  FF76FE            push word [bp-0x2]
00007832  8B5E06            mov bx,[bp+0x6]
00007835  8A87F02B          mov al,[bx+0x2bf0]
00007839  B400              mov ah,0x0
0000783B  05C000            add ax,0xc0
0000783E  50                push ax
0000783F  9A04006809        call 0x968:0x4
00007844  59                pop cx
00007845  59                pop cx
00007846  8BE5              mov sp,bp
00007848  5D                pop bp
00007849  CB                retf
0000784A  55                push bp
0000784B  8BEC              mov bp,sp
0000784D  83EC02            sub sp,byte +0x2
00007850  8B4606            mov ax,[bp+0x6]
00007853  BA0E00            mov dx,0xe
00007856  F7E2              mul dx
00007858  8BD8              mov bx,ax
0000785A  81C3F333          add bx,0x33f3
0000785E  1E                push ds
0000785F  07                pop es
00007860  268A4703          mov al,[es:bx+0x3]
00007864  B400              mov ah,0x0
00007866  B104              mov cl,0x4
00007868  D3E0              shl ax,cl
0000786A  8946FE            mov [bp-0x2],ax
0000786D  8B4606            mov ax,[bp+0x6]
00007870  BA0E00            mov dx,0xe
00007873  F7E2              mul dx
00007875  8BD8              mov bx,ax
00007877  81C3F333          add bx,0x33f3
0000787B  1E                push ds
0000787C  07                pop es
0000787D  268A4706          mov al,[es:bx+0x6]
00007881  B400              mov ah,0x0
00007883  250F00            and ax,0xf
00007886  0946FE            or [bp-0x2],ax
00007889  FF76FE            push word [bp-0x2]
0000788C  8B5E06            mov bx,[bp+0x6]
0000788F  8A87CC2B          mov al,[bx+0x2bcc]
00007893  B400              mov ah,0x0
00007895  056000            add ax,0x60
00007898  50                push ax
00007899  9A04006809        call 0x968:0x4
0000789E  59                pop cx
0000789F  59                pop cx
000078A0  8BE5              mov sp,bp
000078A2  5D                pop bp
000078A3  CB                retf
000078A4  55                push bp
000078A5  8BEC              mov bp,sp
000078A7  83EC02            sub sp,byte +0x2
000078AA  8B4606            mov ax,[bp+0x6]
000078AD  BA0E00            mov dx,0xe
000078B0  F7E2              mul dx
000078B2  8BD8              mov bx,ax
000078B4  81C3F333          add bx,0x33f3
000078B8  1E                push ds
000078B9  07                pop es
000078BA  268A4704          mov al,[es:bx+0x4]
000078BE  B400              mov ah,0x0
000078C0  B104              mov cl,0x4
000078C2  D3E0              shl ax,cl
000078C4  8946FE            mov [bp-0x2],ax
000078C7  8B4606            mov ax,[bp+0x6]
000078CA  BA0E00            mov dx,0xe
000078CD  F7E2              mul dx
000078CF  8BD8              mov bx,ax
000078D1  81C3F333          add bx,0x33f3
000078D5  1E                push ds
000078D6  07                pop es
000078D7  268A4707          mov al,[es:bx+0x7]
000078DB  B400              mov ah,0x0
000078DD  250F00            and ax,0xf
000078E0  0946FE            or [bp-0x2],ax
000078E3  FF76FE            push word [bp-0x2]
000078E6  8B5E06            mov bx,[bp+0x6]
000078E9  8A87CC2B          mov al,[bx+0x2bcc]
000078ED  B400              mov ah,0x0
000078EF  058000            add ax,0x80
000078F2  50                push ax
000078F3  9A04006809        call 0x968:0x4
000078F8  59                pop cx
000078F9  59                pop cx
000078FA  8BE5              mov sp,bp
000078FC  5D                pop bp
000078FD  CB                retf
000078FE  55                push bp
000078FF  8BEC              mov bp,sp
00007901  83EC02            sub sp,byte +0x2
00007904  8B4606            mov ax,[bp+0x6]
00007907  BA0E00            mov dx,0xe
0000790A  F7E2              mul dx
0000790C  8BD8              mov bx,ax
0000790E  81C3F333          add bx,0x33f3
00007912  1E                push ds
00007913  07                pop es
00007914  26807F0900        cmp byte [es:bx+0x9],0x0
00007919  7405              jz 0x7920
0000791B  B88000            mov ax,0x80
0000791E  EB02              jmp short 0x7922
00007920  33C0              xor ax,ax
00007922  8946FE            mov [bp-0x2],ax
00007925  8B4606            mov ax,[bp+0x6]
00007928  BA0E00            mov dx,0xe
0000792B  F7E2              mul dx
0000792D  8BD8              mov bx,ax
0000792F  81C3F333          add bx,0x33f3
00007933  1E                push ds
00007934  07                pop es
00007935  26807F0A00        cmp byte [es:bx+0xa],0x0
0000793A  7405              jz 0x7941
0000793C  B84000            mov ax,0x40
0000793F  EB02              jmp short 0x7943
00007941  33C0              xor ax,ax
00007943  0146FE            add [bp-0x2],ax
00007946  8B4606            mov ax,[bp+0x6]
00007949  BA0E00            mov dx,0xe
0000794C  F7E2              mul dx
0000794E  8BD8              mov bx,ax
00007950  81C3F333          add bx,0x33f3
00007954  1E                push ds
00007955  07                pop es
00007956  26807F0500        cmp byte [es:bx+0x5],0x0
0000795B  7405              jz 0x7962
0000795D  B82000            mov ax,0x20
00007960  EB02              jmp short 0x7964
00007962  33C0              xor ax,ax
00007964  0146FE            add [bp-0x2],ax
00007967  8B4606            mov ax,[bp+0x6]
0000796A  BA0E00            mov dx,0xe
0000796D  F7E2              mul dx
0000796F  8BD8              mov bx,ax
00007971  81C3F333          add bx,0x33f3
00007975  1E                push ds
00007976  07                pop es
00007977  26807F0B00        cmp byte [es:bx+0xb],0x0
0000797C  7405              jz 0x7983
0000797E  B81000            mov ax,0x10
00007981  EB02              jmp short 0x7985
00007983  33C0              xor ax,ax
00007985  0146FE            add [bp-0x2],ax
00007988  8B4606            mov ax,[bp+0x6]
0000798B  BA0E00            mov dx,0xe
0000798E  F7E2              mul dx
00007990  8BD8              mov bx,ax
00007992  81C3F333          add bx,0x33f3
00007996  1E                push ds
00007997  07                pop es
00007998  268A4701          mov al,[es:bx+0x1]
0000799C  B400              mov ah,0x0
0000799E  250F00            and ax,0xf
000079A1  0146FE            add [bp-0x2],ax
000079A4  FF76FE            push word [bp-0x2]
000079A7  8B5E06            mov bx,[bp+0x6]
000079AA  8A87CC2B          mov al,[bx+0x2bcc]
000079AE  B400              mov ah,0x0
000079B0  052000            add ax,0x20
000079B3  50                push ax
000079B4  9A04006809        call 0x968:0x4
000079B9  59                pop cx
000079BA  59                pop cx
000079BB  8BE5              mov sp,bp
000079BD  5D                pop bp
000079BE  CB                retf
000079BF  55                push bp
000079C0  8BEC              mov bp,sp
000079C2  83EC02            sub sp,byte +0x2
000079C5  803E8A3100        cmp byte [0x318a],0x0
000079CA  7405              jz 0x79d1
000079CC  B88000            mov ax,0x80
000079CF  EB02              jmp short 0x79d3
000079D1  33C0              xor ax,ax
000079D3  8946FE            mov [bp-0x2],ax
000079D6  803E8C3100        cmp byte [0x318c],0x0
000079DB  7405              jz 0x79e2
000079DD  B84000            mov ax,0x40
000079E0  EB02              jmp short 0x79e4
000079E2  33C0              xor ax,ax
000079E4  0946FE            or [bp-0x2],ax
000079E7  803EEF3400        cmp byte [0x34ef],0x0
000079EC  7405              jz 0x79f3
000079EE  B82000            mov ax,0x20
000079F1  EB02              jmp short 0x79f5
000079F3  33C0              xor ax,ax
000079F5  0946FE            or [bp-0x2],ax
000079F8  A09831            mov al,[0x3198]
000079FB  B400              mov ah,0x0
000079FD  0946FE            or [bp-0x2],ax
00007A00  FF76FE            push word [bp-0x2]
00007A03  B8BD00            mov ax,0xbd
00007A06  50                push ax
00007A07  9A04006809        call 0x968:0x4
00007A0C  59                pop cx
00007A0D  59                pop cx
00007A0E  8BE5              mov sp,bp
00007A10  5D                pop bp
00007A11  CB                retf
00007A12  55                push bp
00007A13  8BEC              mov bp,sp
00007A15  83EC02            sub sp,byte +0x2
00007A18  833EFB3400        cmp word [0x34fb],byte +0x0
00007A1D  741E              jz 0x7a3d
00007A1F  8B4606            mov ax,[bp+0x6]
00007A22  BA0E00            mov dx,0xe
00007A25  F7E2              mul dx
00007A27  8BD8              mov bx,ax
00007A29  81C3F333          add bx,0x33f3
00007A2D  1E                push ds
00007A2E  07                pop es
00007A2F  268A470D          mov al,[es:bx+0xd]
00007A33  B400              mov ah,0x0
00007A35  250300            and ax,0x3
00007A38  8946FE            mov [bp-0x2],ax
00007A3B  EB05              jmp short 0x7a42
00007A3D  C746FE0000        mov word [bp-0x2],0x0
00007A42  FF76FE            push word [bp-0x2]
00007A45  8B5E06            mov bx,[bp+0x6]
00007A48  8A87CC2B          mov al,[bx+0x2bcc]
00007A4C  B400              mov ah,0x0
00007A4E  05E000            add ax,0xe0
00007A51  50                push ax
00007A52  9A04006809        call 0x968:0x4
00007A57  59                pop cx
00007A58  59                pop cx
00007A59  8BE5              mov sp,bp
00007A5B  5D                pop bp
00007A5C  CB                retf
00007A5D  55                push bp
00007A5E  8BEC              mov bp,sp
00007A60  83EC04            sub sp,byte +0x4
00007A63  8A460A            mov al,[bp+0xa]
00007A66  8B5E06            mov bx,[bp+0x6]
00007A69  8887F034          mov [bx+0x34f0],al
00007A6D  8A4608            mov al,[bp+0x8]
00007A70  8B5E06            mov bx,[bp+0x6]
00007A73  88878D31          mov [bx+0x318d],al
00007A77  8B5E06            mov bx,[bp+0x6]
00007A7A  D1E3              shl bx,1
00007A7C  8B873D35          mov ax,[bx+0x353d]
00007A80  014608            add [bp+0x8],ax
00007A83  837E085F          cmp word [bp+0x8],byte +0x5f
00007A87  7E05              jng 0x7a8e
00007A89  C746085F00        mov word [bp+0x8],0x5f
00007A8E  837E0800          cmp word [bp+0x8],byte +0x0
00007A92  7D05              jnl 0x7a99
00007A94  C746080000        mov word [bp+0x8],0x0
00007A99  8B5E06            mov bx,[bp+0x6]
00007A9C  D1E3              shl bx,1
00007A9E  D1E3              shl bx,1
00007AA0  C49FFD34          les bx,[bx+0x34fd]
00007AA4  06                push es
00007AA5  53                push bx
00007AA6  8B5E08            mov bx,[bp+0x8]
00007AA9  8A872A31          mov al,[bx+0x312a]
00007AAD  B400              mov ah,0x0
00007AAF  D1E0              shl ax,1
00007AB1  5B                pop bx
00007AB2  07                pop es
00007AB3  03D8              add bx,ax
00007AB5  268B07            mov ax,[es:bx]
00007AB8  8946FC            mov [bp-0x4],ax
00007ABB  FF76FC            push word [bp-0x4]
00007ABE  8B4606            mov ax,[bp+0x6]
00007AC1  05A000            add ax,0xa0
00007AC4  50                push ax
00007AC5  9A04006809        call 0x968:0x4
00007ACA  59                pop cx
00007ACB  59                pop cx
00007ACC  837E0A00          cmp word [bp+0xa],byte +0x0
00007AD0  7405              jz 0x7ad7
00007AD2  B82000            mov ax,0x20
00007AD5  EB02              jmp short 0x7ad9
00007AD7  33C0              xor ax,ax
00007AD9  8946FE            mov [bp-0x2],ax
00007ADC  8B5E08            mov bx,[bp+0x8]
00007ADF  8A87CA30          mov al,[bx+0x30ca]
00007AE3  B400              mov ah,0x0
00007AE5  D1E0              shl ax,1
00007AE7  D1E0              shl ax,1
00007AE9  8A56FD            mov dl,[bp-0x3]
00007AEC  B600              mov dh,0x0
00007AEE  81E20300          and dx,0x3
00007AF2  03C2              add ax,dx
00007AF4  0146FE            add [bp-0x2],ax
00007AF7  FF76FE            push word [bp-0x2]
00007AFA  8B4606            mov ax,[bp+0x6]
00007AFD  05B000            add ax,0xb0
00007B00  50                push ax
00007B01  9A04006809        call 0x968:0x4
00007B06  59                pop cx
00007B07  59                pop cx
00007B08  8BE5              mov sp,bp
00007B0A  5D                pop bp
00007B0B  CB                retf
00007B0C  55                push bp
00007B0D  8BEC              mov bp,sp
00007B0F  33C0              xor ax,ax
00007B11  50                push ax
00007B12  8B4606            mov ax,[bp+0x6]
00007B15  05A000            add ax,0xa0
00007B18  50                push ax
00007B19  9A04006809        call 0x968:0x4
00007B1E  8BE5              mov sp,bp
00007B20  33C0              xor ax,ax
00007B22  50                push ax
00007B23  8B4606            mov ax,[bp+0x6]
00007B26  05B000            add ax,0xb0
00007B29  50                push ax
00007B2A  9A04006809        call 0x968:0x4
00007B2F  8BE5              mov sp,bp
00007B31  5D                pop bp
00007B32  CB                retf
00007B33  55                push bp
00007B34  8BEC              mov bp,sp
00007B36  83EC06            sub sp,byte +0x6
00007B39  B86000            mov ax,0x60
00007B3C  50                push ax
00007B3D  B80400            mov ax,0x4
00007B40  50                push ax
00007B41  9A04006809        call 0x968:0x4
00007B46  59                pop cx
00007B47  59                pop cx
00007B48  B88000            mov ax,0x80
00007B4B  50                push ax
00007B4C  B80400            mov ax,0x4
00007B4F  50                push ax
00007B50  9A04006809        call 0x968:0x4
00007B55  59                pop cx
00007B56  59                pop cx
00007B57  BA8803            mov dx,0x388
00007B5A  EC                in al,dx
00007B5B  B400              mov ah,0x0
00007B5D  8946FA            mov [bp-0x6],ax
00007B60  B8FF00            mov ax,0xff
00007B63  50                push ax
00007B64  B80200            mov ax,0x2
00007B67  50                push ax
00007B68  9A04006809        call 0x968:0x4
00007B6D  59                pop cx
00007B6E  59                pop cx
00007B6F  B82100            mov ax,0x21
00007B72  50                push ax
00007B73  B80400            mov ax,0x4
00007B76  50                push ax
00007B77  9A04006809        call 0x968:0x4
00007B7C  59                pop cx
00007B7D  59                pop cx
00007B7E  C746FE0000        mov word [bp-0x2],0x0
00007B83  EB07              jmp short 0x7b8c
00007B85  BA8803            mov dx,0x388
00007B88  EC                in al,dx
00007B89  FF46FE            inc word [bp-0x2]
00007B8C  817EFEC800        cmp word [bp-0x2],0xc8
00007B91  72F2              jc 0x7b85
00007B93  BA8803            mov dx,0x388
00007B96  EC                in al,dx
00007B97  B400              mov ah,0x0
00007B99  8946FC            mov [bp-0x4],ax
00007B9C  B86000            mov ax,0x60
00007B9F  50                push ax
00007BA0  B80400            mov ax,0x4
00007BA3  50                push ax
00007BA4  9A04006809        call 0x968:0x4
00007BA9  59                pop cx
00007BAA  59                pop cx
00007BAB  B88000            mov ax,0x80
00007BAE  50                push ax
00007BAF  B80400            mov ax,0x4
00007BB2  50                push ax
00007BB3  9A04006809        call 0x968:0x4
00007BB8  59                pop cx
00007BB9  59                pop cx
00007BBA  F746FAE000        test word [bp-0x6],0xe0
00007BBF  7510              jnz 0x7bd1
00007BC1  8B46FC            mov ax,[bp-0x4]
00007BC4  25E000            and ax,0xe0
00007BC7  3DC000            cmp ax,0xc0
00007BCA  7505              jnz 0x7bd1
00007BCC  B80100            mov ax,0x1
00007BCF  EB02              jmp short 0x7bd3
00007BD1  33C0              xor ax,ax
00007BD3  EB00              jmp short 0x7bd5
00007BD5  8BE5              mov sp,bp
00007BD7  5D                pop bp
00007BD8  CB                retf
00007BD9  55                push bp
00007BDA  8BEC              mov bp,sp
00007BDC  0E                push cs
00007BDD  E853FF            call 0x7b33
00007BE0  0BC0              or ax,ax
00007BE2  7407              jz 0x7beb
00007BE4  C6060A2B01        mov byte [0x2b0a],0x1
00007BE9  EB05              jmp short 0x7bf0
00007BEB  C6060A2B00        mov byte [0x2b0a],0x0
00007BF0  803E0A2B00        cmp byte [0x2b0a],0x0
00007BF5  7405              jz 0x7bfc
00007BF7  9A63090508        call 0x805:0x963
00007BFC  A00A2B            mov al,[0x2b0a]
00007BFF  EB00              jmp short 0x7c01
00007C01  5D                pop bp
00007C02  CB                retf
00007C03  55                push bp
00007C04  8BEC              mov bp,sp
00007C06  83EC02            sub sp,byte +0x2
00007C09  0E                push cs
00007C0A  E85BF7            call 0x7368
00007C0D  0E                push cs
00007C0E  E89EF8            call 0x74af
00007C11  33C0              xor ax,ax
00007C13  50                push ax
00007C14  9ABB090508        call 0x805:0x9bb
00007C19  59                pop cx
00007C1A  33C0              xor ax,ax
00007C1C  50                push ax
00007C1D  33C0              xor ax,ax
00007C1F  50                push ax
00007C20  33C0              xor ax,ax
00007C22  50                push ax
00007C23  9A920A0508        call 0x805:0xa92
00007C28  83C406            add sp,byte +0x6
00007C2B  C746FE0000        mov word [bp-0x2],0x0
00007C30  EB0B              jmp short 0x7c3d
00007C32  FF76FE            push word [bp-0x2]
00007C35  0E                push cs
00007C36  E8D3FE            call 0x7b0c
00007C39  59                pop cx
00007C3A  FF46FE            inc word [bp-0x2]
00007C3D  837EFE09          cmp word [bp-0x2],byte +0x9
00007C41  7CEF              jl 0x7c32
00007C43  B80100            mov ax,0x1
00007C46  50                push ax
00007C47  9A660A0508        call 0x805:0xa66
00007C4C  59                pop cx
00007C4D  B80100            mov ax,0x1
00007C50  50                push ax
00007C51  9A160A0508        call 0x805:0xa16
00007C56  59                pop cx
00007C57  8BE5              mov sp,bp
00007C59  5D                pop bp
00007C5A  CB                retf
00007C5B  55                push bp
00007C5C  8BEC              mov bp,sp
00007C5E  837E0600          cmp word [bp+0x6],byte +0x0
00007C62  743D              jz 0x7ca1
00007C64  B80600            mov ax,0x6
00007C67  50                push ax
00007C68  0E                push cs
00007C69  E8A0FE            call 0x7b0c
00007C6C  59                pop cx
00007C6D  B80700            mov ax,0x7
00007C70  50                push ax
00007C71  0E                push cs
00007C72  E897FE            call 0x7b0c
00007C75  59                pop cx
00007C76  B80800            mov ax,0x8
00007C79  50                push ax
00007C7A  0E                push cs
00007C7B  E88EFE            call 0x7b0c
00007C7E  59                pop cx
00007C7F  33C0              xor ax,ax
00007C81  50                push ax
00007C82  B81800            mov ax,0x18
00007C85  50                push ax
00007C86  B80800            mov ax,0x8
00007C89  50                push ax
00007C8A  0E                push cs
00007C8B  E8CFFD            call 0x7a5d
00007C8E  8BE5              mov sp,bp
00007C90  33C0              xor ax,ax
00007C92  50                push ax
00007C93  B81F00            mov ax,0x1f
00007C96  50                push ax
00007C97  B80700            mov ax,0x7
00007C9A  50                push ax
00007C9B  0E                push cs
00007C9C  E8BEFD            call 0x7a5d
00007C9F  8BE5              mov sp,bp
00007CA1  8A4606            mov al,[bp+0x6]
00007CA4  A2EF34            mov [0x34ef],al
00007CA7  C606983100        mov byte [0x3198],0x0
00007CAC  0E                push cs
00007CAD  E8F5F5            call 0x72a5
00007CB0  0E                push cs
00007CB1  E80BFD            call 0x79bf
00007CB4  5D                pop bp
00007CB5  CB                retf
00007CB6  55                push bp
00007CB7  8BEC              mov bp,sp
00007CB9  83EC02            sub sp,byte +0x2
00007CBC  837E0600          cmp word [bp+0x6],byte +0x0
00007CC0  7405              jz 0x7cc7
00007CC2  B82000            mov ax,0x20
00007CC5  EB02              jmp short 0x7cc9
00007CC7  33C0              xor ax,ax
00007CC9  A3FB34            mov [0x34fb],ax
00007CCC  C746FE0000        mov word [bp-0x2],0x0
00007CD1  EB1A              jmp short 0x7ced
00007CD3  33C0              xor ax,ax
00007CD5  50                push ax
00007CD6  8B5EFE            mov bx,[bp-0x2]
00007CD9  8A87CC2B          mov al,[bx+0x2bcc]
00007CDD  B400              mov ah,0x0
00007CDF  05E000            add ax,0xe0
00007CE2  50                push ax
00007CE3  9A04006809        call 0x968:0x4
00007CE8  59                pop cx
00007CE9  59                pop cx
00007CEA  FF46FE            inc word [bp-0x2]
00007CED  837EFE12          cmp word [bp-0x2],byte +0x12
00007CF1  7CE0              jl 0x7cd3
00007CF3  FF36FB34          push word [0x34fb]
00007CF7  B80100            mov ax,0x1
00007CFA  50                push ax
00007CFB  9A04006809        call 0x968:0x4
00007D00  59                pop cx
00007D01  59                pop cx
00007D02  8BE5              mov sp,bp
00007D04  5D                pop bp
00007D05  CB                retf
00007D06  55                push bp
00007D07  8BEC              mov bp,sp
00007D09  837E060C          cmp word [bp+0x6],byte +0xc
00007D0D  7E05              jng 0x7d14
00007D0F  C746060C00        mov word [bp+0x6],0xc
00007D14  837E0601          cmp word [bp+0x6],byte +0x1
00007D18  7D05              jnl 0x7d1f
00007D1A  C746060100        mov word [bp+0x6],0x1
00007D1F  8B4606            mov ax,[bp+0x6]
00007D22  A39931            mov [0x3199],ax
00007D25  A19931            mov ax,[0x3199]
00007D28  BA1900            mov dx,0x19
00007D2B  F7E2              mul dx
00007D2D  A33B35            mov [0x353b],ax
00007D30  5D                pop bp
00007D31  CB                retf
00007D32  55                push bp
00007D33  8BEC              mov bp,sp
00007D35  8A4606            mov al,[bp+0x6]
00007D38  A28A31            mov [0x318a],al
00007D3B  8A4608            mov al,[bp+0x8]
00007D3E  A28C31            mov [0x318c],al
00007D41  8A460A            mov al,[bp+0xa]
00007D44  A28B31            mov [0x318b],al
00007D47  0E                push cs
00007D48  E874FC            call 0x79bf
00007D4B  0E                push cs
00007D4C  E873FA            call 0x77c2
00007D4F  5D                pop bp
00007D50  CB                retf
00007D51  55                push bp
00007D52  8BEC              mov bp,sp
00007D54  83EC0C            sub sp,byte +0xc
00007D57  C45E08            les bx,[bp+0x8]
00007D5A  83C334            add bx,byte +0x34
00007D5D  8C46FE            mov [bp-0x2],es
00007D60  895EFC            mov [bp-0x4],bx
00007D63  C45EFC            les bx,[bp-0x4]
00007D66  268B07            mov ax,[es:bx]
00007D69  8946F4            mov [bp-0xc],ax
00007D6C  8346FC02          add word [bp-0x4],byte +0x2
00007D70  C45EFC            les bx,[bp-0x4]
00007D73  268B07            mov ax,[es:bx]
00007D76  8946F6            mov [bp-0xa],ax
00007D79  C45E08            les bx,[bp+0x8]
00007D7C  83C31A            add bx,byte +0x1a
00007D7F  8C46FA            mov [bp-0x6],es
00007D82  895EF8            mov [bp-0x8],bx
00007D85  803EEF3400        cmp byte [0x34ef],0x0
00007D8A  7406              jz 0x7d92
00007D8C  837E0606          cmp word [bp+0x6],byte +0x6
00007D90  7D45              jnl 0x7dd7
00007D92  FF76F4            push word [bp-0xc]
00007D95  FF760A            push word [bp+0xa]
00007D98  FF7608            push word [bp+0x8]
00007D9B  8B5E06            mov bx,[bp+0x6]
00007D9E  D1E3              shl bx,1
00007DA0  81C3B02B          add bx,0x2bb0
00007DA4  1E                push ds
00007DA5  07                pop es
00007DA6  268A07            mov al,[es:bx]
00007DA9  B400              mov ah,0x0
00007DAB  50                push ax
00007DAC  0E                push cs
00007DAD  E8B0F8            call 0x7660
00007DB0  83C408            add sp,byte +0x8
00007DB3  FF76F6            push word [bp-0xa]
00007DB6  FF76FA            push word [bp-0x6]
00007DB9  FF76F8            push word [bp-0x8]
00007DBC  8B5E06            mov bx,[bp+0x6]
00007DBF  D1E3              shl bx,1
00007DC1  81C3B02B          add bx,0x2bb0
00007DC5  1E                push ds
00007DC6  07                pop es
00007DC7  268A4701          mov al,[es:bx+0x1]
00007DCB  B400              mov ah,0x0
00007DCD  50                push ax
00007DCE  0E                push cs
00007DCF  E88EF8            call 0x7660
00007DD2  83C408            add sp,byte +0x8
00007DD5  EB58              jmp short 0x7e2f
00007DD7  837E0606          cmp word [bp+0x6],byte +0x6
00007DDB  752E              jnz 0x7e0b
00007DDD  FF76F4            push word [bp-0xc]
00007DE0  FF760A            push word [bp+0xa]
00007DE3  FF7608            push word [bp+0x8]
00007DE6  A0C22B            mov al,[0x2bc2]
00007DE9  B400              mov ah,0x0
00007DEB  50                push ax
00007DEC  0E                push cs
00007DED  E870F8            call 0x7660
00007DF0  83C408            add sp,byte +0x8
00007DF3  FF76F6            push word [bp-0xa]
00007DF6  FF76FA            push word [bp-0x6]
00007DF9  FF76F8            push word [bp-0x8]
00007DFC  A0C32B            mov al,[0x2bc3]
00007DFF  B400              mov ah,0x0
00007E01  50                push ax
00007E02  0E                push cs
00007E03  E85AF8            call 0x7660
00007E06  83C408            add sp,byte +0x8
00007E09  EB24              jmp short 0x7e2f
00007E0B  FF76F4            push word [bp-0xc]
00007E0E  FF760A            push word [bp+0xa]
00007E11  FF7608            push word [bp+0x8]
00007E14  8B5E06            mov bx,[bp+0x6]
00007E17  83C3FA            add bx,byte -0x6
00007E1A  D1E3              shl bx,1
00007E1C  81C3C22B          add bx,0x2bc2
00007E20  1E                push ds
00007E21  07                pop es
00007E22  268A07            mov al,[es:bx]
00007E25  B400              mov ah,0x0
00007E27  50                push ax
00007E28  0E                push cs
00007E29  E834F8            call 0x7660
00007E2C  83C408            add sp,byte +0x8
00007E2F  8BE5              mov sp,bp
00007E31  5D                pop bp
00007E32  CB                retf
00007E33  55                push bp
00007E34  8BEC              mov bp,sp
00007E36  83EC02            sub sp,byte +0x2
00007E39  803EEF3400        cmp byte [0x34ef],0x0
00007E3E  7406              jz 0x7e46
00007E40  837E0606          cmp word [bp+0x6],byte +0x6
00007E44  7D16              jnl 0x7e5c
00007E46  8B5E06            mov bx,[bp+0x6]
00007E49  D1E3              shl bx,1
00007E4B  81C3B02B          add bx,0x2bb0
00007E4F  1E                push ds
00007E50  07                pop es
00007E51  268A4701          mov al,[es:bx+0x1]
00007E55  B400              mov ah,0x0
00007E57  8946FE            mov [bp-0x2],ax
00007E5A  EB29              jmp short 0x7e85
00007E5C  8B5E06            mov bx,[bp+0x6]
00007E5F  83C3FA            add bx,byte -0x6
00007E62  D1E3              shl bx,1
00007E64  81C3C22B          add bx,0x2bc2
00007E68  1E                push ds
00007E69  07                pop es
00007E6A  06                push es
00007E6B  53                push bx
00007E6C  837E0606          cmp word [bp+0x6],byte +0x6
00007E70  7505              jnz 0x7e77
00007E72  B80100            mov ax,0x1
00007E75  EB02              jmp short 0x7e79
00007E77  33C0              xor ax,ax
00007E79  5B                pop bx
00007E7A  07                pop es
00007E7B  03D8              add bx,ax
00007E7D  268A07            mov al,[es:bx]
00007E80  B400              mov ah,0x0
00007E82  8946FE            mov [bp-0x2],ax
00007E85  837E087F          cmp word [bp+0x8],byte +0x7f
00007E89  7E05              jng 0x7e90
00007E8B  C746087F00        mov word [bp+0x8],0x7f
00007E90  8A4608            mov al,[bp+0x8]
00007E93  8B5EFE            mov bx,[bp-0x2]
00007E96  88872935          mov [bx+0x3529],al
00007E9A  FF76FE            push word [bp-0x2]
00007E9D  0E                push cs
00007E9E  E899F8            call 0x773a
00007EA1  59                pop cx
00007EA2  8BE5              mov sp,bp
00007EA4  5D                pop bp
00007EA5  CB                retf
00007EA6  55                push bp
00007EA7  8BEC              mov bp,sp
00007EA9  803EEF3400        cmp byte [0x34ef],0x0
00007EAE  7406              jz 0x7eb6
00007EB0  837E0606          cmp word [bp+0x6],byte +0x6
00007EB4  7F35              jg 0x7eeb
00007EB6  817E08FF3F        cmp word [bp+0x8],0x3fff
00007EBB  7E05              jng 0x7ec2
00007EBD  C74608FF3F        mov word [bp+0x8],0x3fff
00007EC2  FF7608            push word [bp+0x8]
00007EC5  FF7606            push word [bp+0x6]
00007EC8  0E                push cs
00007EC9  E88EF6            call 0x755a
00007ECC  8BE5              mov sp,bp
00007ECE  8B5E06            mov bx,[bp+0x6]
00007ED1  8A87F034          mov al,[bx+0x34f0]
00007ED5  B400              mov ah,0x0
00007ED7  50                push ax
00007ED8  8B5E06            mov bx,[bp+0x6]
00007EDB  8A878D31          mov al,[bx+0x318d]
00007EDF  B400              mov ah,0x0
00007EE1  50                push ax
00007EE2  FF7606            push word [bp+0x6]
00007EE5  0E                push cs
00007EE6  E874FB            call 0x7a5d
00007EE9  8BE5              mov sp,bp
00007EEB  5D                pop bp
00007EEC  CB                retf
00007EED  55                push bp
00007EEE  8BEC              mov bp,sp
00007EF0  83EC04            sub sp,byte +0x4
00007EF3  803E0A2B00        cmp byte [0x2b0a],0x0
00007EF8  7403              jz 0x7efd
00007EFA  E90401            jmp 0x8001
00007EFD  837E0606          cmp word [bp+0x6],byte +0x6
00007F01  7C03              jl 0x7f06
00007F03  E9F800            jmp 0x7ffe
00007F06  9A05003B0A        call 0xa3b:0x5
00007F0B  8916082B          mov [0x2b08],dx
00007F0F  A3062B            mov [0x2b06],ax
00007F12  836E082E          sub word [bp+0x8],byte +0x2e
00007F16  837E080C          cmp word [bp+0x8],byte +0xc
00007F1A  7D2B              jnl 0x7f47
00007F1C  837E0800          cmp word [bp+0x8],byte +0x0
00007F20  7C25              jl 0x7f47
00007F22  33D2              xor dx,dx
00007F24  B8E803            mov ax,0x3e8
00007F27  52                push dx
00007F28  50                push ax
00007F29  8B5E08            mov bx,[bp+0x8]
00007F2C  D1E3              shl bx,1
00007F2E  D1E3              shl bx,1
00007F30  FFB70D2B          push word [bx+0x2b0d]
00007F34  FFB70B2B          push word [bx+0x2b0b]
00007F38  9A2B040000        call 0x0:0x42b
00007F3D  50                push ax
00007F3E  9A0D003E0A        call 0xa3e:0xd
00007F43  59                pop cx
00007F44  E9B200            jmp 0x7ff9
00007F47  837E0800          cmp word [bp+0x8],byte +0x0
00007F4B  7E57              jng 0x7fa4
00007F4D  C746FE0000        mov word [bp-0x2],0x0
00007F52  C746FC0100        mov word [bp-0x4],0x1
00007F57  EB14              jmp short 0x7f6d
00007F59  8B56FE            mov dx,[bp-0x2]
00007F5C  8B46FC            mov ax,[bp-0x4]
00007F5F  D1E0              shl ax,1
00007F61  D1D2              rcl dx,1
00007F63  8956FE            mov [bp-0x2],dx
00007F66  8946FC            mov [bp-0x4],ax
00007F69  836E080C          sub word [bp+0x8],byte +0xc
00007F6D  837E080C          cmp word [bp+0x8],byte +0xc
00007F71  7DE6              jnl 0x7f59
00007F73  33D2              xor dx,dx
00007F75  B8E803            mov ax,0x3e8
00007F78  52                push dx
00007F79  50                push ax
00007F7A  8B5E08            mov bx,[bp+0x8]
00007F7D  D1E3              shl bx,1
00007F7F  D1E3              shl bx,1
00007F81  8B970D2B          mov dx,[bx+0x2b0d]
00007F85  8B870B2B          mov ax,[bx+0x2b0b]
00007F89  8B4EFE            mov cx,[bp-0x2]
00007F8C  8B5EFC            mov bx,[bp-0x4]
00007F8F  9A12040000        call 0x0:0x412
00007F94  52                push dx
00007F95  50                push ax
00007F96  9A2B040000        call 0x0:0x42b
00007F9B  50                push ax
00007F9C  9A0D003E0A        call 0xa3e:0xd
00007FA1  59                pop cx
00007FA2  EB55              jmp short 0x7ff9
00007FA4  C746FE0000        mov word [bp-0x2],0x0
00007FA9  C746FC0100        mov word [bp-0x4],0x1
00007FAE  EB14              jmp short 0x7fc4
00007FB0  8B56FE            mov dx,[bp-0x2]
00007FB3  8B46FC            mov ax,[bp-0x4]
00007FB6  D1E0              shl ax,1
00007FB8  D1D2              rcl dx,1
00007FBA  8956FE            mov [bp-0x2],dx
00007FBD  8946FC            mov [bp-0x4],ax
00007FC0  8346080C          add word [bp+0x8],byte +0xc
00007FC4  837E0800          cmp word [bp+0x8],byte +0x0
00007FC8  7CE6              jl 0x7fb0
00007FCA  33D2              xor dx,dx
00007FCC  B8E803            mov ax,0x3e8
00007FCF  52                push dx
00007FD0  50                push ax
00007FD1  FF76FE            push word [bp-0x2]
00007FD4  FF76FC            push word [bp-0x4]
00007FD7  8B5E08            mov bx,[bp+0x8]
00007FDA  D1E3              shl bx,1
00007FDC  D1E3              shl bx,1
00007FDE  FFB70D2B          push word [bx+0x2b0d]
00007FE2  FFB70B2B          push word [bx+0x2b0b]
00007FE6  9A2B040000        call 0x0:0x42b
00007FEB  52                push dx
00007FEC  50                push ax
00007FED  9A2B040000        call 0x0:0x42b
00007FF2  50                push ax
00007FF3  9A0D003E0A        call 0xa3e:0xd
00007FF8  59                pop cx
00007FF9  E98800            jmp 0x8084
00007FFC  EB03              jmp short 0x8001
00007FFE  E98300            jmp 0x8084
00008001  836E080C          sub word [bp+0x8],byte +0xc
00008005  837E0800          cmp word [bp+0x8],byte +0x0
00008009  7D05              jnl 0x8010
0000800B  C746080000        mov word [bp+0x8],0x0
00008010  837E0606          cmp word [bp+0x6],byte +0x6
00008014  7C07              jl 0x801d
00008016  803EEF3400        cmp byte [0x34ef],0x0
0000801B  7513              jnz 0x8030
0000801D  B80100            mov ax,0x1
00008020  50                push ax
00008021  FF7608            push word [bp+0x8]
00008024  FF7606            push word [bp+0x6]
00008027  0E                push cs
00008028  E832FA            call 0x7a5d
0000802B  83C406            add sp,byte +0x6
0000802E  EB54              jmp short 0x8084
00008030  837E0606          cmp word [bp+0x6],byte +0x6
00008034  7513              jnz 0x8049
00008036  33C0              xor ax,ax
00008038  50                push ax
00008039  FF7608            push word [bp+0x8]
0000803C  B80600            mov ax,0x6
0000803F  50                push ax
00008040  0E                push cs
00008041  E819FA            call 0x7a5d
00008044  83C406            add sp,byte +0x6
00008047  EB2C              jmp short 0x8075
00008049  837E0608          cmp word [bp+0x6],byte +0x8
0000804D  7526              jnz 0x8075
0000804F  33C0              xor ax,ax
00008051  50                push ax
00008052  FF7608            push word [bp+0x8]
00008055  B80800            mov ax,0x8
00008058  50                push ax
00008059  0E                push cs
0000805A  E800FA            call 0x7a5d
0000805D  83C406            add sp,byte +0x6
00008060  33C0              xor ax,ax
00008062  50                push ax
00008063  8B4608            mov ax,[bp+0x8]
00008066  050700            add ax,0x7
00008069  50                push ax
0000806A  B80700            mov ax,0x7
0000806D  50                push ax
0000806E  0E                push cs
0000806F  E8EBF9            call 0x7a5d
00008072  83C406            add sp,byte +0x6
00008075  8B5E06            mov bx,[bp+0x6]
00008078  8A87352B          mov al,[bx+0x2b35]
0000807C  08069831          or [0x3198],al
00008080  0E                push cs
00008081  E83BF9            call 0x79bf
00008084  8BE5              mov sp,bp
00008086  5D                pop bp
00008087  CB                retf
00008088  55                push bp
00008089  8BEC              mov bp,sp
0000808B  803E0A2B00        cmp byte [0x2b0a],0x0
00008090  7507              jnz 0x8099
00008092  9A39003E0A        call 0xa3e:0x39
00008097  EB36              jmp short 0x80cf
00008099  803EEF3400        cmp byte [0x34ef],0x0
0000809E  7406              jz 0x80a6
000080A0  837E0606          cmp word [bp+0x6],byte +0x6
000080A4  7D18              jnl 0x80be
000080A6  33C0              xor ax,ax
000080A8  50                push ax
000080A9  8B5E06            mov bx,[bp+0x6]
000080AC  8A878D31          mov al,[bx+0x318d]
000080B0  B400              mov ah,0x0
000080B2  50                push ax
000080B3  FF7606            push word [bp+0x6]
000080B6  0E                push cs
000080B7  E8A3F9            call 0x7a5d
000080BA  8BE5              mov sp,bp
000080BC  EB11              jmp short 0x80cf
000080BE  8B5E06            mov bx,[bp+0x6]
000080C1  8A87352B          mov al,[bx+0x2b35]
000080C5  F6D0              not al
000080C7  20069831          and [0x3198],al
000080CB  0E                push cs
000080CC  E8F0F8            call 0x79bf
000080CF  5D                pop bp
000080D0  CB                retf
000080D1  55                push bp
000080D2  8BEC              mov bp,sp
000080D4  803E1F2801        cmp byte [0x281f],0x1
000080D9  7538              jnz 0x8113
000080DB  817E06131F        cmp word [bp+0x6],0x1f13
000080E0  7402              jz 0x80e4
000080E2  EB2F              jmp short 0x8113
000080E4  A01D2C            mov al,[0x2c1d]
000080E7  F6D8              neg al
000080E9  1AC0              sbb al,al
000080EB  FEC0              inc al
000080ED  98                cbw
000080EE  A21D2C            mov [0x2c1d],al
000080F1  803E1D2C00        cmp byte [0x2c1d],0x0
000080F6  750C              jnz 0x8104
000080F8  9AD300E808        call 0x8e8:0xd3
000080FD  C606750601        mov byte [0x675],0x1
00008102  EB0F              jmp short 0x8113
00008104  B80100            mov ax,0x1
00008107  50                push ax
00008108  9A6901E808        call 0x8e8:0x169
0000810D  59                pop cx
0000810E  C606750600        mov byte [0x675],0x0
00008113  5D                pop bp
00008114  CB                retf
00008115  55                push bp
00008116  8BEC              mov bp,sp
00008118  83EC0A            sub sp,byte +0xa
0000811B  8A4608            mov al,[bp+0x8]
0000811E  32E4              xor ah,ah
00008120  33D2              xor dx,dx
00008122  52                push dx
00008123  50                push ax
00008124  8A4606            mov al,[bp+0x6]
00008127  32E4              xor ah,ah
00008129  33D2              xor dx,dx
0000812B  5B                pop bx
0000812C  59                pop cx
0000812D  9A12040000        call 0x0:0x412
00008132  8956F8            mov [bp-0x8],dx
00008135  8946F6            mov [bp-0xa],ax
00008138  33D2              xor dx,dx
0000813A  B83C00            mov ax,0x3c
0000813D  52                push dx
0000813E  50                push ax
0000813F  FF76F8            push word [bp-0x8]
00008142  FF76F6            push word [bp-0xa]
00008145  9A2B040000        call 0x0:0x42b
0000814A  8956FC            mov [bp-0x4],dx
0000814D  8946FA            mov [bp-0x6],ax
00008150  8B46FA            mov ax,[bp-0x6]
00008153  0B46FC            or ax,[bp-0x4]
00008156  7507              jnz 0x815f
00008158  C746FE0000        mov word [bp-0x2],0x0
0000815D  EB37              jmp short 0x8196
0000815F  837EFC00          cmp word [bp-0x4],byte +0x0
00008163  7F0F              jg 0x8174
00008165  7C06              jl 0x816d
00008167  837EFA13          cmp word [bp-0x6],byte +0x13
0000816B  7307              jnc 0x8174
0000816D  33D2              xor dx,dx
0000816F  B81300            mov ax,0x13
00008172  EB06              jmp short 0x817a
00008174  8B56FC            mov dx,[bp-0x4]
00008177  8B46FA            mov ax,[bp-0x6]
0000817A  8956FC            mov [bp-0x4],dx
0000817D  8946FA            mov [bp-0x6],ax
00008180  FF76FC            push word [bp-0x4]
00008183  FF76FA            push word [bp-0x6]
00008186  BA1200            mov dx,0x12
00008189  B8DC34            mov ax,0x34dc
0000818C  52                push dx
0000818D  50                push ax
0000818E  9A2B040000        call 0x0:0x42b
00008193  8946FE            mov [bp-0x2],ax
00008196  FF76FE            push word [bp-0x2]
00008199  9A22006C09        call 0x96c:0x22
0000819E  59                pop cx
0000819F  8BE5              mov sp,bp
000081A1  5D                pop bp
000081A2  CB                retf
000081A3  55                push bp
000081A4  8BEC              mov bp,sp
000081A6  83EC02            sub sp,byte +0x2
000081A9  803E062C00        cmp byte [0x2c06],0x0
000081AE  7502              jnz 0x81b2
000081B0  EB2F              jmp short 0x81e1
000081B2  C606062C00        mov byte [0x2c06],0x0
000081B7  C746FE0000        mov word [bp-0x2],0x0
000081BC  EB0C              jmp short 0x81ca
000081BE  FF76FE            push word [bp-0x2]
000081C1  9AE80D0508        call 0x805:0xde8
000081C6  59                pop cx
000081C7  FF46FE            inc word [bp-0x2]
000081CA  837EFE0B          cmp word [bp-0x2],byte +0xb
000081CE  7CEE              jl 0x81be
000081D0  B001              mov al,0x1
000081D2  50                push ax
000081D3  B000              mov al,0x0
000081D5  50                push ax
000081D6  0E                push cs
000081D7  E83BFF            call 0x8115
000081DA  59                pop cx
000081DB  59                pop cx
000081DC  9A8A006C09        call 0x96c:0x8a
000081E1  8BE5              mov sp,bp
000081E3  5D                pop bp
000081E4  CB                retf
000081E5  55                push bp
000081E6  8BEC              mov bp,sp
000081E8  83EC06            sub sp,byte +0x6
000081EB  C45E0C            les bx,[bp+0xc]
000081EE  268B4702          mov ax,[es:bx+0x2]
000081F2  8946FE            mov [bp-0x2],ax
000081F5  8B4606            mov ax,[bp+0x6]
000081F8  3B46FE            cmp ax,[bp-0x2]
000081FB  7C02              jl 0x81ff
000081FD  EB36              jmp short 0x8235
000081FF  C45E0C            les bx,[bp+0xc]
00008202  268B4704          mov ax,[es:bx+0x4]
00008206  C45E0C            les bx,[bp+0xc]
00008209  03D8              add bx,ax
0000820B  8C46FC            mov [bp-0x4],es
0000820E  895EFA            mov [bp-0x6],bx
00008211  B83800            mov ax,0x38
00008214  50                push ax
00008215  FF760A            push word [bp+0xa]
00008218  FF7608            push word [bp+0x8]
0000821B  8B4606            mov ax,[bp+0x6]
0000821E  BA3800            mov dx,0x38
00008221  F7E2              mul dx
00008223  8B4EFC            mov cx,[bp-0x4]
00008226  8B5EFA            mov bx,[bp-0x6]
00008229  03D8              add bx,ax
0000822B  51                push cx
0000822C  53                push bx
0000822D  9A0100340A        call 0xa34:0x1
00008232  83C40A            add sp,byte +0xa
00008235  8BE5              mov sp,bp
00008237  5D                pop bp
00008238  CB                retf
00008239  55                push bp
0000823A  8BEC              mov bp,sp
0000823C  83EC0E            sub sp,byte +0xe
0000823F  803E062C00        cmp byte [0x2c06],0x0
00008244  7409              jz 0x824f
00008246  0E                push cs
00008247  E859FF            call 0x81a3
0000824A  C6061F2800        mov byte [0x281f],0x0
0000824F  803E1D2C00        cmp byte [0x2c1d],0x0
00008254  7509              jnz 0x825f
00008256  807E0600          cmp byte [bp+0x6],0x0
0000825A  7403              jz 0x825f
0000825C  E90D01            jmp 0x836c
0000825F  8C5EF4            mov [bp-0xc],ds
00008262  C746F25435        mov word [bp-0xe],0x3554
00008267  8A4606            mov al,[bp+0x6]
0000826A  8846FB            mov [bp-0x5],al
0000826D  C746FC0000        mov word [bp-0x4],0x0
00008272  C41E282C          les bx,[0x2c28]
00008276  8C46F8            mov [bp-0x8],es
00008279  895EF6            mov [bp-0xa],bx
0000827C  8B46FC            mov ax,[bp-0x4]
0000827F  A3262C            mov [0x2c26],ax
00008282  8A46FB            mov al,[bp-0x5]
00008285  B400              mov ah,0x0
00008287  A3C735            mov [0x35c7],ax
0000828A  C45EF2            les bx,[bp-0xe]
0000828D  8C06CF35          mov [0x35cf],es
00008291  891ECD35          mov [0x35cd],bx
00008295  C45EF2            les bx,[bp-0xe]
00008298  26C45F46          les bx,[es:bx+0x46]
0000829C  8C06D735          mov [0x35d7],es
000082A0  891ED535          mov [0x35d5],bx
000082A4  8C061B36          mov [0x361b],es
000082A8  891E1936          mov [0x3619],bx
000082AC  C45EF2            les bx,[bp-0xe]
000082AF  8C06DC35          mov [0x35dc],es
000082B3  891EDA35          mov [0x35da],bx
000082B7  C45EF2            les bx,[bp-0xe]
000082BA  268B5728          mov dx,[es:bx+0x28]
000082BE  268B4726          mov ax,[es:bx+0x26]
000082C2  8916242C          mov [0x2c24],dx
000082C6  A3222C            mov [0x2c22],ax
000082C9  C45EF6            les bx,[bp-0xa]
000082CC  8C06AA35          mov [0x35aa],es
000082D0  891EA835          mov [0x35a8],bx
000082D4  C746FE0000        mov word [bp-0x2],0x0
000082D9  EB0B              jmp short 0x82e6
000082DB  8B5EFE            mov bx,[bp-0x2]
000082DE  C687B83500        mov byte [bx+0x35b8],0x0
000082E3  FF46FE            inc word [bp-0x2]
000082E6  837EFE0B          cmp word [bp-0x2],byte +0xb
000082EA  7CEF              jl 0x82db
000082EC  9A44006C09        call 0x96c:0x44
000082F1  803E0A2B00        cmp byte [0x2b0a],0x0
000082F6  7421              jz 0x8319
000082F8  C41ECD35          les bx,[0x35cd]
000082FC  268A473A          mov al,[es:bx+0x3a]
00008300  98                cbw
00008301  50                push ax
00008302  9ABB090508        call 0x805:0x9bb
00008307  59                pop cx
00008308  C41ECD35          les bx,[0x35cd]
0000830C  268A473B          mov al,[es:bx+0x3b]
00008310  B400              mov ah,0x0
00008312  50                push ax
00008313  9A660A0508        call 0x805:0xa66
00008318  59                pop cx
00008319  C41ECD35          les bx,[0x35cd]
0000831D  268A4724          mov al,[es:bx+0x24]
00008321  50                push ax
00008322  C41ECD35          les bx,[0x35cd]
00008326  268A473C          mov al,[es:bx+0x3c]
0000832A  50                push ax
0000832B  0E                push cs
0000832C  E8E6FD            call 0x8115
0000832F  59                pop cx
00008330  59                pop cx
00008331  33C0              xor ax,ax
00008333  50                push ax
00008334  9A9D006C09        call 0x96c:0x9d
00008339  59                pop cx
0000833A  C41ED535          les bx,[0x35d5]
0000833E  268A07            mov al,[es:bx]
00008341  B400              mov ah,0x0
00008343  A3B035            mov [0x35b0],ax
00008346  FF06D535          inc word [0x35d5]
0000834A  833EB03500        cmp word [0x35b0],byte +0x0
0000834F  740C              jz 0x835d
00008351  FF36B035          push word [0x35b0]
00008355  9A9D006C09        call 0x96c:0x9d
0000835A  59                pop cx
0000835B  EB0A              jmp short 0x8367
0000835D  B80100            mov ax,0x1
00008360  50                push ax
00008361  9A9D006C09        call 0x96c:0x9d
00008366  59                pop cx
00008367  C606062C01        mov byte [0x2c06],0x1
0000836C  8BE5              mov sp,bp
0000836E  5D                pop bp
0000836F  CB                retf
00008370  55                push bp
00008371  8BEC              mov bp,sp
00008373  83EC0C            sub sp,byte +0xc
00008376  C6062E2C00        mov byte [0x2c2e],0x0
0000837B  C7062C2C0100      mov word [0x2c2c],0x1
00008381  803E062C00        cmp byte [0x2c06],0x0
00008386  7506              jnz 0x838e
00008388  B80100            mov ax,0x1
0000838B  E9BD04            jmp 0x884b
0000838E  C41E1936          les bx,[0x3619]
00008392  8C46FA            mov [bp-0x6],es
00008395  895EF8            mov [bp-0x8],bx
00008398  8B1EC535          mov bx,[0x35c5]
0000839C  33C9              xor cx,cx
0000839E  8CD2              mov dx,ss
000083A0  8D46F8            lea ax,[bp-0x8]
000083A3  9A13030000        call 0x0:0x313
000083A8  C41ED535          les bx,[0x35d5]
000083AC  8C46FE            mov [bp-0x2],es
000083AF  895EFC            mov [bp-0x4],bx
000083B2  8B56FA            mov dx,[bp-0x6]
000083B5  8B46F8            mov ax,[bp-0x8]
000083B8  8B4EFE            mov cx,[bp-0x2]
000083BB  8B5EFC            mov bx,[bp-0x4]
000083BE  9A0B050000        call 0x0:0x50b
000083C3  8956F6            mov [bp-0xa],dx
000083C6  8946F4            mov [bp-0xc],ax
000083C9  8B56F6            mov dx,[bp-0xa]
000083CC  8B46F4            mov ax,[bp-0xc]
000083CF  8916242C          mov [0x2c24],dx
000083D3  A3222C            mov [0x2c22],ax
000083D6  837EF600          cmp word [bp-0xa],byte +0x0
000083DA  7F17              jg 0x83f3
000083DC  7C06              jl 0x83e4
000083DE  837EF401          cmp word [bp-0xc],byte +0x1
000083E2  730F              jnc 0x83f3
000083E4  833EC73500        cmp word [0x35c7],byte +0x0
000083E9  7408              jz 0x83f3
000083EB  C41ED535          les bx,[0x35d5]
000083EF  26C607FC          mov byte [es:bx],0xfc
000083F3  C41ED535          les bx,[0x35d5]
000083F7  268A07            mov al,[es:bx]
000083FA  A21836            mov [0x3618],al
000083FD  803E1836F8        cmp byte [0x3618],0xf8
00008402  7510              jnz 0x8414
00008404  FF06D535          inc word [0x35d5]
00008408  C706B035F800      mov word [0x35b0],0xf8
0000840E  E90004            jmp 0x8811
00008411  E9F303            jmp 0x8807
00008414  803E1836FC        cmp byte [0x3618],0xfc
00008419  7403              jz 0x841e
0000841B  E9B000            jmp 0x84ce
0000841E  803E342800        cmp byte [0x2834],0x0
00008423  750B              jnz 0x8430
00008425  C706C7350000      mov word [0x35c7],0x0
0000842B  C6060F28FF        mov byte [0x280f],0xff
00008430  833EC73500        cmp word [0x35c7],byte +0x0
00008435  750C              jnz 0x8443
00008437  C6061F2800        mov byte [0x281f],0x0
0000843C  0E                push cs
0000843D  E863FD            call 0x81a3
00008440  E98200            jmp 0x84c5
00008443  C41E1936          les bx,[0x3619]
00008447  8C06D735          mov [0x35d7],es
0000844B  891ED535          mov [0x35d5],bx
0000844F  803E0A2B00        cmp byte [0x2b0a],0x0
00008454  7421              jz 0x8477
00008456  C41ECD35          les bx,[0x35cd]
0000845A  268A473A          mov al,[es:bx+0x3a]
0000845E  98                cbw
0000845F  50                push ax
00008460  9ABB090508        call 0x805:0x9bb
00008465  59                pop cx
00008466  C41ECD35          les bx,[0x35cd]
0000846A  268A473B          mov al,[es:bx+0x3b]
0000846E  B400              mov ah,0x0
00008470  50                push ax
00008471  9A660A0508        call 0x805:0xa66
00008476  59                pop cx
00008477  C41ECD35          les bx,[0x35cd]
0000847B  268A4724          mov al,[es:bx+0x24]
0000847F  50                push ax
00008480  C41ECD35          les bx,[0x35cd]
00008484  268A473C          mov al,[es:bx+0x3c]
00008488  50                push ax
00008489  0E                push cs
0000848A  E888FC            call 0x8115
0000848D  59                pop cx
0000848E  59                pop cx
0000848F  33C0              xor ax,ax
00008491  50                push ax
00008492  9A9D006C09        call 0x96c:0x9d
00008497  59                pop cx
00008498  C41ED535          les bx,[0x35d5]
0000849C  268A07            mov al,[es:bx]
0000849F  B400              mov ah,0x0
000084A1  A3B035            mov [0x35b0],ax
000084A4  FF06D535          inc word [0x35d5]
000084A8  833EB03500        cmp word [0x35b0],byte +0x0
000084AD  740C              jz 0x84bb
000084AF  FF36B035          push word [0x35b0]
000084B3  9A9D006C09        call 0x96c:0x9d
000084B8  59                pop cx
000084B9  EB0A              jmp short 0x84c5
000084BB  B80100            mov ax,0x1
000084BE  50                push ax
000084BF  9A9D006C09        call 0x96c:0x9d
000084C4  59                pop cx
000084C5  A1C735            mov ax,[0x35c7]
000084C8  E98003            jmp 0x884b
000084CB  E93903            jmp 0x8807
000084CE  803E1836F0        cmp byte [0x3618],0xf0
000084D3  7403              jz 0x84d8
000084D5  E9C600            jmp 0x859e
000084D8  FF06D535          inc word [0x35d5]
000084DC  C41ED535          les bx,[0x35d5]
000084E0  268A07            mov al,[es:bx]
000084E3  B400              mov ah,0x0
000084E5  A39E35            mov [0x359e],ax
000084E8  FF06D535          inc word [0x35d5]
000084EC  C41ED535          les bx,[0x35d5]
000084F0  268A07            mov al,[es:bx]
000084F3  B400              mov ah,0x0
000084F5  A3AC35            mov [0x35ac],ax
000084F8  FF06D535          inc word [0x35d5]
000084FC  833E9E357F        cmp word [0x359e],byte +0x7f
00008501  7507              jnz 0x850a
00008503  833EAC3500        cmp word [0x35ac],byte +0x0
00008508  7417              jz 0x8521
0000850A  832ED53502        sub word [0x35d5],byte +0x2
0000850F  EB00              jmp short 0x8511
00008511  C41ED535          les bx,[0x35d5]
00008515  FF06D535          inc word [0x35d5]
00008519  26803FF7          cmp byte [es:bx],0xf7
0000851D  75F2              jnz 0x8511
0000851F  EB6A              jmp short 0x858b
00008521  C41ED535          les bx,[0x35d5]
00008525  268A07            mov al,[es:bx]
00008528  B400              mov ah,0x0
0000852A  A3DE35            mov [0x35de],ax
0000852D  FF06D535          inc word [0x35d5]
00008531  C41ED535          les bx,[0x35d5]
00008535  268A07            mov al,[es:bx]
00008538  B400              mov ah,0x0
0000853A  A3A435            mov [0x35a4],ax
0000853D  FF06D535          inc word [0x35d5]
00008541  C41EDA35          les bx,[0x35da]
00008545  268B473C          mov ax,[es:bx+0x3c]
00008549  A3C335            mov [0x35c3],ax
0000854C  A1C335            mov ax,[0x35c3]
0000854F  33D2              xor dx,dx
00008551  52                push dx
00008552  50                push ax
00008553  A1A435            mov ax,[0x35a4]
00008556  99                cwd
00008557  5B                pop bx
00008558  59                pop cx
00008559  9A12040000        call 0x0:0x412
0000855E  B107              mov cl,0x7
00008560  9ACE040000        call 0x0:0x4ce
00008565  50                push ax
00008566  A1C335            mov ax,[0x35c3]
00008569  F726DE35          mul word [0x35de]
0000856D  5A                pop dx
0000856E  03D0              add dx,ax
00008570  8916C335          mov [0x35c3],dx
00008574  C41EDA35          les bx,[0x35da]
00008578  268A4724          mov al,[es:bx+0x24]
0000857C  50                push ax
0000857D  FF36C335          push word [0x35c3]
00008581  0E                push cs
00008582  E890FB            call 0x8115
00008585  59                pop cx
00008586  59                pop cx
00008587  FF06D535          inc word [0x35d5]
0000858B  C41ED535          les bx,[0x35d5]
0000858F  268A07            mov al,[es:bx]
00008592  B400              mov ah,0x0
00008594  A3B035            mov [0x35b0],ax
00008597  FF06D535          inc word [0x35d5]
0000859B  E96902            jmp 0x8807
0000859E  803E183680        cmp byte [0x3618],0x80
000085A3  720A              jc 0x85af
000085A5  FF06D535          inc word [0x35d5]
000085A9  A01836            mov al,[0x3618]
000085AC  A2D935            mov [0x35d9],al
000085AF  A0D935            mov al,[0x35d9]
000085B2  B400              mov ah,0x0
000085B4  250F00            and ax,0xf
000085B7  A32C2C            mov [0x2c2c],ax
000085BA  A0D935            mov al,[0x35d9]
000085BD  B400              mov ah,0x0
000085BF  25F000            and ax,0xf0
000085C2  B90700            mov cx,0x7
000085C5  BB0805            mov bx,0x508
000085C8  2E3B07            cmp ax,[cs:bx]
000085CB  7407              jz 0x85d4
000085CD  43                inc bx
000085CE  43                inc bx
000085CF  E2F7              loop 0x85c8
000085D1  E90302            jmp 0x87d7
000085D4  2EFF670E          jmp [cs:bx+0xe]
000085D8  800090            add byte [bx+si],0x90
000085DB  00A000B0          add [bx+si-0x5000],ah
000085DF  00C0              add al,al
000085E1  00D0              add al,dl
000085E3  00E0              add al,ah
000085E5  0022              add [bp+si],ah
000085E7  06                push es
000085E8  2405              and al,0x5
000085EA  58                pop ax
000085EB  06                push es
000085EC  FA                cli
000085ED  06                push es
000085EE  7B06              jpo 0x85f6
000085F0  0107              add [bx],ax
000085F2  BD06FF            mov bp,0xff06
000085F5  06                push es
000085F6  AE                scasb
000085F7  35833E            xor ax,0x3e83
000085FA  1E                push ds
000085FB  2C00              sub al,0x0
000085FD  7411              jz 0x8610
000085FF  FF0E1E2C          dec word [0x2c1e]
00008603  8306D53502        add word [0x35d5],byte +0x2
00008608  C6062E2C01        mov byte [0x2c2e],0x1
0000860D  E9E701            jmp 0x87f7
00008610  833E202C00        cmp word [0x2c20],byte +0x0
00008615  7419              jz 0x8630
00008617  FF0E202C          dec word [0x2c20]
0000861B  833E202C00        cmp word [0x2c20],byte +0x0
00008620  750E              jnz 0x8630
00008622  C6061F2800        mov byte [0x281f],0x0
00008627  0E                push cs
00008628  E878FB            call 0x81a3
0000862B  33C0              xor ax,ax
0000862D  E91B02            jmp 0x884b
00008630  C41ED535          les bx,[0x35d5]
00008634  268A07            mov al,[es:bx]
00008637  B400              mov ah,0x0
00008639  A3B435            mov [0x35b4],ax
0000863C  FF06D535          inc word [0x35d5]
00008640  C41ED535          les bx,[0x35d5]
00008644  268A07            mov al,[es:bx]
00008647  B400              mov ah,0x0
00008649  A3A635            mov [0x35a6],ax
0000864C  FF06D535          inc word [0x35d5]
00008650  833EA63500        cmp word [0x35a6],byte +0x0
00008655  7530              jnz 0x8687
00008657  FF362C2C          push word [0x2c2c]
0000865B  9AE80D0508        call 0x805:0xde8
00008660  59                pop cx
00008661  8B1E2C2C          mov bx,[0x2c2c]
00008665  D1E3              shl bx,1
00008667  83AF072C0A        sub word [bx+0x2c07],byte +0xa
0000866C  8B1E2C2C          mov bx,[0x2c2c]
00008670  D1E3              shl bx,1
00008672  83BF072C00        cmp word [bx+0x2c07],byte +0x0
00008677  7D0C              jnl 0x8685
00008679  8B1E2C2C          mov bx,[0x2c2c]
0000867D  D1E3              shl bx,1
0000867F  C787072C0000      mov word [bx+0x2c07],0x0
00008685  EB68              jmp short 0x86ef
00008687  8B1E2C2C          mov bx,[0x2c2c]
0000868B  8A87B835          mov al,[bx+0x35b8]
0000868F  B400              mov ah,0x0
00008691  3B06A635          cmp ax,[0x35a6]
00008695  7421              jz 0x86b8
00008697  803E0A2B00        cmp byte [0x2b0a],0x0
0000869C  740F              jz 0x86ad
0000869E  FF36A635          push word [0x35a6]
000086A2  FF362C2C          push word [0x2c2c]
000086A6  9A930B0508        call 0x805:0xb93
000086AB  59                pop cx
000086AC  59                pop cx
000086AD  A0A635            mov al,[0x35a6]
000086B0  8B1E2C2C          mov bx,[0x2c2c]
000086B4  8887B835          mov [bx+0x35b8],al
000086B8  FF36B435          push word [0x35b4]
000086BC  FF362C2C          push word [0x2c2c]
000086C0  9A4D0C0508        call 0x805:0xc4d
000086C5  59                pop cx
000086C6  59                pop cx
000086C7  8B1E2C2C          mov bx,[0x2c2c]
000086CB  D1E3              shl bx,1
000086CD  8387072C28        add word [bx+0x2c07],byte +0x28
000086D2  8B1E2C2C          mov bx,[0x2c2c]
000086D6  D1E3              shl bx,1
000086D8  8B87072C          mov ax,[bx+0x2c07]
000086DC  3B06262C          cmp ax,[0x2c26]
000086E0  7E0D              jng 0x86ef
000086E2  A1262C            mov ax,[0x2c26]
000086E5  8B1E2C2C          mov bx,[0x2c2c]
000086E9  D1E3              shl bx,1
000086EB  8987072C          mov [bx+0x2c07],ax
000086EF  E90501            jmp 0x87f7
000086F2  8306D53502        add word [0x35d5],byte +0x2
000086F7  FF362C2C          push word [0x2c2c]
000086FB  9AE80D0508        call 0x805:0xde8
00008700  59                pop cx
00008701  8B1E2C2C          mov bx,[0x2c2c]
00008705  D1E3              shl bx,1
00008707  83AF072C0A        sub word [bx+0x2c07],byte +0xa
0000870C  8B1E2C2C          mov bx,[0x2c2c]
00008710  D1E3              shl bx,1
00008712  83BF072C00        cmp word [bx+0x2c07],byte +0x0
00008717  7D0C              jnl 0x8725
00008719  8B1E2C2C          mov bx,[0x2c2c]
0000871D  D1E3              shl bx,1
0000871F  C787072C0000      mov word [bx+0x2c07],0x0
00008725  E9CF00            jmp 0x87f7
00008728  803E0A2B00        cmp byte [0x2b0a],0x0
0000872D  7419              jz 0x8748
0000872F  C41ED535          les bx,[0x35d5]
00008733  FF06D535          inc word [0x35d5]
00008737  268A07            mov al,[es:bx]
0000873A  B400              mov ah,0x0
0000873C  50                push ax
0000873D  FF362C2C          push word [0x2c2c]
00008741  9A930B0508        call 0x805:0xb93
00008746  59                pop cx
00008747  59                pop cx
00008748  E9AC00            jmp 0x87f7
0000874B  C41ED535          les bx,[0x35d5]
0000874F  268A07            mov al,[es:bx]
00008752  B400              mov ah,0x0
00008754  A3B635            mov [0x35b6],ax
00008757  FF06D535          inc word [0x35d5]
0000875B  803E0A2B00        cmp byte [0x2b0a],0x0
00008760  7429              jz 0x878b
00008762  FF36AA35          push word [0x35aa]
00008766  FF36A835          push word [0x35a8]
0000876A  1E                push ds
0000876B  B8E035            mov ax,0x35e0
0000876E  50                push ax
0000876F  FF36B635          push word [0x35b6]
00008773  0E                push cs
00008774  E86EFA            call 0x81e5
00008777  83C40A            add sp,byte +0xa
0000877A  1E                push ds
0000877B  B8E035            mov ax,0x35e0
0000877E  50                push ax
0000877F  FF362C2C          push word [0x2c2c]
00008783  9AB10A0508        call 0x805:0xab1
00008788  83C406            add sp,byte +0x6
0000878B  EB6A              jmp short 0x87f7
0000878D  C41ED535          les bx,[0x35d5]
00008791  268A07            mov al,[es:bx]
00008794  B400              mov ah,0x0
00008796  A3B235            mov [0x35b2],ax
00008799  FF06D535          inc word [0x35d5]
0000879D  C41ED535          les bx,[0x35d5]
000087A1  268A07            mov al,[es:bx]
000087A4  B400              mov ah,0x0
000087A6  B107              mov cl,0x7
000087A8  D3E0              shl ax,cl
000087AA  0106B235          add [0x35b2],ax
000087AE  FF06D535          inc word [0x35d5]
000087B2  803E0A2B00        cmp byte [0x2b0a],0x0
000087B7  740F              jz 0x87c8
000087B9  FF36B235          push word [0x35b2]
000087BD  FF362C2C          push word [0x2c2c]
000087C1  9A060C0508        call 0x805:0xc06
000087C6  59                pop cx
000087C7  59                pop cx
000087C8  EB2D              jmp short 0x87f7
000087CA  8306D53502        add word [0x35d5],byte +0x2
000087CF  EB26              jmp short 0x87f7
000087D1  FF06D535          inc word [0x35d5]
000087D5  EB20              jmp short 0x87f7
000087D7  EB04              jmp short 0x87dd
000087D9  FF06D535          inc word [0x35d5]
000087DD  C41ED535          les bx,[0x35d5]
000087E1  26803F80          cmp byte [es:bx],0x80
000087E5  72F2              jc 0x87d9
000087E7  C41ED535          les bx,[0x35d5]
000087EB  26803FF8          cmp byte [es:bx],0xf8
000087EF  7404              jz 0x87f5
000087F1  FF0ED535          dec word [0x35d5]
000087F5  EB00              jmp short 0x87f7
000087F7  C41ED535          les bx,[0x35d5]
000087FB  268A07            mov al,[es:bx]
000087FE  B400              mov ah,0x0
00008800  A3B035            mov [0x35b0],ax
00008803  FF06D535          inc word [0x35d5]
00008807  833EB03500        cmp word [0x35b0],byte +0x0
0000880C  7503              jnz 0x8811
0000880E  E9E2FB            jmp 0x83f3
00008811  813EB035F800      cmp word [0x35b0],0xf8
00008817  7521              jnz 0x883a
00008819  C706B035F000      mov word [0x35b0],0xf0
0000881F  C41ED535          les bx,[0x35d5]
00008823  26803FF8          cmp byte [es:bx],0xf8
00008827  7411              jz 0x883a
00008829  C41ED535          les bx,[0x35d5]
0000882D  268A07            mov al,[es:bx]
00008830  B400              mov ah,0x0
00008832  0106B035          add [0x35b0],ax
00008836  FF06D535          inc word [0x35d5]
0000883A  803E2E2C00        cmp byte [0x2c2e],0x0
0000883F  7405              jz 0x8846
00008841  B80100            mov ax,0x1
00008844  EB05              jmp short 0x884b
00008846  A1B035            mov ax,[0x35b0]
00008849  EB00              jmp short 0x884b
0000884B  8BE5              mov sp,bp
0000884D  5D                pop bp
0000884E  CB                retf
0000884F  55                push bp
00008850  8BEC              mov bp,sp
00008852  9A39090508        call 0x805:0x939
00008857  C6061F2801        mov byte [0x281f],0x1
0000885C  C6060F2800        mov byte [0x280f],0x0
00008861  8B161428          mov dx,[0x2814]
00008865  A11628            mov ax,[0x2816]
00008868  8916A235          mov [0x35a2],dx
0000886C  A3A035            mov [0x35a0],ax
0000886F  8B161828          mov dx,[0x2818]
00008873  A11A28            mov ax,[0x281a]
00008876  8916D335          mov [0x35d3],dx
0000887A  A3D135            mov [0x35d1],ax
0000887D  A11C28            mov ax,[0x281c]
00008880  05B6FF            add ax,0xffb6
00008883  A3C535            mov [0x35c5],ax
00008886  B84600            mov ax,0x46
00008889  50                push ax
0000888A  FF36D335          push word [0x35d3]
0000888E  FF36D135          push word [0x35d1]
00008892  1E                push ds
00008893  B85435            mov ax,0x3554
00008896  50                push ax
00008897  9A0B00310A        call 0xa31:0xb
0000889C  83C40A            add sp,byte +0xa
0000889F  C41ED135          les bx,[0x35d1]
000088A3  83C346            add bx,byte +0x46
000088A6  8C069C35          mov [0x359c],es
000088AA  891E9A35          mov [0x359a],bx
000088AE  C41EA035          les bx,[0x35a0]
000088B2  8C062A2C          mov [0x2c2a],es
000088B6  891E282C          mov [0x2c28],bx
000088BA  B80100            mov ax,0x1
000088BD  50                push ax
000088BE  0E                push cs
000088BF  E877F9            call 0x8239
000088C2  59                pop cx
000088C3  5D                pop bp
000088C4  CB                retf
000088C5  55                push bp
000088C6  8BEC              mov bp,sp
000088C8  B8131F            mov ax,0x1f13
000088CB  50                push ax
000088CC  0E                push cs
000088CD  E801F8            call 0x80d1
000088D0  59                pop cx
000088D1  5D                pop bp
000088D2  CB                retf
000088D3  00558B            add [di-0x75],dl
000088D6  EC                in al,dx
000088D7  BA8803            mov dx,0x388
000088DA  8B4606            mov ax,[bp+0x6]
000088DD  EE                out dx,al
000088DE  EC                in al,dx
000088DF  EC                in al,dx
000088E0  EC                in al,dx
000088E1  EC                in al,dx
000088E2  EC                in al,dx
000088E3  EC                in al,dx
000088E4  42                inc dx
000088E5  8B4608            mov ax,[bp+0x8]
000088E8  EE                out dx,al
000088E9  4A                dec dx
000088EA  EC                in al,dx
000088EB  EC                in al,dx
000088EC  EC                in al,dx
000088ED  EC                in al,dx
000088EE  EC                in al,dx
000088EF  EC                in al,dx
000088F0  EC                in al,dx
000088F1  EC                in al,dx
000088F2  EC                in al,dx
000088F3  EC                in al,dx
000088F4  EC                in al,dx
000088F5  EC                in al,dx
000088F6  EC                in al,dx
000088F7  EC                in al,dx
000088F8  EC                in al,dx
000088F9  EC                in al,dx
000088FA  EC                in al,dx
000088FB  EC                in al,dx
000088FC  EC                in al,dx
000088FD  EC                in al,dx
000088FE  EC                in al,dx
000088FF  EC                in al,dx
00008900  EC                in al,dx
00008901  EC                in al,dx
00008902  EC                in al,dx
00008903  EC                in al,dx
00008904  EC                in al,dx
00008905  EC                in al,dx
00008906  EC                in al,dx
00008907  EC                in al,dx
00008908  EC                in al,dx
00008909  EC                in al,dx
0000890A  EC                in al,dx
0000890B  EC                in al,dx
0000890C  EC                in al,dx
0000890D  5D                pop bp
0000890E  CB                retf
0000890F  0000              add [bx+si],al
00008911  0000              add [bx+si],al
00008913  0000              add [bx+si],al
00008915  0000              add [bx+si],al
00008917  0000              add [bx+si],al
00008919  0000              add [bx+si],al
0000891B  0000              add [bx+si],al
0000891D  0000              add [bx+si],al
0000891F  0000              add [bx+si],al
00008921  0000              add [bx+si],al
00008923  50                push ax
00008924  B036              mov al,0x36
00008926  E643              out 0x43,al
00008928  58                pop ax
00008929  E640              out 0x40,al
0000892B  86E0              xchg ah,al
0000892D  E640              out 0x40,al
0000892F  86E0              xchg ah,al
00008931  C3                ret
00008932  55                push bp
00008933  8BEC              mov bp,sp
00008935  8B4606            mov ax,[bp+0x6]
00008938  9C                pushf
00008939  FA                cli
0000893A  2EA30200          mov [cs:0x2],ax
0000893E  3D0100            cmp ax,0x1
00008941  2EC70600000000    mov word [cs:0x0],0x0
00008948  2E8316000000      adc word [cs:0x0],byte +0x0
0000894E  E8D2FF            call 0x8923
00008951  9D                popf
00008952  5D                pop bp
00008953  CB                retf
00008954  50                push ax
00008955  52                push dx
00008956  33C0              xor ax,ax
00008958  E8C8FF            call 0x8923
0000895B  2EC70600000100    mov word [cs:0x0],0x1
00008962  2EA30200          mov [cs:0x2],ax
00008966  2EA30400          mov [cs:0x4],ax
0000896A  2EC606120000      mov byte [cs:0x12],0x0
00008970  8CD8              mov ax,ds
00008972  2EA30A00          mov [cs:0xa],ax
00008976  06                push es
00008977  B435              mov ah,0x35
00008979  B008              mov al,0x8
0000897B  CD21              int 0x21
0000897D  2E891E0600        mov [cs:0x6],bx
00008982  2E8C060800        mov [cs:0x8],es
00008987  07                pop es
00008988  1E                push ds
00008989  B425              mov ah,0x25
0000898B  B008              mov al,0x8
0000898D  BAAC00            mov dx,0xac
00008990  8CCB              mov bx,cs
00008992  8EDB              mov ds,bx
00008994  CD21              int 0x21
00008996  1F                pop ds
00008997  5A                pop dx
00008998  58                pop ax
00008999  CB                retf
0000899A  33C0              xor ax,ax
0000899C  E884FF            call 0x8923
0000899F  1E                push ds
000089A0  B425              mov ah,0x25
000089A2  B008              mov al,0x8
000089A4  2EC5160600        lds dx,[cs:0x6]
000089A9  CD21              int 0x21
000089AB  1F                pop ds
000089AC  CB                retf
000089AD  55                push bp
000089AE  8BEC              mov bp,sp
000089B0  9C                pushf
000089B1  FA                cli
000089B2  8B4606            mov ax,[bp+0x6]
000089B5  2EA31000          mov [cs:0x10],ax
000089B9  9D                popf
000089BA  5D                pop bp
000089BB  CB                retf
000089BC  50                push ax
000089BD  2EA10200          mov ax,[cs:0x2]
000089C1  2E01060400        add [cs:0x4],ax
000089C6  2EA10000          mov ax,[cs:0x0]
000089CA  150000            adc ax,0x0
000089CD  7507              jnz 0x89d6
000089CF  B020              mov al,0x20
000089D1  E620              out 0x20,al
000089D3  EB07              jmp short 0x89dc
000089D5  90                nop
000089D6  9C                pushf
000089D7  2EFF1E0600        call far [cs:0x6]
000089DC  2EFF0E1000        dec word [cs:0x10]
000089E1  7563              jnz 0x8a46
000089E3  2E803E120000      cmp byte [cs:0x12],0x0
000089E9  755B              jnz 0x8a46
000089EB  53                push bx
000089EC  51                push cx
000089ED  52                push dx
000089EE  1E                push ds
000089EF  06                push es
000089F0  56                push si
000089F1  57                push di
000089F2  55                push bp
000089F3  2E8C160C00        mov [cs:0xc],ss
000089F8  2E89260E00        mov [cs:0xe],sp
000089FD  2EA10A00          mov ax,[cs:0xa]
00008A01  8EC0              mov es,ax
00008A03  8ED8              mov ds,ax
00008A05  8ED0              mov ss,ax
00008A07  BC302E            mov sp,0x2e30
00008A0A  2EFE061200        inc byte [cs:0x12]
00008A0F  9AA002E808        call 0x8e8:0x2a0
00008A14  2EFE0E1200        dec byte [cs:0x12]
00008A19  2E8B1E1000        mov bx,[cs:0x10]
00008A1E  F7DB              neg bx
00008A20  3BD8              cmp bx,ax
00008A22  7209              jc 0x8a2d
00008A24  2EC70610000000    mov word [cs:0x10],0x0
00008A2B  EBDD              jmp short 0x8a0a
00008A2D  2E01061000        add [cs:0x10],ax
00008A32  2E8B1E0C00        mov bx,[cs:0xc]
00008A37  8ED3              mov ss,bx
00008A39  2E8B260E00        mov sp,[cs:0xe]
00008A3E  5D                pop bp
00008A3F  5F                pop di
00008A40  5E                pop si
00008A41  07                pop es
00008A42  1F                pop ds
00008A43  5A                pop dx
00008A44  59                pop cx
00008A45  5B                pop bx
00008A46  58                pop ax
00008A47  CF                iret
00008A48  55                push bp
00008A49  8BEC              mov bp,sp
00008A4B  83EC02            sub sp,byte +0x2
00008A4E  EB2D              jmp short 0x8a7d
00008A50  C41E2436          les bx,[0x3624]
00008A54  FF062436          inc word [0x3624]
00008A58  268A07            mov al,[es:bx]
00008A5B  B400              mov ah,0x0
00008A5D  8946FE            mov [bp-0x2],ax
00008A60  0BC0              or ax,ax
00008A62  7D05              jnl 0x8a69
00008A64  C746FE0000        mov word [bp-0x2],0x0
00008A69  B108              mov cl,0x8
00008A6B  2A0E4030          sub cl,[0x3040]
00008A6F  8B46FE            mov ax,[bp-0x2]
00008A72  D3E0              shl ax,cl
00008A74  09063E30          or [0x303e],ax
00008A78  8006403008        add byte [0x3040],0x8
00008A7D  803E403008        cmp byte [0x3040],0x8
00008A82  76CC              jna 0x8a50
00008A84  A13E30            mov ax,[0x303e]
00008A87  8946FE            mov [bp-0x2],ax
00008A8A  D1263E30          shl word [0x303e],1
00008A8E  FE0E4030          dec byte [0x3040]
00008A92  837EFE00          cmp word [bp-0x2],byte +0x0
00008A96  7D05              jnl 0x8a9d
00008A98  B80100            mov ax,0x1
00008A9B  EB02              jmp short 0x8a9f
00008A9D  33C0              xor ax,ax
00008A9F  EB00              jmp short 0x8aa1
00008AA1  8BE5              mov sp,bp
00008AA3  5D                pop bp
00008AA4  CB                retf
00008AA5  55                push bp
00008AA6  8BEC              mov bp,sp
00008AA8  83EC02            sub sp,byte +0x2
00008AAB  EB2D              jmp short 0x8ada
00008AAD  C41E2436          les bx,[0x3624]
00008AB1  FF062436          inc word [0x3624]
00008AB5  268A07            mov al,[es:bx]
00008AB8  B400              mov ah,0x0
00008ABA  8946FE            mov [bp-0x2],ax
00008ABD  0BC0              or ax,ax
00008ABF  7305              jnc 0x8ac6
00008AC1  C746FE0000        mov word [bp-0x2],0x0
00008AC6  B108              mov cl,0x8
00008AC8  2A0E4030          sub cl,[0x3040]
00008ACC  8B46FE            mov ax,[bp-0x2]
00008ACF  D3E0              shl ax,cl
00008AD1  09063E30          or [0x303e],ax
00008AD5  8006403008        add byte [0x3040],0x8
00008ADA  803E403008        cmp byte [0x3040],0x8
00008ADF  76CC              jna 0x8aad
00008AE1  A13E30            mov ax,[0x303e]
00008AE4  8946FE            mov [bp-0x2],ax
00008AE7  B108              mov cl,0x8
00008AE9  D3263E30          shl word [0x303e],cl
00008AED  802E403008        sub byte [0x3040],0x8
00008AF2  8B46FE            mov ax,[bp-0x2]
00008AF5  B108              mov cl,0x8
00008AF7  D3E8              shr ax,cl
00008AF9  EB00              jmp short 0x8afb
00008AFB  8BE5              mov sp,bp
00008AFD  5D                pop bp
00008AFE  CB                retf
00008AFF  55                push bp
00008B00  8BEC              mov bp,sp
00008B02  83EC04            sub sp,byte +0x4
00008B05  C746FC0000        mov word [bp-0x4],0x0
00008B0A  EB2D              jmp short 0x8b39
00008B0C  8B5EFC            mov bx,[bp-0x4]
00008B0F  D1E3              shl bx,1
00008B11  C787125B0100      mov word [bx+0x5b12],0x1
00008B17  8B46FC            mov ax,[bp-0x4]
00008B1A  057302            add ax,0x273
00008B1D  8B5EFC            mov bx,[bp-0x4]
00008B20  D1E3              shl bx,1
00008B22  89872A36          mov [bx+0x362a],ax
00008B26  8B46FC            mov ax,[bp-0x4]
00008B29  8B5EFC            mov bx,[bp-0x4]
00008B2C  81C37302          add bx,0x273
00008B30  D1E3              shl bx,1
00008B32  8987FA5F          mov [bx+0x5ffa],ax
00008B36  FF46FC            inc word [bp-0x4]
00008B39  817EFC3A01        cmp word [bp-0x4],0x13a
00008B3E  7CCC              jl 0x8b0c
00008B40  C746FC0000        mov word [bp-0x4],0x0
00008B45  C746FE3A01        mov word [bp-0x2],0x13a
00008B4A  EB45              jmp short 0x8b91
00008B4C  8B5EFC            mov bx,[bp-0x4]
00008B4F  D1E3              shl bx,1
00008B51  8B87125B          mov ax,[bx+0x5b12]
00008B55  8B5EFC            mov bx,[bp-0x4]
00008B58  43                inc bx
00008B59  D1E3              shl bx,1
00008B5B  0387125B          add ax,[bx+0x5b12]
00008B5F  8B5EFE            mov bx,[bp-0x2]
00008B62  D1E3              shl bx,1
00008B64  8987125B          mov [bx+0x5b12],ax
00008B68  8B46FC            mov ax,[bp-0x4]
00008B6B  8B5EFE            mov bx,[bp-0x2]
00008B6E  D1E3              shl bx,1
00008B70  89872A36          mov [bx+0x362a],ax
00008B74  8B46FE            mov ax,[bp-0x2]
00008B77  8B5EFC            mov bx,[bp-0x4]
00008B7A  43                inc bx
00008B7B  D1E3              shl bx,1
00008B7D  8987FA5F          mov [bx+0x5ffa],ax
00008B81  8B5EFC            mov bx,[bp-0x4]
00008B84  D1E3              shl bx,1
00008B86  8987FA5F          mov [bx+0x5ffa],ax
00008B8A  8346FC02          add word [bp-0x4],byte +0x2
00008B8E  FF46FE            inc word [bp-0x2]
00008B91  817EFE7202        cmp word [bp-0x2],0x272
00008B96  7EB4              jng 0x8b4c
00008B98  C706F85FFFFF      mov word [0x5ff8],0xffff
00008B9E  C706DE640000      mov word [0x64de],0x0
00008BA4  8BE5              mov sp,bp
00008BA6  5D                pop bp
00008BA7  CB                retf
00008BA8  55                push bp
00008BA9  8BEC              mov bp,sp
00008BAB  83EC0C            sub sp,byte +0xc
00008BAE  C746F60000        mov word [bp-0xa],0x0
00008BB3  C746F40000        mov word [bp-0xc],0x0
00008BB8  EB3A              jmp short 0x8bf4
00008BBA  8B5EF4            mov bx,[bp-0xc]
00008BBD  D1E3              shl bx,1
00008BBF  81BF2A367302      cmp word [bx+0x362a],0x273
00008BC5  7C2A              jl 0x8bf1
00008BC7  8B5EF4            mov bx,[bp-0xc]
00008BCA  D1E3              shl bx,1
00008BCC  8B87125B          mov ax,[bx+0x5b12]
00008BD0  40                inc ax
00008BD1  D1E8              shr ax,1
00008BD3  8B5EF6            mov bx,[bp-0xa]
00008BD6  D1E3              shl bx,1
00008BD8  8987125B          mov [bx+0x5b12],ax
00008BDC  8B5EF4            mov bx,[bp-0xc]
00008BDF  D1E3              shl bx,1
00008BE1  8B872A36          mov ax,[bx+0x362a]
00008BE5  8B5EF6            mov bx,[bp-0xa]
00008BE8  D1E3              shl bx,1
00008BEA  89872A36          mov [bx+0x362a],ax
00008BEE  FF46F6            inc word [bp-0xa]
00008BF1  FF46F4            inc word [bp-0xc]
00008BF4  817EF47302        cmp word [bp-0xc],0x273
00008BF9  7CBF              jl 0x8bba
00008BFB  C746F40000        mov word [bp-0xc],0x0
00008C00  C746F63A01        mov word [bp-0xa],0x13a
00008C05  E9C200            jmp 0x8cca
00008C08  8B46F4            mov ax,[bp-0xc]
00008C0B  40                inc ax
00008C0C  8946F8            mov [bp-0x8],ax
00008C0F  8B5EF4            mov bx,[bp-0xc]
00008C12  D1E3              shl bx,1
00008C14  8B87125B          mov ax,[bx+0x5b12]
00008C18  8B5EF8            mov bx,[bp-0x8]
00008C1B  D1E3              shl bx,1
00008C1D  0387125B          add ax,[bx+0x5b12]
00008C21  8B5EF6            mov bx,[bp-0xa]
00008C24  D1E3              shl bx,1
00008C26  8987125B          mov [bx+0x5b12],ax
00008C2A  8946FC            mov [bp-0x4],ax
00008C2D  8B46F6            mov ax,[bp-0xa]
00008C30  48                dec ax
00008C31  8946F8            mov [bp-0x8],ax
00008C34  EB03              jmp short 0x8c39
00008C36  FF4EF8            dec word [bp-0x8]
00008C39  8B5EF8            mov bx,[bp-0x8]
00008C3C  D1E3              shl bx,1
00008C3E  8B87125B          mov ax,[bx+0x5b12]
00008C42  3B46FC            cmp ax,[bp-0x4]
00008C45  77EF              ja 0x8c36
00008C47  FF46F8            inc word [bp-0x8]
00008C4A  8B46F6            mov ax,[bp-0xa]
00008C4D  2B46F8            sub ax,[bp-0x8]
00008C50  D1E0              shl ax,1
00008C52  8946FE            mov [bp-0x2],ax
00008C55  8B46FE            mov ax,[bp-0x2]
00008C58  48                dec ax
00008C59  8946FA            mov [bp-0x6],ax
00008C5C  EB1C              jmp short 0x8c7a
00008C5E  8B5EF8            mov bx,[bp-0x8]
00008C61  035EFA            add bx,[bp-0x6]
00008C64  D1E3              shl bx,1
00008C66  8B87125B          mov ax,[bx+0x5b12]
00008C6A  8B5EF8            mov bx,[bp-0x8]
00008C6D  035EFA            add bx,[bp-0x6]
00008C70  43                inc bx
00008C71  D1E3              shl bx,1
00008C73  8987125B          mov [bx+0x5b12],ax
00008C77  FF4EFA            dec word [bp-0x6]
00008C7A  837EFA00          cmp word [bp-0x6],byte +0x0
00008C7E  7CDE              jl 0x8c5e
00008C80  8B46FC            mov ax,[bp-0x4]
00008C83  8B5EF8            mov bx,[bp-0x8]
00008C86  D1E3              shl bx,1
00008C88  8987125B          mov [bx+0x5b12],ax
00008C8C  8B46FE            mov ax,[bp-0x2]
00008C8F  48                dec ax
00008C90  8946FA            mov [bp-0x6],ax
00008C93  EB1C              jmp short 0x8cb1
00008C95  8B5EF8            mov bx,[bp-0x8]
00008C98  035EFA            add bx,[bp-0x6]
00008C9B  D1E3              shl bx,1
00008C9D  8B872A36          mov ax,[bx+0x362a]
00008CA1  8B5EF8            mov bx,[bp-0x8]
00008CA4  035EFA            add bx,[bp-0x6]
00008CA7  43                inc bx
00008CA8  D1E3              shl bx,1
00008CAA  89872A36          mov [bx+0x362a],ax
00008CAE  FF4EFA            dec word [bp-0x6]
00008CB1  837EFA00          cmp word [bp-0x6],byte +0x0
00008CB5  7CDE              jl 0x8c95
00008CB7  8B46F4            mov ax,[bp-0xc]
00008CBA  8B5EF8            mov bx,[bp-0x8]
00008CBD  D1E3              shl bx,1
00008CBF  89872A36          mov [bx+0x362a],ax
00008CC3  8346F402          add word [bp-0xc],byte +0x2
00008CC7  FF46F6            inc word [bp-0xa]
00008CCA  817EF67302        cmp word [bp-0xa],0x273
00008CCF  7D03              jnl 0x8cd4
00008CD1  E934FF            jmp 0x8c08
00008CD4  C746F40000        mov word [bp-0xc],0x0
00008CD9  EB38              jmp short 0x8d13
00008CDB  8B5EF4            mov bx,[bp-0xc]
00008CDE  D1E3              shl bx,1
00008CE0  8B872A36          mov ax,[bx+0x362a]
00008CE4  8946F8            mov [bp-0x8],ax
00008CE7  3D7302            cmp ax,0x273
00008CEA  7C0E              jl 0x8cfa
00008CEC  8B46F4            mov ax,[bp-0xc]
00008CEF  8B5EF8            mov bx,[bp-0x8]
00008CF2  D1E3              shl bx,1
00008CF4  8987FA5F          mov [bx+0x5ffa],ax
00008CF8  EB16              jmp short 0x8d10
00008CFA  8B46F4            mov ax,[bp-0xc]
00008CFD  8B5EF8            mov bx,[bp-0x8]
00008D00  43                inc bx
00008D01  D1E3              shl bx,1
00008D03  8987FA5F          mov [bx+0x5ffa],ax
00008D07  8B5EF8            mov bx,[bp-0x8]
00008D0A  D1E3              shl bx,1
00008D0C  8987FA5F          mov [bx+0x5ffa],ax
00008D10  FF46F4            inc word [bp-0xc]
00008D13  817EF47302        cmp word [bp-0xc],0x273
00008D18  7CC1              jl 0x8cdb
00008D1A  8BE5              mov sp,bp
00008D1C  5D                pop bp
00008D1D  CB                retf
00008D1E  55                push bp
00008D1F  8BEC              mov bp,sp
00008D21  83EC08            sub sp,byte +0x8
00008D24  813EF65F0080      cmp word [0x5ff6],0x8000
00008D2A  7504              jnz 0x8d30
00008D2C  0E                push cs
00008D2D  E878FE            call 0x8ba8
00008D30  8B5E06            mov bx,[bp+0x6]
00008D33  81C37302          add bx,0x273
00008D37  D1E3              shl bx,1
00008D39  8B87FA5F          mov ax,[bx+0x5ffa]
00008D3D  894606            mov [bp+0x6],ax
00008D40  8B5E06            mov bx,[bp+0x6]
00008D43  D1E3              shl bx,1
00008D45  FF87125B          inc word [bx+0x5b12]
00008D49  8B87125B          mov ax,[bx+0x5b12]
00008D4D  8946FC            mov [bp-0x4],ax
00008D50  8B5E06            mov bx,[bp+0x6]
00008D53  43                inc bx
00008D54  895EFE            mov [bp-0x2],bx
00008D57  D1E3              shl bx,1
00008D59  8B87125B          mov ax,[bx+0x5b12]
00008D5D  3B46FC            cmp ax,[bp-0x4]
00008D60  7203              jc 0x8d65
00008D62  E9AA00            jmp 0x8e0f
00008D65  EB00              jmp short 0x8d67
00008D67  FF46FE            inc word [bp-0x2]
00008D6A  8B5EFE            mov bx,[bp-0x2]
00008D6D  D1E3              shl bx,1
00008D6F  8B87125B          mov ax,[bx+0x5b12]
00008D73  3B46FC            cmp ax,[bp-0x4]
00008D76  72EF              jc 0x8d67
00008D78  FF4EFE            dec word [bp-0x2]
00008D7B  8B5EFE            mov bx,[bp-0x2]
00008D7E  D1E3              shl bx,1
00008D80  8B87125B          mov ax,[bx+0x5b12]
00008D84  8B5E06            mov bx,[bp+0x6]
00008D87  D1E3              shl bx,1
00008D89  8987125B          mov [bx+0x5b12],ax
00008D8D  8B46FC            mov ax,[bp-0x4]
00008D90  8B5EFE            mov bx,[bp-0x2]
00008D93  D1E3              shl bx,1
00008D95  8987125B          mov [bx+0x5b12],ax
00008D99  8B5E06            mov bx,[bp+0x6]
00008D9C  D1E3              shl bx,1
00008D9E  8B872A36          mov ax,[bx+0x362a]
00008DA2  8946F8            mov [bp-0x8],ax
00008DA5  8B46FE            mov ax,[bp-0x2]
00008DA8  8B5EF8            mov bx,[bp-0x8]
00008DAB  D1E3              shl bx,1
00008DAD  8987FA5F          mov [bx+0x5ffa],ax
00008DB1  817EF87302        cmp word [bp-0x8],0x273
00008DB6  7D0D              jnl 0x8dc5
00008DB8  8B46FE            mov ax,[bp-0x2]
00008DBB  8B5EF8            mov bx,[bp-0x8]
00008DBE  43                inc bx
00008DBF  D1E3              shl bx,1
00008DC1  8987FA5F          mov [bx+0x5ffa],ax
00008DC5  8B5EFE            mov bx,[bp-0x2]
00008DC8  D1E3              shl bx,1
00008DCA  8B872A36          mov ax,[bx+0x362a]
00008DCE  8946FA            mov [bp-0x6],ax
00008DD1  8B46F8            mov ax,[bp-0x8]
00008DD4  8B5EFE            mov bx,[bp-0x2]
00008DD7  D1E3              shl bx,1
00008DD9  89872A36          mov [bx+0x362a],ax
00008DDD  8B4606            mov ax,[bp+0x6]
00008DE0  8B5EFA            mov bx,[bp-0x6]
00008DE3  D1E3              shl bx,1
00008DE5  8987FA5F          mov [bx+0x5ffa],ax
00008DE9  817EFA7302        cmp word [bp-0x6],0x273
00008DEE  7D0D              jnl 0x8dfd
00008DF0  8B4606            mov ax,[bp+0x6]
00008DF3  8B5EFA            mov bx,[bp-0x6]
00008DF6  43                inc bx
00008DF7  D1E3              shl bx,1
00008DF9  8987FA5F          mov [bx+0x5ffa],ax
00008DFD  8B46FA            mov ax,[bp-0x6]
00008E00  8B5E06            mov bx,[bp+0x6]
00008E03  D1E3              shl bx,1
00008E05  89872A36          mov [bx+0x362a],ax
00008E09  8B46FE            mov ax,[bp-0x2]
00008E0C  894606            mov [bp+0x6],ax
00008E0F  8B5E06            mov bx,[bp+0x6]
00008E12  D1E3              shl bx,1
00008E14  8B87FA5F          mov ax,[bx+0x5ffa]
00008E18  894606            mov [bp+0x6],ax
00008E1B  0BC0              or ax,ax
00008E1D  7403              jz 0x8e22
00008E1F  E91EFF            jmp 0x8d40
00008E22  8BE5              mov sp,bp
00008E24  5D                pop bp
00008E25  CB                retf
00008E26  55                push bp
00008E27  8BEC              mov bp,sp
00008E29  83EC02            sub sp,byte +0x2
00008E2C  A10E3B            mov ax,[0x3b0e]
00008E2F  8946FE            mov [bp-0x2],ax
00008E32  EB13              jmp short 0x8e47
00008E34  0E                push cs
00008E35  E810FC            call 0x8a48
00008E38  0146FE            add [bp-0x2],ax
00008E3B  8B5EFE            mov bx,[bp-0x2]
00008E3E  D1E3              shl bx,1
00008E40  8B872A36          mov ax,[bx+0x362a]
00008E44  8946FE            mov [bp-0x2],ax
00008E47  817EFE7302        cmp word [bp-0x2],0x273
00008E4C  72E6              jc 0x8e34
00008E4E  816EFE7302        sub word [bp-0x2],0x273
00008E53  FF76FE            push word [bp-0x2]
00008E56  0E                push cs
00008E57  E8C4FE            call 0x8d1e
00008E5A  59                pop cx
00008E5B  8B46FE            mov ax,[bp-0x2]
00008E5E  EB00              jmp short 0x8e60
00008E60  8BE5              mov sp,bp
00008E62  5D                pop bp
00008E63  CB                retf
00008E64  55                push bp
00008E65  8BEC              mov bp,sp
00008E67  83EC06            sub sp,byte +0x6
00008E6A  0E                push cs
00008E6B  E837FC            call 0x8aa5
00008E6E  8946FA            mov [bp-0x6],ax
00008E71  8B5EFA            mov bx,[bp-0x6]
00008E74  8A873E2E          mov al,[bx+0x2e3e]
00008E78  B400              mov ah,0x0
00008E7A  B106              mov cl,0x6
00008E7C  D3E0              shl ax,cl
00008E7E  8946FE            mov [bp-0x2],ax
00008E81  8B5EFA            mov bx,[bp-0x6]
00008E84  8A873E2F          mov al,[bx+0x2f3e]
00008E88  B400              mov ah,0x0
00008E8A  8946FC            mov [bp-0x4],ax
00008E8D  836EFC02          sub word [bp-0x4],byte +0x2
00008E91  EB0E              jmp short 0x8ea1
00008E93  0E                push cs
00008E94  E8B1FB            call 0x8a48
00008E97  8B56FA            mov dx,[bp-0x6]
00008E9A  D1E2              shl dx,1
00008E9C  03C2              add ax,dx
00008E9E  8946FA            mov [bp-0x6],ax
00008EA1  8B46FC            mov ax,[bp-0x4]
00008EA4  FF4EFC            dec word [bp-0x4]
00008EA7  0BC0              or ax,ax
00008EA9  75E8              jnz 0x8e93
00008EAB  8B46FA            mov ax,[bp-0x6]
00008EAE  253F00            and ax,0x3f
00008EB1  0B46FE            or ax,[bp-0x2]
00008EB4  EB00              jmp short 0x8eb6
00008EB6  8BE5              mov sp,bp
00008EB8  5D                pop bp
00008EB9  CB                retf
00008EBA  55                push bp
00008EBB  8BEC              mov bp,sp
00008EBD  83EC0E            sub sp,byte +0xe
00008EC0  8306243604        add word [0x3624],byte +0x4
00008EC5  0E                push cs
00008EC6  E836FC            call 0x8aff
00008EC9  C746F20000        mov word [bp-0xe],0x0
00008ECE  EB0B              jmp short 0x8edb
00008ED0  8B5EF2            mov bx,[bp-0xe]
00008ED3  C687546720        mov byte [bx+0x6754],0x20
00008ED8  FF46F2            inc word [bp-0xe]
00008EDB  817EF2C40F        cmp word [bp-0xe],0xfc4
00008EE0  7CEE              jl 0x8ed0
00008EE2  C746F8C40F        mov word [bp-0x8],0xfc4
00008EE7  C746FE0000        mov word [bp-0x2],0x0
00008EEC  C746FC0000        mov word [bp-0x4],0x0
00008EF1  E9CA00            jmp 0x8fbe
00008EF4  0E                push cs
00008EF5  E82EFF            call 0x8e26
00008EF8  8946FA            mov [bp-0x6],ax
00008EFB  817EFA0001        cmp word [bp-0x6],0x100
00008F00  7D30              jnl 0x8f32
00008F02  8A46FA            mov al,[bp-0x6]
00008F05  8B1E3028          mov bx,[0x2830]
00008F09  8EC3              mov es,bx
00008F0B  8B1E2E28          mov bx,[0x282e]
00008F0F  268807            mov [es:bx],al
00008F12  FF062E28          inc word [0x282e]
00008F16  8A46FA            mov al,[bp-0x6]
00008F19  8B5EF8            mov bx,[bp-0x8]
00008F1C  88875467          mov [bx+0x6754],al
00008F20  FF46F8            inc word [bp-0x8]
00008F23  8166F8FF0F        and word [bp-0x8],0xfff
00008F28  8346FC01          add word [bp-0x4],byte +0x1
00008F2C  8356FE00          adc word [bp-0x2],byte +0x0
00008F30  EB6D              jmp short 0x8f9f
00008F32  0E                push cs
00008F33  E82EFF            call 0x8e64
00008F36  8B56F8            mov dx,[bp-0x8]
00008F39  2BD0              sub dx,ax
00008F3B  4A                dec dx
00008F3C  81E2FF0F          and dx,0xfff
00008F40  8956F2            mov [bp-0xe],dx
00008F43  8B46FA            mov ax,[bp-0x6]
00008F46  0503FF            add ax,0xff03
00008F49  8946F4            mov [bp-0xc],ax
00008F4C  C746F60000        mov word [bp-0xa],0x0
00008F51  EB44              jmp short 0x8f97
00008F53  8B5EF2            mov bx,[bp-0xe]
00008F56  035EF6            add bx,[bp-0xa]
00008F59  81E3FF0F          and bx,0xfff
00008F5D  8A875467          mov al,[bx+0x6754]
00008F61  B400              mov ah,0x0
00008F63  8946FA            mov [bp-0x6],ax
00008F66  8A46FA            mov al,[bp-0x6]
00008F69  8B1E3028          mov bx,[0x2830]
00008F6D  8EC3              mov es,bx
00008F6F  8B1E2E28          mov bx,[0x282e]
00008F73  268807            mov [es:bx],al
00008F76  FF062E28          inc word [0x282e]
00008F7A  8A46FA            mov al,[bp-0x6]
00008F7D  8B5EF8            mov bx,[bp-0x8]
00008F80  88875467          mov [bx+0x6754],al
00008F84  FF46F8            inc word [bp-0x8]
00008F87  8166F8FF0F        and word [bp-0x8],0xfff
00008F8C  8346FC01          add word [bp-0x4],byte +0x1
00008F90  8356FE00          adc word [bp-0x2],byte +0x0
00008F94  FF46F6            inc word [bp-0xa]
00008F97  8B46F6            mov ax,[bp-0xa]
00008F9A  3B46F4            cmp ax,[bp-0xc]
00008F9D  7CB4              jl 0x8f53
00008F9F  8B56FE            mov dx,[bp-0x2]
00008FA2  8B46FC            mov ax,[bp-0x4]
00008FA5  3B163C2E          cmp dx,[0x2e3c]
00008FA9  7213              jc 0x8fbe
00008FAB  7706              ja 0x8fb3
00008FAD  3B063A2E          cmp ax,[0x2e3a]
00008FB1  760B              jna 0x8fbe
00008FB3  81063A2E0004      add word [0x2e3a],0x400
00008FB9  83163C2E00        adc word [0x2e3c],byte +0x0
00008FBE  8B56FE            mov dx,[bp-0x2]
00008FC1  8B46FC            mov ax,[bp-0x4]
00008FC4  3B16342E          cmp dx,[0x2e34]
00008FC8  7303              jnc 0x8fcd
00008FCA  E927FF            jmp 0x8ef4
00008FCD  7509              jnz 0x8fd8
00008FCF  3B06322E          cmp ax,[0x2e32]
00008FD3  7303              jnc 0x8fd8
00008FD5  E91CFF            jmp 0x8ef4
00008FD8  8B46FC            mov ax,[bp-0x4]
00008FDB  A33228            mov [0x2832],ax
00008FDE  8BE5              mov sp,bp
00008FE0  5D                pop bp
00008FE1  CB                retf
00008FE2  55                push bp
00008FE3  8BEC              mov bp,sp
00008FE5  83EC04            sub sp,byte +0x4
00008FE8  8946FC            mov [bp-0x4],ax
00008FEB  8956FE            mov [bp-0x2],dx
00008FEE  C706382E0000      mov word [0x2e38],0x0
00008FF4  C706362E0000      mov word [0x2e36],0x0
00008FFA  C7063C2E0000      mov word [0x2e3c],0x0
00009000  C7063A2E0000      mov word [0x2e3a],0x0
00009006  C7063E300000      mov word [0x303e],0x0
0000900C  C606403000        mov byte [0x3040],0x0
00009011  C70641300000      mov word [0x3041],0x0
00009017  C606433000        mov byte [0x3043],0x0
0000901C  8B46FE            mov ax,[bp-0x2]
0000901F  33D2              xor dx,dx
00009021  8BD0              mov dx,ax
00009023  33C0              xor ax,ax
00009025  8B5EFC            mov bx,[bp-0x4]
00009028  33C9              xor cx,cx
0000902A  03C3              add ax,bx
0000902C  13D1              adc dx,cx
0000902E  8916342E          mov [0x2e34],dx
00009032  A3322E            mov [0x2e32],ax
00009035  8B162C28          mov dx,[0x282c]
00009039  A12A28            mov ax,[0x282a]
0000903C  89162636          mov [0x3626],dx
00009040  A32436            mov [0x3624],ax
00009043  0E                push cs
00009044  E873FE            call 0x8eba
00009047  8BE5              mov sp,bp
00009049  5D                pop bp
0000904A  CB                retf
0000904B  55                push bp
0000904C  8BEC              mov bp,sp
0000904E  56                push si
0000904F  8B7606            mov si,[bp+0x6]
00009052  0BF6              or si,si
00009054  7C14              jl 0x906a
00009056  83FE58            cmp si,byte +0x58
00009059  7603              jna 0x905e
0000905B  BE5700            mov si,0x57
0000905E  89364430          mov [0x3044],si
00009062  8A844630          mov al,[si+0x3046]
00009066  98                cbw
00009067  96                xchg ax,si
00009068  EB0D              jmp short 0x9077
0000906A  F7DE              neg si
0000906C  83FE23            cmp si,byte +0x23
0000906F  77EA              ja 0x905b
00009071  C7064430FFFF      mov word [0x3044],0xffff
00009077  8BC6              mov ax,si
00009079  A37F00            mov [0x7f],ax
0000907C  B8FFFF            mov ax,0xffff
0000907F  EB00              jmp short 0x9081
00009081  5E                pop si
00009082  5D                pop bp
00009083  CA0200            retf 0x2
00009086  CB                retf
00009087  55                push bp
00009088  8BEC              mov bp,sp
0000908A  EB0C              jmp short 0x9098
0000908C  8B1EAE30          mov bx,[0x30ae]
00009090  D1E3              shl bx,1
00009092  D1E3              shl bx,1
00009094  FF9F9477          call far [bx+0x7794]
00009098  A1AE30            mov ax,[0x30ae]
0000909B  FF0EAE30          dec word [0x30ae]
0000909F  0BC0              or ax,ax
000090A1  75E9              jnz 0x908c
000090A3  FF1EA030          call far [0x30a0]
000090A7  FF1EA430          call far [0x30a4]
000090AB  FF1EA830          call far [0x30a8]
000090AF  FF7606            push word [bp+0x6]
000090B2  9A0D010000        call 0x0:0x10d
000090B7  59                pop cx
000090B8  5D                pop bp
000090B9  CB                retf
000090BA  55                push bp
000090BB  8BEC              mov bp,sp
000090BD  833EAE3020        cmp word [0x30ae],byte +0x20
000090C2  7505              jnz 0x90c9
000090C4  B80100            mov ax,0x1
000090C7  EB1E              jmp short 0x90e7
000090C9  8B5608            mov dx,[bp+0x8]
000090CC  8B4606            mov ax,[bp+0x6]
000090CF  8B1EAE30          mov bx,[0x30ae]
000090D3  D1E3              shl bx,1
000090D5  D1E3              shl bx,1
000090D7  89979677          mov [bx+0x7796],dx
000090DB  89879477          mov [bx+0x7794],ax
000090DF  FF06AE30          inc word [0x30ae]
000090E3  33C0              xor ax,ax
000090E5  EB00              jmp short 0x90e7
000090E7  5D                pop bp
000090E8  CB                retf
000090E9  55                push bp
000090EA  8BEC              mov bp,sp
000090EC  8B4606            mov ax,[bp+0x6]
000090EF  33D2              xor dx,dx
000090F1  52                push dx
000090F2  50                push ax
000090F3  9A0A02E909        call 0x9e9:0x20a
000090F8  8BE5              mov sp,bp
000090FA  EB00              jmp short 0x90fc
000090FC  5D                pop bp
000090FD  CB                retf
000090FE  55                push bp
000090FF  8BEC              mov bp,sp
00009101  83EC04            sub sp,byte +0x4
00009104  C45E06            les bx,[bp+0x6]
00009107  268B570E          mov dx,[es:bx+0xe]
0000910B  268B470C          mov ax,[es:bx+0xc]
0000910F  8916BA30          mov [0x30ba],dx
00009113  A3B830            mov [0x30b8],ax
00009116  8B4E08            mov cx,[bp+0x8]
00009119  8B5E06            mov bx,[bp+0x6]
0000911C  9AF1030000        call 0x0:0x3f1
00009121  750E              jnz 0x9131
00009123  C706BA300000      mov word [0x30ba],0x0
00009129  C706B8300000      mov word [0x30b8],0x0
0000912F  EB31              jmp short 0x9162
00009131  C45E06            les bx,[bp+0x6]
00009134  26C45F08          les bx,[es:bx+0x8]
00009138  8C46FE            mov [bp-0x2],es
0000913B  895EFC            mov [bp-0x4],bx
0000913E  8B56FE            mov dx,[bp-0x2]
00009141  8B46FC            mov ax,[bp-0x4]
00009144  C41EB830          les bx,[0x30b8]
00009148  2689570A          mov [es:bx+0xa],dx
0000914C  26894708          mov [es:bx+0x8],ax
00009150  8B16BA30          mov dx,[0x30ba]
00009154  A1B830            mov ax,[0x30b8]
00009157  C45EFC            les bx,[bp-0x4]
0000915A  2689570E          mov [es:bx+0xe],dx
0000915E  2689470C          mov [es:bx+0xc],ax
00009162  8BE5              mov sp,bp
00009164  5D                pop bp
00009165  CB                retf
00009166  55                push bp
00009167  8BEC              mov bp,sp
00009169  83EC04            sub sp,byte +0x4
0000916C  8B560C            mov dx,[bp+0xc]
0000916F  8B460A            mov ax,[bp+0xa]
00009172  C45E06            les bx,[bp+0x6]
00009175  262907            sub [es:bx],ax
00009178  26195702          sbb [es:bx+0x2],dx
0000917C  C45E06            les bx,[bp+0x6]
0000917F  268B4F02          mov cx,[es:bx+0x2]
00009183  268B1F            mov bx,[es:bx]
00009186  8B5608            mov dx,[bp+0x8]
00009189  8B4606            mov ax,[bp+0x6]
0000918C  9A96030000        call 0x0:0x396
00009191  8956FE            mov [bp-0x2],dx
00009194  8946FC            mov [bp-0x4],ax
00009197  8B560C            mov dx,[bp+0xc]
0000919A  8B460A            mov ax,[bp+0xa]
0000919D  050100            add ax,0x1
000091A0  83D200            adc dx,byte +0x0
000091A3  C45EFC            les bx,[bp-0x4]
000091A6  26895702          mov [es:bx+0x2],dx
000091AA  268907            mov [es:bx],ax
000091AD  8B5608            mov dx,[bp+0x8]
000091B0  8B4606            mov ax,[bp+0x6]
000091B3  C45EFC            les bx,[bp-0x4]
000091B6  26895706          mov [es:bx+0x6],dx
000091BA  26894704          mov [es:bx+0x4],ax
000091BE  8B4E08            mov cx,[bp+0x8]
000091C1  8B5E06            mov bx,[bp+0x6]
000091C4  8B16B630          mov dx,[0x30b6]
000091C8  A1B430            mov ax,[0x30b4]
000091CB  9AF1030000        call 0x0:0x3f1
000091D0  750D              jnz 0x91df
000091D2  C45EFC            les bx,[bp-0x4]
000091D5  8C06B630          mov [0x30b6],es
000091D9  891EB430          mov [0x30b4],bx
000091DD  EB28              jmp short 0x9207
000091DF  8B56FE            mov dx,[bp-0x2]
000091E2  8B46FC            mov ax,[bp-0x4]
000091E5  8B4E0C            mov cx,[bp+0xc]
000091E8  8B5E0A            mov bx,[bp+0xa]
000091EB  9A96030000        call 0x0:0x396
000091F0  895608            mov [bp+0x8],dx
000091F3  894606            mov [bp+0x6],ax
000091F6  8B56FE            mov dx,[bp-0x2]
000091F9  8B46FC            mov ax,[bp-0x4]
000091FC  C45E06            les bx,[bp+0x6]
000091FF  26895706          mov [es:bx+0x6],dx
00009203  26894704          mov [es:bx+0x4],ax
00009207  8B56FE            mov dx,[bp-0x2]
0000920A  8B46FC            mov ax,[bp-0x4]
0000920D  050800            add ax,0x8
00009210  EB00              jmp short 0x9212
00009212  8BE5              mov sp,bp
00009214  5D                pop bp
00009215  CB                retf
00009216  55                push bp
00009217  8BEC              mov bp,sp
00009219  83EC04            sub sp,byte +0x4
0000921C  FF7608            push word [bp+0x8]
0000921F  FF7606            push word [bp+0x6]
00009222  9AE0001A0A        call 0xa1a:0xe0
00009227  59                pop cx
00009228  59                pop cx
00009229  8956FE            mov [bp-0x2],dx
0000922C  8946FC            mov [bp-0x4],ax
0000922F  837EFEFF          cmp word [bp-0x2],byte -0x1
00009233  750C              jnz 0x9241
00009235  837EFCFF          cmp word [bp-0x4],byte -0x1
00009239  7506              jnz 0x9241
0000923B  33D2              xor dx,dx
0000923D  33C0              xor ax,ax
0000923F  EB3F              jmp short 0x9280
00009241  8B16B630          mov dx,[0x30b6]
00009245  A1B430            mov ax,[0x30b4]
00009248  C45EFC            les bx,[bp-0x4]
0000924B  26895706          mov [es:bx+0x6],dx
0000924F  26894704          mov [es:bx+0x4],ax
00009253  8B5608            mov dx,[bp+0x8]
00009256  8B4606            mov ax,[bp+0x6]
00009259  050100            add ax,0x1
0000925C  83D200            adc dx,byte +0x0
0000925F  C45EFC            les bx,[bp-0x4]
00009262  26895702          mov [es:bx+0x2],dx
00009266  268907            mov [es:bx],ax
00009269  C45EFC            les bx,[bp-0x4]
0000926C  8C06B630          mov [0x30b6],es
00009270  891EB430          mov [0x30b4],bx
00009274  8B16B630          mov dx,[0x30b6]
00009278  A1B430            mov ax,[0x30b4]
0000927B  050800            add ax,0x8
0000927E  EB00              jmp short 0x9280
00009280  8BE5              mov sp,bp
00009282  5D                pop bp
00009283  CB                retf
00009284  55                push bp
00009285  8BEC              mov bp,sp
00009287  83EC04            sub sp,byte +0x4
0000928A  FF7608            push word [bp+0x8]
0000928D  FF7606            push word [bp+0x6]
00009290  9AE0001A0A        call 0xa1a:0xe0
00009295  59                pop cx
00009296  59                pop cx
00009297  8956FE            mov [bp-0x2],dx
0000929A  8946FC            mov [bp-0x4],ax
0000929D  837EFEFF          cmp word [bp-0x2],byte -0x1
000092A1  750C              jnz 0x92af
000092A3  837EFCFF          cmp word [bp-0x4],byte -0x1
000092A7  7506              jnz 0x92af
000092A9  33D2              xor dx,dx
000092AB  33C0              xor ax,ax
000092AD  EB37              jmp short 0x92e6
000092AF  C45EFC            les bx,[bp-0x4]
000092B2  8C06B230          mov [0x30b2],es
000092B6  891EB030          mov [0x30b0],bx
000092BA  C45EFC            les bx,[bp-0x4]
000092BD  8C06B630          mov [0x30b6],es
000092C1  891EB430          mov [0x30b4],bx
000092C5  8B5608            mov dx,[bp+0x8]
000092C8  8B4606            mov ax,[bp+0x6]
000092CB  050100            add ax,0x1
000092CE  83D200            adc dx,byte +0x0
000092D1  C45EFC            les bx,[bp-0x4]
000092D4  26895702          mov [es:bx+0x2],dx
000092D8  268907            mov [es:bx],ax
000092DB  8B56FE            mov dx,[bp-0x2]
000092DE  8B46FC            mov ax,[bp-0x4]
000092E1  050800            add ax,0x8
000092E4  EB00              jmp short 0x92e6
000092E6  8BE5              mov sp,bp
000092E8  5D                pop bp
000092E9  CB                retf
000092EA  55                push bp
000092EB  8BEC              mov bp,sp
000092ED  83EC04            sub sp,byte +0x4
000092F0  8B4606            mov ax,[bp+0x6]
000092F3  0B4608            or ax,[bp+0x8]
000092F6  7507              jnz 0x92ff
000092F8  33D2              xor dx,dx
000092FA  33C0              xor ax,ax
000092FC  E9F600            jmp 0x93f5
000092FF  8B5608            mov dx,[bp+0x8]
00009302  8B4606            mov ax,[bp+0x6]
00009305  051700            add ax,0x17
00009308  83D200            adc dx,byte +0x0
0000930B  25F0FF            and ax,0xfff0
0000930E  81E2FFFF          and dx,0xffff
00009312  895608            mov [bp+0x8],dx
00009315  894606            mov [bp+0x6],ax
00009318  33C9              xor cx,cx
0000931A  33DB              xor bx,bx
0000931C  8B16B230          mov dx,[0x30b2]
00009320  A1B030            mov ax,[0x30b0]
00009323  9AF1030000        call 0x0:0x3f1
00009328  750F              jnz 0x9339
0000932A  FF7608            push word [bp+0x8]
0000932D  FF7606            push word [bp+0x6]
00009330  0E                push cs
00009331  E850FF            call 0x9284
00009334  59                pop cx
00009335  59                pop cx
00009336  E9BC00            jmp 0x93f5
00009339  8B16BA30          mov dx,[0x30ba]
0000933D  A1B830            mov ax,[0x30b8]
00009340  8956FE            mov [bp-0x2],dx
00009343  8946FC            mov [bp-0x4],ax
00009346  33C9              xor cx,cx
00009348  33DB              xor bx,bx
0000934A  9AF1030000        call 0x0:0x3f1
0000934F  7503              jnz 0x9354
00009351  E99300            jmp 0x93e7
00009354  C45EFC            les bx,[bp-0x4]
00009357  268B5702          mov dx,[es:bx+0x2]
0000935B  268B07            mov ax,[es:bx]
0000935E  8B4E08            mov cx,[bp+0x8]
00009361  8B5E06            mov bx,[bp+0x6]
00009364  83C330            add bx,byte +0x30
00009367  83D100            adc cx,byte +0x0
0000936A  3BD1              cmp dx,cx
0000936C  721B              jc 0x9389
0000936E  7504              jnz 0x9374
00009370  3BC3              cmp ax,bx
00009372  7215              jc 0x9389
00009374  FF7608            push word [bp+0x8]
00009377  FF7606            push word [bp+0x6]
0000937A  FF76FE            push word [bp-0x2]
0000937D  FF76FC            push word [bp-0x4]
00009380  0E                push cs
00009381  E8E2FD            call 0x9166
00009384  83C408            add sp,byte +0x8
00009387  EB6C              jmp short 0x93f5
00009389  C45EFC            les bx,[bp-0x4]
0000938C  268B5702          mov dx,[es:bx+0x2]
00009390  268B07            mov ax,[es:bx]
00009393  3B5608            cmp dx,[bp+0x8]
00009396  722A              jc 0x93c2
00009398  7505              jnz 0x939f
0000939A  3B4606            cmp ax,[bp+0x6]
0000939D  7223              jc 0x93c2
0000939F  FF76FE            push word [bp-0x2]
000093A2  FF76FC            push word [bp-0x4]
000093A5  0E                push cs
000093A6  E855FD            call 0x90fe
000093A9  59                pop cx
000093AA  59                pop cx
000093AB  C45EFC            les bx,[bp-0x4]
000093AE  26830701          add word [es:bx],byte +0x1
000093B2  2683570200        adc word [es:bx+0x2],byte +0x0
000093B7  8B56FE            mov dx,[bp-0x2]
000093BA  8B46FC            mov ax,[bp-0x4]
000093BD  050800            add ax,0x8
000093C0  EB33              jmp short 0x93f5
000093C2  C45EFC            les bx,[bp-0x4]
000093C5  26C45F0C          les bx,[es:bx+0xc]
000093C9  8C46FE            mov [bp-0x2],es
000093CC  895EFC            mov [bp-0x4],bx
000093CF  8B0EBA30          mov cx,[0x30ba]
000093D3  8B1EB830          mov bx,[0x30b8]
000093D7  8B56FE            mov dx,[bp-0x2]
000093DA  8B46FC            mov ax,[bp-0x4]
000093DD  9AF1030000        call 0x0:0x3f1
000093E2  7403              jz 0x93e7
000093E4  E96DFF            jmp 0x9354
000093E7  FF7608            push word [bp+0x8]
000093EA  FF7606            push word [bp+0x6]
000093ED  0E                push cs
000093EE  E825FE            call 0x9216
000093F1  59                pop cx
000093F2  59                pop cx
000093F3  EB00              jmp short 0x93f5
000093F5  8BE5              mov sp,bp
000093F7  5D                pop bp
000093F8  CB                retf
000093F9  55                push bp
000093FA  8BEC              mov bp,sp
000093FC  56                push si
000093FD  57                push di
000093FE  8B7606            mov si,[bp+0x6]
00009401  46                inc si
00009402  2B367B00          sub si,[0x7b]
00009406  8BC6              mov ax,si
00009408  053F00            add ax,0x3f
0000940B  B106              mov cl,0x6
0000940D  D3E8              shr ax,cl
0000940F  8BF0              mov si,ax
00009411  3B36BC30          cmp si,[0x30bc]
00009415  7510              jnz 0x9427
00009417  C45E04            les bx,[bp+0x4]
0000941A  8C068D00          mov [0x8d],es
0000941E  891E8B00          mov [0x8b],bx
00009422  B80100            mov ax,0x1
00009425  EB5C              jmp short 0x9483
00009427  B106              mov cl,0x6
00009429  D3E6              shl si,cl
0000942B  8B3E9100          mov di,[0x91]
0000942F  8BC6              mov ax,si
00009431  03067B00          add ax,[0x7b]
00009435  3BC7              cmp ax,di
00009437  7606              jna 0x943f
00009439  8BF7              mov si,di
0000943B  2B367B00          sub si,[0x7b]
0000943F  56                push si
00009440  FF367B00          push word [0x7b]
00009444  9A0B002F0A        call 0xa2f:0xb
00009449  59                pop cx
0000944A  59                pop cx
0000944B  8BF8              mov di,ax
0000944D  83FFFF            cmp di,byte -0x1
00009450  751B              jnz 0x946d
00009452  8BC6              mov ax,si
00009454  B106              mov cl,0x6
00009456  D3E8              shr ax,cl
00009458  A3BC30            mov [0x30bc],ax
0000945B  C45E04            les bx,[bp+0x4]
0000945E  8C068D00          mov [0x8d],es
00009462  891E8B00          mov [0x8b],bx
00009466  B80100            mov ax,0x1
00009469  EB18              jmp short 0x9483
0000946B  EB16              jmp short 0x9483
0000946D  A17B00            mov ax,[0x7b]
00009470  03C7              add ax,di
00009472  33D2              xor dx,dx
00009474  8BD0              mov dx,ax
00009476  33C0              xor ax,ax
00009478  89169100          mov [0x91],dx
0000947C  A38F00            mov [0x8f],ax
0000947F  33C0              xor ax,ax
00009481  EB00              jmp short 0x9483
00009483  5F                pop di
00009484  5E                pop si
00009485  5D                pop bp
00009486  C20400            ret 0x4
00009489  55                push bp
0000948A  8BEC              mov bp,sp
0000948C  8B0E8900          mov cx,[0x89]
00009490  8B1E8700          mov bx,[0x87]
00009494  8B5608            mov dx,[bp+0x8]
00009497  8B4606            mov ax,[bp+0x6]
0000949A  9AF1030000        call 0x0:0x3f1
0000949F  7222              jc 0x94c3
000094A1  8B0E9100          mov cx,[0x91]
000094A5  8B1E8F00          mov bx,[0x8f]
000094A9  8B5608            mov dx,[bp+0x8]
000094AC  8B4606            mov ax,[bp+0x6]
000094AF  9AF1030000        call 0x0:0x3f1
000094B4  770D              ja 0x94c3
000094B6  FF7608            push word [bp+0x8]
000094B9  FF7606            push word [bp+0x6]
000094BC  E83AFF            call 0x93f9
000094BF  0BC0              or ax,ax
000094C1  7507              jnz 0x94ca
000094C3  B8FFFF            mov ax,0xffff
000094C6  EB06              jmp short 0x94ce
000094C8  EB04              jmp short 0x94ce
000094CA  33C0              xor ax,ax
000094CC  EB00              jmp short 0x94ce
000094CE  5D                pop bp
000094CF  CB                retf
000094D0  55                push bp
000094D1  8BEC              mov bp,sp
000094D3  83EC08            sub sp,byte +0x8
000094D6  8B168D00          mov dx,[0x8d]
000094DA  A18B00            mov ax,[0x8b]
000094DD  8B4E08            mov cx,[bp+0x8]
000094E0  8B5E06            mov bx,[bp+0x6]
000094E3  9A96030000        call 0x0:0x396
000094E8  8956FA            mov [bp-0x6],dx
000094EB  8946F8            mov [bp-0x8],ax
000094EE  8B0E8900          mov cx,[0x89]
000094F2  8B1E8700          mov bx,[0x87]
000094F6  8B56FA            mov dx,[bp-0x6]
000094F9  8B46F8            mov ax,[bp-0x8]
000094FC  9AF1030000        call 0x0:0x3f1
00009501  7215              jc 0x9518
00009503  8B0E9100          mov cx,[0x91]
00009507  8B1E8F00          mov bx,[0x8f]
0000950B  8B56FA            mov dx,[bp-0x6]
0000950E  8B46F8            mov ax,[bp-0x8]
00009511  9AF1030000        call 0x0:0x3f1
00009516  7608              jna 0x9520
00009518  BAFFFF            mov dx,0xffff
0000951B  B8FFFF            mov ax,0xffff
0000951E  EB27              jmp short 0x9547
00009520  C41E8B00          les bx,[0x8b]
00009524  8C46FE            mov [bp-0x2],es
00009527  895EFC            mov [bp-0x4],bx
0000952A  FF76FA            push word [bp-0x6]
0000952D  FF76F8            push word [bp-0x8]
00009530  E8C6FE            call 0x93f9
00009533  0BC0              or ax,ax
00009535  7508              jnz 0x953f
00009537  BAFFFF            mov dx,0xffff
0000953A  B8FFFF            mov ax,0xffff
0000953D  EB08              jmp short 0x9547
0000953F  8B56FE            mov dx,[bp-0x2]
00009542  8B46FC            mov ax,[bp-0x4]
00009545  EB00              jmp short 0x9547
00009547  8BE5              mov sp,bp
00009549  5D                pop bp
0000954A  CB                retf
0000954B  55                push bp
0000954C  8BEC              mov bp,sp
0000954E  B44A              mov ah,0x4a
00009550  8B5E08            mov bx,[bp+0x8]
00009553  8E4606            mov es,[bp+0x6]
00009556  CD21              int 0x21
00009558  7205              jc 0x955f
0000955A  B8FFFF            mov ax,0xffff
0000955D  EB0A              jmp short 0x9569
0000955F  53                push bx
00009560  50                push ax
00009561  9A0B00DF09        call 0x9df:0xb
00009566  58                pop ax
00009567  EB00              jmp short 0x9569
00009569  5D                pop bp
0000956A  CB                retf
0000956B  55                push bp
0000956C  8BEC              mov bp,sp
0000956E  56                push si
0000956F  57                push di
00009570  8CDA              mov dx,ds
00009572  C47E06            les di,[bp+0x6]
00009575  C5760A            lds si,[bp+0xa]
00009578  8B4E0E            mov cx,[bp+0xe]
0000957B  D1E9              shr cx,1
0000957D  FC                cld
0000957E  F3A5              rep movsw
00009580  7301              jnc 0x9583
00009582  A4                movsb
00009583  8EDA              mov ds,dx
00009585  8B5608            mov dx,[bp+0x8]
00009588  8B4606            mov ax,[bp+0x6]
0000958B  EB00              jmp short 0x958d
0000958D  5F                pop di
0000958E  5E                pop si
0000958F  5D                pop bp
00009590  CB                retf
00009591  55                push bp
00009592  8BEC              mov bp,sp
00009594  56                push si
00009595  57                push di
00009596  1E                push ds
00009597  8B4E0C            mov cx,[bp+0xc]
0000959A  8B5E0A            mov bx,[bp+0xa]
0000959D  8B5608            mov dx,[bp+0x8]
000095A0  8B4606            mov ax,[bp+0x6]
000095A3  9AF1030000        call 0x0:0x3f1
000095A8  7306              jnc 0x95b0
000095AA  FD                std
000095AB  B80100            mov ax,0x1
000095AE  EB03              jmp short 0x95b3
000095B0  FC                cld
000095B1  33C0              xor ax,ax
000095B3  C57606            lds si,[bp+0x6]
000095B6  C47E0A            les di,[bp+0xa]
000095B9  8B4E0E            mov cx,[bp+0xe]
000095BC  0BC0              or ax,ax
000095BE  7406              jz 0x95c6
000095C0  03F1              add si,cx
000095C2  4E                dec si
000095C3  03F9              add di,cx
000095C5  4F                dec di
000095C6  F7C70100          test di,0x1
000095CA  7404              jz 0x95d0
000095CC  E311              jcxz 0x95df
000095CE  A4                movsb
000095CF  49                dec cx
000095D0  2BF0              sub si,ax
000095D2  2BF8              sub di,ax
000095D4  D1E9              shr cx,1
000095D6  F3A5              rep movsw
000095D8  7305              jnc 0x95df
000095DA  03F0              add si,ax
000095DC  03F8              add di,ax
000095DE  A4                movsb
000095DF  FC                cld
000095E0  1F                pop ds
000095E1  5F                pop di
000095E2  5E                pop si
000095E3  5D                pop bp
000095E4  CB                retf
000095E5  55                push bp
000095E6  8BEC              mov bp,sp
000095E8  FF760E            push word [bp+0xe]
000095EB  FF7608            push word [bp+0x8]
000095EE  FF7606            push word [bp+0x6]
000095F1  FF760C            push word [bp+0xc]
000095F4  FF760A            push word [bp+0xa]
000095F7  0E                push cs
000095F8  E896FF            call 0x9591
000095FB  8BE5              mov sp,bp
000095FD  8B5608            mov dx,[bp+0x8]
00009600  8B4606            mov ax,[bp+0x6]
00009603  5D                pop bp
00009604  CB                retf
00009605  55                push bp
00009606  8BEC              mov bp,sp
00009608  83EC04            sub sp,byte +0x4
0000960B  32E4              xor ah,ah
0000960D  CD1A              int 0x1a
0000960F  00061478          add [0x7814],al
00009613  8956FC            mov [bp-0x4],dx
00009616  894EFE            mov [bp-0x2],cx
00009619  803E147800        cmp byte [0x7814],0x0
0000961E  7409              jz 0x9629
00009620  8146FCB000        add word [bp-0x4],0xb0
00009625  8356FE18          adc word [bp-0x2],byte +0x18
00009629  8B56FE            mov dx,[bp-0x2]
0000962C  8B46FC            mov ax,[bp-0x4]
0000962F  2B068300          sub ax,[0x83]
00009633  1B168500          sbb dx,[0x85]
00009637  EB00              jmp short 0x9639
00009639  8BE5              mov sp,bp
0000963B  5D                pop bp
0000963C  CB                retf
0000963D  55                push bp
0000963E  8BEC              mov bp,sp
00009640  8B5E06            mov bx,[bp+0x6]
00009643  B8DD34            mov ax,0x34dd
00009646  BA1200            mov dx,0x12
00009649  3BD3              cmp dx,bx
0000964B  731A              jnc 0x9667
0000964D  F7F3              div bx
0000964F  8BD8              mov bx,ax
00009651  E461              in al,0x61
00009653  A803              test al,0x3
00009655  7508              jnz 0x965f
00009657  0C03              or al,0x3
00009659  E661              out 0x61,al
0000965B  B0B6              mov al,0xb6
0000965D  E643              out 0x43,al
0000965F  8AC3              mov al,bl
00009661  E642              out 0x42,al
00009663  8AC7              mov al,bh
00009665  E642              out 0x42,al
00009667  5D                pop bp
00009668  CB                retf
00009669  E461              in al,0x61
0000966B  24FC              and al,0xfc
0000966D  E661              out 0x61,al
0000966F  CB                retf
00009670  0000              add [bx+si],al
00009672  0000              add [bx+si],al
00009674  54                push sp
00009675  7572              jnz 0x96e9
00009677  626F2D            bound bp,[bx+0x2d]
0000967A  43                inc bx
0000967B  202D              and [di],ch
0000967D  20436F            and [bp+di+0x6f],al
00009680  7079              jo 0x96fb
00009682  7269              jc 0x96ed
00009684  67687420          push word 0x2074
00009688  286329            sub [bp+di+0x29],ah
0000968B  2031              and [bx+di],dh
0000968D  3938              cmp [bx+si],di
0000968F  3820              cmp [bx+si],ah
00009691  42                inc dx
00009692  6F                outsw
00009693  726C              jc 0x9701
00009695  61                popa
00009696  6E                outsb
00009697  6420496E          and [fs:bx+di+0x6e],cl
0000969B  746C              jz 0x9709
0000969D  2E004469          add [cs:si+0x69],al
000096A1  7669              jna 0x970c
000096A3  6465206572        and [gs:di+0x72],ah
000096A8  726F              jc 0x9719
000096AA  720D              jc 0x96b9
000096AC  0A4162            or al,[bx+di+0x62]
000096AF  6E                outsb
000096B0  6F                outsw
000096B1  726D              jc 0x9720
000096B3  61                popa
000096B4  6C                insb
000096B5  207072            and [bx+si+0x72],dh
000096B8  6F                outsw
000096B9  677261            jc 0x971d
000096BC  6D                insw
000096BD  207465            and [si+0x65],dh
000096C0  726D              jc 0x972f
000096C2  696E617469        imul bp,[bp+0x61],word 0x6974
000096C7  6F                outsw
000096C8  6E                outsb
000096C9  0D0A00            or ax,0xa
000096CC  0000              add [bx+si],al
000096CE  0000              add [bx+si],al
000096D0  0000              add [bx+si],al
000096D2  0000              add [bx+si],al
000096D4  0000              add [bx+si],al
000096D6  0000              add [bx+si],al
000096D8  0000              add [bx+si],al
000096DA  0000              add [bx+si],al
000096DC  0000              add [bx+si],al
000096DE  0000              add [bx+si],al
000096E0  0000              add [bx+si],al
000096E2  0000              add [bx+si],al
000096E4  0000              add [bx+si],al
000096E6  0000              add [bx+si],al
000096E8  0000              add [bx+si],al
000096EA  0000              add [bx+si],al
000096EC  0000              add [bx+si],al
000096EE  0000              add [bx+si],al
000096F0  0000              add [bx+si],al
000096F2  0000              add [bx+si],al
000096F4  0000              add [bx+si],al
000096F6  0000              add [bx+si],al
000096F8  0000              add [bx+si],al
000096FA  0000              add [bx+si],al
000096FC  0000              add [bx+si],al
000096FE  0000              add [bx+si],al
00009700  0000              add [bx+si],al
00009702  0000              add [bx+si],al
00009704  0000              add [bx+si],al
00009706  0000              add [bx+si],al
00009708  0000              add [bx+si],al
0000970A  0000              add [bx+si],al
0000970C  0000              add [bx+si],al
0000970E  0000              add [bx+si],al
00009710  0000              add [bx+si],al
00009712  0000              add [bx+si],al
00009714  0000              add [bx+si],al
00009716  0000              add [bx+si],al
00009718  0000              add [bx+si],al
0000971A  0000              add [bx+si],al
0000971C  0000              add [bx+si],al
0000971E  0000              add [bx+si],al
00009720  0000              add [bx+si],al
00009722  0000              add [bx+si],al
00009724  0000              add [bx+si],al
00009726  0000              add [bx+si],al
00009728  0000              add [bx+si],al
0000972A  0000              add [bx+si],al
0000972C  0000              add [bx+si],al
0000972E  0000              add [bx+si],al
00009730  0000              add [bx+si],al
00009732  0000              add [bx+si],al
00009734  0000              add [bx+si],al
00009736  0000              add [bx+si],al
00009738  0000              add [bx+si],al
0000973A  0000              add [bx+si],al
0000973C  0000              add [bx+si],al
0000973E  0000              add [bx+si],al
00009740  0000              add [bx+si],al
00009742  0000              add [bx+si],al
00009744  0000              add [bx+si],al
00009746  0000              add [bx+si],al
00009748  0000              add [bx+si],al
0000974A  0000              add [bx+si],al
0000974C  0000              add [bx+si],al
0000974E  0000              add [bx+si],al
00009750  0000              add [bx+si],al
00009752  0000              add [bx+si],al
00009754  0000              add [bx+si],al
00009756  0000              add [bx+si],al
00009758  0000              add [bx+si],al
0000975A  0000              add [bx+si],al
0000975C  0000              add [bx+si],al
0000975E  0000              add [bx+si],al
00009760  0000              add [bx+si],al
00009762  0000              add [bx+si],al
00009764  0000              add [bx+si],al
00009766  0000              add [bx+si],al
00009768  0000              add [bx+si],al
0000976A  0000              add [bx+si],al
0000976C  0000              add [bx+si],al
0000976E  0000              add [bx+si],al
00009770  0000              add [bx+si],al
00009772  0000              add [bx+si],al
00009774  0000              add [bx+si],al
00009776  0000              add [bx+si],al
00009778  0000              add [bx+si],al
0000977A  0000              add [bx+si],al
0000977C  0000              add [bx+si],al
0000977E  0000              add [bx+si],al
00009780  0000              add [bx+si],al
00009782  0000              add [bx+si],al
00009784  0000              add [bx+si],al
00009786  0000              add [bx+si],al
00009788  0000              add [bx+si],al
0000978A  0000              add [bx+si],al
0000978C  0000              add [bx+si],al
0000978E  0000              add [bx+si],al
00009790  0000              add [bx+si],al
00009792  0000              add [bx+si],al
00009794  0000              add [bx+si],al
00009796  0000              add [bx+si],al
00009798  0000              add [bx+si],al
0000979A  0000              add [bx+si],al
0000979C  0000              add [bx+si],al
0000979E  0000              add [bx+si],al
000097A0  0000              add [bx+si],al
000097A2  0000              add [bx+si],al
000097A4  0000              add [bx+si],al
000097A6  0000              add [bx+si],al
000097A8  0000              add [bx+si],al
000097AA  0000              add [bx+si],al
000097AC  0000              add [bx+si],al
000097AE  0000              add [bx+si],al
000097B0  0000              add [bx+si],al
000097B2  0000              add [bx+si],al
000097B4  0000              add [bx+si],al
000097B6  0000              add [bx+si],al
000097B8  0000              add [bx+si],al
000097BA  0000              add [bx+si],al
000097BC  0000              add [bx+si],al
000097BE  0000              add [bx+si],al
000097C0  0000              add [bx+si],al
000097C2  0000              add [bx+si],al
000097C4  0000              add [bx+si],al
000097C6  0000              add [bx+si],al
000097C8  0000              add [bx+si],al
000097CA  0000              add [bx+si],al
000097CC  0100              add [bx+si],ax
000097CE  0200              add al,[bx+si]
000097D0  0300              add ax,[bx+si]
000097D2  0400              add al,0x0
000097D4  050000            add ax,0x0
000097D7  0000              add [bx+si],al
000097D9  0000              add [bx+si],al
000097DB  0000              add [bx+si],al
000097DD  0000              add [bx+si],al
000097DF  0000              add [bx+si],al
000097E1  0000              add [bx+si],al
000097E3  0000              add [bx+si],al
000097E5  0000              add [bx+si],al
000097E7  0000              add [bx+si],al
000097E9  0000              add [bx+si],al
000097EB  0000              add [bx+si],al
000097ED  0000              add [bx+si],al
000097EF  0000              add [bx+si],al
000097F1  0000              add [bx+si],al
000097F3  0000              add [bx+si],al
000097F5  0000              add [bx+si],al
000097F7  0000              add [bx+si],al
000097F9  0000              add [bx+si],al
000097FB  0000              add [bx+si],al
000097FD  0000              add [bx+si],al
000097FF  0000              add [bx+si],al
00009801  0000              add [bx+si],al
00009803  0000              add [bx+si],al
00009805  0000              add [bx+si],al
00009807  0000              add [bx+si],al
00009809  0000              add [bx+si],al
0000980B  0000              add [bx+si],al
0000980D  0000              add [bx+si],al
0000980F  0000              add [bx+si],al
00009811  0000              add [bx+si],al
00009813  0000              add [bx+si],al
00009815  0000              add [bx+si],al
00009817  0000              add [bx+si],al
00009819  0000              add [bx+si],al
0000981B  0000              add [bx+si],al
0000981D  0000              add [bx+si],al
0000981F  0000              add [bx+si],al
00009821  0000              add [bx+si],al
00009823  0000              add [bx+si],al
00009825  0000              add [bx+si],al
00009827  0000              add [bx+si],al
00009829  0000              add [bx+si],al
0000982B  0000              add [bx+si],al
0000982D  0000              add [bx+si],al
0000982F  0000              add [bx+si],al
00009831  0000              add [bx+si],al
00009833  0000              add [bx+si],al
00009835  0000              add [bx+si],al
00009837  0000              add [bx+si],al
00009839  0000              add [bx+si],al
0000983B  0000              add [bx+si],al
0000983D  0000              add [bx+si],al
0000983F  0000              add [bx+si],al
00009841  0000              add [bx+si],al
00009843  0000              add [bx+si],al
00009845  0000              add [bx+si],al
00009847  0000              add [bx+si],al
00009849  0000              add [bx+si],al
0000984B  0000              add [bx+si],al
0000984D  0000              add [bx+si],al
0000984F  0000              add [bx+si],al
00009851  0000              add [bx+si],al
00009853  0000              add [bx+si],al
00009855  0000              add [bx+si],al
00009857  0000              add [bx+si],al
00009859  0000              add [bx+si],al
0000985B  0000              add [bx+si],al
0000985D  0000              add [bx+si],al
0000985F  0000              add [bx+si],al
00009861  0000              add [bx+si],al
00009863  0000              add [bx+si],al
00009865  0000              add [bx+si],al
00009867  0000              add [bx+si],al
00009869  0000              add [bx+si],al
0000986B  0000              add [bx+si],al
0000986D  0000              add [bx+si],al
0000986F  0000              add [bx+si],al
00009871  0000              add [bx+si],al
00009873  0000              add [bx+si],al
00009875  0000              add [bx+si],al
00009877  0000              add [bx+si],al
00009879  0000              add [bx+si],al
0000987B  0000              add [bx+si],al
0000987D  0000              add [bx+si],al
0000987F  0000              add [bx+si],al
00009881  0000              add [bx+si],al
00009883  0000              add [bx+si],al
00009885  0000              add [bx+si],al
00009887  0000              add [bx+si],al
00009889  0000              add [bx+si],al
0000988B  0000              add [bx+si],al
0000988D  0000              add [bx+si],al
0000988F  0000              add [bx+si],al
00009891  0000              add [bx+si],al
00009893  0000              add [bx+si],al
00009895  0000              add [bx+si],al
00009897  0000              add [bx+si],al
00009899  0000              add [bx+si],al
0000989B  0000              add [bx+si],al
0000989D  0000              add [bx+si],al
0000989F  0000              add [bx+si],al
000098A1  0000              add [bx+si],al
000098A3  0000              add [bx+si],al
000098A5  0000              add [bx+si],al
000098A7  0000              add [bx+si],al
000098A9  0000              add [bx+si],al
000098AB  0000              add [bx+si],al
000098AD  0000              add [bx+si],al
000098AF  0000              add [bx+si],al
000098B1  0000              add [bx+si],al
000098B3  0000              add [bx+si],al
000098B5  0000              add [bx+si],al
000098B7  0000              add [bx+si],al
000098B9  0000              add [bx+si],al
000098BB  0000              add [bx+si],al
000098BD  0000              add [bx+si],al
000098BF  0000              add [bx+si],al
000098C1  0000              add [bx+si],al
000098C3  0000              add [bx+si],al
000098C5  0000              add [bx+si],al
000098C7  0000              add [bx+si],al
000098C9  0000              add [bx+si],al
000098CB  0000              add [bx+si],al
000098CD  0000              add [bx+si],al
000098CF  0000              add [bx+si],al
000098D1  0000              add [bx+si],al
000098D3  0000              add [bx+si],al
000098D5  0000              add [bx+si],al
000098D7  0000              add [bx+si],al
000098D9  0000              add [bx+si],al
000098DB  0000              add [bx+si],al
000098DD  0000              add [bx+si],al
000098DF  0000              add [bx+si],al
000098E1  0000              add [bx+si],al
000098E3  0000              add [bx+si],al
000098E5  0000              add [bx+si],al
000098E7  0000              add [bx+si],al
000098E9  0000              add [bx+si],al
000098EB  0000              add [bx+si],al
000098ED  0000              add [bx+si],al
000098EF  0000              add [bx+si],al
000098F1  0000              add [bx+si],al
000098F3  0000              add [bx+si],al
000098F5  0000              add [bx+si],al
000098F7  0000              add [bx+si],al
000098F9  0000              add [bx+si],al
000098FB  0000              add [bx+si],al
000098FD  0000              add [bx+si],al
000098FF  0000              add [bx+si],al
00009901  0000              add [bx+si],al
00009903  0000              add [bx+si],al
00009905  0000              add [bx+si],al
00009907  0000              add [bx+si],al
00009909  0000              add [bx+si],al
0000990B  0101              add [bx+di],ax
0000990D  0001              add [bx+di],al
0000990F  0101              add [bx+di],ax
00009911  0000              add [bx+si],al
00009913  0101              add [bx+di],ax
00009915  0100              add [bx+si],ax
00009917  0000              add [bx+si],al
00009919  0001              add [bx+di],al
0000991B  0000              add [bx+si],al
0000991D  0101              add [bx+di],ax
0000991F  0101              add [bx+di],ax
00009921  0000              add [bx+si],al
00009923  0100              add [bx+si],ax
00009925  0001              add [bx+di],al
00009927  0100              add [bx+si],ax
00009929  0000              add [bx+si],al
0000992B  0000              add [bx+si],al
0000992D  0000              add [bx+si],al
0000992F  0000              add [bx+si],al
00009931  0000              add [bx+si],al
00009933  0000              add [bx+si],al
00009935  0000              add [bx+si],al
00009937  0000              add [bx+si],al
00009939  0000              add [bx+si],al
0000993B  0000              add [bx+si],al
0000993D  0000              add [bx+si],al
0000993F  0000              add [bx+si],al
00009941  0000              add [bx+si],al
00009943  0000              add [bx+si],al
00009945  0000              add [bx+si],al
00009947  0000              add [bx+si],al
00009949  0203              add al,[bp+di]
0000994B  0305              add ax,[di]
0000994D  0401              add al,0x1
0000994F  0203              add al,[bp+di]
00009951  0305              add ax,[di]
00009953  0201              add al,[bx+di]
00009955  0403              add al,0x3
00009957  0300              add ax,[bx+si]
00009959  0000              add [bx+si],al
0000995B  0000              add [bx+si],al
0000995D  0000              add [bx+si],al
0000995F  0000              add [bx+si],al
00009961  0000              add [bx+si],al
00009963  0000              add [bx+si],al
00009965  0000              add [bx+si],al
00009967  0000              add [bx+si],al
00009969  0000              add [bx+si],al
0000996B  0000              add [bx+si],al
0000996D  0000              add [bx+si],al
0000996F  0000              add [bx+si],al
00009971  0000              add [bx+si],al
00009973  0000              add [bx+si],al
00009975  0000              add [bx+si],al
00009977  0000              add [bx+si],al
00009979  0000              add [bx+si],al
0000997B  0000              add [bx+si],al
0000997D  0000              add [bx+si],al
0000997F  0000              add [bx+si],al
00009981  0000              add [bx+si],al
00009983  0000              add [bx+si],al
00009985  0000              add [bx+si],al
00009987  0000              add [bx+si],al
00009989  0000              add [bx+si],al
0000998B  0000              add [bx+si],al
0000998D  0000              add [bx+si],al
0000998F  0000              add [bx+si],al
00009991  0000              add [bx+si],al
00009993  0000              add [bx+si],al
00009995  0000              add [bx+si],al
00009997  0000              add [bx+si],al
00009999  0000              add [bx+si],al
0000999B  0000              add [bx+si],al
0000999D  0000              add [bx+si],al
0000999F  0000              add [bx+si],al
000099A1  0000              add [bx+si],al
000099A3  0000              add [bx+si],al
000099A5  0000              add [bx+si],al
000099A7  0000              add [bx+si],al
000099A9  0000              add [bx+si],al
000099AB  0000              add [bx+si],al
000099AD  0000              add [bx+si],al
000099AF  0000              add [bx+si],al
000099B1  0000              add [bx+si],al
000099B3  0000              add [bx+si],al
000099B5  0000              add [bx+si],al
000099B7  0032              add [bp+si],dh
000099B9  2829              sub [bx+di],ch
000099BB  096703            or [bx+0x3],sp
000099BE  64640203          add al,[fs:bp+di]
000099C2  0000              add [bx+si],al
000099C4  007150            add [bx+di+0x50],dh
000099C7  5A                pop dx
000099C8  0E                push cs
000099C9  3F                aas
000099CA  06                push es
000099CB  3238              xor bh,[bx+si]
000099CD  0203              add al,[bp+di]
000099CF  06                push es
000099D0  07                pop es
000099D1  0000              add [bx+si],al
000099D3  204D41            and [di+0x41],cl
000099D6  53                push bx
000099D7  54                push sp
000099D8  45                inc bp
000099D9  52                push dx
000099DA  204347            and [bp+di+0x47],al
000099DD  41                inc cx
000099DE  2020              and [bx+si],ah
000099E0  2020              and [bx+si],ah
000099E2  2020              and [bx+si],ah
000099E4  2D2D2D            sub ax,0x2d2d
000099E7  3E2020            and [ds:bx+si],ah
000099EA  2020              and [bx+si],ah
000099EC  43                inc bx
000099ED  2E45              cs inc bp
000099EF  47                inc di
000099F0  41                inc cx
000099F1  2020              and [bx+si],ah
000099F3  2020              and [bx+si],ah
000099F5  2020              and [bx+si],ah
000099F7  2D2D2D            sub ax,0x2d2d
000099FA  3E2020            and [ds:bx+si],ah
000099FD  2020              and [bx+si],ah
000099FF  45                inc bp
00009A00  2E41              cs inc cx
00009A02  4D                dec bp
00009A03  53                push bx
00009A04  54                push sp
00009A05  52                push dx
00009A06  41                inc cx
00009A07  44                inc sp
00009A08  2020              and [bx+si],ah
00009A0A  2D2D2D            sub ax,0x2d2d
00009A0D  3E2020            and [ds:bx+si],ah
00009A10  2020              and [bx+si],ah
00009A12  41                inc cx
00009A13  2E48              cs dec ax
00009A15  45                inc bp
00009A16  52                push dx
00009A17  43                inc bx
00009A18  55                push bp
00009A19  4C                dec sp
00009A1A  45                inc bp
00009A1B  2020              and [bx+si],ah
00009A1D  2D2D2D            sub ax,0x2d2d
00009A20  3E2020            and [ds:bx+si],ah
00009A23  2020              and [bx+si],ah
00009A25  48                dec ax
00009A26  2E54              cs push sp
00009A28  41                inc cx
00009A29  4E                dec si
00009A2A  44                inc sp
00009A2B  59                pop cx
00009A2C  2020              and [bx+si],ah
00009A2E  2020              and [bx+si],ah
00009A30  2D2D2D            sub ax,0x2d2d
00009A33  3E2020            and [ds:bx+si],ah
00009A36  2020              and [bx+si],ah
00009A38  54                push sp
00009A39  2E56              cs push si
00009A3B  47                inc di
00009A3C  41                inc cx
00009A3D  2020              and [bx+si],ah
00009A3F  2020              and [bx+si],ah
00009A41  2020              and [bx+si],ah
00009A43  2D2D2D            sub ax,0x2d2d
00009A46  3E2020            and [ds:bx+si],ah
00009A49  2020              and [bx+si],ah
00009A4B  56                push si
00009A4C  2E41              cs inc cx
00009A4E  61                popa
00009A4F  43                inc bx
00009A50  634565            arpl [di+0x65],ax
00009A53  48                dec ax
00009A54  685474            push word 0x7454
00009A57  56                push si
00009A58  7643              jna 0x9a9d
00009A5A  6C                insb
00009A5B  61                popa
00009A5C  7669              jna 0x9ac7
00009A5E  657220            gs jc 0x9a81
00009A61  6F                outsw
00009A62  7520              jnz 0x9a84
00009A64  53                push bx
00009A65  6F                outsw
00009A66  7572              jnz 0x9ada
00009A68  6973203C43        imul si,[bp+di+0x20],word 0x433c
00009A6D  206F75            and [bx+0x75],ch
00009A70  20533E            and [bp+di+0x3e],dl
00009A73  203F              and [bx],bh
00009A75  41                inc cx
00009A76  4D                dec bp
00009A77  53                push bx
00009A78  43                inc bx
00009A79  47                inc di
00009A7A  41                inc cx
00009A7B  45                inc bp
00009A7C  47                inc di
00009A7D  41                inc cx
00009A7E  48                dec ax
00009A7F  45                inc bp
00009A80  52                push dx
00009A81  54                push sp
00009A82  41                inc cx
00009A83  4E                dec si
00009A84  56                push si
00009A85  47                inc di
00009A86  41                inc cx
00009A87  4D                dec bp
00009A88  41                inc cx
00009A89  4E                dec si
00009A8A  51                push cx
00009A8B  55                push bp
00009A8C  45                inc bp
00009A8D  204445            and [si+0x45],al
00009A90  204D45            and [di+0x45],cl
00009A93  4D                dec bp
00009A94  4F                dec di
00009A95  49                dec cx
00009A96  52                push dx
00009A97  45                inc bp
00009A98  004C05            add [si+0x5],cl
00009A9B  0113              add [bp+di],dx
00009A9D  120E0915          adc cl,[0x1509]
00009AA1  140F              adc al,0xf
00009AA3  0C54              or al,0x54
00009AA5  0403              add al,0x3
00009AA7  4D                dec bp
00009AA8  100D              adc [di],cl
00009AAA  08160265          or [0x6502],dl
00009AAE  06                push es
00009AAF  07                pop es
00009AB0  43                inc bx
00009AB1  5E                pop si
00009AB2  53                push bx
00009AB3  58                pop ax
00009AB4  55                push bp
00009AB5  261D2719          es sbb ax,0x1927
00009AB9  361A11            sbb dl,[ss:bx+di]
00009ABC  41                inc cx
00009ABD  1B1C              sbb bx,[si]
00009ABF  183A              sbb [bp+si],bh
00009AC1  1E                push ds
00009AC2  3938              cmp [bx+si],di
00009AC4  2330              and si,[bx+si]
00009AC6  2D372C            sub ax,0x2c37
00009AC9  242E              and al,0x2e
00009ACB  0A3C              or bh,[si]
00009ACD  46                inc si
00009ACE  3B2A              cmp bp,[bp+si]
00009AD0  44                inc sp
00009AD1  3D1F52            cmp ax,0x521f
00009AD4  2029              and [bx+di],ch
00009AD6  2F                das
00009AD7  0B593E            or bx,[bx+di+0x3e]
00009ADA  2835              sub [di],dh
00009ADC  17                pop ss
00009ADD  57                push di
00009ADE  2131              and [bx+di],si
00009AE0  2B5D5B            sub bx,[di+0x5b]
00009AE3  5C                pop sp
00009AE4  49                dec cx
00009AE5  22603F            and ah,[bx+si+0x3f]
00009AE8  42                inc dx
00009AE9  47                inc di
00009AEA  56                push si
00009AEB  25334E            and ax,0x4e33
00009AEE  4F                dec di
00009AEF  48                dec ax
00009AF0  0000              add [bx+si],al
00009AF2  0000              add [bx+si],al
00009AF4  0000              add [bx+si],al
00009AF6  0000              add [bx+si],al
00009AF8  0000              add [bx+si],al
00009AFA  0000              add [bx+si],al
00009AFC  0000              add [bx+si],al
00009AFE  0000              add [bx+si],al
00009B00  0000              add [bx+si],al
00009B02  0000              add [bx+si],al
00009B04  0000              add [bx+si],al
00009B06  0000              add [bx+si],al
00009B08  0000              add [bx+si],al
00009B0A  0000              add [bx+si],al
00009B0C  0000              add [bx+si],al
00009B0E  0000              add [bx+si],al
00009B10  0000              add [bx+si],al
00009B12  0000              add [bx+si],al
00009B14  0000              add [bx+si],al
00009B16  006222            add [bp+si+0x22],ah
00009B19  094E42            or [bp+0x42],cx
00009B1C  0E                push cs
00009B1D  45                inc bp
00009B1E  0C48              or al,0x48
00009B20  4C                dec sp
00009B21  0A03              or al,[bp+di]
00009B23  1800              sbb [bx+si],al
00009B25  58                pop ax
00009B26  0004              add [si],al
00009B28  0102              add [bp+si],ax
00009B2A  0200              add al,[bx+si]
00009B2C  0103              add [bp+di],ax
00009B2E  0204              add al,[si]
00009B30  0102              add [bp+si],ax
00009B32  0200              add al,[bx+si]
00009B34  0101              add [bx+di],ax
00009B36  0301              add ax,[bx+di]
00009B38  0101              add [bx+di],ax
00009B3A  0102              add [bp+si],ax
00009B3C  0102              add [bp+si],ax
00009B3E  0102              add [bp+si],ax
00009B40  0101              add [bx+di],ax
00009B42  0302              add ax,[bp+si]
00009B44  0002              add [bp+si],al
00009B46  0103              add [bp+di],ax
00009B48  0202              add al,[bp+si]
00009B4A  0202              add al,[bp+si]
00009B4C  0102              add [bp+si],ax
00009B4E  0105              add [di],ax
00009B50  0101              add [bx+di],ax
00009B52  0200              add al,[bx+si]
00009B54  0201              add al,[bx+di]
00009B56  0204              add al,[si]
00009B58  0103              add [bp+di],ax
00009B5A  0002              add [bp+si],al
00009B5C  0003              add [bp+di],al
00009B5E  0101              add [bx+di],ax
00009B60  0102              add [bp+si],ax
00009B62  0203              add al,[bp+di]
00009B64  0005              add [di],al
00009B66  04FF              add al,0xff
00009B68  FF01              inc word [bx+di]
00009B6A  0201              add al,[bx+di]
00009B6C  0003              add [bp+di],al
00009B6E  0100              add [bx+si],ax
00009B70  0203              add al,[bp+di]
00009B72  0100              add [bx+si],ax
00009B74  0102              add [bp+si],ax
00009B76  0301              add ax,[bx+di]
00009B78  0302              add ax,[bp+si]
00009B7A  0001              add [bx+di],al
00009B7C  0101              add [bx+di],ax
00009B7E  0102              add [bp+si],ax
00009B80  0102              add [bp+si],ax
00009B82  0101              add [bx+di],ax
00009B84  0200              add al,[bx+si]
00009B86  0001              add [bx+di],al
00009B88  0002              add [bp+si],al
00009B8A  0301              add ax,[bx+di]
00009B8C  0202              add al,[bp+si]
00009B8E  0004              add [si],al
00009B90  0103              add [bp+di],ax
00009B92  0202              add al,[bp+si]
00009B94  0200              add al,[bx+si]
00009B96  0201              add al,[bx+di]
00009B98  0307              add ax,[bx]
00009B9A  050300            add ax,0x3
00009B9D  0101              add [bx+di],ax
00009B9F  0402              add al,0x2
00009BA1  0400              add al,0x0
00009BA3  000A              add [bp+si],cl
00009BA5  0302              add ax,[bp+si]
00009BA7  0000              add [bx+si],al
00009BA9  FF                db 0xff
00009BAA  FF00              inc word [bx+si]
00009BAC  0000              add [bx+si],al
00009BAE  0101              add [bx+di],ax
00009BB0  0001              add [bx+di],al
00009BB2  0101              add [bx+di],ax
00009BB4  0000              add [bx+si],al
00009BB6  0101              add [bx+di],ax
00009BB8  0100              add [bx+si],ax
00009BBA  0000              add [bx+si],al
00009BBC  0001              add [bx+di],al
00009BBE  0000              add [bx+si],al
00009BC0  0101              add [bx+di],ax
00009BC2  0101              add [bx+di],ax
00009BC4  0000              add [bx+si],al
00009BC6  0100              add [bx+si],ax
00009BC8  0001              add [bx+di],al
00009BCA  0100              add [bx+si],ax
00009BCC  0203              add al,[bp+di]
00009BCE  0305              add ax,[di]
00009BD0  0401              add al,0x1
00009BD2  0203              add al,[bp+di]
00009BD4  0305              add ax,[di]
00009BD6  0201              add al,[bx+di]
00009BD8  0403              add al,0x3
00009BDA  035341            add dx,[bp+di+0x41]
00009BDD  55                push bp
00009BDE  56                push si
00009BDF  45                inc bp
00009BE0  4D                dec bp
00009BE1  41                inc cx
00009BE2  55                push bp
00009BE3  2E3030            xor [cs:bx+si],dh
00009BE6  3100              xor [bx+si],ax
00009BE8  47                inc di
00009BE9  312E434F          xor [0x4f43],bp
00009BED  4E                dec si
00009BEE  004732            add [bx+0x32],al
00009BF1  2E43              cs inc bx
00009BF3  4F                dec di
00009BF4  4E                dec si
00009BF5  004733            add [bx+0x33],al
00009BF8  2E43              cs inc bx
00009BFA  4F                dec di
00009BFB  4E                dec si
00009BFC  0000              add [bx+si],al
00009BFE  0000              add [bx+si],al
00009C00  0000              add [bx+si],al
00009C02  0000              add [bx+si],al
00009C04  0000              add [bx+si],al
00009C06  0000              add [bx+si],al
00009C08  0000              add [bx+si],al
00009C0A  0000              add [bx+si],al
00009C0C  0000              add [bx+si],al
00009C0E  0000              add [bx+si],al
00009C10  0000              add [bx+si],al
00009C12  0000              add [bx+si],al
00009C14  0000              add [bx+si],al
00009C16  0000              add [bx+si],al
00009C18  0000              add [bx+si],al
00009C1A  0000              add [bx+si],al
00009C1C  0000              add [bx+si],al
00009C1E  0000              add [bx+si],al
00009C20  0000              add [bx+si],al
00009C22  0000              add [bx+si],al
00009C24  0000              add [bx+si],al
00009C26  0000              add [bx+si],al
00009C28  0000              add [bx+si],al
00009C2A  0000              add [bx+si],al
00009C2C  0000              add [bx+si],al
00009C2E  0000              add [bx+si],al
00009C30  0000              add [bx+si],al
00009C32  0000              add [bx+si],al
00009C34  0000              add [bx+si],al
00009C36  0000              add [bx+si],al
00009C38  0000              add [bx+si],al
00009C3A  0000              add [bx+si],al
00009C3C  0000              add [bx+si],al
00009C3E  0000              add [bx+si],al
00009C40  0000              add [bx+si],al
00009C42  0000              add [bx+si],al
00009C44  0000              add [bx+si],al
00009C46  0000              add [bx+si],al
00009C48  0000              add [bx+si],al
00009C4A  0000              add [bx+si],al
00009C4C  0000              add [bx+si],al
00009C4E  0000              add [bx+si],al
00009C50  0000              add [bx+si],al
00009C52  0000              add [bx+si],al
00009C54  0000              add [bx+si],al
00009C56  0000              add [bx+si],al
00009C58  0000              add [bx+si],al
00009C5A  0000              add [bx+si],al
00009C5C  0000              add [bx+si],al
00009C5E  0000              add [bx+si],al
00009C60  0000              add [bx+si],al
00009C62  0000              add [bx+si],al
00009C64  0000              add [bx+si],al
00009C66  0000              add [bx+si],al
00009C68  0000              add [bx+si],al
00009C6A  0000              add [bx+si],al
00009C6C  0000              add [bx+si],al
00009C6E  0000              add [bx+si],al
00009C70  0000              add [bx+si],al
00009C72  0000              add [bx+si],al
00009C74  0000              add [bx+si],al
00009C76  0000              add [bx+si],al
00009C78  0000              add [bx+si],al
00009C7A  0000              add [bx+si],al
00009C7C  004E42            add [bp+0x42],cl
00009C7F  51                push cx
00009C80  49                dec cx
00009C81  4C                dec sp
00009C82  4C                dec sp
00009C83  4B                dec bx
00009C84  4E                dec si
00009C85  46                inc si
00009C86  43                inc bx
00009C87  253B31            and ax,0x313b
00009C8A  3E3B3B            cmp di,[ds:bp+di]
00009C8D  324200            xor al,[bp+si+0x0]
00009C90  0000              add [bx+si],al
00009C92  0000              add [bx+si],al
00009C94  0024              add [si],ah
00009C96  0000              add [bx+si],al
00009C98  0000              add [bx+si],al
00009C9A  0000              add [bx+si],al
00009C9C  0000              add [bx+si],al
00009C9E  0000              add [bx+si],al
00009CA0  0000              add [bx+si],al
00009CA2  0000              add [bx+si],al
00009CA4  0000              add [bx+si],al
00009CA6  0000              add [bx+si],al
00009CA8  0000              add [bx+si],al
00009CAA  0000              add [bx+si],al
00009CAC  0001              add [bx+di],al
00009CAE  0000              add [bx+si],al
00009CB0  0000              add [bx+si],al
00009CB2  0000              add [bx+si],al
00009CB4  003F              add [bx],bh
00009CB6  0000              add [bx+si],al
00009CB8  003F              add [bx],bh
00009CBA  0100              add [bx+si],ax
00009CBC  0000              add [bx+si],al
00009CBE  0000              add [bx+si],al
00009CC0  0000              add [bx+si],al
00009CC2  0000              add [bx+si],al
00009CC4  0000              add [bx+si],al
00009CC6  0000              add [bx+si],al
00009CC8  0000              add [bx+si],al
00009CCA  0000              add [bx+si],al
00009CCC  0000              add [bx+si],al
00009CCE  0000              add [bx+si],al
00009CD0  0000              add [bx+si],al
00009CD2  0000              add [bx+si],al
00009CD4  0000              add [bx+si],al
00009CD6  0000              add [bx+si],al
00009CD8  0000              add [bx+si],al
00009CDA  0000              add [bx+si],al
00009CDC  0000              add [bx+si],al
00009CDE  0000              add [bx+si],al
00009CE0  0001              add [bx+di],al
00009CE2  0100              add [bx+si],ax
00009CE4  0000              add [bx+si],al
00009CE6  0003              add [bp+di],al
00009CE8  111F              adc [bx],bx
00009CEA  2C3A              sub al,0x3a
00009CEC  3F                aas
00009CED  3F                aas
00009CEE  0007              add [bx],al
00009CF0  121E2B36          adc bl,[0x362b]
00009CF4  3F                aas
00009CF5  3F                aas
00009CF6  0004              add [si],al
00009CF8  0D1D29            or ax,0x291d
00009CFB  3C3F              cmp al,0x3f
00009CFD  3F                aas
00009CFE  0008              add [bx+si],cl
00009D00  040C              add al,0xc
00009D02  020A              add cl,[bp+si]
00009D04  06                push es
00009D05  0E                push cs
00009D06  0109              add [bx+di],cx
00009D08  050D03            add ax,0x30d
00009D0B  0B07              or ax,[bx]
00009D0D  0F0000            sldt [bx+si]
00009D10  0000              add [bx+si],al
00009D12  0000              add [bx+si],al
00009D14  0000              add [bx+si],al
00009D16  0000              add [bx+si],al
00009D18  0000              add [bx+si],al
00009D1A  0000              add [bx+si],al
00009D1C  0000              add [bx+si],al
00009D1E  0000              add [bx+si],al
00009D20  0000              add [bx+si],al
00009D22  0000              add [bx+si],al
00009D24  0000              add [bx+si],al
00009D26  0000              add [bx+si],al
00009D28  0000              add [bx+si],al
00009D2A  0000              add [bx+si],al
00009D2C  0000              add [bx+si],al
00009D2E  0000              add [bx+si],al
00009D30  0000              add [bx+si],al
00009D32  0000              add [bx+si],al
00009D34  0000              add [bx+si],al
00009D36  0000              add [bx+si],al
00009D38  0000              add [bx+si],al
00009D3A  0000              add [bx+si],al
00009D3C  0000              add [bx+si],al
00009D3E  0000              add [bx+si],al
00009D40  0000              add [bx+si],al
00009D42  0000              add [bx+si],al
00009D44  0000              add [bx+si],al
00009D46  0000              add [bx+si],al
00009D48  0000              add [bx+si],al
00009D4A  0000              add [bx+si],al
00009D4C  0000              add [bx+si],al
00009D4E  0000              add [bx+si],al
00009D50  0000              add [bx+si],al
00009D52  0000              add [bx+si],al
00009D54  0000              add [bx+si],al
00009D56  0000              add [bx+si],al
00009D58  0000              add [bx+si],al
00009D5A  0000              add [bx+si],al
00009D5C  0000              add [bx+si],al
00009D5E  0000              add [bx+si],al
00009D60  0000              add [bx+si],al
00009D62  0000              add [bx+si],al
00009D64  0000              add [bx+si],al
00009D66  0000              add [bx+si],al
00009D68  0000              add [bx+si],al
00009D6A  0000              add [bx+si],al
00009D6C  0000              add [bx+si],al
00009D6E  0000              add [bx+si],al
00009D70  0000              add [bx+si],al
00009D72  0000              add [bx+si],al
00009D74  0000              add [bx+si],al
00009D76  0000              add [bx+si],al
00009D78  0000              add [bx+si],al
00009D7A  0000              add [bx+si],al
00009D7C  0000              add [bx+si],al
00009D7E  0000              add [bx+si],al
00009D80  0000              add [bx+si],al
00009D82  0000              add [bx+si],al
00009D84  0000              add [bx+si],al
00009D86  0000              add [bx+si],al
00009D88  0000              add [bx+si],al
00009D8A  0000              add [bx+si],al
00009D8C  0000              add [bx+si],al
00009D8E  0000              add [bx+si],al
00009D90  0000              add [bx+si],al
00009D92  0000              add [bx+si],al
00009D94  0000              add [bx+si],al
00009D96  0000              add [bx+si],al
00009D98  0000              add [bx+si],al
00009D9A  0000              add [bx+si],al
00009D9C  0000              add [bx+si],al
00009D9E  0000              add [bx+si],al
00009DA0  0000              add [bx+si],al
00009DA2  0000              add [bx+si],al
00009DA4  0000              add [bx+si],al
00009DA6  0000              add [bx+si],al
00009DA8  0000              add [bx+si],al
00009DAA  0000              add [bx+si],al
00009DAC  0000              add [bx+si],al
00009DAE  0000              add [bx+si],al
00009DB0  0000              add [bx+si],al
00009DB2  0000              add [bx+si],al
00009DB4  0000              add [bx+si],al
00009DB6  0000              add [bx+si],al
00009DB8  0000              add [bx+si],al
00009DBA  0000              add [bx+si],al
00009DBC  0000              add [bx+si],al
00009DBE  0000              add [bx+si],al
00009DC0  0000              add [bx+si],al
00009DC2  0000              add [bx+si],al
00009DC4  0000              add [bx+si],al
00009DC6  0000              add [bx+si],al
00009DC8  0000              add [bx+si],al
00009DCA  0000              add [bx+si],al
00009DCC  0000              add [bx+si],al
00009DCE  0000              add [bx+si],al
00009DD0  0000              add [bx+si],al
00009DD2  0000              add [bx+si],al
00009DD4  0000              add [bx+si],al
00009DD6  0000              add [bx+si],al
00009DD8  0000              add [bx+si],al
00009DDA  0000              add [bx+si],al
00009DDC  0000              add [bx+si],al
00009DDE  0000              add [bx+si],al
00009DE0  0000              add [bx+si],al
00009DE2  0000              add [bx+si],al
00009DE4  0000              add [bx+si],al
00009DE6  0000              add [bx+si],al
00009DE8  0000              add [bx+si],al
00009DEA  0000              add [bx+si],al
00009DEC  0000              add [bx+si],al
00009DEE  0000              add [bx+si],al
00009DF0  0000              add [bx+si],al
00009DF2  0000              add [bx+si],al
00009DF4  0000              add [bx+si],al
00009DF6  0000              add [bx+si],al
00009DF8  0000              add [bx+si],al
00009DFA  0000              add [bx+si],al
00009DFC  0000              add [bx+si],al
00009DFE  0000              add [bx+si],al
00009E00  0000              add [bx+si],al
00009E02  0000              add [bx+si],al
00009E04  0000              add [bx+si],al
00009E06  0000              add [bx+si],al
00009E08  0000              add [bx+si],al
00009E0A  0000              add [bx+si],al
00009E0C  0000              add [bx+si],al
00009E0E  0000              add [bx+si],al
00009E10  0000              add [bx+si],al
00009E12  0000              add [bx+si],al
00009E14  0000              add [bx+si],al
00009E16  0000              add [bx+si],al
00009E18  0000              add [bx+si],al
00009E1A  0000              add [bx+si],al
00009E1C  0000              add [bx+si],al
00009E1E  0000              add [bx+si],al
00009E20  0000              add [bx+si],al
00009E22  0000              add [bx+si],al
00009E24  0000              add [bx+si],al
00009E26  0000              add [bx+si],al
00009E28  0000              add [bx+si],al
00009E2A  0000              add [bx+si],al
00009E2C  0000              add [bx+si],al
00009E2E  0000              add [bx+si],al
00009E30  0000              add [bx+si],al
00009E32  0000              add [bx+si],al
00009E34  0000              add [bx+si],al
00009E36  0000              add [bx+si],al
00009E38  0000              add [bx+si],al
00009E3A  0000              add [bx+si],al
00009E3C  0000              add [bx+si],al
00009E3E  0000              add [bx+si],al
00009E40  0000              add [bx+si],al
00009E42  0000              add [bx+si],al
00009E44  0000              add [bx+si],al
00009E46  0000              add [bx+si],al
00009E48  0000              add [bx+si],al
00009E4A  0000              add [bx+si],al
00009E4C  0000              add [bx+si],al
00009E4E  0000              add [bx+si],al
00009E50  0000              add [bx+si],al
00009E52  0000              add [bx+si],al
00009E54  0000              add [bx+si],al
00009E56  0000              add [bx+si],al
00009E58  0000              add [bx+si],al
00009E5A  0000              add [bx+si],al
00009E5C  0000              add [bx+si],al
00009E5E  0000              add [bx+si],al
00009E60  0000              add [bx+si],al
00009E62  0000              add [bx+si],al
00009E64  0000              add [bx+si],al
00009E66  0000              add [bx+si],al
00009E68  0000              add [bx+si],al
00009E6A  0000              add [bx+si],al
00009E6C  0000              add [bx+si],al
00009E6E  F03CF0            lock cmp al,0xf0
00009E71  0030              add [bx+si],dh
00009E73  01F0              add ax,si
00009E75  1430              adc al,0x30
00009E77  15003C            adc ax,0x3c00
00009E7A  003D              add [di],bh
00009E7C  802DB0            sub byte [di],0xb0
00009E7F  2D0400            sub ax,0x4
00009E82  0303              add ax,[bp+di]
00009E84  0300              add ax,[bx+si]
00009E86  0404              add al,0x4
00009E88  0404              add al,0x4
00009E8A  0003              add [bp+di],al
00009E8C  0303              add ax,[bp+di]
00009E8E  0303              add ax,[bp+di]
00009E90  0300              add ax,[bx+si]
00009E92  0004              add [si],al
00009E94  0404              add al,0x4
00009E96  0404              add al,0x4
00009E98  0404              add al,0x4
00009E9A  0000              add [bx+si],al
00009E9C  0303              add ax,[bp+di]
00009E9E  0303              add ax,[bp+di]
00009EA0  0303              add ax,[bp+di]
00009EA2  0303              add ax,[bp+di]
00009EA4  0300              add ax,[bx+si]
00009EA6  0000              add [bx+si],al
00009EA8  0404              add al,0x4
00009EAA  0404              add al,0x4
00009EAC  0404              add al,0x4
00009EAE  0404              add al,0x4
00009EB0  0404              add al,0x4
00009EB2  0001              add [bx+di],al
00009EB4  0100              add [bx+si],ax
00009EB6  0202              add al,[bp+si]
00009EB8  0200              add al,[bx+si]
00009EBA  0101              add [bx+di],ax
00009EBC  0101              add [bx+di],ax
00009EBE  0100              add [bx+si],ax
00009EC0  0002              add [bp+si],al
00009EC2  0202              add al,[bp+si]
00009EC4  0202              add al,[bp+si]
00009EC6  0200              add al,[bx+si]
00009EC8  0001              add [bx+di],al
00009ECA  0101              add [bx+di],ax
00009ECC  0101              add [bx+di],ax
00009ECE  0101              add [bx+di],ax
00009ED0  0100              add [bx+si],ax
00009ED2  0000              add [bx+si],al
00009ED4  0202              add al,[bp+si]
00009ED6  0202              add al,[bp+si]
00009ED8  0202              add al,[bp+si]
00009EDA  0202              add al,[bp+si]
00009EDC  0200              add al,[bx+si]
00009EDE  0000              add [bx+si],al
00009EE0  0101              add [bx+di],ax
00009EE2  0101              add [bx+di],ax
00009EE4  0404              add al,0x4
00009EE6  0404              add al,0x4
00009EE8  0404              add al,0x4
00009EEA  0404              add al,0x4
00009EEC  0400              add al,0x0
00009EEE  0000              add [bx+si],al
00009EF0  0303              add ax,[bp+di]
00009EF2  0303              add ax,[bp+di]
00009EF4  0303              add ax,[bp+di]
00009EF6  0303              add ax,[bp+di]
00009EF8  0300              add ax,[bx+si]
00009EFA  0000              add [bx+si],al
00009EFC  0404              add al,0x4
00009EFE  0404              add al,0x4
00009F00  0404              add al,0x4
00009F02  0400              add al,0x0
00009F04  0003              add [bp+di],al
00009F06  0303              add ax,[bp+di]
00009F08  0303              add ax,[bp+di]
00009F0A  0300              add ax,[bx+si]
00009F0C  0004              add [si],al
00009F0E  0404              add al,0x4
00009F10  0003              add [bp+di],al
00009F12  0303              add ax,[bp+di]
00009F14  0404              add al,0x4
00009F16  0202              add al,[bp+si]
00009F18  0200              add al,[bx+si]
00009F1A  0000              add [bx+si],al
00009F1C  0101              add [bx+di],ax
00009F1E  0101              add [bx+di],ax
00009F20  0101              add [bx+di],ax
00009F22  0101              add [bx+di],ax
00009F24  0100              add [bx+si],ax
00009F26  0000              add [bx+si],al
00009F28  0202              add al,[bp+si]
00009F2A  0202              add al,[bp+si]
00009F2C  0202              add al,[bp+si]
00009F2E  0202              add al,[bp+si]
00009F30  0200              add al,[bx+si]
00009F32  0001              add [bx+di],al
00009F34  0101              add [bx+di],ax
00009F36  0101              add [bx+di],ax
00009F38  0100              add [bx+si],ax
00009F3A  0002              add [bp+si],al
00009F3C  0202              add al,[bp+si]
00009F3E  0202              add al,[bp+si]
00009F40  0001              add [bx+di],al
00009F42  0101              add [bx+di],ax
00009F44  0002              add [bp+si],al
00009F46  0200              add al,[bx+si]
00009F48  0202              add al,[bp+si]
00009F4A  0201              add al,[bx+di]
00009F4C  0202              add al,[bp+si]
00009F4E  0203              add al,[bp+di]
00009F50  0202              add al,[bp+si]
00009F52  0302              add ax,[bp+si]
00009F54  0202              add al,[bp+si]
00009F56  0201              add al,[bx+di]
00009F58  0302              add ax,[bp+si]
00009F5A  0202              add al,[bp+si]
00009F5C  0203              add al,[bp+di]
00009F5E  0202              add al,[bp+si]
00009F60  0201              add al,[bx+di]
00009F62  0203              add al,[bp+di]
00009F64  0201              add al,[bx+di]
00009F66  0203              add al,[bp+di]
00009F68  0303              add ax,[bp+di]
00009F6A  0303              add ax,[bp+di]
00009F6C  0202              add al,[bp+si]
00009F6E  0201              add al,[bx+di]
00009F70  0101              add [bx+di],ax
00009F72  0103              add [bp+di],ax
00009F74  0302              add ax,[bp+si]
00009F76  0202              add al,[bp+si]
00009F78  0202              add al,[bp+si]
00009F7A  0202              add al,[bp+si]
00009F7C  0202              add al,[bp+si]
00009F7E  0202              add al,[bp+si]
00009F80  0202              add al,[bp+si]
00009F82  0202              add al,[bp+si]
00009F84  0202              add al,[bp+si]
00009F86  0202              add al,[bp+si]
00009F88  0202              add al,[bp+si]
00009F8A  0202              add al,[bp+si]
00009F8C  0202              add al,[bp+si]
00009F8E  0202              add al,[bp+si]
00009F90  0202              add al,[bp+si]
00009F92  0202              add al,[bp+si]
00009F94  0202              add al,[bp+si]
00009F96  0202              add al,[bp+si]
00009F98  0202              add al,[bp+si]
00009F9A  0202              add al,[bp+si]
00009F9C  0101              add [bx+di],ax
00009F9E  0101              add [bx+di],ax
00009FA0  0202              add al,[bp+si]
00009FA2  0100              add [bx+si],ax
00009FA4  0100              add [bx+si],ax
00009FA6  0100              add [bx+si],ax
00009FA8  06                push es
00009FA9  0001              add [bx+di],al
00009FAB  0001              add [bx+di],al
00009FAD  0001              add [bx+di],al
00009FAF  0002              add [bp+si],al
00009FB1  0001              add [bx+di],al
00009FB3  0001              add [bx+di],al
00009FB5  0002              add [bp+si],al
00009FB7  0001              add [bx+di],al
00009FB9  0001              add [bx+di],al
00009FBB  0001              add [bx+di],al
00009FBD  0001              add [bx+di],al
00009FBF  00060002          add [0x200],al
00009FC3  0000              add [bx+si],al
00009FC5  0001              add [bx+di],al
00009FC7  0001              add [bx+di],al
00009FC9  0001              add [bx+di],al
00009FCB  0002              add [bp+si],al
00009FCD  0000              add [bx+si],al
00009FCF  0001              add [bx+di],al
00009FD1  0001              add [bx+di],al
00009FD3  00060001          add [0x100],al
00009FD7  0002              add [bp+si],al
00009FD9  0001              add [bx+di],al
00009FDB  00060001          add [0x100],al
00009FDF  0005              add [di],al
00009FE1  0005              add [di],al
00009FE3  0004              add [si],al
00009FE5  0004              add [si],al
00009FE7  0004              add [si],al
00009FE9  0000              add [bx+si],al
00009FEB  0000              add [bx+si],al
00009FED  0000              add [bx+si],al
00009FEF  0003              add [bp+di],al
00009FF1  0003              add [bp+di],al
00009FF3  0003              add [bp+di],al
00009FF5  0003              add [bp+di],al
00009FF7  0004              add [si],al
00009FF9  0004              add [si],al
00009FFB  0000              add [bx+si],al
00009FFD  0000              add [bx+si],al
00009FFF  008B3600          add [bp+di+0x36],cl
0000A003  0032              add [bp+si],dh
0000A005  7000              jo 0xa007
0000A007  00F9              add cl,bh
0000A009  C00000            rol byte [bx+si],byte 0x0
0000A00C  18F7              sbb bh,dh
0000A00E  0000              add [bx+si],al
0000A010  C9                leave
0000A011  40                inc ax
0000A012  0100              add [bx+si],ax
0000A014  207901            and [bx+di+0x1],bh
0000A017  000F              add [bx],cl
0000A019  C20100            ret 0x1
0000A01C  2A0B              sub cl,[bp+di]
0000A01E  0200              add al,[bx+si]
0000A020  7D4E              jnl 0xa070
0000A022  0200              add al,[bx+si]
0000A024  7894              js 0x9fba
0000A026  0200              add al,[bx+si]
0000A028  79C8              jns 0x9ff2
0000A02A  0200              add al,[bx+si]
0000A02C  BAF802            mov dx,0x2f8
0000A02F  0039              add [bx+di],bh
0000A031  3B03              cmp ax,[bp+di]
0000A033  00F0              add al,dh
0000A035  7403              jz 0xa03a
0000A037  0087B203          add [bx+0x3b2],al
0000A03B  00BCDF03          add [si+0x3df],bh
0000A03F  00DF              add bh,bl
0000A041  1404              adc al,0x4
0000A043  007A49            add [bp+si+0x49],bh
0000A046  0400              add al,0x0
0000A048  796B              jns 0xa0b5
0000A04A  0400              add al,0x0
0000A04C  EE                out dx,al
0000A04D  81040000          add word [si],0x0
0000A051  0000              add [bx+si],al
0000A053  00753D            add [di+0x3d],dh
0000A056  0000              add [bx+si],al
0000A058  086500            or [di+0x0],ah
0000A05B  0075A2            add [di-0x5e],dh
0000A05E  0000              add [bx+si],al
0000A060  76DB              jna 0xa03d
0000A062  0000              add [bx+si],al
0000A064  7113              jno 0xa079
0000A066  0100              add [bx+si],ax
0000A068  0000              add [bx+si],al
0000A06A  0000              add [bx+si],al
0000A06C  B45C              mov ah,0x5c
0000A06E  0000              add [bx+si],al
0000A070  2669000090        imul ax,[es:bx+si],word 0x9000
0000A075  1A01              sbb al,[bx+di]
0000A077  0035              add [di],dh
0000A079  BE0100            mov si,0x1
0000A07C  0000              add [bx+si],al
0000A07E  0000              add [bx+si],al
0000A080  5C                pop sp
0000A081  7B00              jpo 0xa083
0000A083  0019              add [bx+di],bl
0000A085  1401              adc al,0x1
0000A087  00F1              add cl,dh
0000A089  5D                pop bp
0000A08A  0100              add [bx+si],ax
0000A08C  8B2A              mov bp,[bp+si]
0000A08E  0200              add al,[bx+si]
0000A090  21C2              and dx,ax
0000A092  0200              add al,[bx+si]
0000A094  0000              add [bx+si],al
0000A096  0000              add [bx+si],al
0000A098  5E                pop si
0000A099  50                push ax
0000A09A  0000              add [bx+si],al
0000A09C  C2D600            ret 0xd6
0000A09F  0000              add [bx+si],al
0000A0A1  0000              add [bx+si],al
0000A0A3  004536            add [di+0x36],al
0000A0A6  0000              add [bx+si],al
0000A0A8  BE7B00            mov si,0x7b
0000A0AB  00CB              add bl,cl
0000A0AD  B700              mov bh,0x0
0000A0AF  0074F9            add [si-0x7],dh
0000A0B2  0000              add [bx+si],al
0000A0B4  0000              add [bx+si],al
0000A0B6  0100              add [bx+si],ax
0000A0B8  0200              add al,[bx+si]
0000A0BA  0400              add al,0x0
0000A0BC  050006            add ax,0x600
0000A0BF  0008              add [bx+si],cl
0000A0C1  0009              add [bx+di],cl
0000A0C3  000B              add [bp+di],cl
0000A0C5  000C              add [si],cl
0000A0C7  000D              add [di],cl
0000A0C9  000E0012          add [0x1200],cl
0000A0CD  0013              add [bp+di],dl
0000A0CF  0014              add [si],dl
0000A0D1  0017              add [bx],dl
0000A0D3  0018              add [bx+si],bl
0000A0D5  001A              add [bp+si],bl
0000A0D7  001C              add [si],bl
0000A0D9  001E00FF          add [0xff00],bl
0000A0DD  FF07              inc word [bx]
0000A0DF  000A              add [bp+si],cl
0000A0E1  0010              add [bx+si],dl
0000A0E3  0015              add [di],dl
0000A0E5  001B              add [bp+di],bl
0000A0E7  00FF              add bh,bh
0000A0E9  FF27              jmp [bx]
0000A0EB  0028              add [bx+si],ch
0000A0ED  0029              add [bx+di],ch
0000A0EF  002A              add [bp+si],ch
0000A0F1  00FF              add bh,bh
0000A0F3  FF21              jmp [bx+di]
0000A0F5  0022              add [bp+si],ah
0000A0F7  0023              add [bp+di],ah
0000A0F9  002B              add [bp+di],ch
0000A0FB  002C              add [si],ch
0000A0FD  00FF              add bh,bh
0000A0FF  FF20              jmp [bx+si]
0000A101  001F              add [bx],bl
0000A103  00FF              add bh,bh
0000A105  FF03              inc word [bp+di]
0000A107  000F              add [bx],cl
0000A109  0019              add [bx+di],bl
0000A10B  001D              add [di],bl
0000A10D  00FF              add bh,bh
0000A10F  FF00              inc word [bx+si]
0000A111  0000              add [bx+si],al
0000A113  0000              add [bx+si],al
0000A115  0000              add [bx+si],al
0000A117  004731            add [bx+0x31],al
0000A11A  2E43              cs inc bx
0000A11C  4F                dec di
0000A11D  4E                dec si
0000A11E  004732            add [bx+0x32],al
0000A121  2E43              cs inc bx
0000A123  4F                dec di
0000A124  4E                dec si
0000A125  004733            add [bx+0x33],al
0000A128  2E43              cs inc bx
0000A12A  4F                dec di
0000A12B  4E                dec si
0000A12C  004734            add [bx+0x34],al
0000A12F  2E43              cs inc bx
0000A131  4F                dec di
0000A132  4E                dec si
0000A133  004735            add [bx+0x35],al
0000A136  2E43              cs inc bx
0000A138  4F                dec di
0000A139  4E                dec si
0000A13A  004736            add [bx+0x36],al
0000A13D  2E43              cs inc bx
0000A13F  4F                dec di
0000A140  4E                dec si
0000A141  005341            add [bp+di+0x41],dl
0000A144  55                push bp
0000A145  50                push ax
0000A146  2E4D              cs dec bp
0000A148  41                inc cx
0000A149  55                push bp
0000A14A  004445            add [si+0x45],al
0000A14D  4D                dec bp
0000A14E  4F                dec di
0000A14F  46                inc si
0000A150  52                push dx
0000A151  2E4D              cs dec bp
0000A153  41                inc cx
0000A154  55                push bp
0000A155  0000              add [bx+si],al
0000A157  0000              add [bx+si],al
0000A159  0000              add [bx+si],al
0000A15B  0000              add [bx+si],al
0000A15D  0000              add [bx+si],al
0000A15F  0000              add [bx+si],al
0000A161  0000              add [bx+si],al
0000A163  0000              add [bx+si],al
0000A165  0000              add [bx+si],al
0000A167  0000              add [bx+si],al
0000A169  0000              add [bx+si],al
0000A16B  0000              add [bx+si],al
0000A16D  0000              add [bx+si],al
0000A16F  0000              add [bx+si],al
0000A171  0000              add [bx+si],al
0000A173  0000              add [bx+si],al
0000A175  0000              add [bx+si],al
0000A177  0000              add [bx+si],al
0000A179  0000              add [bx+si],al
0000A17B  0000              add [bx+si],al
0000A17D  0000              add [bx+si],al
0000A17F  0000              add [bx+si],al
0000A181  0000              add [bx+si],al
0000A183  0000              add [bx+si],al
0000A185  0000              add [bx+si],al
0000A187  0000              add [bx+si],al
0000A189  0000              add [bx+si],al
0000A18B  0000              add [bx+si],al
0000A18D  0000              add [bx+si],al
0000A18F  0000              add [bx+si],al
0000A191  0000              add [bx+si],al
0000A193  0000              add [bx+si],al
0000A195  0000              add [bx+si],al
0000A197  0000              add [bx+si],al
0000A199  0000              add [bx+si],al
0000A19B  0000              add [bx+si],al
0000A19D  0000              add [bx+si],al
0000A19F  0000              add [bx+si],al
0000A1A1  0000              add [bx+si],al
0000A1A3  0000              add [bx+si],al
0000A1A5  0000              add [bx+si],al
0000A1A7  0000              add [bx+si],al
0000A1A9  0000              add [bx+si],al
0000A1AB  0000              add [bx+si],al
0000A1AD  0000              add [bx+si],al
0000A1AF  0000              add [bx+si],al
0000A1B1  0000              add [bx+si],al
0000A1B3  0000              add [bx+si],al
0000A1B5  0000              add [bx+si],al
0000A1B7  0000              add [bx+si],al
0000A1B9  0000              add [bx+si],al
0000A1BB  0000              add [bx+si],al
0000A1BD  0000              add [bx+si],al
0000A1BF  0000              add [bx+si],al
0000A1C1  0000              add [bx+si],al
0000A1C3  0000              add [bx+si],al
0000A1C5  0000              add [bx+si],al
0000A1C7  0000              add [bx+si],al
0000A1C9  0000              add [bx+si],al
0000A1CB  0000              add [bx+si],al
0000A1CD  0000              add [bx+si],al
0000A1CF  0000              add [bx+si],al
0000A1D1  0000              add [bx+si],al
0000A1D3  0000              add [bx+si],al
0000A1D5  0000              add [bx+si],al
0000A1D7  0000              add [bx+si],al
0000A1D9  0000              add [bx+si],al
0000A1DB  0000              add [bx+si],al
0000A1DD  0000              add [bx+si],al
0000A1DF  0000              add [bx+si],al
0000A1E1  0000              add [bx+si],al
0000A1E3  0000              add [bx+si],al
0000A1E5  0000              add [bx+si],al
0000A1E7  0000              add [bx+si],al
0000A1E9  0000              add [bx+si],al
0000A1EB  0000              add [bx+si],al
0000A1ED  0000              add [bx+si],al
0000A1EF  0000              add [bx+si],al
0000A1F1  0000              add [bx+si],al
0000A1F3  0000              add [bx+si],al
0000A1F5  0000              add [bx+si],al
0000A1F7  0000              add [bx+si],al
0000A1F9  0000              add [bx+si],al
0000A1FB  0000              add [bx+si],al
0000A1FD  0000              add [bx+si],al
0000A1FF  0000              add [bx+si],al
0000A201  0000              add [bx+si],al
0000A203  0000              add [bx+si],al
0000A205  0000              add [bx+si],al
0000A207  0000              add [bx+si],al
0000A209  0000              add [bx+si],al
0000A20B  0000              add [bx+si],al
0000A20D  0000              add [bx+si],al
0000A20F  0000              add [bx+si],al
0000A211  0000              add [bx+si],al
0000A213  0000              add [bx+si],al
0000A215  0000              add [bx+si],al
0000A217  0000              add [bx+si],al
0000A219  0000              add [bx+si],al
0000A21B  0000              add [bx+si],al
0000A21D  0000              add [bx+si],al
0000A21F  0000              add [bx+si],al
0000A221  0000              add [bx+si],al
0000A223  0000              add [bx+si],al
0000A225  0000              add [bx+si],al
0000A227  0000              add [bx+si],al
0000A229  0000              add [bx+si],al
0000A22B  0000              add [bx+si],al
0000A22D  0000              add [bx+si],al
0000A22F  0000              add [bx+si],al
0000A231  0000              add [bx+si],al
0000A233  0000              add [bx+si],al
0000A235  0000              add [bx+si],al
0000A237  0000              add [bx+si],al
0000A239  0000              add [bx+si],al
0000A23B  0000              add [bx+si],al
0000A23D  0000              add [bx+si],al
0000A23F  0000              add [bx+si],al
0000A241  0000              add [bx+si],al
0000A243  0000              add [bx+si],al
0000A245  0000              add [bx+si],al
0000A247  0000              add [bx+si],al
0000A249  0000              add [bx+si],al
0000A24B  0000              add [bx+si],al
0000A24D  0000              add [bx+si],al
0000A24F  0000              add [bx+si],al
0000A251  0000              add [bx+si],al
0000A253  0000              add [bx+si],al
0000A255  0000              add [bx+si],al
0000A257  0000              add [bx+si],al
0000A259  0000              add [bx+si],al
0000A25B  0000              add [bx+si],al
0000A25D  0000              add [bx+si],al
0000A25F  0000              add [bx+si],al
0000A261  0000              add [bx+si],al
0000A263  0000              add [bx+si],al
0000A265  0000              add [bx+si],al
0000A267  0000              add [bx+si],al
0000A269  0000              add [bx+si],al
0000A26B  0000              add [bx+si],al
0000A26D  0000              add [bx+si],al
0000A26F  0000              add [bx+si],al
0000A271  0000              add [bx+si],al
0000A273  0000              add [bx+si],al
0000A275  0000              add [bx+si],al
0000A277  0000              add [bx+si],al
0000A279  0000              add [bx+si],al
0000A27B  0000              add [bx+si],al
0000A27D  0000              add [bx+si],al
0000A27F  0000              add [bx+si],al
0000A281  0000              add [bx+si],al
0000A283  0000              add [bx+si],al
0000A285  0000              add [bx+si],al
0000A287  0000              add [bx+si],al
0000A289  0000              add [bx+si],al
0000A28B  0000              add [bx+si],al
0000A28D  0000              add [bx+si],al
0000A28F  0000              add [bx+si],al
0000A291  0000              add [bx+si],al
0000A293  0000              add [bx+si],al
0000A295  0000              add [bx+si],al
0000A297  0000              add [bx+si],al
0000A299  0000              add [bx+si],al
0000A29B  0000              add [bx+si],al
0000A29D  0000              add [bx+si],al
0000A29F  0000              add [bx+si],al
0000A2A1  0000              add [bx+si],al
0000A2A3  0000              add [bx+si],al
0000A2A5  0000              add [bx+si],al
0000A2A7  0000              add [bx+si],al
0000A2A9  0000              add [bx+si],al
0000A2AB  0000              add [bx+si],al
0000A2AD  0000              add [bx+si],al
0000A2AF  0000              add [bx+si],al
0000A2B1  0000              add [bx+si],al
0000A2B3  0000              add [bx+si],al
0000A2B5  0000              add [bx+si],al
0000A2B7  0000              add [bx+si],al
0000A2B9  0000              add [bx+si],al
0000A2BB  0000              add [bx+si],al
0000A2BD  0000              add [bx+si],al
0000A2BF  0000              add [bx+si],al
0000A2C1  0000              add [bx+si],al
0000A2C3  0000              add [bx+si],al
0000A2C5  0000              add [bx+si],al
0000A2C7  0000              add [bx+si],al
0000A2C9  0000              add [bx+si],al
0000A2CB  0000              add [bx+si],al
0000A2CD  0000              add [bx+si],al
0000A2CF  0000              add [bx+si],al
0000A2D1  0000              add [bx+si],al
0000A2D3  0000              add [bx+si],al
0000A2D5  0000              add [bx+si],al
0000A2D7  0000              add [bx+si],al
0000A2D9  0000              add [bx+si],al
0000A2DB  0000              add [bx+si],al
0000A2DD  0000              add [bx+si],al
0000A2DF  0000              add [bx+si],al
0000A2E1  0000              add [bx+si],al
0000A2E3  0000              add [bx+si],al
0000A2E5  0000              add [bx+si],al
0000A2E7  0000              add [bx+si],al
0000A2E9  0000              add [bx+si],al
0000A2EB  0000              add [bx+si],al
0000A2ED  0000              add [bx+si],al
0000A2EF  0000              add [bx+si],al
0000A2F1  0000              add [bx+si],al
0000A2F3  0000              add [bx+si],al
0000A2F5  0000              add [bx+si],al
0000A2F7  0000              add [bx+si],al
0000A2F9  0000              add [bx+si],al
0000A2FB  0000              add [bx+si],al
0000A2FD  0000              add [bx+si],al
0000A2FF  0000              add [bx+si],al
0000A301  0000              add [bx+si],al
0000A303  0000              add [bx+si],al
0000A305  0000              add [bx+si],al
0000A307  0000              add [bx+si],al
0000A309  0000              add [bx+si],al
0000A30B  0000              add [bx+si],al
0000A30D  0000              add [bx+si],al
0000A30F  0000              add [bx+si],al
0000A311  0000              add [bx+si],al
0000A313  0000              add [bx+si],al
0000A315  0000              add [bx+si],al
0000A317  0000              add [bx+si],al
0000A319  0000              add [bx+si],al
0000A31B  0000              add [bx+si],al
0000A31D  0000              add [bx+si],al
0000A31F  0000              add [bx+si],al
0000A321  0000              add [bx+si],al
0000A323  0000              add [bx+si],al
0000A325  0000              add [bx+si],al
0000A327  0000              add [bx+si],al
0000A329  0000              add [bx+si],al
0000A32B  0000              add [bx+si],al
0000A32D  0000              add [bx+si],al
0000A32F  0000              add [bx+si],al
0000A331  0000              add [bx+si],al
0000A333  0000              add [bx+si],al
0000A335  0000              add [bx+si],al
0000A337  0000              add [bx+si],al
0000A339  0000              add [bx+si],al
0000A33B  0000              add [bx+si],al
0000A33D  0000              add [bx+si],al
0000A33F  0000              add [bx+si],al
0000A341  0000              add [bx+si],al
0000A343  0000              add [bx+si],al
0000A345  0000              add [bx+si],al
0000A347  0000              add [bx+si],al
0000A349  0000              add [bx+si],al
0000A34B  0000              add [bx+si],al
0000A34D  0000              add [bx+si],al
0000A34F  0000              add [bx+si],al
0000A351  0000              add [bx+si],al
0000A353  0000              add [bx+si],al
0000A355  0000              add [bx+si],al
0000A357  0000              add [bx+si],al
0000A359  0000              add [bx+si],al
0000A35B  0000              add [bx+si],al
0000A35D  0000              add [bx+si],al
0000A35F  0000              add [bx+si],al
0000A361  0000              add [bx+si],al
0000A363  0000              add [bx+si],al
0000A365  0000              add [bx+si],al
0000A367  0000              add [bx+si],al
0000A369  0000              add [bx+si],al
0000A36B  0000              add [bx+si],al
0000A36D  0000              add [bx+si],al
0000A36F  0000              add [bx+si],al
0000A371  0000              add [bx+si],al
0000A373  0000              add [bx+si],al
0000A375  0000              add [bx+si],al
0000A377  0000              add [bx+si],al
0000A379  0000              add [bx+si],al
0000A37B  0000              add [bx+si],al
0000A37D  0000              add [bx+si],al
0000A37F  0000              add [bx+si],al
0000A381  0000              add [bx+si],al
0000A383  0000              add [bx+si],al
0000A385  0000              add [bx+si],al
0000A387  0000              add [bx+si],al
0000A389  0000              add [bx+si],al
0000A38B  0000              add [bx+si],al
0000A38D  0000              add [bx+si],al
0000A38F  0000              add [bx+si],al
0000A391  0000              add [bx+si],al
0000A393  0000              add [bx+si],al
0000A395  0000              add [bx+si],al
0000A397  0000              add [bx+si],al
0000A399  0000              add [bx+si],al
0000A39B  0000              add [bx+si],al
0000A39D  0000              add [bx+si],al
0000A39F  0000              add [bx+si],al
0000A3A1  0000              add [bx+si],al
0000A3A3  0000              add [bx+si],al
0000A3A5  0000              add [bx+si],al
0000A3A7  0000              add [bx+si],al
0000A3A9  0000              add [bx+si],al
0000A3AB  0000              add [bx+si],al
0000A3AD  0000              add [bx+si],al
0000A3AF  0000              add [bx+si],al
0000A3B1  0000              add [bx+si],al
0000A3B3  0000              add [bx+si],al
0000A3B5  0000              add [bx+si],al
0000A3B7  0000              add [bx+si],al
0000A3B9  0000              add [bx+si],al
0000A3BB  0000              add [bx+si],al
0000A3BD  0000              add [bx+si],al
0000A3BF  0000              add [bx+si],al
0000A3C1  0000              add [bx+si],al
0000A3C3  0000              add [bx+si],al
0000A3C5  0000              add [bx+si],al
0000A3C7  0000              add [bx+si],al
0000A3C9  0000              add [bx+si],al
0000A3CB  0000              add [bx+si],al
0000A3CD  0000              add [bx+si],al
0000A3CF  0000              add [bx+si],al
0000A3D1  0000              add [bx+si],al
0000A3D3  0000              add [bx+si],al
0000A3D5  0000              add [bx+si],al
0000A3D7  0000              add [bx+si],al
0000A3D9  0000              add [bx+si],al
0000A3DB  0000              add [bx+si],al
0000A3DD  0000              add [bx+si],al
0000A3DF  0000              add [bx+si],al
0000A3E1  0000              add [bx+si],al
0000A3E3  0000              add [bx+si],al
0000A3E5  0000              add [bx+si],al
0000A3E7  0000              add [bx+si],al
0000A3E9  0000              add [bx+si],al
0000A3EB  0000              add [bx+si],al
0000A3ED  0000              add [bx+si],al
0000A3EF  0000              add [bx+si],al
0000A3F1  0000              add [bx+si],al
0000A3F3  0000              add [bx+si],al
0000A3F5  0000              add [bx+si],al
0000A3F7  0000              add [bx+si],al
0000A3F9  0000              add [bx+si],al
0000A3FB  0000              add [bx+si],al
0000A3FD  0000              add [bx+si],al
0000A3FF  0000              add [bx+si],al
0000A401  0000              add [bx+si],al
0000A403  0000              add [bx+si],al
0000A405  0000              add [bx+si],al
0000A407  0000              add [bx+si],al
0000A409  0000              add [bx+si],al
0000A40B  0000              add [bx+si],al
0000A40D  0000              add [bx+si],al
0000A40F  0000              add [bx+si],al
0000A411  0000              add [bx+si],al
0000A413  0000              add [bx+si],al
0000A415  0000              add [bx+si],al
0000A417  0000              add [bx+si],al
0000A419  0000              add [bx+si],al
0000A41B  0000              add [bx+si],al
0000A41D  0000              add [bx+si],al
0000A41F  0000              add [bx+si],al
0000A421  0000              add [bx+si],al
0000A423  0000              add [bx+si],al
0000A425  0000              add [bx+si],al
0000A427  0000              add [bx+si],al
0000A429  0000              add [bx+si],al
0000A42B  0000              add [bx+si],al
0000A42D  0000              add [bx+si],al
0000A42F  0000              add [bx+si],al
0000A431  0000              add [bx+si],al
0000A433  0000              add [bx+si],al
0000A435  0000              add [bx+si],al
0000A437  0000              add [bx+si],al
0000A439  0000              add [bx+si],al
0000A43B  0000              add [bx+si],al
0000A43D  0000              add [bx+si],al
0000A43F  0000              add [bx+si],al
0000A441  0000              add [bx+si],al
0000A443  0000              add [bx+si],al
0000A445  0000              add [bx+si],al
0000A447  0000              add [bx+si],al
0000A449  0000              add [bx+si],al
0000A44B  0000              add [bx+si],al
0000A44D  0000              add [bx+si],al
0000A44F  0000              add [bx+si],al
0000A451  0000              add [bx+si],al
0000A453  0000              add [bx+si],al
0000A455  0000              add [bx+si],al
0000A457  0000              add [bx+si],al
0000A459  0000              add [bx+si],al
0000A45B  0000              add [bx+si],al
0000A45D  0000              add [bx+si],al
0000A45F  0000              add [bx+si],al
0000A461  0000              add [bx+si],al
0000A463  0000              add [bx+si],al
0000A465  0000              add [bx+si],al
0000A467  0000              add [bx+si],al
0000A469  0000              add [bx+si],al
0000A46B  0000              add [bx+si],al
0000A46D  0000              add [bx+si],al
0000A46F  0000              add [bx+si],al
0000A471  0000              add [bx+si],al
0000A473  0000              add [bx+si],al
0000A475  0000              add [bx+si],al
0000A477  0000              add [bx+si],al
0000A479  0000              add [bx+si],al
0000A47B  0000              add [bx+si],al
0000A47D  0000              add [bx+si],al
0000A47F  0000              add [bx+si],al
0000A481  0000              add [bx+si],al
0000A483  0000              add [bx+si],al
0000A485  0000              add [bx+si],al
0000A487  0000              add [bx+si],al
0000A489  0000              add [bx+si],al
0000A48B  0000              add [bx+si],al
0000A48D  0000              add [bx+si],al
0000A48F  0000              add [bx+si],al
0000A491  0000              add [bx+si],al
0000A493  0000              add [bx+si],al
0000A495  0000              add [bx+si],al
0000A497  0000              add [bx+si],al
0000A499  0000              add [bx+si],al
0000A49B  0000              add [bx+si],al
0000A49D  0000              add [bx+si],al
0000A49F  0000              add [bx+si],al
0000A4A1  0000              add [bx+si],al
0000A4A3  0000              add [bx+si],al
0000A4A5  0000              add [bx+si],al
0000A4A7  0000              add [bx+si],al
0000A4A9  0000              add [bx+si],al
0000A4AB  0000              add [bx+si],al
0000A4AD  0000              add [bx+si],al
0000A4AF  0000              add [bx+si],al
0000A4B1  0000              add [bx+si],al
0000A4B3  0000              add [bx+si],al
0000A4B5  0000              add [bx+si],al
0000A4B7  0000              add [bx+si],al
0000A4B9  0000              add [bx+si],al
0000A4BB  0000              add [bx+si],al
0000A4BD  0000              add [bx+si],al
0000A4BF  0000              add [bx+si],al
0000A4C1  0000              add [bx+si],al
0000A4C3  0000              add [bx+si],al
0000A4C5  0000              add [bx+si],al
0000A4C7  0000              add [bx+si],al
0000A4C9  0000              add [bx+si],al
0000A4CB  0000              add [bx+si],al
0000A4CD  0000              add [bx+si],al
0000A4CF  0000              add [bx+si],al
0000A4D1  0000              add [bx+si],al
0000A4D3  0000              add [bx+si],al
0000A4D5  0000              add [bx+si],al
0000A4D7  0000              add [bx+si],al
0000A4D9  0000              add [bx+si],al
0000A4DB  0000              add [bx+si],al
0000A4DD  0000              add [bx+si],al
0000A4DF  0000              add [bx+si],al
0000A4E1  0000              add [bx+si],al
0000A4E3  0001              add [bx+di],al
0000A4E5  0000              add [bx+si],al
0000A4E7  0000              add [bx+si],al
0000A4E9  0000              add [bx+si],al
0000A4EB  0000              add [bx+si],al
0000A4ED  0000              add [bx+si],al
0000A4EF  0000              add [bx+si],al
0000A4F1  0000              add [bx+si],al
0000A4F3  0000              add [bx+si],al
0000A4F5  0000              add [bx+si],al
0000A4F7  0000              add [bx+si],al
0000A4F9  0000              add [bx+si],al
0000A4FB  0000              add [bx+si],al
0000A4FD  0000              add [bx+si],al
0000A4FF  0000              add [bx+si],al
0000A501  0000              add [bx+si],al
0000A503  0000              add [bx+si],al
0000A505  0000              add [bx+si],al
0000A507  0003              add [bp+di],al
0000A509  111F              adc [bx],bx
0000A50B  2C3A              sub al,0x3a
0000A50D  3F                aas
0000A50E  3F                aas
0000A50F  0007              add [bx],al
0000A511  121E2B36          adc bl,[0x362b]
0000A515  3F                aas
0000A516  3F                aas
0000A517  0004              add [si],al
0000A519  0D1D29            or ax,0x291d
0000A51C  3C3F              cmp al,0x3f
0000A51E  3F                aas
0000A51F  0008              add [bx+si],cl
0000A521  040C              add al,0xc
0000A523  020A              add cl,[bp+si]
0000A525  06                push es
0000A526  0E                push cs
0000A527  0109              add [bx+di],cx
0000A529  050D03            add ax,0x30d
0000A52C  0B07              or ax,[bx]
0000A52E  0F0000            sldt [bx+si]
0000A531  0800              or [bx+si],al
0000A533  0202              add al,[bp+si]
0000A535  0C07              or al,0x7
0000A537  0B07              or ax,[bx]
0000A539  0804              or [si],al
0000A53B  0808              or [bx+si],cl
0000A53D  0F                db 0x0f
0000A53E  0F07              sysret
0000A540  03060002          add ax,[0x200]
0000A544  000F              add [bx],cl
0000A546  0C0B              or al,0xb
0000A548  0806060C          or [0xc06],al
0000A54C  040F              add al,0xf
0000A54E  0F0000            sldt [bx+si]
0000A551  0800              or [bx+si],al
0000A553  0202              add al,[bp+si]
0000A555  0C07              or al,0x7
0000A557  07                pop es
0000A558  07                pop es
0000A559  0804              or [si],al
0000A55B  0808              or [bx+si],cl
0000A55D  0F                db 0x0f
0000A55E  0F07              sysret
0000A560  0406              add al,0x6
0000A562  0002              add [bp+si],al
0000A564  000F              add [bx],cl
0000A566  0C0F              or al,0xf
0000A568  0006060C          add [0xc06],al
0000A56C  040F              add al,0xf
0000A56E  0F0000            sldt [bx+si]
0000A571  0301              add ax,[bx+di]
0000A573  0200              add al,[bx+si]
0000A575  0003              add [bp+di],al
0000A577  0100              add [bx+si],ax
0000A579  0003              add [bp+di],al
0000A57B  0301              add ax,[bx+di]
0000A57D  0103              add [bp+di],ax
0000A57F  0000              add [bx+si],al
0000A581  0000              add [bx+si],al
0000A583  0000              add [bx+si],al
0000A585  0000              add [bx+si],al
0000A587  0000              add [bx+si],al
0000A589  0000              add [bx+si],al
0000A58B  0000              add [bx+si],al
0000A58D  0000              add [bx+si],al
0000A58F  0000              add [bx+si],al
0000A591  0000              add [bx+si],al
0000A593  0000              add [bx+si],al
0000A595  0000              add [bx+si],al
0000A597  0000              add [bx+si],al
0000A599  0000              add [bx+si],al
0000A59B  0000              add [bx+si],al
0000A59D  0000              add [bx+si],al
0000A59F  0000              add [bx+si],al
0000A5A1  0000              add [bx+si],al
0000A5A3  0000              add [bx+si],al
0000A5A5  0000              add [bx+si],al
0000A5A7  0000              add [bx+si],al
0000A5A9  0000              add [bx+si],al
0000A5AB  0000              add [bx+si],al
0000A5AD  0000              add [bx+si],al
0000A5AF  0000              add [bx+si],al
0000A5B1  0000              add [bx+si],al
0000A5B3  0000              add [bx+si],al
0000A5B5  0000              add [bx+si],al
0000A5B7  0000              add [bx+si],al
0000A5B9  0000              add [bx+si],al
0000A5BB  0000              add [bx+si],al
0000A5BD  0000              add [bx+si],al
0000A5BF  0007              add [bx],al
0000A5C1  17                pop ss
0000A5C2  07                pop es
0000A5C3  17                pop ss
0000A5C4  0D090E            or ax,0xe09
0000A5C7  0905              or [di],ax
0000A5C9  0C06              or al,0x6
0000A5CB  0C0D              or al,0xd
0000A5CD  0400              add al,0x0
0000A5CF  0405              add al,0x5
0000A5D1  0900              or [bx+si],ax
0000A5D3  0A02              or al,[bp+si]
0000A5D5  0002              add [bp+si],al
0000A5D7  0A03              or al,[bp+di]
0000A5D9  0003              add [bp+di],al
0000A5DB  07                pop es
0000A5DC  050006            add ax,0x600
0000A5DF  07                pop es
0000A5E0  07                pop es
0000A5E1  0A00              or al,[bx+si]
0000A5E3  0001              add [bx+di],al
0000A5E5  0100              add [bx+si],ax
0000A5E7  0000              add [bx+si],al
0000A5E9  0101              add [bx+di],ax
0000A5EB  0000              add [bx+si],al
0000A5ED  0101              add [bx+di],ax
0000A5EF  0000              add [bx+si],al
0000A5F1  0100              add [bx+si],ax
0000A5F3  0000              add [bx+si],al
0000A5F5  0000              add [bx+si],al
0000A5F7  0000              add [bx+si],al
0000A5F9  0102              add [bp+si],ax
0000A5FB  0301              add ax,[bx+di]
0000A5FD  0000              add [bx+si],al
0000A5FF  0100              add [bx+si],ax
0000A601  0100              add [bx+si],ax
0000A603  0001              add [bx+di],al
0000A605  0000              add [bx+si],al
0000A607  0100              add [bx+si],ax
0000A609  0100              add [bx+si],ax
0000A60B  0000              add [bx+si],al
0000A60D  0000              add [bx+si],al
0000A60F  0001              add [bx+di],al
0000A611  0000              add [bx+si],al
0000A613  0000              add [bx+si],al
0000A615  0000              add [bx+si],al
0000A617  0000              add [bx+si],al
0000A619  0000              add [bx+si],al
0000A61B  0000              add [bx+si],al
0000A61D  0000              add [bx+si],al
0000A61F  0000              add [bx+si],al
0000A621  0000              add [bx+si],al
0000A623  0000              add [bx+si],al
0000A625  0000              add [bx+si],al
0000A627  0000              add [bx+si],al
0000A629  0000              add [bx+si],al
0000A62B  0000              add [bx+si],al
0000A62D  0000              add [bx+si],al
0000A62F  0000              add [bx+si],al
0000A631  0000              add [bx+si],al
0000A633  0000              add [bx+si],al
0000A635  0000              add [bx+si],al
0000A637  0000              add [bx+si],al
0000A639  0000              add [bx+si],al
0000A63B  0000              add [bx+si],al
0000A63D  0000              add [bx+si],al
0000A63F  0001              add [bx+di],al
0000A641  0000              add [bx+si],al
0000A643  0000              add [bx+si],al
0000A645  0000              add [bx+si],al
0000A647  0000              add [bx+si],al
0000A649  0000              add [bx+si],al
0000A64B  0000              add [bx+si],al
0000A64D  0000              add [bx+si],al
0000A64F  0100              add [bx+si],ax
0000A651  0000              add [bx+si],al
0000A653  0000              add [bx+si],al
0000A655  0000              add [bx+si],al
0000A657  0000              add [bx+si],al
0000A659  0001              add [bx+di],al
0000A65B  0000              add [bx+si],al
0000A65D  0000              add [bx+si],al
0000A65F  0000              add [bx+si],al
0000A661  0000              add [bx+si],al
0000A663  0000              add [bx+si],al
0000A665  0000              add [bx+si],al
0000A667  0000              add [bx+si],al
0000A669  0100              add [bx+si],ax
0000A66B  0000              add [bx+si],al
0000A66D  0000              add [bx+si],al
0000A66F  0000              add [bx+si],al
0000A671  0000              add [bx+si],al
0000A673  0001              add [bx+di],al
0000A675  0000              add [bx+si],al
0000A677  0000              add [bx+si],al
0000A679  0000              add [bx+si],al
0000A67B  0000              add [bx+si],al
0000A67D  0000              add [bx+si],al
0000A67F  0000              add [bx+si],al
0000A681  0000              add [bx+si],al
0000A683  0100              add [bx+si],ax
0000A685  0000              add [bx+si],al
0000A687  0000              add [bx+si],al
0000A689  0000              add [bx+si],al
0000A68B  0001              add [bx+di],al
0000A68D  0101              add [bx+di],ax
0000A68F  0000              add [bx+si],al
0000A691  0000              add [bx+si],al
0000A693  0000              add [bx+si],al
0000A695  0000              add [bx+si],al
0000A697  0000              add [bx+si],al
0000A699  0000              add [bx+si],al
0000A69B  0000              add [bx+si],al
0000A69D  0100              add [bx+si],ax
0000A69F  0000              add [bx+si],al
0000A6A1  0000              add [bx+si],al
0000A6A3  0000              add [bx+si],al
0000A6A5  0101              add [bx+di],ax
0000A6A7  0101              add [bx+di],ax
0000A6A9  0000              add [bx+si],al
0000A6AB  0000              add [bx+si],al
0000A6AD  0000              add [bx+si],al
0000A6AF  0000              add [bx+si],al
0000A6B1  0000              add [bx+si],al
0000A6B3  0000              add [bx+si],al
0000A6B5  0000              add [bx+si],al
0000A6B7  0100              add [bx+si],ax
0000A6B9  0000              add [bx+si],al
0000A6BB  0000              add [bx+si],al
0000A6BD  0000              add [bx+si],al
0000A6BF  0101              add [bx+di],ax
0000A6C1  0101              add [bx+di],ax
0000A6C3  0000              add [bx+si],al
0000A6C5  0000              add [bx+si],al
0000A6C7  0000              add [bx+si],al
0000A6C9  0000              add [bx+si],al
0000A6CB  0000              add [bx+si],al
0000A6CD  0000              add [bx+si],al
0000A6CF  0000              add [bx+si],al
0000A6D1  0100              add [bx+si],ax
0000A6D3  0000              add [bx+si],al
0000A6D5  0000              add [bx+si],al
0000A6D7  0000              add [bx+si],al
0000A6D9  0101              add [bx+di],ax
0000A6DB  0101              add [bx+di],ax
0000A6DD  0000              add [bx+si],al
0000A6DF  0000              add [bx+si],al
0000A6E1  0000              add [bx+si],al
0000A6E3  0000              add [bx+si],al
0000A6E5  0000              add [bx+si],al
0000A6E7  0000              add [bx+si],al
0000A6E9  0000              add [bx+si],al
0000A6EB  0000              add [bx+si],al
0000A6ED  0000              add [bx+si],al
0000A6EF  0000              add [bx+si],al
0000A6F1  0000              add [bx+si],al
0000A6F3  0000              add [bx+si],al
0000A6F5  0100              add [bx+si],ax
0000A6F7  0000              add [bx+si],al
0000A6F9  0000              add [bx+si],al
0000A6FB  0000              add [bx+si],al
0000A6FD  0000              add [bx+si],al
0000A6FF  0000              add [bx+si],al
0000A701  0000              add [bx+si],al
0000A703  0000              add [bx+si],al
0000A705  0100              add [bx+si],ax
0000A707  0000              add [bx+si],al
0000A709  0000              add [bx+si],al
0000A70B  0000              add [bx+si],al
0000A70D  0000              add [bx+si],al
0000A70F  0101              add [bx+di],ax
0000A711  0000              add [bx+si],al
0000A713  0000              add [bx+si],al
0000A715  0000              add [bx+si],al
0000A717  0000              add [bx+si],al
0000A719  0000              add [bx+si],al
0000A71B  0000              add [bx+si],al
0000A71D  0000              add [bx+si],al
0000A71F  0100              add [bx+si],ax
0000A721  0000              add [bx+si],al
0000A723  0000              add [bx+si],al
0000A725  0000              add [bx+si],al
0000A727  0000              add [bx+si],al
0000A729  0101              add [bx+di],ax
0000A72B  0000              add [bx+si],al
0000A72D  0000              add [bx+si],al
0000A72F  0000              add [bx+si],al
0000A731  0000              add [bx+si],al
0000A733  0000              add [bx+si],al
0000A735  0000              add [bx+si],al
0000A737  0000              add [bx+si],al
0000A739  0100              add [bx+si],ax
0000A73B  0000              add [bx+si],al
0000A73D  0000              add [bx+si],al
0000A73F  0000              add [bx+si],al
0000A741  0000              add [bx+si],al
0000A743  0000              add [bx+si],al
0000A745  0000              add [bx+si],al
0000A747  0000              add [bx+si],al
0000A749  0000              add [bx+si],al
0000A74B  0000              add [bx+si],al
0000A74D  0000              add [bx+si],al
0000A74F  0000              add [bx+si],al
0000A751  0000              add [bx+si],al
0000A753  0100              add [bx+si],ax
0000A755  0000              add [bx+si],al
0000A757  0000              add [bx+si],al
0000A759  0000              add [bx+si],al
0000A75B  0101              add [bx+di],ax
0000A75D  0100              add [bx+si],ax
0000A75F  0000              add [bx+si],al
0000A761  0000              add [bx+si],al
0000A763  0000              add [bx+si],al
0000A765  0000              add [bx+si],al
0000A767  0000              add [bx+si],al
0000A769  0000              add [bx+si],al
0000A76B  0000              add [bx+si],al
0000A76D  0100              add [bx+si],ax
0000A76F  0000              add [bx+si],al
0000A771  0000              add [bx+si],al
0000A773  0000              add [bx+si],al
0000A775  0101              add [bx+di],ax
0000A777  0100              add [bx+si],ax
0000A779  0000              add [bx+si],al
0000A77B  0000              add [bx+si],al
0000A77D  0000              add [bx+si],al
0000A77F  0000              add [bx+si],al
0000A781  0000              add [bx+si],al
0000A783  0000              add [bx+si],al
0000A785  0000              add [bx+si],al
0000A787  0000              add [bx+si],al
0000A789  0000              add [bx+si],al
0000A78B  0000              add [bx+si],al
0000A78D  0000              add [bx+si],al
0000A78F  0000              add [bx+si],al
0000A791  0000              add [bx+si],al
0000A793  0000              add [bx+si],al
0000A795  0000              add [bx+si],al
0000A797  0000              add [bx+si],al
0000A799  0000              add [bx+si],al
0000A79B  0000              add [bx+si],al
0000A79D  0000              add [bx+si],al
0000A79F  0000              add [bx+si],al
0000A7A1  0000              add [bx+si],al
0000A7A3  0000              add [bx+si],al
0000A7A5  0000              add [bx+si],al
0000A7A7  0000              add [bx+si],al
0000A7A9  0000              add [bx+si],al
0000A7AB  0000              add [bx+si],al
0000A7AD  0000              add [bx+si],al
0000A7AF  0000              add [bx+si],al
0000A7B1  0000              add [bx+si],al
0000A7B3  0000              add [bx+si],al
0000A7B5  0000              add [bx+si],al
0000A7B7  0000              add [bx+si],al
0000A7B9  0000              add [bx+si],al
0000A7BB  0000              add [bx+si],al
0000A7BD  0000              add [bx+si],al
0000A7BF  0000              add [bx+si],al
0000A7C1  0000              add [bx+si],al
0000A7C3  0000              add [bx+si],al
0000A7C5  0000              add [bx+si],al
0000A7C7  0000              add [bx+si],al
0000A7C9  0000              add [bx+si],al
0000A7CB  0000              add [bx+si],al
0000A7CD  0000              add [bx+si],al
0000A7CF  0000              add [bx+si],al
0000A7D1  0000              add [bx+si],al
0000A7D3  0000              add [bx+si],al
0000A7D5  0000              add [bx+si],al
0000A7D7  0000              add [bx+si],al
0000A7D9  0000              add [bx+si],al
0000A7DB  0000              add [bx+si],al
0000A7DD  0000              add [bx+si],al
0000A7DF  0000              add [bx+si],al
0000A7E1  0000              add [bx+si],al
0000A7E3  0000              add [bx+si],al
0000A7E5  0000              add [bx+si],al
0000A7E7  0000              add [bx+si],al
0000A7E9  0000              add [bx+si],al
0000A7EB  0000              add [bx+si],al
0000A7ED  0000              add [bx+si],al
0000A7EF  0000              add [bx+si],al
0000A7F1  0000              add [bx+si],al
0000A7F3  0000              add [bx+si],al
0000A7F5  0000              add [bx+si],al
0000A7F7  0000              add [bx+si],al
0000A7F9  0000              add [bx+si],al
0000A7FB  0000              add [bx+si],al
0000A7FD  0000              add [bx+si],al
0000A7FF  0000              add [bx+si],al
0000A801  0000              add [bx+si],al
0000A803  0000              add [bx+si],al
0000A805  0000              add [bx+si],al
0000A807  0000              add [bx+si],al
0000A809  0000              add [bx+si],al
0000A80B  0000              add [bx+si],al
0000A80D  0000              add [bx+si],al
0000A80F  0000              add [bx+si],al
0000A811  0000              add [bx+si],al
0000A813  0000              add [bx+si],al
0000A815  0000              add [bx+si],al
0000A817  0000              add [bx+si],al
0000A819  0000              add [bx+si],al
0000A81B  0000              add [bx+si],al
0000A81D  0000              add [bx+si],al
0000A81F  0000              add [bx+si],al
0000A821  0000              add [bx+si],al
0000A823  0000              add [bx+si],al
0000A825  0000              add [bx+si],al
0000A827  0000              add [bx+si],al
0000A829  0000              add [bx+si],al
0000A82B  0000              add [bx+si],al
0000A82D  0000              add [bx+si],al
0000A82F  0000              add [bx+si],al
0000A831  0000              add [bx+si],al
0000A833  0000              add [bx+si],al
0000A835  0000              add [bx+si],al
0000A837  0000              add [bx+si],al
0000A839  0000              add [bx+si],al
0000A83B  0000              add [bx+si],al
0000A83D  0000              add [bx+si],al
0000A83F  0000              add [bx+si],al
0000A841  0000              add [bx+si],al
0000A843  0000              add [bx+si],al
0000A845  0000              add [bx+si],al
0000A847  0000              add [bx+si],al
0000A849  0000              add [bx+si],al
0000A84B  0000              add [bx+si],al
0000A84D  0000              add [bx+si],al
0000A84F  0000              add [bx+si],al
0000A851  0000              add [bx+si],al
0000A853  0000              add [bx+si],al
0000A855  0000              add [bx+si],al
0000A857  0000              add [bx+si],al
0000A859  0000              add [bx+si],al
0000A85B  0000              add [bx+si],al
0000A85D  0000              add [bx+si],al
0000A85F  0000              add [bx+si],al
0000A861  0000              add [bx+si],al
0000A863  0000              add [bx+si],al
0000A865  0000              add [bx+si],al
0000A867  0000              add [bx+si],al
0000A869  0000              add [bx+si],al
0000A86B  0000              add [bx+si],al
0000A86D  0000              add [bx+si],al
0000A86F  0000              add [bx+si],al
0000A871  0000              add [bx+si],al
0000A873  0000              add [bx+si],al
0000A875  0000              add [bx+si],al
0000A877  0000              add [bx+si],al
0000A879  0000              add [bx+si],al
0000A87B  0000              add [bx+si],al
0000A87D  0000              add [bx+si],al
0000A87F  0000              add [bx+si],al
0000A881  00DC              add ah,bl
0000A883  E4EB              in al,0xeb
0000A885  F1                int1
0000A886  F6FA              idiv dl
0000A888  FD                std
0000A889  FF00              inc word [bx+si]
0000A88B  0103              add [bp+di],ax
0000A88D  06                push es
0000A88E  0A0F              or cl,[bx]
0000A890  151CE4            adc ax,0xe41c
0000A893  0000              add [bx+si],al
0000A895  0000              add [bx+si],al
0000A897  0000              add [bx+si],al
0000A899  0000              add [bx+si],al
0000A89B  0000              add [bx+si],al
0000A89D  0000              add [bx+si],al
0000A89F  0000              add [bx+si],al
0000A8A1  00EB              add bl,ch
0000A8A3  0000              add [bx+si],al
0000A8A5  0000              add [bx+si],al
0000A8A7  0000              add [bx+si],al
0000A8A9  0000              add [bx+si],al
0000A8AB  0000              add [bx+si],al
0000A8AD  0000              add [bx+si],al
0000A8AF  0000              add [bx+si],al
0000A8B1  00F1              add cl,dh
0000A8B3  0000              add [bx+si],al
0000A8B5  0000              add [bx+si],al
0000A8B7  0000              add [bx+si],al
0000A8B9  0000              add [bx+si],al
0000A8BB  0000              add [bx+si],al
0000A8BD  0000              add [bx+si],al
0000A8BF  0000              add [bx+si],al
0000A8C1  00F6              add dh,dh
0000A8C3  0000              add [bx+si],al
0000A8C5  0000              add [bx+si],al
0000A8C7  0000              add [bx+si],al
0000A8C9  0000              add [bx+si],al
0000A8CB  0000              add [bx+si],al
0000A8CD  0000              add [bx+si],al
0000A8CF  0000              add [bx+si],al
0000A8D1  00FA              add dl,bh
0000A8D3  0000              add [bx+si],al
0000A8D5  0000              add [bx+si],al
0000A8D7  0000              add [bx+si],al
0000A8D9  0000              add [bx+si],al
0000A8DB  0000              add [bx+si],al
0000A8DD  0000              add [bx+si],al
0000A8DF  0000              add [bx+si],al
0000A8E1  00FD              add ch,bh
0000A8E3  0000              add [bx+si],al
0000A8E5  0000              add [bx+si],al
0000A8E7  0000              add [bx+si],al
0000A8E9  0000              add [bx+si],al
0000A8EB  0000              add [bx+si],al
0000A8ED  0000              add [bx+si],al
0000A8EF  0000              add [bx+si],al
0000A8F1  00FF              add bh,bh
0000A8F3  0000              add [bx+si],al
0000A8F5  0000              add [bx+si],al
0000A8F7  0000              add [bx+si],al
0000A8F9  0000              add [bx+si],al
0000A8FB  0000              add [bx+si],al
0000A8FD  0000              add [bx+si],al
0000A8FF  0000              add [bx+si],al
0000A901  0000              add [bx+si],al
0000A903  0000              add [bx+si],al
0000A905  0000              add [bx+si],al
0000A907  0000              add [bx+si],al
0000A909  0000              add [bx+si],al
0000A90B  0000              add [bx+si],al
0000A90D  0000              add [bx+si],al
0000A90F  0000              add [bx+si],al
0000A911  0001              add [bx+di],al
0000A913  0000              add [bx+si],al
0000A915  0000              add [bx+si],al
0000A917  0000              add [bx+si],al
0000A919  0000              add [bx+si],al
0000A91B  0000              add [bx+si],al
0000A91D  0000              add [bx+si],al
0000A91F  0000              add [bx+si],al
0000A921  0003              add [bp+di],al
0000A923  0000              add [bx+si],al
0000A925  0000              add [bx+si],al
0000A927  0000              add [bx+si],al
0000A929  0000              add [bx+si],al
0000A92B  0000              add [bx+si],al
0000A92D  0000              add [bx+si],al
0000A92F  0000              add [bx+si],al
0000A931  00060000          add [0x0],al
0000A935  0000              add [bx+si],al
0000A937  0000              add [bx+si],al
0000A939  0000              add [bx+si],al
0000A93B  0000              add [bx+si],al
0000A93D  0000              add [bx+si],al
0000A93F  0000              add [bx+si],al
0000A941  000A              add [bp+si],cl
0000A943  0000              add [bx+si],al
0000A945  0000              add [bx+si],al
0000A947  0000              add [bx+si],al
0000A949  0000              add [bx+si],al
0000A94B  0000              add [bx+si],al
0000A94D  0000              add [bx+si],al
0000A94F  0000              add [bx+si],al
0000A951  000F              add [bx],cl
0000A953  0000              add [bx+si],al
0000A955  0000              add [bx+si],al
0000A957  0000              add [bx+si],al
0000A959  0000              add [bx+si],al
0000A95B  0000              add [bx+si],al
0000A95D  0000              add [bx+si],al
0000A95F  0000              add [bx+si],al
0000A961  0015              add [di],dl
0000A963  0000              add [bx+si],al
0000A965  0000              add [bx+si],al
0000A967  0000              add [bx+si],al
0000A969  0000              add [bx+si],al
0000A96B  0000              add [bx+si],al
0000A96D  0000              add [bx+si],al
0000A96F  0000              add [bx+si],al
0000A971  001C              add [si],bl
0000A973  0000              add [bx+si],al
0000A975  0000              add [bx+si],al
0000A977  0000              add [bx+si],al
0000A979  0000              add [bx+si],al
0000A97B  0000              add [bx+si],al
0000A97D  0000              add [bx+si],al
0000A97F  0000              add [bx+si],al
0000A981  0000              add [bx+si],al
0000A983  0000              add [bx+si],al
0000A985  0000              add [bx+si],al
0000A987  0000              add [bx+si],al
0000A989  0000              add [bx+si],al
0000A98B  0000              add [bx+si],al
0000A98D  0000              add [bx+si],al
0000A98F  0000              add [bx+si],al
0000A991  0000              add [bx+si],al
0000A993  0000              add [bx+si],al
0000A995  0000              add [bx+si],al
0000A997  0000              add [bx+si],al
0000A999  0000              add [bx+si],al
0000A99B  0000              add [bx+si],al
0000A99D  0000              add [bx+si],al
0000A99F  0000              add [bx+si],al
0000A9A1  0000              add [bx+si],al
0000A9A3  0000              add [bx+si],al
0000A9A5  0000              add [bx+si],al
0000A9A7  0000              add [bx+si],al
0000A9A9  0000              add [bx+si],al
0000A9AB  0000              add [bx+si],al
0000A9AD  0000              add [bx+si],al
0000A9AF  0000              add [bx+si],al
0000A9B1  0000              add [bx+si],al
0000A9B3  0000              add [bx+si],al
0000A9B5  0000              add [bx+si],al
0000A9B7  0000              add [bx+si],al
0000A9B9  0000              add [bx+si],al
0000A9BB  0000              add [bx+si],al
0000A9BD  0000              add [bx+si],al
0000A9BF  0000              add [bx+si],al
0000A9C1  0000              add [bx+si],al
0000A9C3  0000              add [bx+si],al
0000A9C5  0000              add [bx+si],al
0000A9C7  0000              add [bx+si],al
0000A9C9  0000              add [bx+si],al
0000A9CB  0000              add [bx+si],al
0000A9CD  0000              add [bx+si],al
0000A9CF  0000              add [bx+si],al
0000A9D1  0000              add [bx+si],al
0000A9D3  0000              add [bx+si],al
0000A9D5  0000              add [bx+si],al
0000A9D7  0000              add [bx+si],al
0000A9D9  0000              add [bx+si],al
0000A9DB  0000              add [bx+si],al
0000A9DD  0000              add [bx+si],al
0000A9DF  0000              add [bx+si],al
0000A9E1  0000              add [bx+si],al
0000A9E3  0408              add al,0x8
0000A9E5  0C10              or al,0x10
0000A9E7  1418              adc al,0x18
0000A9E9  1C20              sbb al,0x20
0000A9EB  2428              and al,0x28
0000A9ED  2C30              sub al,0x30
0000A9EF  3438              xor al,0x38
0000A9F1  3C40              cmp al,0x40
0000A9F3  44                inc sp
0000A9F4  48                dec ax
0000A9F5  4C                dec sp
0000A9F6  50                push ax
0000A9F7  54                push sp
0000A9F8  58                pop ax
0000A9F9  5C                pop sp
0000A9FA  60                pusha
0000A9FB  64686C70          fs push word 0x706c
0000A9FF  7478              jz 0xaa79
0000AA01  7C80              jl 0xa983
0000AA03  84888C90          test [bx+si-0x6f74],cl
0000AA07  94                xchg ax,sp
0000AA08  98                cbw
0000AA09  9C                pushf
0000AA0A  A0A4A8            mov al,[0xa8a4]
0000AA0D  AC                lodsb
0000AA0E  B0B4              mov al,0xb4
0000AA10  B8BCC0            mov ax,0xc0bc
0000AA13  C4                db 0xc4
0000AA14  C8CCD0D4          enter 0xd0cc,0xd4
0000AA18  D8DC              fcomp st4
0000AA1A  E0E4              loopne 0xaa00
0000AA1C  E8ECF0            call 0x9b0b
0000AA1F  F4                hlt
0000AA20  F8                clc
0000AA21  FC                cld
0000AA22  FF                db 0xff
0000AA23  FF                db 0xff
0000AA24  FF                db 0xff
0000AA25  FF                db 0xff
0000AA26  FF                db 0xff
0000AA27  FF                db 0xff
0000AA28  FF                db 0xff
0000AA29  FF                db 0xff
0000AA2A  FF                db 0xff
0000AA2B  FF                db 0xff
0000AA2C  FF                db 0xff
0000AA2D  FF                db 0xff
0000AA2E  FF                db 0xff
0000AA2F  FF                db 0xff
0000AA30  FF                db 0xff
0000AA31  FF                db 0xff
0000AA32  FF                db 0xff
0000AA33  FF                db 0xff
0000AA34  FF                db 0xff
0000AA35  FF                db 0xff
0000AA36  FF                db 0xff
0000AA37  FF                db 0xff
0000AA38  FF                db 0xff
0000AA39  FF                db 0xff
0000AA3A  FF                db 0xff
0000AA3B  FF                db 0xff
0000AA3C  FF                db 0xff
0000AA3D  FF                db 0xff
0000AA3E  FF                db 0xff
0000AA3F  FF                db 0xff
0000AA40  FF                db 0xff
0000AA41  FF                db 0xff
0000AA42  FF                db 0xff
0000AA43  FF                db 0xff
0000AA44  FF                db 0xff
0000AA45  FF                db 0xff
0000AA46  FF                db 0xff
0000AA47  FF                db 0xff
0000AA48  FF                db 0xff
0000AA49  FF                db 0xff
0000AA4A  FF                db 0xff
0000AA4B  FF                db 0xff
0000AA4C  FF                db 0xff
0000AA4D  FF                db 0xff
0000AA4E  FF                db 0xff
0000AA4F  FF                db 0xff
0000AA50  FF                db 0xff
0000AA51  FF                db 0xff
0000AA52  FF                db 0xff
0000AA53  FF                db 0xff
0000AA54  FF                db 0xff
0000AA55  FF                db 0xff
0000AA56  FF                db 0xff
0000AA57  FF                db 0xff
0000AA58  FF                db 0xff
0000AA59  FF                db 0xff
0000AA5A  FF                db 0xff
0000AA5B  FF                db 0xff
0000AA5C  FF                db 0xff
0000AA5D  FF                db 0xff
0000AA5E  FF                db 0xff
0000AA5F  FF                db 0xff
0000AA60  FF                db 0xff
0000AA61  FF                db 0xff
0000AA62  FF                db 0xff
0000AA63  FF                db 0xff
0000AA64  FF                db 0xff
0000AA65  FF                db 0xff
0000AA66  FF                db 0xff
0000AA67  FF                db 0xff
0000AA68  FF                db 0xff
0000AA69  FF                db 0xff
0000AA6A  FF                db 0xff
0000AA6B  FF                db 0xff
0000AA6C  FF                db 0xff
0000AA6D  FF                db 0xff
0000AA6E  FF                db 0xff
0000AA6F  FF                db 0xff
0000AA70  FF                db 0xff
0000AA71  FF                db 0xff
0000AA72  FF                db 0xff
0000AA73  FF                db 0xff
0000AA74  FF                db 0xff
0000AA75  FF                db 0xff
0000AA76  FF                db 0xff
0000AA77  FF                db 0xff
0000AA78  FF                db 0xff
0000AA79  FF                db 0xff
0000AA7A  FF                db 0xff
0000AA7B  FF                db 0xff
0000AA7C  FF                db 0xff
0000AA7D  FF                db 0xff
0000AA7E  FF                db 0xff
0000AA7F  FF                db 0xff
0000AA80  FF                db 0xff
0000AA81  FF                db 0xff
0000AA82  3F                aas
0000AA83  3F                aas
0000AA84  3F                aas
0000AA85  3F                aas
0000AA86  3F                aas
0000AA87  3F                aas
0000AA88  3F                aas
0000AA89  3F                aas
0000AA8A  3F                aas
0000AA8B  3F                aas
0000AA8C  3F                aas
0000AA8D  3F                aas
0000AA8E  3F                aas
0000AA8F  3F                aas
0000AA90  3F                aas
0000AA91  3F                aas
0000AA92  3F                aas
0000AA93  3F                aas
0000AA94  3F                aas
0000AA95  3F                aas
0000AA96  3F                aas
0000AA97  3F                aas
0000AA98  3F                aas
0000AA99  3F                aas
0000AA9A  3F                aas
0000AA9B  3F                aas
0000AA9C  3F                aas
0000AA9D  3F                aas
0000AA9E  3F                aas
0000AA9F  3F                aas
0000AAA0  3F                aas
0000AAA1  3F                aas
0000AAA2  3F                aas
0000AAA3  3F                aas
0000AAA4  3F                aas
0000AAA5  3F                aas
0000AAA6  3F                aas
0000AAA7  3F                aas
0000AAA8  3F                aas
0000AAA9  3F                aas
0000AAAA  3F                aas
0000AAAB  3F                aas
0000AAAC  3F                aas
0000AAAD  3F                aas
0000AAAE  3F                aas
0000AAAF  3F                aas
0000AAB0  3F                aas
0000AAB1  3F                aas
0000AAB2  3F                aas
0000AAB3  3F                aas
0000AAB4  3F                aas
0000AAB5  3F                aas
0000AAB6  3F                aas
0000AAB7  3F                aas
0000AAB8  3F                aas
0000AAB9  3F                aas
0000AABA  3F                aas
0000AABB  3F                aas
0000AABC  3F                aas
0000AABD  3F                aas
0000AABE  3F                aas
0000AABF  3F                aas
0000AAC0  3F                aas
0000AAC1  3F                aas
0000AAC2  3F                aas
0000AAC3  3F                aas
0000AAC4  3F                aas
0000AAC5  3F                aas
0000AAC6  3F                aas
0000AAC7  3F                aas
0000AAC8  3F                aas
0000AAC9  3F                aas
0000AACA  3F                aas
0000AACB  3F                aas
0000AACC  3F                aas
0000AACD  3F                aas
0000AACE  3F                aas
0000AACF  3F                aas
0000AAD0  3F                aas
0000AAD1  3F                aas
0000AAD2  3F                aas
0000AAD3  3F                aas
0000AAD4  3F                aas
0000AAD5  3F                aas
0000AAD6  3F                aas
0000AAD7  3F                aas
0000AAD8  3F                aas
0000AAD9  3F                aas
0000AADA  2F                das
0000AADB  27                daa
0000AADC  2320              and sp,[bx+si]
0000AADE  1E                push ds
0000AADF  1C1A              sbb al,0x1a
0000AAE1  1918              sbb [bx+si],bx
0000AAE3  16                push ss
0000AAE4  151514            adc ax,0x1415
0000AAE7  1312              adc dx,[bp+si]
0000AAE9  1211              adc dl,[bx+di]
0000AAEB  1010              adc [bx+si],dl
0000AAED  0F0F0E0E0D0D      pi2fd mm1,[0xd0e]
0000AAF3  0C0C              or al,0xc
0000AAF5  0C0B              or al,0xb
0000AAF7  0B0B              or cx,[bp+di]
0000AAF9  0A0A              or cl,[bp+si]
0000AAFB  0A09              or cl,[bx+di]
0000AAFD  0909              or [bx+di],cx
0000AAFF  0808              or [bx+si],cl
0000AB01  0808              or [bx+si],cl
0000AB03  07                pop es
0000AB04  07                pop es
0000AB05  07                pop es
0000AB06  07                pop es
0000AB07  06                push es
0000AB08  06                push es
0000AB09  06                push es
0000AB0A  06                push es
0000AB0B  06                push es
0000AB0C  050505            add ax,0x505
0000AB0F  050504            add ax,0x405
0000AB12  0404              add al,0x4
0000AB14  0404              add al,0x4
0000AB16  0303              add ax,[bp+di]
0000AB18  0303              add ax,[bp+di]
0000AB1A  0303              add ax,[bp+di]
0000AB1C  0202              add al,[bp+si]
0000AB1E  0202              add al,[bp+si]
0000AB20  0202              add al,[bp+si]
0000AB22  0201              add al,[bx+di]
0000AB24  0101              add [bx+di],ax
0000AB26  0101              add [bx+di],ax
0000AB28  0101              add [bx+di],ax
0000AB2A  0100              add [bx+si],ax
0000AB2C  0000              add [bx+si],al
0000AB2E  0000              add [bx+si],al
0000AB30  0000              add [bx+si],al
0000AB32  0000              add [bx+si],al
0000AB34  0000              add [bx+si],al
0000AB36  0000              add [bx+si],al
0000AB38  0000              add [bx+si],al
0000AB3A  0000              add [bx+si],al
0000AB3C  0000              add [bx+si],al
0000AB3E  0000              add [bx+si],al
0000AB40  0000              add [bx+si],al
0000AB42  0000              add [bx+si],al
0000AB44  0000              add [bx+si],al
0000AB46  0000              add [bx+si],al
0000AB48  0000              add [bx+si],al
0000AB4A  0000              add [bx+si],al
0000AB4C  0000              add [bx+si],al
0000AB4E  0000              add [bx+si],al
0000AB50  0000              add [bx+si],al
0000AB52  0000              add [bx+si],al
0000AB54  0000              add [bx+si],al
0000AB56  0000              add [bx+si],al
0000AB58  0000              add [bx+si],al
0000AB5A  0000              add [bx+si],al
0000AB5C  0000              add [bx+si],al
0000AB5E  0000              add [bx+si],al
0000AB60  0000              add [bx+si],al
0000AB62  0000              add [bx+si],al
0000AB64  0000              add [bx+si],al
0000AB66  0000              add [bx+si],al
0000AB68  0000              add [bx+si],al
0000AB6A  0000              add [bx+si],al
0000AB6C  0000              add [bx+si],al
0000AB6E  0000              add [bx+si],al
0000AB70  0000              add [bx+si],al
0000AB72  0000              add [bx+si],al
0000AB74  0000              add [bx+si],al
0000AB76  0000              add [bx+si],al
0000AB78  0000              add [bx+si],al
0000AB7A  0000              add [bx+si],al
0000AB7C  0000              add [bx+si],al
0000AB7E  0000              add [bx+si],al
0000AB80  0000              add [bx+si],al
0000AB82  50                push ax
0000AB83  005900            add [bx+di+0x0],bl
0000AB86  0000              add [bx+si],al
0000AB88  0000              add [bx+si],al
0000AB8A  0000              add [bx+si],al
0000AB8C  6B600070          imul sp,[bx+si+0x0],byte +0x70
0000AB90  0000              add [bx+si],al
0000AB92  007075            add [bx+si+0x75],dh
0000AB95  4E                dec si
0000AB96  0000              add [bx+si],al
0000AB98  0000              add [bx+si],al
0000AB9A  0000              add [bx+si],al
0000AB9C  0000              add [bx+si],al
0000AB9E  000C              add [si],cl
0000ABA0  2400              and al,0x0
0000ABA2  1E                push ds
0000ABA3  8D800F01          lea ax,[bx+si+0x10f]
0000ABA7  0000              add [bx+si],al
0000ABA9  0000              add [bx+si],al
0000ABAB  00614D            add [bx+di+0x4d],ah
0000ABAE  7075              jo 0xac25
0000ABB0  2020              and [bx+si],ah
0000ABB2  2020              and [bx+si],ah
0000ABB4  2020              and [bx+si],ah
0000ABB6  2020              and [bx+si],ah
0000ABB8  2020              and [bx+si],ah
0000ABBA  2020              and [bx+si],ah
0000ABBC  2020              and [bx+si],ah
0000ABBE  2020              and [bx+si],ah
0000ABC0  2020              and [bx+si],ah
0000ABC2  2020              and [bx+si],ah
0000ABC4  2020              and [bx+si],ah
0000ABC6  2020              and [bx+si],ah
0000ABC8  2020              and [bx+si],ah
0000ABCA  2020              and [bx+si],ah
0000ABCC  0000              add [bx+si],al
0000ABCE  0000              add [bx+si],al
0000ABD0  0000              add [bx+si],al
0000ABD2  0000              add [bx+si],al
0000ABD4  000C              add [si],cl
0000ABD6  2400              and al,0x0
0000ABD8  1E                push ds
0000ABD9  8D00              lea ax,[bx+si]
0000ABDB  0000              add [bx+si],al
0000ABDD  0000              add [bx+si],al
0000ABDF  0008              add [bx+si],cl
0000ABE1  006200            add [bp+si+0x0],ah
0000ABE4  0B00              or ax,[bx+si]
0000ABE6  06                push es
0000ABE7  0001              add [bx+di],al
0000ABE9  0000              add [bx+si],al
0000ABEB  006201            add [bp+si+0x1],ah
0000ABEE  6E                outsb
0000ABEF  0000              add [bx+si],al
0000ABF1  004400            add [si+0x0],al
0000ABF4  8E02              mov es,[bp+si]
0000ABF6  0000              add [bx+si],al
0000ABF8  1A04              sbb al,[si]
0000ABFA  0000              add [bx+si],al
0000ABFC  E004              loopne 0xac02
0000ABFE  0000              add [bx+si],al
0000AC00  0003              add [bp+di],al
0000AC02  030C              add cx,[si]
0000AC04  0403              add al,0x3
0000AC06  C0                db 0xc0
0000AC07  7000              jo 0xac09
0000AC09  0000              add [bx+si],al
0000AC0B  0000              add [bx+si],al
0000AC0D  0200              add al,[bx+si]
0000AC0F  0000              add [bx+si],al
0000AC11  003E02F3          add [0xf302],bh
0000AC15  3BF3              cmp si,bx
0000AC17  FF                db 0xff
0000AC18  F8                clc
0000AC19  BDF8FD            mov bp,0xfdf8
0000AC1C  E3C1              jcxz 0xabdf
0000AC1E  F8                clc
0000AC1F  9C                pushf
0000AC20  C7                db 0xc7
0000AC21  E7F3              out 0xf3,ax
0000AC23  FF                db 0xff
0000AC24  EE                out dx,al
0000AC25  F7FB              idiv bx
0000AC27  FD                std
0000AC28  31FF              xor di,di
0000AC2A  C239BE            ret 0xbe39
0000AC2D  FB                sti
0000AC2E  18E7              sbb bh,ah
0000AC30  00A3951B          add [bp+di+0x1b95],ah
0000AC34  48                dec ax
0000AC35  8518              test [bx+si],bx
0000AC37  A6                cmpsb
0000AC38  48                dec ax
0000AC39  C2056A            ret 0x6a05
0000AC3C  60                pusha
0000AC3D  C20B00            ret 0xb
0000AC40  00C0              add al,al
0000AC42  0000              add [bx+si],al
0000AC44  0001              add [bx+di],al
0000AC46  0404              add al,0x4
0000AC48  0001              add [bx+di],al
0000AC4A  40                inc ax
0000AC4B  1000              adc [bx+si],al
0000AC4D  0000              add [bx+si],al
0000AC4F  0000              add [bx+si],al
0000AC51  0200              add al,[bx+si]
0000AC53  0000              add [bx+si],al
0000AC55  0011              add [bx+di],dl
0000AC57  02894614          add cl,[bx+di+0x1446]
0000AC5B  0A906890          or dl,[bx+si-0x6f98]
0000AC5F  48                dec ax
0000AC60  316345            xor [bp+di+0x45],sp
0000AC63  2228              and ch,[bx+si]
0000AC65  12A16444          adc ah,[bx+di+0x4464]
0000AC69  2291484B          and dl,[bx+di+0x4b48]
0000AC6D  42                inc dx
0000AC6E  2646              es inc si
0000AC70  6384A418          arpl [si+0x18a4],ax
0000AC74  800040            add byte [bx+si],0x40
0000AC77  2414              and al,0x14
0000AC79  4A                dec dx
0000AC7A  2401              and al,0x1
0000AC7C  1420              adc al,0x20
0000AC7E  06                push es
0000AC7F  AA                stosb
0000AC80  91                xchg ax,cx
0000AC81  22160000          and dl,[0x0]
0000AC85  2000              and [bx+si],al
0000AC87  00E7              add bh,ah
0000AC89  71E4              jno 0xac6f
0000AC8B  BCCC75            mov sp,0x75cc
0000AC8E  56                push si
0000AC8F  D31D              rcr word [di],cl
0000AC91  CB                retf
0000AC92  BB73EF            mov bx,0xef73
0000AC95  7F93              jg 0xac2a
0000AC97  DF                db 0xdf
0000AC98  DF                db 0xdf
0000AC99  E711              out 0x11,ax
0000AC9B  E585              in ax,0x85
0000AC9D  80482290          or byte [bx+si+0x22],0x90
0000ACA1  0810              or [bx+si],dl
0000ACA3  49                dec cx
0000ACA4  295546            sub [di+0x46],dx
0000ACA7  41                inc cx
0000ACA8  280A              sub [bp+si],cl
0000ACAA  2104              and [si],ax
0000ACAC  44                inc sp
0000ACAD  2211              and dl,[bx+di]
0000ACAF  45                inc bp
0000ACB0  8504              test [si],ax
0000ACB2  2A4405            sub al,[si+0x5]
0000ACB5  F4                hlt
0000ACB6  B8188F            mov ax,0x8f18
0000ACB9  E39C              jcxz 0xac57
0000ACBB  739C              jnc 0xac59
0000ACBD  E101              loope 0xacc0
0000ACBF  E769              out 0x69,ax
0000ACC1  BE0404            mov si,0x404
0000ACC4  0925              or [di],sp
0000ACC6  0A00              or al,[bx+si]
0000ACC8  004000            add [bx+si+0x0],al
0000ACCB  0018              add [bx+si],bl
0000ACCD  091F              or [bx],bx
0000ACCF  C524              lds sp,[si]
0000ACD1  894954            mov [bx+di+0x54],cx
0000ACD4  A2244D            mov [0x4d24],al
0000ACD7  8C24              mov [si],fs
0000ACD9  82                db 0x82
0000ACDA  11898A24          adc [bx+di+0x248a],cx
0000ACDE  1E                push ds
0000ACDF  45                inc bp
0000ACE0  8580C8E3          test [bx+si-0x1c38],ax
0000ACE4  90                nop
0000ACE5  EF                out dx,ax
0000ACE6  104A25            adc [bp+si+0x25],cl
0000ACE9  49                dec cx
0000ACEA  7A41              jpe 0xad2d
0000ACEC  C7                db 0xc7
0000ACED  0B21              or sp,[bx+di]
0000ACEF  842A              test [bp+si],ch
0000ACF1  140A              adc al,0xa
0000ACF3  82                db 0x82
0000ACF4  8508              test [bx+si],cx
0000ACF6  D208              ror byte [bx+si],cl
0000ACF8  888F84E7          mov [bx-0x187c],cl
0000ACFC  51                push cx
0000ACFD  10638C            adc [bp+di-0x74],ah
0000AD00  A31CEC            mov [0xec1c],ax
0000AD03  184292            sbb [bp+si-0x6e],al
0000AD06  0C00              or al,0x0
0000AD08  0F45E2            cmovnz sp,dx
0000AD0B  FF00              inc word [bx+si]
0000AD0D  2000              and [bx+si],al
0000AD0F  0018              add [bx+si],bl
0000AD11  79F4              jns 0xad07
0000AD13  45                inc bp
0000AD14  2489              and al,0x89
0000AD16  49                dec cx
0000AD17  5C                pop sp
0000AD18  A22448            mov [0x4824],al
0000AD1B  8C24              mov [si],fs
0000AD1D  72AA              jc 0xacc9
0000AD1F  50                push ax
0000AD20  50                push ax
0000AD21  18918F85          sbb [bx+di-0x7a71],dl
0000AD25  80482294          or byte [bx+si+0x22],0x94
0000AD29  2810              sub [bx+si],dl
0000AD2B  4D                dec bp
0000AD2C  234142            and ax,[bx+di+0x42]
0000AD2F  41                inc cx
0000AD30  40                inc ax
0000AD31  2A21              sub ah,[bx+di]
0000AD33  44                inc sp
0000AD34  2A14              sub dl,[si]
0000AD36  0485              add al,0x85
0000AD38  8510              test [bx+si],dx
0000AD3A  3F                aas
0000AD3B  10510C            adc [bx+di+0xc],dl
0000AD3E  BC10D0            mov sp,0xd010
0000AD41  F3                rep
0000AD42  FF                db 0xff
0000AD43  FFA3F4A4          jmp [bp+di-0x5b0c]
0000AD47  184492            sbb [si-0x6e],al
0000AD4A  1480              adc al,0x80
0000AD4C  09890200          or [bx+di+0x2],cx
0000AD50  0020              add [bx+si],ah
0000AD52  0000              add [bx+si],al
0000AD54  188904C5          sbb [bx+di-0x3afc],cl
0000AD58  2471              and al,0x71
0000AD5A  49                dec cx
0000AD5B  52                push dx
0000AD5C  A224C8            mov [0xc824],al
0000AD5F  F3240A            rep and al,0xa
0000AD62  AA                stosb
0000AD63  50                push ax
0000AD64  51                push cx
0000AD65  2491              and al,0x91
0000AD67  28894204          sub [bx+di+0x442],cl
0000AD6B  0A946891          or dl,[si-0x6e98]
0000AD6F  48                dec ax
0000AD70  214141            and [bx+di+0x41],ax
0000AD73  2228              and ch,[bx+si]
0000AD75  1221              adc ah,[bx+di]
0000AD77  44                inc sp
0000AD78  1108              adc [bx+si],cx
0000AD7A  8408              test [bx+si],cl
0000AD7C  49                dec cx
0000AD7D  2122              and [bp+si],sp
0000AD7F  22618C            and ah,[bx+di-0x74]
0000AD82  C518              lds bx,[bx+si]
0000AD84  4D                dec bp
0000AD85  1421              adc al,0x21
0000AD87  84A304A4          test [bp+di-0x5bfc],ah
0000AD8B  184992            sbb [bx+di-0x6e],cl
0000AD8E  40                inc ax
0000AD8F  40                inc ax
0000AD90  91                xchg ax,cx
0000AD91  08E2              or dl,ah
0000AD93  0100              add [bx+si],ax
0000AD95  2000              and [bx+si],al
0000AD97  00E7              add bh,ah
0000AD99  76EE              jna 0xad89
0000AD9B  3ABE0BFD          cmp bh,[bp-0x2f5]
0000AD9F  7BDC              jpo 0xad7d
0000ADA1  BE5C80            mov si,0x805c
0000ADA4  9AF1442023        call 0x2320:0x44f1
0000ADA9  66                o32
0000ADAA  FE                db 0xfe
0000ADAB  FD                std
0000ADAC  F33D03FF          rep cmp ax,0xff03
0000ADB0  FB                sti
0000ADB1  BDFF9D            mov bp,0x9dff
0000ADB4  F1                int1
0000ADB5  E3E0              jcxz 0xad97
0000ADB7  1C3F              sbb al,0x3f
0000ADB9  EF                out dx,ax
0000ADBA  1E                push ds
0000ADBB  8E11              mov ss,[bx+di]
0000ADBD  08CE              or dh,cl
0000ADBF  1D337F            sbb ax,0x7f33
0000ADC2  C7                db 0xc7
0000ADC3  FD                std
0000ADC4  A0733A            mov al,[0x3a73]
0000ADC7  E7A2              out 0xa2,ax
0000ADC9  EB9C              jmp short 0xad67
0000ADCB  73DC              jnc 0xada9
0000ADCD  EF                out dx,ax
0000ADCE  1AE7              sbb ah,bh
0000ADD0  B069              mov al,0x69
0000ADD2  5C                pop sp
0000ADD3  8160900200        and word [bx+si-0x70],0x2
0000ADD8  00C0              add al,al
0000ADDA  0000              add [bx+si],al
0000ADDC  0000              add [bx+si],al
0000ADDE  0000              add [bx+si],al
0000ADE0  01F0              add ax,si
0000ADE2  00800100          add [bx+si+0x1],al
0000ADE6  E0C0              loopne 0xada8
0000ADE8  0000              add [bx+si],al
0000ADEA  0000              add [bx+si],al
0000ADEC  C00100            rol byte [bx+di],byte 0x0
0000ADEF  0000              add [bx+si],al
0000ADF1  0000              add [bx+si],al
0000ADF3  0000              add [bx+si],al
0000ADF5  0000              add [bx+si],al
0000ADF7  0000              add [bx+si],al
0000ADF9  0000              add [bx+si],al
0000ADFB  0000              add [bx+si],al
0000ADFD  0000              add [bx+si],al
0000ADFF  0000              add [bx+si],al
0000AE01  0000              add [bx+si],al
0000AE03  0000              add [bx+si],al
0000AE05  0000              add [bx+si],al
0000AE07  0000              add [bx+si],al
0000AE09  0000              add [bx+si],al
0000AE0B  000C              add [si],cl
0000AE0D  0000              add [bx+si],al
0000AE0F  0000              add [bx+si],al
0000AE11  0000              add [bx+si],al
0000AE13  0000              add [bx+si],al
0000AE15  00A00000          add [bx+si+0x0],ah
0000AE19  1002              adc [bp+si],al
0000AE1B  0000              add [bx+si],al
0000AE1D  0000              add [bx+si],al
0000AE1F  0000              add [bx+si],al
0000AE21  00060006          add [0x600],al
0000AE25  0006000C          add [0xc00],al
0000AE29  0005              add [di],al
0000AE2B  0011              add [bx+di],dl
0000AE2D  00060017          add [0x1700],al
0000AE31  0005              add [di],al
0000AE33  001C              add [si],bl
0000AE35  0004              add [si],al
0000AE37  0020              add [bx+si],ah
0000AE39  00060026          add [0x2600],al
0000AE3D  0006002C          add [0x2c00],al
0000AE41  0003              add [bp+di],al
0000AE43  002F              add [bx],ch
0000AE45  0003              add [bp+di],al
0000AE47  0032              add [bp+si],dh
0000AE49  00060038          add [0x3800],al
0000AE4D  0003              add [bp+di],al
0000AE4F  003B              add [bp+di],bh
0000AE51  0009              add [bx+di],cl
0000AE53  004400            add [si+0x0],al
0000AE56  06                push es
0000AE57  004A00            add [bp+si+0x0],cl
0000AE5A  05004F            add ax,0x4f00
0000AE5D  00060055          add [0x5500],al
0000AE61  0006005B          add [0x5b00],al
0000AE65  0005              add [di],al
0000AE67  006000            add [bx+si+0x0],ah
0000AE6A  050065            add ax,0x6500
0000AE6D  0004              add [si],al
0000AE6F  006900            add [bx+di+0x0],ch
0000AE72  06                push es
0000AE73  006F00            add [bx+0x0],ch
0000AE76  07                pop es
0000AE77  007600            add [bp+0x0],dh
0000AE7A  0B00              or ax,[bx+si]
0000AE7C  81000600          add word [bx+si],0x6
0000AE80  8700              xchg ax,[bx+si]
0000AE82  07                pop es
0000AE83  008E0005          add [bp+0x500],cl
0000AE87  00930007          add [bp+di+0x700],dl
0000AE8B  009A0006          add [bp+si+0x600],bl
0000AE8F  00A00007          add [bx+si+0x700],ah
0000AE93  00A70007          add [bx+0x700],ah
0000AE97  00AE0007          add [bp+0x700],ch
0000AE9B  00B50007          add [di+0x700],dh
0000AE9F  00BC0007          add [si+0x700],bh
0000AEA3  00C3              add bl,al
0000AEA5  0007              add [bx],al
0000AEA7  00CA              add dl,cl
0000AEA9  0003              add [bp+di],al
0000AEAB  00CD              add ch,cl
0000AEAD  000600D3          add [0xd300],al
0000AEB1  0007              add [bx],al
0000AEB3  00DA              add dl,bl
0000AEB5  000600E0          add [0xe000],al
0000AEB9  0009              add [bx+di],cl
0000AEBB  00E9              add cl,ch
0000AEBD  0008              add [bx+si],cl
0000AEBF  00F1              add cl,dh
0000AEC1  0007              add [bx],al
0000AEC3  00F8              add al,bh
0000AEC5  000600FE          add [0xfe00],al
0000AEC9  0007              add [bx],al
0000AECB  0005              add [di],al
0000AECD  0107              add [bx],ax
0000AECF  000C              add [si],cl
0000AED1  01060012          add [0x1200],ax
0000AED5  0107              add [bx],ax
0000AED7  0019              add [bx+di],bl
0000AED9  0108              add [bx+si],cx
0000AEDB  0021              add [bx+di],ah
0000AEDD  0107              add [bx],ax
0000AEDF  0028              add [bx+si],ch
0000AEE1  010B              add [bp+di],cx
0000AEE3  0033              add [bp+di],dh
0000AEE5  0107              add [bx],ax
0000AEE7  003A              add [bp+si],bh
0000AEE9  0107              add [bx],ax
0000AEEB  004101            add [bx+di+0x1],al
0000AEEE  07                pop es
0000AEEF  004801            add [bx+si+0x1],cl
0000AEF2  06                push es
0000AEF3  004E01            add [bp+0x1],cl
0000AEF6  0300              add ax,[bx+si]
0000AEF8  51                push cx
0000AEF9  0105              add [di],ax
0000AEFB  005601            add [bp+0x1],dl
0000AEFE  05005B            add ax,0x5b00
0000AF01  0105              add [di],ax
0000AF03  006001            add [bx+si+0x1],ah
0000AF06  050065            add ax,0x6500
0000AF09  0105              add [di],ax
0000AF0B  006A01            add [bp+si+0x1],ch
0000AF0E  05006F            add ax,0x6f00
0000AF11  0105              add [di],ax
0000AF13  007401            add [si+0x1],dh
0000AF16  050079            add ax,0x7900
0000AF19  0106007F          add [0x7f00],ax
0000AF1D  01060085          add [0x8500],ax
0000AF21  0106008B          add [0x8b00],ax
0000AF25  0105              add [di],ax
0000AF27  00900105          add [bx+si+0x501],dl
0000AF2B  00950105          add [di+0x501],dl
0000AF2F  009A0105          add [bp+si+0x501],bl
0000AF33  009F0105          add [bx+0x501],bl
0000AF37  00A40103          add [si+0x301],ah
0000AF3B  00A70103          add [bx+0x301],ah
0000AF3F  00AA0105          add [bp+si+0x501],ch
0000AF43  00AF0105          add [bx+0x501],ch
0000AF47  00B40105          add [si+0x501],dh
0000AF4B  00B90100          add [bx+di+0x1],bh
0000AF4F  00B90100          add [bx+di+0x1],bh
0000AF53  00B90106          add [bx+di+0x601],bh
0000AF57  00BF0106          add [bx+0x601],bh
0000AF5B  00C5              add ch,al
0000AF5D  010600CB          add [0xcb00],ax
0000AF61  0107              add [bx],ax
0000AF63  00D2              add dl,dl
0000AF65  0103              add [bp+di],ax
0000AF67  00D5              add ch,dl
0000AF69  0102              add [bp+si],ax
0000AF6B  00D7              add bh,dl
0000AF6D  0101              add [bx+di],ax
0000AF6F  00D8              add al,bl
0000AF71  0102              add [bp+si],ax
0000AF73  00DA              add dl,bl
0000AF75  0102              add [bp+si],ax
0000AF77  00DC              add ah,bl
0000AF79  0101              add [bx+di],ax
0000AF7B  00DD              add ch,bl
0000AF7D  0101              add [bx+di],ax
0000AF7F  00DE              add dh,bl
0000AF81  0105              add [di],ax
0000AF83  00E3              add bl,ah
0000AF85  0104              add [si],ax
0000AF87  00E7              add bh,ah
0000AF89  0103              add [bp+di],ax
0000AF8B  00EA              add dl,ch
0000AF8D  0103              add [bp+di],ax
0000AF8F  00ED              add ch,ch
0000AF91  0105              add [di],ax
0000AF93  00F2              add dl,dh
0000AF95  0105              add [di],ax
0000AF97  00F7              add bh,dh
0000AF99  0104              add [si],ax
0000AF9B  00FB              add bl,bh
0000AF9D  0103              add [bp+di],ax
0000AF9F  00FE              add dh,bh
0000AFA1  0105              add [di],ax
0000AFA3  0003              add [bp+di],al
0000AFA5  0200              add al,[bx+si]
0000AFA7  0003              add [bp+di],al
0000AFA9  0200              add al,[bx+si]
0000AFAB  0007              add [bx],al
0000AFAD  0007              add [bx],al
0000AFAF  00060007          add [0x700],al
0000AFB3  00060005          add [0x500],al
0000AFB7  0007              add [bx],al
0000AFB9  0007              add [bx],al
0000AFBB  0004              add [si],al
0000AFBD  0004              add [si],al
0000AFBF  0007              add [bx],al
0000AFC1  0004              add [si],al
0000AFC3  000A              add [bp+si],cl
0000AFC5  0007              add [bx],al
0000AFC7  00060007          add [0x700],al
0000AFCB  0007              add [bx],al
0000AFCD  00060006          add [0x600],al
0000AFD1  0005              add [di],al
0000AFD3  0007              add [bx],al
0000AFD5  0008              add [bx+si],cl
0000AFD7  000C              add [si],cl
0000AFD9  0007              add [bx],al
0000AFDB  0008              add [bx+si],cl
0000AFDD  00060008          add [0x800],al
0000AFE1  0007              add [bx],al
0000AFE3  0008              add [bx+si],cl
0000AFE5  0008              add [bx+si],cl
0000AFE7  0008              add [bx+si],cl
0000AFE9  0008              add [bx+si],cl
0000AFEB  0008              add [bx+si],cl
0000AFED  0008              add [bx+si],cl
0000AFEF  0004              add [si],al
0000AFF1  0007              add [bx],al
0000AFF3  0008              add [bx+si],cl
0000AFF5  0007              add [bx],al
0000AFF7  000A              add [bp+si],cl
0000AFF9  0009              add [bx+di],cl
0000AFFB  0008              add [bx+si],cl
0000AFFD  0007              add [bx],al
0000AFFF  0008              add [bx+si],cl
0000B001  0008              add [bx+si],cl
0000B003  0007              add [bx],al
0000B005  0008              add [bx+si],cl
0000B007  0009              add [bx+di],cl
0000B009  0008              add [bx+si],cl
0000B00B  000C              add [si],cl
0000B00D  0008              add [bx+si],cl
0000B00F  0008              add [bx+si],cl
0000B011  0008              add [bx+si],cl
0000B013  0007              add [bx],al
0000B015  0004              add [si],al
0000B017  00060006          add [0x600],al
0000B01B  00060006          add [0x600],al
0000B01F  00060006          add [0x600],al
0000B023  00060006          add [0x600],al
0000B027  0007              add [bx],al
0000B029  0007              add [bx],al
0000B02B  0007              add [bx],al
0000B02D  00060006          add [0x600],al
0000B031  00060006          add [0x600],al
0000B035  00060004          add [0x400],al
0000B039  0004              add [si],al
0000B03B  00060006          add [0x600],al
0000B03F  00060006          add [0x600],al
0000B043  00060007          add [0x700],al
0000B047  0007              add [bx],al
0000B049  0007              add [bx],al
0000B04B  0008              add [bx+si],cl
0000B04D  0004              add [si],al
0000B04F  0003              add [bp+di],al
0000B051  0002              add [bp+si],al
0000B053  0003              add [bp+di],al
0000B055  0003              add [bp+di],al
0000B057  0002              add [bp+si],al
0000B059  0002              add [bp+si],al
0000B05B  00060005          add [0x500],al
0000B05F  0004              add [si],al
0000B061  0004              add [si],al
0000B063  00060006          add [0x600],al
0000B067  0005              add [di],al
0000B069  0004              add [si],al
0000B06B  00060006          add [0x600],al
0000B06F  0004              add [si],al
0000B071  0000              add [bx+si],al
0000B073  0000              add [bx+si],al
0000B075  0000              add [bx+si],al
0000B077  0000              add [bx+si],al
0000B079  0000              add [bx+si],al
0000B07B  0000              add [bx+si],al
0000B07D  0000              add [bx+si],al
0000B07F  0000              add [bx+si],al
0000B081  0000              add [bx+si],al
0000B083  0000              add [bx+si],al
0000B085  0000              add [bx+si],al
0000B087  0000              add [bx+si],al
0000B089  0000              add [bx+si],al
0000B08B  0000              add [bx+si],al
0000B08D  0000              add [bx+si],al
0000B08F  0000              add [bx+si],al
0000B091  0000              add [bx+si],al
0000B093  0000              add [bx+si],al
0000B095  0000              add [bx+si],al
0000B097  0000              add [bx+si],al
0000B099  0000              add [bx+si],al
0000B09B  0000              add [bx+si],al
0000B09D  0000              add [bx+si],al
0000B09F  0000              add [bx+si],al
0000B0A1  0000              add [bx+si],al
0000B0A3  0000              add [bx+si],al
0000B0A5  0000              add [bx+si],al
0000B0A7  0000              add [bx+si],al
0000B0A9  0000              add [bx+si],al
0000B0AB  0000              add [bx+si],al
0000B0AD  0000              add [bx+si],al
0000B0AF  0000              add [bx+si],al
0000B0B1  0000              add [bx+si],al
0000B0B3  0000              add [bx+si],al
0000B0B5  0000              add [bx+si],al
0000B0B7  0000              add [bx+si],al
0000B0B9  0000              add [bx+si],al
0000B0BB  0000              add [bx+si],al
0000B0BD  0000              add [bx+si],al
0000B0BF  0000              add [bx+si],al
0000B0C1  0000              add [bx+si],al
0000B0C3  0000              add [bx+si],al
0000B0C5  0000              add [bx+si],al
0000B0C7  0000              add [bx+si],al
0000B0C9  0000              add [bx+si],al
0000B0CB  0000              add [bx+si],al
0000B0CD  0000              add [bx+si],al
0000B0CF  0000              add [bx+si],al
0000B0D1  0000              add [bx+si],al
0000B0D3  0000              add [bx+si],al
0000B0D5  0000              add [bx+si],al
0000B0D7  0000              add [bx+si],al
0000B0D9  0000              add [bx+si],al
0000B0DB  0001              add [bx+di],al
0000B0DD  0000              add [bx+si],al
0000B0DF  0000              add [bx+si],al
0000B0E1  0000              add [bx+si],al
0000B0E3  0000              add [bx+si],al
0000B0E5  0000              add [bx+si],al
0000B0E7  0000              add [bx+si],al
0000B0E9  0000              add [bx+si],al
0000B0EB  0000              add [bx+si],al
0000B0ED  0000              add [bx+si],al
0000B0EF  0000              add [bx+si],al
0000B0F1  0000              add [bx+si],al
0000B0F3  0000              add [bx+si],al
0000B0F5  0000              add [bx+si],al
0000B0F7  0000              add [bx+si],al
0000B0F9  0000              add [bx+si],al
0000B0FB  0000              add [bx+si],al
0000B0FD  0000              add [bx+si],al
0000B0FF  0000              add [bx+si],al
0000B101  0000              add [bx+si],al
0000B103  0000              add [bx+si],al
0000B105  0000              add [bx+si],al
0000B107  0000              add [bx+si],al
0000B109  0000              add [bx+si],al
0000B10B  0000              add [bx+si],al
0000B10D  0000              add [bx+si],al
0000B10F  0001              add [bx+di],al
0000B111  0000              add [bx+si],al
0000B113  0000              add [bx+si],al
0000B115  0000              add [bx+si],al
0000B117  0001              add [bx+di],al
0000B119  0001              add [bx+di],al
0000B11B  0001              add [bx+di],al
0000B11D  0001              add [bx+di],al
0000B11F  0000              add [bx+si],al
0000B121  0000              add [bx+si],al
0000B123  0000              add [bx+si],al
0000B125  0000              add [bx+si],al
0000B127  0000              add [bx+si],al
0000B129  0000              add [bx+si],al
0000B12B  0000              add [bx+si],al
0000B12D  0000              add [bx+si],al
0000B12F  0000              add [bx+si],al
0000B131  0000              add [bx+si],al
0000B133  0000              add [bx+si],al
0000B135  0000              add [bx+si],al
0000B137  0000              add [bx+si],al
0000B139  0000              add [bx+si],al
0000B13B  00EC              add ah,ch
0000B13D  0300              add ax,[bx+si]
0000B13F  00060000          add [0x0],al
0000B143  0000              add [bx+si],al
0000B145  0000              add [bx+si],al
0000B147  006A00            add [bp+si+0x0],ch
0000B14A  0000              add [bx+si],al
0000B14C  660000            o32 add [bx+si],al
0000B14F  006200            add [bp+si+0x0],ah
0000B152  0000              add [bx+si],al
0000B154  5C                pop sp
0000B155  0000              add [bx+si],al
0000B157  004400            add [si+0x0],al
0000B15A  0000              add [bx+si],al
0000B15C  0E                push cs
0000B15D  0000              add [bx+si],al
0000B15F  0000              add [bx+si],al
0000B161  0000              add [bx+si],al
0000B163  00F2              add dl,dh
0000B165  0300              add ax,[bx+si]
0000B167  0000              add [bx+si],al
0000B169  0000              add [bx+si],al
0000B16B  0000              add [bx+si],al
0000B16D  0000              add [bx+si],al
0000B16F  0000              add [bx+si],al
0000B171  0000              add [bx+si],al
0000B173  0000              add [bx+si],al
0000B175  00F3              add bl,dh
0000B177  06                push es
0000B178  6205              bound ax,[di]
0000B17A  6309              arpl [bx+di],cx
0000B17C  305388            xor [bp+di-0x78],dl
0000B17F  3E17              ds pop ss
0000B181  F5                cmc
0000B182  E8FABE            call 0x707f
0000B185  EF                out dx,ax
0000B186  A7                cmpsw
0000B187  EE                out dx,al
0000B188  B18C              mov cl,0x8c
0000B18A  EF                out dx,ax
0000B18B  91                xchg ax,cx
0000B18C  F4                hlt
0000B18D  7F3F              jg 0xb1ce
0000B18F  9F                lahf
0000B190  C7                db 0xc7
0000B191  E98605            jmp 0xb71a
0000B194  C10464            rol word [si],byte 0x64
0000B197  88F9              mov cl,bh
0000B199  0C20              or al,0x20
0000B19B  8E6232            mov fs,[bp+si+0x32]
0000B19E  50                push ax
0000B19F  51                push cx
0000B1A0  05A20F            add ax,0xfa2
0000B1A3  A982FE            test ax,0xfe82
0000B1A6  51                push cx
0000B1A7  107A33            adc [bp+si+0x33],bh
0000B1AA  5C                pop sp
0000B1AB  40                inc ax
0000B1AC  F4                hlt
0000B1AD  5D                pop bp
0000B1AE  830CA7            or word [si],byte -0x59
0000B1B1  57                push di
0000B1B2  D6                salc
0000B1B3  1F                pop ds
0000B1B4  47                inc di
0000B1B5  C3                ret
0000B1B6  5C                pop sp
0000B1B7  CE                into
0000B1B8  3300              xor ax,[bx+si]
0000B1BA  6E                outsb
0000B1BB  8702              xchg ax,[bp+si]
0000B1BD  FB                sti
0000B1BE  040A              add al,0xa
0000B1C0  0C20              or al,0x20
0000B1C2  C8E44A8E          enter 0x4ae4,0x8e
0000B1C6  51                push cx
0000B1C7  05453D            add ax,0x3d45
0000B1CA  CE                into
0000B1CB  61                popa
0000B1CC  AC                lodsb
0000B1CD  41                inc cx
0000B1CE  6880EF            push word 0xef80
0000B1D1  91                xchg ax,cx
0000B1D2  F4                hlt
0000B1D3  7F3F              jg 0xb214
0000B1D5  9F                lahf
0000B1D6  C7                db 0xc7
0000B1D7  E980F3            jmp 0xa55a
0000B1DA  D6                salc
0000B1DB  B411              mov ah,0x11
0000B1DD  251A4E            and ax,0x4e1a
0000B1E0  A310F4            mov [0xf410],ax
0000B1E3  53                push bx
0000B1E4  884866            mov [bx+si+0x66],cl
0000B1E7  107DA5            adc [di-0x5b],bh
0000B1EA  2C65              sub al,0x65
0000B1EC  68F090            push word 0x90f0
0000B1EF  43                inc bx
0000B1F0  F8                clc
0000B1F1  C8110224          enter 0x211,0x24
0000B1F5  868541D2          xchg al,[di-0x2dbf]
0000B1F9  3B8880F2          cmp cx,[bx+si-0xd80]
0000B1FD  0CD2              or al,0xd2
0000B1FF  E03E              loopne 0xb23f
0000B201  48                dec ax
0000B202  88E5              mov ch,ah
0000B204  19A0F47C          sbb [bx+si+0x7cf4],sp
0000B208  33265EC1          xor sp,[0xc15e]
0000B20C  0419              add al,0x19
0000B20E  A9C358            test ax,0x58c3
0000B211  80F270            xor dl,0x70
0000B214  3494              xor al,0x94
0000B216  EE                out dx,al
0000B217  107A33            adc [bp+si+0x33],bh
0000B21A  5D                pop bp
0000B21B  6A39              push byte +0x39
0000B21D  00F4              add ah,dh
0000B21F  F0359C83          lock xor ax,0x839c
0000B223  49                dec cx
0000B224  D460              aam 0x60
0000B226  F06453            fs lock push bx
0000B229  91                xchg ax,cx
0000B22A  27                daa
0000B22B  1983E615          sbb [bp+di+0x15e6],ax
0000B22F  47                inc di
0000B230  30F2              xor dl,dh
0000B232  4A                dec dx
0000B233  83283F            sub word [bx+si],byte +0x3f
0000B236  62905388          bound dx,[bx+si-0x77ad]
0000B23A  A0F504            mov al,[0x4f5]
0000B23D  3367A8            xor sp,[bx-0x58]
0000B240  707A              jo 0xb2bc
0000B242  335D6A            xor bx,[di+0x6a]
0000B245  3900              cmp [bx+si],ax
0000B247  F055              lock push bp
0000B249  0F                db 0x0f
0000B24A  0CA7              or al,0xa7
0000B24C  BC921F            mov sp,0x1f92
0000B24F  C1DF88            rcr di,byte 0x88
0000B252  7C4F              jl 0xb2a3
0000B254  9F                lahf
0000B255  E7FA              out 0xfa,ax
0000B257  40                inc ax
0000B258  F4                hlt
0000B259  0452              add al,0x52
0000B25B  1D460F            sbb ax,0xf46
0000B25E  B5E0              mov ch,0xe0
0000B260  80FB10            cmp bl,0x10
0000B263  75AC              jnz 0xb211
0000B265  688883            push word 0x8388
0000B268  F6                db 0xf6
0000B269  08C9              or cl,cl
0000B26B  F0C00014          lock rol byte [bx+si],byte 0x14
0000B26F  000E0014          add [0x1400],cl
0000B273  000E0016          add [0x1600],cl
0000B277  0009              add [bx+di],cl
0000B279  0009              add [bx+di],cl
0000B27B  000B              add [bp+di],cl
0000B27D  000F              add [bx],cl
0000B27F  000A              add [bp+si],cl
0000B281  000C              add [si],cl
0000B283  000C              add [si],cl
0000B285  0008              add [bx+si],cl
0000B287  000B              add [bp+di],cl
0000B289  000A              add [bp+si],cl
0000B28B  000C              add [si],cl
0000B28D  0011              add [bx+di],dl
0000B28F  0009              add [bx+di],cl
0000B291  000C              add [si],cl
0000B293  0000              add [bx+si],al
0000B295  0C00              or al,0x0
0000B297  0000              add [bx+si],al
0000B299  0100              add [bx+si],ax
0000B29B  0000              add [bx+si],al
0000B29D  3200              xor al,[bx+si]
0000B29F  0000              add [bx+si],al
0000B2A1  1400              adc al,0x0
0000B2A3  0000              add [bx+si],al
0000B2A5  0800              or [bx+si],al
0000B2A7  0000              add [bx+si],al
0000B2A9  3000              xor [bx+si],al
0000B2AB  0000              add [bx+si],al
0000B2AD  3C00              cmp al,0x0
0000B2AF  0000              add [bx+si],al
0000B2B1  1000              adc [bx+si],al
0000B2B3  0000              add [bx+si],al
0000B2B5  801A06            sbb byte [bp+si],0x6
0000B2B8  000C              add [si],cl
0000B2BA  0000              add [bx+si],al
0000B2BC  0002              add [bp+si],al
0000B2BE  0000              add [bx+si],al
0000B2C0  004600            add [bp+0x0],al
0000B2C3  0000              add [bx+si],al
0000B2C5  1400              adc al,0x0
0000B2C7  0000              add [bx+si],al
0000B2C9  0800              or [bx+si],al
0000B2CB  0000              add [bx+si],al
0000B2CD  44                inc sp
0000B2CE  0000              add [bx+si],al
0000B2D0  005000            add [bx+si+0x0],dl
0000B2D3  0000              add [bx+si],al
0000B2D5  1000              adc [bx+si],al
0000B2D7  0000              add [bx+si],al
0000B2D9  801A06            sbb byte [bp+si],0x6
0000B2DC  0000              add [bx+si],al
0000B2DE  0000              add [bx+si],al
0000B2E0  000C              add [si],cl
0000B2E2  0000              add [bx+si],al
0000B2E4  0003              add [bp+di],al
0000B2E6  0000              add [bx+si],al
0000B2E8  004600            add [bp+0x0],al
0000B2EB  0000              add [bx+si],al
0000B2ED  1400              adc al,0x0
0000B2EF  0000              add [bx+si],al
0000B2F1  0800              or [bx+si],al
0000B2F3  0000              add [bx+si],al
0000B2F5  3000              xor [bx+si],al
0000B2F7  0000              add [bx+si],al
0000B2F9  50                push ax
0000B2FA  0000              add [bx+si],al
0000B2FC  0010              add [bx+si],dl
0000B2FE  0000              add [bx+si],al
0000B300  00801A06          add [bx+si+0x61a],al
0000B304  0000              add [bx+si],al
0000B306  0000              add [bx+si],al
0000B308  0004              add [si],al
0000B30A  0000              add [bx+si],al
0000B30C  0003              add [bp+di],al
0000B30E  0000              add [bx+si],al
0000B310  004300            add [bp+di+0x0],al
0000B313  0000              add [bx+si],al
0000B315  2800              sub [bx+si],al
0000B317  0000              add [bx+si],al
0000B319  1400              adc al,0x0
0000B31B  0000              add [bx+si],al
0000B31D  0800              or [bx+si],al
0000B31F  0000              add [bx+si],al
0000B321  1400              adc al,0x0
0000B323  0000              add [bx+si],al
0000B325  41                inc cx
0000B326  0000              add [bx+si],al
0000B328  0010              add [bx+si],dl
0000B32A  0000              add [bx+si],al
0000B32C  00801A06          add [bx+si+0x61a],al
0000B330  000C              add [si],cl
0000B332  0000              add [bx+si],al
0000B334  0004              add [si],al
0000B336  0000              add [bx+si],al
0000B338  005A00            add [bp+si+0x0],bl
0000B33B  0000              add [bx+si],al
0000B33D  0800              or [bx+si],al
0000B33F  0000              add [bx+si],al
0000B341  58                pop ax
0000B342  0000              add [bx+si],al
0000B344  006400            add [si+0x0],ah
0000B347  0000              add [bx+si],al
0000B349  1000              adc [bx+si],al
0000B34B  0000              add [bx+si],al
0000B34D  801A06            sbb byte [bp+si],0x6
0000B350  000C              add [si],cl
0000B352  0000              add [bx+si],al
0000B354  0005              add [di],al
0000B356  0000              add [bx+si],al
0000B358  006E00            add [bp+0x0],ch
0000B35B  0000              add [bx+si],al
0000B35D  0800              or [bx+si],al
0000B35F  0000              add [bx+si],al
0000B361  6C                insb
0000B362  0000              add [bx+si],al
0000B364  007800            add [bx+si+0x0],bh
0000B367  0000              add [bx+si],al
0000B369  1000              adc [bx+si],al
0000B36B  0000              add [bx+si],al
0000B36D  40                inc ax
0000B36E  0D0300            or ax,0x3
0000B371  0C00              or al,0x0
0000B373  0000              add [bx+si],al
0000B375  06                push es
0000B376  0000              add [bx+si],al
0000B378  00820000          add [bp+si+0x0],al
0000B37C  0008              add [bx+si],cl
0000B37E  0000              add [bx+si],al
0000B380  00800000          add [bx+si+0x0],al
0000B384  008C0000          add [si+0x0],cl
0000B388  0010              add [bx+si],dl
0000B38A  0000              add [bx+si],al
0000B38C  00A0BB0D          add [bx+si+0xdbb],ah
0000B390  0000              add [bx+si],al
0000B392  0000              add [bx+si],al
0000B394  000C              add [si],cl
0000B396  0000              add [bx+si],al
0000B398  0007              add [bx],al
0000B39A  0000              add [bx+si],al
0000B39C  006400            add [si+0x0],ah
0000B39F  0000              add [bx+si],al
0000B3A1  0800              or [bx+si],al
0000B3A3  0000              add [bx+si],al
0000B3A5  58                pop ax
0000B3A6  0000              add [bx+si],al
0000B3A8  008C0000          add [si+0x0],cl
0000B3AC  0010              add [bx+si],dl
0000B3AE  0000              add [bx+si],al
0000B3B0  00400D            add [bx+si+0xd],al
0000B3B3  0300              add ax,[bx+si]
0000B3B5  0C00              or al,0x0
0000B3B7  0000              add [bx+si],al
0000B3B9  0800              or [bx+si],al
0000B3BB  0000              add [bx+si],al
0000B3BD  7800              js 0xb3bf
0000B3BF  0000              add [bx+si],al
0000B3C1  0800              or [bx+si],al
0000B3C3  0000              add [bx+si],al
0000B3C5  7600              jna 0xb3c7
0000B3C7  0000              add [bx+si],al
0000B3C9  82                db 0x82
0000B3CA  0000              add [bx+si],al
0000B3CC  0010              add [bx+si],dl
0000B3CE  0000              add [bx+si],al
0000B3D0  00A0BB0D          add [bx+si+0xdbb],ah
0000B3D4  0000              add [bx+si],al
0000B3D6  0000              add [bx+si],al
0000B3D8  000C              add [si],cl
0000B3DA  0000              add [bx+si],al
0000B3DC  0009              add [bx+di],cl
0000B3DE  0000              add [bx+si],al
0000B3E0  006400            add [si+0x0],ah
0000B3E3  0000              add [bx+si],al
0000B3E5  0800              or [bx+si],al
0000B3E7  0000              add [bx+si],al
0000B3E9  6200              bound ax,[bx+si]
0000B3EB  0000              add [bx+si],al
0000B3ED  82                db 0x82
0000B3EE  0000              add [bx+si],al
0000B3F0  0010              add [bx+si],dl
0000B3F2  0000              add [bx+si],al
0000B3F4  00400D            add [bx+si+0xd],al
0000B3F7  0300              add ax,[bx+si]
0000B3F9  0C00              or al,0x0
0000B3FB  0000              add [bx+si],al
0000B3FD  0A00              or al,[bx+si]
0000B3FF  0000              add [bx+si],al
0000B401  7800              js 0xb403
0000B403  0000              add [bx+si],al
0000B405  0800              or [bx+si],al
0000B407  0000              add [bx+si],al
0000B409  7600              jna 0xb40b
0000B40B  0000              add [bx+si],al
0000B40D  82                db 0x82
0000B40E  0000              add [bx+si],al
0000B410  0010              add [bx+si],dl
0000B412  0000              add [bx+si],al
0000B414  00A0BB0D          add [bx+si+0xdbb],ah
0000B418  0000              add [bx+si],al
0000B41A  0000              add [bx+si],al
0000B41C  000C              add [si],cl
0000B41E  0000              add [bx+si],al
0000B420  000B              add [bp+di],cl
0000B422  0000              add [bx+si],al
0000B424  006400            add [si+0x0],ah
0000B427  0000              add [bx+si],al
0000B429  0800              or [bx+si],al
0000B42B  0000              add [bx+si],al
0000B42D  6200              bound ax,[bx+si]
0000B42F  0000              add [bx+si],al
0000B431  82                db 0x82
0000B432  0000              add [bx+si],al
0000B434  0010              add [bx+si],dl
0000B436  0000              add [bx+si],al
0000B438  00400D            add [bx+si+0xd],al
0000B43B  0300              add ax,[bx+si]
0000B43D  0C00              or al,0x0
0000B43F  0000              add [bx+si],al
0000B441  0C00              or al,0x0
0000B443  0000              add [bx+si],al
0000B445  7800              js 0xb447
0000B447  0000              add [bx+si],al
0000B449  0800              or [bx+si],al
0000B44B  0000              add [bx+si],al
0000B44D  7600              jna 0xb44f
0000B44F  0000              add [bx+si],al
0000B451  82                db 0x82
0000B452  0000              add [bx+si],al
0000B454  0010              add [bx+si],dl
0000B456  0000              add [bx+si],al
0000B458  00A0BB0D          add [bx+si+0xdbb],ah
0000B45C  0000              add [bx+si],al
0000B45E  0000              add [bx+si],al
0000B460  000C              add [si],cl
0000B462  0000              add [bx+si],al
0000B464  000D              add [di],cl
0000B466  0000              add [bx+si],al
0000B468  005A00            add [bp+si+0x0],bl
0000B46B  0000              add [bx+si],al
0000B46D  0800              or [bx+si],al
0000B46F  0000              add [bx+si],al
0000B471  58                pop ax
0000B472  0000              add [bx+si],al
0000B474  00820000          add [bp+si+0x0],al
0000B478  0010              add [bx+si],dl
0000B47A  0000              add [bx+si],al
0000B47C  00400D            add [bx+si+0xd],al
0000B47F  0300              add ax,[bx+si]
0000B481  0C00              or al,0x0
0000B483  0000              add [bx+si],al
0000B485  0E                push cs
0000B486  0000              add [bx+si],al
0000B488  006E00            add [bp+0x0],ch
0000B48B  0000              add [bx+si],al
0000B48D  0800              or [bx+si],al
0000B48F  0000              add [bx+si],al
0000B491  6C                insb
0000B492  0000              add [bx+si],al
0000B494  007800            add [bx+si+0x0],bh
0000B497  0000              add [bx+si],al
0000B499  1000              adc [bx+si],al
0000B49B  0000              add [bx+si],al
0000B49D  A08601            mov al,[0x186]
0000B4A0  000C              add [si],cl
0000B4A2  0000              add [bx+si],al
0000B4A4  000F              add [bx],cl
0000B4A6  0000              add [bx+si],al
0000B4A8  007800            add [bx+si+0x0],bh
0000B4AB  0000              add [bx+si],al
0000B4AD  0800              or [bx+si],al
0000B4AF  0000              add [bx+si],al
0000B4B1  7600              jna 0xb4b3
0000B4B3  0000              add [bx+si],al
0000B4B5  82                db 0x82
0000B4B6  0000              add [bx+si],al
0000B4B8  0010              add [bx+si],dl
0000B4BA  0000              add [bx+si],al
0000B4BC  00A08601          add [bx+si+0x186],ah
0000B4C0  000C              add [si],cl
0000B4C2  0000              add [bx+si],al
0000B4C4  0010              add [bx+si],dl
0000B4C6  0000              add [bx+si],al
0000B4C8  00820000          add [bp+si+0x0],al
0000B4CC  0008              add [bx+si],cl
0000B4CE  0000              add [bx+si],al
0000B4D0  00800000          add [bx+si+0x0],al
0000B4D4  008C0000          add [si+0x0],cl
0000B4D8  0010              add [bx+si],dl
0000B4DA  0000              add [bx+si],al
0000B4DC  004042            add [bx+si+0x42],al
0000B4DF  0F0000            sldt [bx+si]
0000B4E2  0000              add [bx+si],al
0000B4E4  000C              add [si],cl
0000B4E6  0000              add [bx+si],al
0000B4E8  0011              add [bx+di],dl
0000B4EA  0000              add [bx+si],al
0000B4EC  006E00            add [bp+0x0],ch
0000B4EF  0000              add [bx+si],al
0000B4F1  0800              or [bx+si],al
0000B4F3  0000              add [bx+si],al
0000B4F5  58                pop ax
0000B4F6  0000              add [bx+si],al
0000B4F8  008C0000          add [si+0x0],cl
0000B4FC  0010              add [bx+si],dl
0000B4FE  0000              add [bx+si],al
0000B500  00400D            add [bx+si+0xd],al
0000B503  0300              add ax,[bx+si]
0000B505  0400              add al,0x0
0000B507  0000              add [bx+si],al
0000B509  0400              add al,0x0
0000B50B  0000              add [bx+si],al
0000B50D  41                inc cx
0000B50E  0000              add [bx+si],al
0000B510  004B00            add [bp+di+0x0],cl
0000B513  0000              add [bx+si],al
0000B515  0800              or [bx+si],al
0000B517  0000              add [bx+si],al
0000B519  91                xchg ax,cx
0000B51A  0000              add [bx+si],al
0000B51C  00C3              add bl,al
0000B51E  0000              add [bx+si],al
0000B520  0010              add [bx+si],dl
0000B522  0000              add [bx+si],al
0000B524  00A0BB0D          add [bx+si+0xdbb],ah
0000B528  0000              add [bx+si],al
0000B52A  0000              add [bx+si],al
0000B52C  000C              add [si],cl
0000B52E  0000              add [bx+si],al
0000B530  0012              add [bp+si],dl
0000B532  0000              add [bx+si],al
0000B534  005A00            add [bp+si+0x0],bl
0000B537  0000              add [bx+si],al
0000B539  0800              or [bx+si],al
0000B53B  0000              add [bx+si],al
0000B53D  58                pop ax
0000B53E  0000              add [bx+si],al
0000B540  00820000          add [bp+si+0x0],al
0000B544  0010              add [bx+si],dl
0000B546  0000              add [bx+si],al
0000B548  00400D            add [bx+si+0xd],al
0000B54B  0300              add ax,[bx+si]
0000B54D  0000              add [bx+si],al
0000B54F  0000              add [bx+si],al
0000B551  0C00              or al,0x0
0000B553  0000              add [bx+si],al
0000B555  1300              adc ax,[bx+si]
0000B557  0000              add [bx+si],al
0000B559  6E                outsb
0000B55A  0000              add [bx+si],al
0000B55C  0008              add [bx+si],cl
0000B55E  0000              add [bx+si],al
0000B560  006C00            add [si+0x0],ch
0000B563  0000              add [bx+si],al
0000B565  7800              js 0xb567
0000B567  0000              add [bx+si],al
0000B569  1000              adc [bx+si],al
0000B56B  0000              add [bx+si],al
0000B56D  001B              add [bp+di],bl
0000B56F  B700              mov bh,0x0
0000B571  0800              or [bx+si],al
0000B573  0000              add [bx+si],al
0000B575  58                pop ax
0000B576  0000              add [bx+si],al
0000B578  008C0000          add [si+0x0],cl
0000B57C  00FF              add bh,bh
0000B57E  FF                db 0xff
0000B57F  FF                db 0xff
0000B580  FF00              inc word [bx+si]
0000B582  7075              jo 0xb5f9
0000B584  4E                dec si
0000B585  0000              add [bx+si],al
0000B587  0000              add [bx+si],al
0000B589  0000              add [bx+si],al
0000B58B  0000              add [bx+si],al
0000B58D  000C              add [si],cl
0000B58F  2400              and al,0x0
0000B591  1E                push ds
0000B592  8D800F01          lea ax,[bx+si+0x10f]
0000B596  0000              add [bx+si],al
0000B598  0000              add [bx+si],al
0000B59A  00614D            add [bx+di+0x4d],ah
0000B59D  7075              jo 0xb614
0000B59F  2020              and [bx+si],ah
0000B5A1  2020              and [bx+si],ah
0000B5A3  2020              and [bx+si],ah
0000B5A5  2020              and [bx+si],ah
0000B5A7  2020              and [bx+si],ah
0000B5A9  2020              and [bx+si],ah
0000B5AB  2020              and [bx+si],ah
0000B5AD  2020              and [bx+si],ah
0000B5AF  2020              and [bx+si],ah
0000B5B1  2020              and [bx+si],ah
0000B5B3  2020              and [bx+si],ah
0000B5B5  2020              and [bx+si],ah
0000B5B7  2020              and [bx+si],ah
0000B5B9  2020              and [bx+si],ah
0000B5BB  0000              add [bx+si],al
0000B5BD  0000              add [bx+si],al
0000B5BF  0000              add [bx+si],al
0000B5C1  0000              add [bx+si],al
0000B5C3  000C              add [si],cl
0000B5C5  2400              and al,0x0
0000B5C7  1E                push ds
0000B5C8  8D00              lea ax,[bx+si]
0000B5CA  0000              add [bx+si],al
0000B5CC  0000              add [bx+si],al
0000B5CE  0007              add [bx],al
0000B5D0  006200            add [bp+si+0x0],ah
0000B5D3  07                pop es
0000B5D4  0005              add [di],al
0000B5D6  0001              add [bx+di],al
0000B5D8  0000              add [bx+si],al
0000B5DA  006201            add [bp+si+0x1],ah
0000B5DD  6E                outsb
0000B5DE  0000              add [bx+si],al
0000B5E0  0038              add [bx+si],bh
0000B5E2  00F6              add dh,dh
0000B5E4  0100              add [bx+si],ax
0000B5E6  00820300          add [bp+si+0x3],al
0000B5EA  004804            add [bx+si+0x4],cl
0000B5ED  0000              add [bx+si],al
0000B5EF  000630C0          add [0xc030],al
0000B5F3  1C61              sbb al,0x61
0000B5F5  006000            add [bx+si+0x0],ah
0000B5F8  00800000          add [bx+si+0x0],al
0000B5FC  0004              add [si],al
0000B5FE  00F9              add cl,bh
0000B600  F1                int1
0000B601  9F                lahf
0000B602  FF                db 0xff
0000B603  FD                std
0000B604  3C3D              cmp al,0x3d
0000B606  E6E7              out 0xe7,al
0000B608  DDDF              fstp st7
0000B60A  7960              jns 0xb66c
0000B60C  8C3F              mov [bx],segr7
0000B60E  C6                db 0xc6
0000B60F  3931              cmp [bx+di],si
0000B611  FB                sti
0000B612  C2E7BE            ret 0xbee7
0000B615  58                pop ax
0000B616  21910154          and [bx+di+0x5401],dx
0000B61A  58                pop ax
0000B61B  61                popa
0000B61C  8A29              mov ch,[bx+di]
0000B61E  8C400D            mov [bx+si+0xd],es
0000B621  4C                dec sp
0000B622  B80100            mov ax,0x1
0000B625  007800            add [bx+si+0x0],bh
0000B628  024040            add al,[bx+si+0x40]
0000B62B  04A0              add al,0xa0
0000B62D  0020              add [bx+si],ah
0000B62F  0000              add [bx+si],al
0000B631  800000            add byte [bx+si],0x0
0000B634  0004              add [si],al
0000B636  00544A            add [si+0x4a],dl
0000B639  A5                movsw
0000B63A  94                xchg ax,sp
0000B63B  49                dec cx
0000B63C  286443            sub [si+0x43],ah
0000B63F  98                cbw
0000B640  A235A6            mov [0xa635],al
0000B643  60                pusha
0000B644  8C31              mov [bx+di],segr6
0000B646  C6464B84          mov byte [bp+0x4b],0x84
0000B64A  26186304          sbb [es:bp+di+0x4],ah
0000B64E  D028              shr byte [bx+si],1
0000B650  02A10412          add ah,[bx+di+0x1204]
0000B654  40                inc ax
0000B655  004240            add [bp+si+0x40],al
0000B658  1552C4            adc ax,0xc452
0000B65B  0220              add ah,[bx+si]
0000B65D  00C4              add ah,al
0000B65F  9D                popf
0000B660  73F7              jnc 0xb659
0000B662  CE                into
0000B663  343B              xor al,0x3b
0000B665  AC                lodsb
0000B666  AA                stosb
0000B667  37                aaa
0000B668  EBDB              jmp short 0xb645
0000B66A  6F                outsw
0000B66B  1CC7              sbb al,0xc7
0000B66D  EA63127441        jmp 0x4174:0x1263
0000B672  C6                db 0xc6
0000B673  4A                dec dx
0000B674  E8A642            call 0xf91d
0000B677  E8A284            call 0x3b1c
0000B67A  B9608C            mov cx,0x8c60
0000B67D  42                inc dx
0000B67E  A90885            test ax,0x8508
0000B681  F4                hlt
0000B682  CAE704            retf 0x4e7
0000B685  CE                into
0000B686  B93977            mov cx,0x7739
0000B689  19CE              sbb si,cx
0000B68B  70CE              jo 0xb65b
0000B68D  EE                out dx,al
0000B68E  1B8120A1          sbb ax,[bx+di-0x5ee0]
0000B692  883D              mov [di],bh
0000B694  2000              and [bx+si],al
0000B696  48                dec ax
0000B697  6692              xchg eax,edx
0000B699  49                dec cx
0000B69A  5F                pop di
0000B69B  17                pop ss
0000B69C  255325            and ax,0x2553
0000B69F  C9                leave
0000B6A0  1489              adc al,0x89
0000B6A2  B85245            mov ax,0x4552
0000B6A5  4E                dec si
0000B6A6  94                xchg ax,sp
0000B6A7  124C4D            adc cl,[si+0x4d]
0000B6AA  844C2A            test [si+0x2a],cl
0000B6AD  A5                movsw
0000B6AE  42                inc dx
0000B6AF  8AA264A8          mov ah,[bp+si-0x579c]
0000B6B3  95                xchg ax,bp
0000B6B4  8A841010          mov al,[si+0x1010]
0000B6B8  850F              test [bx],cx
0000B6BA  3F                aas
0000B6BB  108952CA          adc [bx+di-0x35ae],cl
0000B6BF  FF9FCAFF          call far [bx-0x36]
0000B6C3  8E31              mov segr6,[bx+di]
0000B6C5  24E9              and al,0xe9
0000B6C7  0240A1            add al,[bx+si-0x5f]
0000B6CA  90                nop
0000B6CB  C0FF00            sar bh,byte 0x0
0000B6CE  44                inc sp
0000B6CF  62924650          bound dx,[bp+si+0x5046]
0000B6D3  152553            adc ax,0x5325
0000B6D6  253917            and ax,0x1739
0000B6D9  A90651            test ax,0x5106
0000B6DC  29910854          sub [bx+di+0x5408],dx
0000B6E0  4A                dec dx
0000B6E1  25944A            and ax,0x4a94
0000B6E4  2A24              sub ah,[si]
0000B6E6  4A                dec dx
0000B6E7  89A22426          mov [bp+si+0x2624],sp
0000B6EB  95                xchg ax,bp
0000B6EC  8A892822          mov cl,[bx+di+0x2228]
0000B6F0  49                dec cx
0000B6F1  8C22              mov [bp+si],fs
0000B6F3  185152            sbb [bx+di+0x52],dl
0000B6F6  CA4288            retf 0x8842
0000B6F9  4A                dec dx
0000B6FA  108A3124          adc [bp+si+0x2431],cl
0000B6FE  49                dec cx
0000B6FF  08802101          or [bx+si+0x121],al
0000B703  3C20              cmp al,0x20
0000B705  00449D            add [si-0x63],al
0000B708  6D                insw
0000B709  E1AE              loope 0xb6b9
0000B70B  DC6772            fsub qword [bx+0x72]
0000B70E  FD                std
0000B70F  0BE4              or sp,sp
0000B711  46                inc si
0000B712  9C                pushf
0000B713  A6                cmpsb
0000B714  90                nop
0000B715  F1                int1
0000B716  C9                leave
0000B717  B9F11F            mov cx,0x1ff1
0000B71A  FE                db 0xfe
0000B71B  99                cwd
0000B71C  3D7EFF            cmp ax,0xff7e
0000B71F  C6                db 0xc6
0000B720  9D                popf
0000B721  CE                into
0000B722  E70A              out 0xa,ax
0000B724  71DF              jno 0xb705
0000B726  45                inc bp
0000B727  FD                std
0000B728  3373C2            xor si,[bp+di-0x3e]
0000B72B  E790              out 0x90,ax
0000B72D  AD                lodsw
0000B72E  353977            xor ax,0x7739
0000B731  FD                std
0000B732  CE                into
0000B733  71CE              jno 0xb703
0000B735  9BA6              wait cmpsb
0000B737  2B08              sub cx,[bx+si]
0000B739  12910020          adc dl,[bx+di+0x2000]
0000B73D  005800            add [bx+si+0x0],bl
0000B740  000E0020          add [0x2000],cl
0000B744  0000              add [bx+si],al
0000B746  001C              add [si],bl
0000B748  0E                push cs
0000B749  0000              add [bx+si],al
0000B74B  0000              add [bx+si],al
0000B74D  0000              add [bx+si],al
0000B74F  0000              add [bx+si],al
0000B751  0000              add [bx+si],al
0000B753  0000              add [bx+si],al
0000B755  0000              add [bx+si],al
0000B757  0000              add [bx+si],al
0000B759  0000              add [bx+si],al
0000B75B  0000              add [bx+si],al
0000B75D  0000              add [bx+si],al
0000B75F  0000              add [bx+si],al
0000B761  0000              add [bx+si],al
0000B763  0000              add [bx+si],al
0000B765  0000              add [bx+si],al
0000B767  0020              add [bx+si],ah
0000B769  0000              add [bx+si],al
0000B76B  0000              add [bx+si],al
0000B76D  0000              add [bx+si],al
0000B76F  1400              adc al,0x0
0000B771  0C02              or al,0x2
0000B773  0000              add [bx+si],al
0000B775  004000            add [bx+si+0x0],al
0000B778  0005              add [di],al
0000B77A  0005              add [di],al
0000B77C  0005              add [di],al
0000B77E  000A              add [bp+si],cl
0000B780  0004              add [si],al
0000B782  000E0005          add [0x500],cl
0000B786  0013              add [bp+di],dl
0000B788  0005              add [di],al
0000B78A  0018              add [bx+si],bl
0000B78C  0004              add [si],al
0000B78E  001C              add [si],bl
0000B790  0005              add [di],al
0000B792  0021              add [bx+di],ah
0000B794  0005              add [di],al
0000B796  00260003          add [0x300],ah
0000B79A  0029              add [bx+di],ch
0000B79C  0003              add [bp+di],al
0000B79E  002C              add [si],ch
0000B7A0  0005              add [di],al
0000B7A2  0031              add [bx+di],dh
0000B7A4  0003              add [bp+di],al
0000B7A6  0034              add [si],dh
0000B7A8  0006003A          add [0x3a00],al
0000B7AC  0005              add [di],al
0000B7AE  003F              add [bx],bh
0000B7B0  0005              add [di],al
0000B7B2  004400            add [si+0x0],al
0000B7B5  050049            add ax,0x4900
0000B7B8  0005              add [di],al
0000B7BA  004E00            add [bp+0x0],cl
0000B7BD  050053            add ax,0x5300
0000B7C0  0004              add [si],al
0000B7C2  005700            add [bx+0x0],dl
0000B7C5  0400              add al,0x0
0000B7C7  5B                pop bx
0000B7C8  00060061          add [0x6100],al
0000B7CC  0005              add [di],al
0000B7CE  006600            add [bp+0x0],ah
0000B7D1  07                pop es
0000B7D2  006D00            add [di+0x0],ch
0000B7D5  050072            add ax,0x7200
0000B7D8  0005              add [di],al
0000B7DA  007700            add [bx+0x0],dh
0000B7DD  0400              add al,0x0
0000B7DF  7B00              jpo 0xb7e1
0000B7E1  050080            add ax,0x8000
0000B7E4  0005              add [di],al
0000B7E6  00850005          add [di+0x500],al
0000B7EA  008A0005          add [bp+si+0x500],cl
0000B7EE  008F0005          add [bx+0x500],cl
0000B7F2  00940005          add [si+0x500],dl
0000B7F6  00990005          add [bx+di+0x500],bl
0000B7FA  009E0005          add [bp+0x500],bl
0000B7FE  00A30003          add [bp+di+0x300],ah
0000B802  00A60005          add [bp+0x500],ah
0000B806  00AB0005          add [bp+di+0x500],ch
0000B80A  00B00005          add [bx+si+0x500],dh
0000B80E  00B50007          add [di+0x700],dh
0000B812  00BC0006          add [si+0x600],bh
0000B816  00C2              add dl,al
0000B818  0005              add [di],al
0000B81A  00C7              add bh,al
0000B81C  0005              add [di],al
0000B81E  00CC              add ah,cl
0000B820  0005              add [di],al
0000B822  00D1              add cl,dl
0000B824  0005              add [di],al
0000B826  00D6              add dh,dl
0000B828  0005              add [di],al
0000B82A  00DB              add bl,bl
0000B82C  0005              add [di],al
0000B82E  00E0              add al,ah
0000B830  0005              add [di],al
0000B832  00E5              add ch,ah
0000B834  0005              add [di],al
0000B836  00EA              add dl,ch
0000B838  0007              add [bx],al
0000B83A  00F1              add cl,dh
0000B83C  0005              add [di],al
0000B83E  00F6              add dh,dh
0000B840  0005              add [di],al
0000B842  00FB              add bl,bh
0000B844  0005              add [di],al
0000B846  0000              add [bx+si],al
0000B848  01060006          add [0x600],ax
0000B84C  0103              add [bp+di],ax
0000B84E  0009              add [bx+di],cl
0000B850  0105              add [di],ax
0000B852  000E0105          add [0x501],cl
0000B856  0013              add [bp+di],dl
0000B858  0105              add [di],ax
0000B85A  0018              add [bx+si],bl
0000B85C  0105              add [di],ax
0000B85E  001D              add [di],bl
0000B860  0105              add [di],ax
0000B862  0022              add [bp+si],ah
0000B864  0105              add [di],ax
0000B866  0027              add [bx],ah
0000B868  0105              add [di],ax
0000B86A  002C              add [si],ch
0000B86C  0105              add [di],ax
0000B86E  0031              add [bx+di],dh
0000B870  0105              add [di],ax
0000B872  00360105          add [0x501],dh
0000B876  003B              add [bp+di],bh
0000B878  0105              add [di],ax
0000B87A  004001            add [bx+si+0x1],al
0000B87D  0400              add al,0x0
0000B87F  44                inc sp
0000B880  0105              add [di],ax
0000B882  004901            add [bx+di+0x1],cl
0000B885  05004E            add ax,0x4e00
0000B888  0105              add [di],ax
0000B88A  005301            add [bp+di+0x1],dl
0000B88D  050058            add ax,0x5800
0000B890  0103              add [bp+di],ax
0000B892  005B01            add [bp+di+0x1],bl
0000B895  0300              add ax,[bx+si]
0000B897  5E                pop si
0000B898  0105              add [di],ax
0000B89A  006301            add [bp+di+0x1],ah
0000B89D  050068            add ax,0x6800
0000B8A0  0105              add [di],ax
0000B8A2  006D01            add [di+0x1],ch
0000B8A5  0000              add [bx+si],al
0000B8A7  6D                insw
0000B8A8  0100              add [bx+si],ax
0000B8AA  006D01            add [di+0x1],ch
0000B8AD  06                push es
0000B8AE  007301            add [bp+di+0x1],dh
0000B8B1  06                push es
0000B8B2  007901            add [bx+di+0x1],bh
0000B8B5  06                push es
0000B8B6  007F01            add [bx+0x1],bh
0000B8B9  06                push es
0000B8BA  00850103          add [di+0x301],al
0000B8BE  00880102          add [bx+si+0x201],cl
0000B8C2  008A0101          add [bp+si+0x101],cl
0000B8C6  008B0102          add [bp+di+0x201],cl
0000B8CA  008D0102          add [di+0x201],cl
0000B8CE  008F0101          add [bx+0x101],cl
0000B8D2  00900101          add [bx+si+0x101],dl
0000B8D6  00910105          add [bx+di+0x501],dl
0000B8DA  00960104          add [bp+0x401],dl
0000B8DE  009A0103          add [bp+si+0x301],bl
0000B8E2  009D0103          add [di+0x301],bl
0000B8E6  00A00105          add [bx+si+0x501],ah
0000B8EA  00A50105          add [di+0x501],ah
0000B8EE  00AA0104          add [bp+si+0x401],ch
0000B8F2  00AE0103          add [bp+0x301],ch
0000B8F6  00B10105          add [bx+di+0x501],dh
0000B8FA  00B60100          add [bp+0x1],dh
0000B8FE  00B60100          add [bp+0x1],dh
0000B902  00060006          add [0x600],al
0000B906  0005              add [di],al
0000B908  00060006          add [0x600],al
0000B90C  0005              add [di],al
0000B90E  00060006          add [0x600],al
0000B912  0004              add [si],al
0000B914  0004              add [si],al
0000B916  00060004          add [0x400],al
0000B91A  0007              add [bx],al
0000B91C  00060006          add [0x600],al
0000B920  00060006          add [0x600],al
0000B924  00060005          add [0x500],al
0000B928  0005              add [di],al
0000B92A  0007              add [bx],al
0000B92C  00060008          add [0x800],al
0000B930  00060006          add [0x600],al
0000B934  0005              add [di],al
0000B936  00060006          add [0x600],al
0000B93A  00060006          add [0x600],al
0000B93E  00060006          add [0x600],al
0000B942  00060006          add [0x600],al
0000B946  0004              add [si],al
0000B948  00060006          add [0x600],al
0000B94C  00060008          add [0x800],al
0000B950  0007              add [bx],al
0000B952  00060006          add [0x600],al
0000B956  00060006          add [0x600],al
0000B95A  00060006          add [0x600],al
0000B95E  00060006          add [0x600],al
0000B962  0008              add [bx+si],cl
0000B964  00060006          add [0x600],al
0000B968  00060007          add [0x700],al
0000B96C  0004              add [si],al
0000B96E  00060006          add [0x600],al
0000B972  00060006          add [0x600],al
0000B976  00060006          add [0x600],al
0000B97A  00060006          add [0x600],al
0000B97E  00060006          add [0x600],al
0000B982  00060005          add [0x500],al
0000B986  00060006          add [0x600],al
0000B98A  00060006          add [0x600],al
0000B98E  0004              add [si],al
0000B990  0004              add [si],al
0000B992  00060006          add [0x600],al
0000B996  00060006          add [0x600],al
0000B99A  00060007          add [0x700],al
0000B99E  0007              add [bx],al
0000B9A0  0007              add [bx],al
0000B9A2  0007              add [bx],al
0000B9A4  0004              add [si],al
0000B9A6  0003              add [bp+di],al
0000B9A8  0002              add [bp+si],al
0000B9AA  0003              add [bp+di],al
0000B9AC  0003              add [bp+di],al
0000B9AE  0002              add [bp+si],al
0000B9B0  0002              add [bp+si],al
0000B9B2  00060005          add [0x500],al
0000B9B6  0004              add [si],al
0000B9B8  0004              add [si],al
0000B9BA  00060006          add [0x600],al
0000B9BE  0005              add [di],al
0000B9C0  0004              add [si],al
0000B9C2  00060006          add [0x600],al
0000B9C6  0004              add [si],al
0000B9C8  0000              add [bx+si],al
0000B9CA  0000              add [bx+si],al
0000B9CC  0000              add [bx+si],al
0000B9CE  0000              add [bx+si],al
0000B9D0  0000              add [bx+si],al
0000B9D2  0000              add [bx+si],al
0000B9D4  0000              add [bx+si],al
0000B9D6  0000              add [bx+si],al
0000B9D8  0000              add [bx+si],al
0000B9DA  0000              add [bx+si],al
0000B9DC  0000              add [bx+si],al
0000B9DE  0000              add [bx+si],al
0000B9E0  0000              add [bx+si],al
0000B9E2  0000              add [bx+si],al
0000B9E4  0000              add [bx+si],al
0000B9E6  0000              add [bx+si],al
0000B9E8  0000              add [bx+si],al
0000B9EA  0000              add [bx+si],al
0000B9EC  0000              add [bx+si],al
0000B9EE  0000              add [bx+si],al
0000B9F0  0000              add [bx+si],al
0000B9F2  0000              add [bx+si],al
0000B9F4  0000              add [bx+si],al
0000B9F6  0000              add [bx+si],al
0000B9F8  0000              add [bx+si],al
0000B9FA  0000              add [bx+si],al
0000B9FC  0000              add [bx+si],al
0000B9FE  0000              add [bx+si],al
0000BA00  0000              add [bx+si],al
0000BA02  0000              add [bx+si],al
0000BA04  0000              add [bx+si],al
0000BA06  0000              add [bx+si],al
0000BA08  0000              add [bx+si],al
0000BA0A  0000              add [bx+si],al
0000BA0C  0000              add [bx+si],al
0000BA0E  0000              add [bx+si],al
0000BA10  0000              add [bx+si],al
0000BA12  0000              add [bx+si],al
0000BA14  0000              add [bx+si],al
0000BA16  0000              add [bx+si],al
0000BA18  0000              add [bx+si],al
0000BA1A  0000              add [bx+si],al
0000BA1C  0000              add [bx+si],al
0000BA1E  0000              add [bx+si],al
0000BA20  0000              add [bx+si],al
0000BA22  0000              add [bx+si],al
0000BA24  0000              add [bx+si],al
0000BA26  0000              add [bx+si],al
0000BA28  0000              add [bx+si],al
0000BA2A  0000              add [bx+si],al
0000BA2C  0000              add [bx+si],al
0000BA2E  0000              add [bx+si],al
0000BA30  0000              add [bx+si],al
0000BA32  0001              add [bx+di],al
0000BA34  0000              add [bx+si],al
0000BA36  0000              add [bx+si],al
0000BA38  0000              add [bx+si],al
0000BA3A  0000              add [bx+si],al
0000BA3C  0000              add [bx+si],al
0000BA3E  0000              add [bx+si],al
0000BA40  0000              add [bx+si],al
0000BA42  0000              add [bx+si],al
0000BA44  0000              add [bx+si],al
0000BA46  0000              add [bx+si],al
0000BA48  0000              add [bx+si],al
0000BA4A  0000              add [bx+si],al
0000BA4C  0000              add [bx+si],al
0000BA4E  0000              add [bx+si],al
0000BA50  0000              add [bx+si],al
0000BA52  0000              add [bx+si],al
0000BA54  0000              add [bx+si],al
0000BA56  0000              add [bx+si],al
0000BA58  0000              add [bx+si],al
0000BA5A  0000              add [bx+si],al
0000BA5C  0000              add [bx+si],al
0000BA5E  0000              add [bx+si],al
0000BA60  0000              add [bx+si],al
0000BA62  0000              add [bx+si],al
0000BA64  0000              add [bx+si],al
0000BA66  0000              add [bx+si],al
0000BA68  0001              add [bx+di],al
0000BA6A  0000              add [bx+si],al
0000BA6C  0000              add [bx+si],al
0000BA6E  0002              add [bp+si],al
0000BA70  0001              add [bx+di],al
0000BA72  0001              add [bx+di],al
0000BA74  0001              add [bx+di],al
0000BA76  0000              add [bx+si],al
0000BA78  0000              add [bx+si],al
0000BA7A  0000              add [bx+si],al
0000BA7C  0000              add [bx+si],al
0000BA7E  0000              add [bx+si],al
0000BA80  0000              add [bx+si],al
0000BA82  0000              add [bx+si],al
0000BA84  0000              add [bx+si],al
0000BA86  0000              add [bx+si],al
0000BA88  0000              add [bx+si],al
0000BA8A  0000              add [bx+si],al
0000BA8C  0000              add [bx+si],al
0000BA8E  0000              add [bx+si],al
0000BA90  0000              add [bx+si],al
0000BA92  00EC              add ah,ch
0000BA94  0300              add ax,[bx+si]
0000BA96  00060000          add [0x0],al
0000BA9A  0000              add [bx+si],al
0000BA9C  0000              add [bx+si],al
0000BA9E  006A00            add [bp+si+0x0],ch
0000BAA1  0000              add [bx+si],al
0000BAA3  660000            o32 add [bx+si],al
0000BAA6  006200            add [bp+si+0x0],ah
0000BAA9  0000              add [bx+si],al
0000BAAB  5C                pop sp
0000BAAC  0000              add [bx+si],al
0000BAAE  004400            add [si+0x0],al
0000BAB1  0000              add [bx+si],al
0000BAB3  0E                push cs
0000BAB4  0000              add [bx+si],al
0000BAB6  0000              add [bx+si],al
0000BAB8  0000              add [bx+si],al
0000BABA  00F2              add dl,dh
0000BABC  0300              add ax,[bx+si]
0000BABE  0000              add [bx+si],al
0000BAC0  0000              add [bx+si],al
0000BAC2  0000              add [bx+si],al
0000BAC4  0034              add [si],dh
0000BAC6  03C6              add ax,si
0000BAC8  01F4              add sp,si
0000BACA  011A              add [bp+si],bx
0000BACC  004200            add [bp+si+0x0],al
0000BACF  6A00              push byte +0x0
0000BAD1  AA                stosb
0000BAD2  00D2              add dl,dl
0000BAD4  0012              add [bp+si],dl
0000BAD6  013A              add [bp+si],di
0000BAD8  015601            add [bp+0x1],dx
0000BADB  7201              jc 0xbade
0000BADD  8E01              mov es,[bx+di]
0000BADF  AA                stosb
0000BAE0  0198000A          add [bx+si+0xa00],bx
0000BAE4  0004              add [si],al
0000BAE6  0032              add [bp+si],dh
0000BAE8  000A              add [bp+si],cl
0000BAEA  0001              add [bx+di],al
0000BAEC  0001              add [bx+di],al
0000BAEE  001B              add [bp+di],bl
0000BAF0  0018              add [bx+si],bl
0000BAF2  0018              add [bx+si],bl
0000BAF4  0008              add [bx+si],cl
0000BAF6  0000              add [bx+si],al
0000BAF8  0002              add [bp+si],al
0000BAFA  006A00            add [bp+si+0x0],ch
0000BAFD  1800              sbb [bx+si],al
0000BAFF  16                push ss
0000BB00  0008              add [bx+si],cl
0000BB02  0000              add [bx+si],al
0000BB04  0003              add [bp+di],al
0000BB06  00FF              add bh,bh
0000BB08  FFA2000A          jmp [bp+si+0xa00]
0000BB0C  0002              add [bp+si],al
0000BB0E  0010              add [bx+si],dl
0000BB10  0008              add [bx+si],cl
0000BB12  0001              add [bx+di],al
0000BB14  0004              add [si],al
0000BB16  001E001A          add [0x1a00],bl
0000BB1A  0010              add [bx+si],dl
0000BB1C  0008              add [bx+si],cl
0000BB1E  0000              add [bx+si],al
0000BB20  0005              add [di],al
0000BB22  006400            add [si+0x0],ah
0000BB25  1A00              sbb al,[bx+si]
0000BB27  3000              xor [bx+si],al
0000BB29  0800              or [bx+si],al
0000BB2B  0000              add [bx+si],al
0000BB2D  06                push es
0000BB2E  00FF              add bh,bh
0000BB30  FF6000            jmp [bx+si+0x0]
0000BB33  0A00              or al,[bx+si]
0000BB35  0400              add al,0x0
0000BB37  3200              xor al,[bx+si]
0000BB39  0A00              or al,[bx+si]
0000BB3B  0100              add [bx+si],ax
0000BB3D  07                pop es
0000BB3E  0014              add [si],dl
0000BB40  0010              add [bx+si],dl
0000BB42  0007              add [bx],al
0000BB44  000F              add [bx],cl
0000BB46  0000              add [bx+si],al
0000BB48  0008              add [bx+si],cl
0000BB4A  0024              add [si],ah
0000BB4C  0010              add [bx+si],dl
0000BB4E  0007              add [bx],al
0000BB50  000F              add [bx],cl
0000BB52  0000              add [bx+si],al
0000BB54  0009              add [bx+di],cl
0000BB56  0034              add [si],dh
0000BB58  0010              add [bx+si],dl
0000BB5A  0007              add [bx],al
0000BB5C  000F              add [bx],cl
0000BB5E  0000              add [bx+si],al
0000BB60  000A              add [bp+si],cl
0000BB62  004400            add [si+0x0],al
0000BB65  1000              adc [bx+si],al
0000BB67  07                pop es
0000BB68  000F              add [bx],cl
0000BB6A  0000              add [bx+si],al
0000BB6C  000B              add [bp+di],cl
0000BB6E  00FF              add bh,bh
0000BB70  FFB6000A          push word [bp+0xa00]
0000BB74  0004              add [si],al
0000BB76  0032              add [bp+si],dh
0000BB78  000A              add [bp+si],cl
0000BB7A  0001              add [bx+di],al
0000BB7C  000C              add [si],cl
0000BB7E  0014              add [si],dl
0000BB80  0018              add [bx+si],bl
0000BB82  004B00            add [bp+di+0x0],cl
0000BB85  0800              or [bx+si],al
0000BB87  0000              add [bx+si],al
0000BB89  0D0078            or ax,0x7800
0000BB8C  0018              add [bx+si],bl
0000BB8E  0030              add [bx+si],dh
0000BB90  0008              add [bx+si],cl
0000BB92  0000              add [bx+si],al
0000BB94  000600FF          add [0xff00],al
0000BB98  FF6400            jmp [si+0x0]
0000BB9B  0A00              or al,[bx+si]
0000BB9D  0400              add al,0x0
0000BB9F  3200              xor al,[bx+si]
0000BBA1  0A00              or al,[bx+si]
0000BBA3  0100              add [bx+si],ax
0000BBA5  0E                push cs
0000BBA6  0014              add [si],dl
0000BBA8  0010              add [bx+si],dl
0000BBAA  0007              add [bx],al
0000BBAC  000F              add [bx],cl
0000BBAE  0000              add [bx+si],al
0000BBB0  0008              add [bx+si],cl
0000BBB2  0024              add [si],ah
0000BBB4  0010              add [bx+si],dl
0000BBB6  0007              add [bx],al
0000BBB8  000F              add [bx],cl
0000BBBA  0000              add [bx+si],al
0000BBBC  0009              add [bx+di],cl
0000BBBE  0034              add [si],dh
0000BBC0  0010              add [bx+si],dl
0000BBC2  0007              add [bx],al
0000BBC4  000F              add [bx],cl
0000BBC6  0000              add [bx+si],al
0000BBC8  000A              add [bp+si],cl
0000BBCA  004400            add [si+0x0],al
0000BBCD  1000              adc [bx+si],al
0000BBCF  07                pop es
0000BBD0  000F              add [bx],cl
0000BBD2  0000              add [bx+si],al
0000BBD4  000B              add [bp+di],cl
0000BBD6  00FF              add bh,bh
0000BBD8  FF98000A          call far [bx+si+0xa00]
0000BBDC  0004              add [si],al
0000BBDE  0032              add [bp+si],dh
0000BBE0  000A              add [bp+si],cl
0000BBE2  0001              add [bx+di],al
0000BBE4  0015              add [di],dl
0000BBE6  0014              add [si],dl
0000BBE8  0018              add [bx+si],bl
0000BBEA  002A              add [bp+si],ch
0000BBEC  0008              add [bx+si],cl
0000BBEE  0000              add [bx+si],al
0000BBF0  00160058          add [0x5800],dl
0000BBF4  0018              add [bx+si],bl
0000BBF6  002A              add [bp+si],ch
0000BBF8  0008              add [bx+si],cl
0000BBFA  0000              add [bx+si],al
0000BBFC  000600FF          add [0xff00],al
0000BC00  FFAC000A          jmp far [si+0xa00]
0000BC04  0004              add [si],al
0000BC06  0032              add [bp+si],dh
0000BC08  000A              add [bp+si],cl
0000BC0A  0001              add [bx+di],al
0000BC0C  000F              add [bx],cl
0000BC0E  004C00            add [si+0x0],cl
0000BC11  1800              sbb [bx+si],al
0000BC13  0E                push cs
0000BC14  0008              add [bx+si],cl
0000BC16  0000              add [bx+si],al
0000BC18  0005              add [di],al
0000BC1A  00FF              add bh,bh
0000BC1C  FFAC000A          jmp far [si+0xa00]
0000BC20  0004              add [si],al
0000BC22  0032              add [bp+si],dh
0000BC24  000A              add [bp+si],cl
0000BC26  0001              add [bx+di],al
0000BC28  0010              add [bx+si],dl
0000BC2A  004C00            add [si+0x0],cl
0000BC2D  1800              sbb [bx+si],al
0000BC2F  0E                push cs
0000BC30  0008              add [bx+si],cl
0000BC32  0000              add [bx+si],al
0000BC34  0005              add [di],al
0000BC36  00FF              add bh,bh
0000BC38  FF98000A          call far [bx+si+0xa00]
0000BC3C  0004              add [si],al
0000BC3E  0032              add [bp+si],dh
0000BC40  000A              add [bp+si],cl
0000BC42  0001              add [bx+di],al
0000BC44  0011              add [bx+di],dl
0000BC46  004400            add [si+0x0],al
0000BC49  1800              sbb [bx+si],al
0000BC4B  0E                push cs
0000BC4C  0008              add [bx+si],cl
0000BC4E  0000              add [bx+si],al
0000BC50  0005              add [di],al
0000BC52  00FF              add bh,bh
0000BC54  FF98000A          call far [bx+si+0xa00]
0000BC58  0004              add [si],al
0000BC5A  0032              add [bp+si],dh
0000BC5C  000A              add [bp+si],cl
0000BC5E  0001              add [bx+di],al
0000BC60  0012              add [bp+si],dl
0000BC62  002C              add [si],ch
0000BC64  0018              add [bx+si],bl
0000BC66  004B00            add [bp+di+0x0],cl
0000BC69  0800              or [bx+si],al
0000BC6B  0000              add [bx+si],al
0000BC6D  0D00FF            or ax,0xff00
0000BC70  FF98000A          call far [bx+si+0xa00]
0000BC74  0004              add [si],al
0000BC76  0032              add [bp+si],dh
0000BC78  000A              add [bp+si],cl
0000BC7A  0001              add [bx+di],al
0000BC7C  0013              add [bp+di],dl
0000BC7E  0028              add [bx+si],ch
0000BC80  0018              add [bx+si],bl
0000BC82  004B00            add [bp+di+0x0],cl
0000BC85  0800              or [bx+si],al
0000BC87  0000              add [bx+si],al
0000BC89  0D00FF            or ax,0xff00
0000BC8C  FF17              call [bx]
0000BC8E  0003              add [bp+di],al
0000BC90  0003              add [bp+di],al
0000BC92  0027              add [bx],ah
0000BC94  0003              add [bp+di],al
0000BC96  0005              add [di],al
0000BC98  0007              add [bx],al
0000BC9A  0002              add [bp+si],al
0000BC9C  0002              add [bp+si],al
0000BC9E  0002              add [bp+si],al
0000BCA0  0002              add [bp+si],al
0000BCA2  001B              add [bp+di],bl
0000BCA4  000A              add [bp+si],cl
0000BCA6  0007              add [bx],al
0000BCA8  0020              add [bx+si],ah
0000BCAA  0020              add [bx+si],ah
0000BCAC  0020              add [bx+si],ah
0000BCAE  00160017          add [0x1700],dl
0000BCB2  0003              add [bp+di],al
0000BCB4  0014              add [si],dl
0000BCB6  000600FF          add [0xff00],al
0000BCBA  FF64F0            jmp [si-0x10]
0000BCBD  DC32              fdiv qword [bp+si]
0000BCBF  115116            adc [bx+di+0x16],dx
0000BCC2  92                xchg ax,dx
0000BCC3  06                push es
0000BCC4  E96010            jmp 0xcd27
0000BCC7  A4                movsb
0000BCC8  3209              xor cl,[bx+di]
0000BCCA  E289              loop 0xbc55
0000BCCC  06                push es
0000BCCD  E38A              jcxz 0xbc59
0000BCCF  702B              jo 0xbcfc
0000BCD1  FA                cli
0000BCD2  206014            and [bx+si+0x14],ah
0000BCD5  D0F8              sar al,1
0000BCD7  F3704C            rep jo 0xbd26
0000BCDA  CC                int3
0000BCDB  5E                pop si
0000BCDC  1450              adc al,0x50
0000BCDE  2805              sub [di],al
0000BCE0  61                popa
0000BCE1  27                daa
0000BCE2  A7                cmpsw
0000BCE3  818C2225440B      or word [si+0x2522],0xb44
0000BCE9  0D1215            or ax,0x1512
0000BCEC  1356C6            adc dx,[bp-0x3a]
0000BCEF  2D8888            sub ax,0x8888
0000BCF2  19881513          sbb [bx+si+0x1315],cx
0000BCF6  2B24              sub sp,[si]
0000BCF8  92                xchg ax,dx
0000BCF9  27                daa
0000BCFA  1444              adc al,0x44
0000BCFC  3208              xor cl,[bx+si]
0000BCFE  53                push bx
0000BCFF  FE                db 0xfe
0000BD00  F8                clc
0000BD01  F250              repne push ax
0000BD03  640C45            fs or al,0x45
0000BD06  2C64              sub al,0x64
0000BD08  F0DC32            lock fdiv qword [bp+si]
0000BD0B  1151F1            adc [bx+di-0xf],dx
0000BD0E  92                xchg ax,dx
0000BD0F  F4                hlt
0000BD10  00F3              add bl,dh
0000BD12  80F380            xor bl,0x80
0000BD15  F040              lock inc ax
0000BD17  134444            adc ax,[si+0x44]
0000BD1A  686048            push word 0x4860
0000BD1D  053210            add ax,0x1032
0000BD20  06                push es
0000BD21  725A              jc 0xbd7d
0000BD23  C8785212          enter 0x5278,0x12
0000BD27  B420              mov ah,0x20
0000BD29  204131            and [bx+di+0x31],al
0000BD2C  D1655C            shl word [di+0x5c],1
0000BD2F  B668              mov dh,0x68
0000BD31  C4                db 0xc4
0000BD32  F4                hlt
0000BD33  46                inc si
0000BD34  E533              in ax,0x33
0000BD36  22E2              and ah,dl
0000BD38  858CB146          test [si+0x46b1],cx
0000BD3C  F4                hlt
0000BD3D  8A892BE3          mov cl,[bx+di-0x1cd5]
0000BD41  F344              rep inc sp
0000BD43  4C                dec sp
0000BD44  CC                int3
0000BD45  5E                pop si
0000BD46  1456              adc al,0x56
0000BD48  28B430F1          sub [si-0xed0],dh
0000BD4C  E424              in al,0x24
0000BD4E  90                nop
0000BD4F  41                inc cx
0000BD50  A4                movsb
0000BD51  82                db 0x82
0000BD52  F4                hlt
0000BD53  98                cbw
0000BD54  D15881            rcr word [bx+si-0x7f],1
0000BD57  B182              mov cl,0x82
0000BD59  2239              and bh,[bx+di]
0000BD5B  42                inc dx
0000BD5C  41                inc cx
0000BD5D  2473              and al,0x73
0000BD5F  3045F3            xor [di-0xd],al
0000BD62  804CCC5E          or byte [si-0x34],0x5e
0000BD66  1456              adc al,0x56
0000BD68  28B430F1          sub [si-0xed0],dh
0000BD6C  E424              in al,0x24
0000BD6E  90                nop
0000BD6F  41                inc cx
0000BD70  A4                movsb
0000BD71  82                db 0x82
0000BD72  F4                hlt
0000BD73  98                cbw
0000BD74  D15881            rcr word [bx+si-0x7f],1
0000BD77  B182              mov cl,0x82
0000BD79  2239              and bh,[bx+di]
0000BD7B  42                inc dx
0000BD7C  41                inc cx
0000BD7D  292F              sub [bx],bp
0000BD7F  2922              sub [bp+si],sp
0000BD81  F3844CCC          rep test [si-0x34],cl
0000BD85  5E                pop si
0000BD86  1456              adc al,0x56
0000BD88  28B430F1          sub [si-0xed0],dh
0000BD8C  E424              in al,0x24
0000BD8E  90                nop
0000BD8F  41                inc cx
0000BD90  A4                movsb
0000BD91  02F1              add dh,cl
0000BD93  98                cbw
0000BD94  D15881            rcr word [bx+si-0x7f],1
0000BD97  B182              mov cl,0x82
0000BD99  2239              and bh,[bx+di]
0000BD9B  42                inc dx
0000BD9C  41                inc cx
0000BD9D  2473              and al,0x73
0000BD9F  3045F0            xor [di-0x10],al
0000BDA2  801344            adc byte [bp+di],0x44
0000BDA5  44                inc sp
0000BDA6  686048            push word 0x4860
0000BDA9  05320D            add ax,0xd32
0000BDAC  636314            arpl [bp+di+0x14],sp
0000BDAF  2D083C            sub ax,0x3c08
0000BDB2  3909              cmp [bx+di],cx
0000BDB4  6416              fs push ss
0000BDB6  29F3              sub bx,si
0000BDB8  C04F0E02          ror byte [bx+0xe],byte 0x2
0000BDBC  19444A            sbb [si+0x4a],ax
0000BDBF  D011              rcl byte [bx+di],1
0000BDC1  32821544          xor al,[bp+si+0x4415]
0000BDC5  2220              and ah,[bx+si]
0000BDC7  55                push bp
0000BDC8  338E1813          xor cx,[bp+0x1318]
0000BDCC  F8                clc
0000BDCD  C0188E            rcr byte [bx+si],byte 0x8e
0000BDD0  F8                clc
0000BDD1  F060              lock pusha
0000BDD3  94                xchg ax,sp
0000BDD4  44                inc sp
0000BDD5  2488              and al,0x88
0000BDD7  261A8C2B10        sbb cl,[es:si+0x102b]
0000BDDC  AD                lodsw
0000BDDD  44                inc sp
0000BDDE  44                inc sp
0000BDDF  46                inc si
0000BDE0  84A36ADF          test [bp+di-0x2096],ah
0000BDE4  11F2              adc dx,si
0000BDE6  0292108C          add dl,[bp+si-0x73f0]
0000BDEA  8992608C          mov [bp+si-0x73a0],dx
0000BDEE  8900              mov [bx+si],ax
0000BDF0  60                pusha
0000BDF1  0000              add [bx+si],al
0000BDF3  0000              add [bx+si],al
0000BDF5  0000              add [bx+si],al
0000BDF7  0000              add [bx+si],al
0000BDF9  0000              add [bx+si],al
0000BDFB  0000              add [bx+si],al
0000BDFD  0000              add [bx+si],al
0000BDFF  0000              add [bx+si],al
0000BE01  0000              add [bx+si],al
0000BE03  0000              add [bx+si],al
0000BE05  0000              add [bx+si],al
0000BE07  0000              add [bx+si],al
0000BE09  0000              add [bx+si],al
0000BE0B  0000              add [bx+si],al
0000BE0D  0000              add [bx+si],al
0000BE0F  0000              add [bx+si],al
0000BE11  0000              add [bx+si],al
0000BE13  0000              add [bx+si],al
0000BE15  0000              add [bx+si],al
0000BE17  0000              add [bx+si],al
0000BE19  0000              add [bx+si],al
0000BE1B  0000              add [bx+si],al
0000BE1D  0000              add [bx+si],al
0000BE1F  0000              add [bx+si],al
0000BE21  0000              add [bx+si],al
0000BE23  0000              add [bx+si],al
0000BE25  0000              add [bx+si],al
0000BE27  0000              add [bx+si],al
0000BE29  0000              add [bx+si],al
0000BE2B  0000              add [bx+si],al
0000BE2D  0000              add [bx+si],al
0000BE2F  0000              add [bx+si],al
0000BE31  0000              add [bx+si],al
0000BE33  0000              add [bx+si],al
0000BE35  0000              add [bx+si],al
0000BE37  0000              add [bx+si],al
0000BE39  0000              add [bx+si],al
0000BE3B  0000              add [bx+si],al
0000BE3D  0000              add [bx+si],al
0000BE3F  0000              add [bx+si],al
0000BE41  0000              add [bx+si],al
0000BE43  0000              add [bx+si],al
0000BE45  0000              add [bx+si],al
0000BE47  0000              add [bx+si],al
0000BE49  0000              add [bx+si],al
0000BE4B  0000              add [bx+si],al
0000BE4D  0000              add [bx+si],al
0000BE4F  0000              add [bx+si],al
0000BE51  0000              add [bx+si],al
0000BE53  0000              add [bx+si],al
0000BE55  0000              add [bx+si],al
0000BE57  0000              add [bx+si],al
0000BE59  0000              add [bx+si],al
0000BE5B  0000              add [bx+si],al
0000BE5D  0000              add [bx+si],al
0000BE5F  0000              add [bx+si],al
0000BE61  0000              add [bx+si],al
0000BE63  0000              add [bx+si],al
0000BE65  0000              add [bx+si],al
0000BE67  0000              add [bx+si],al
0000BE69  0000              add [bx+si],al
0000BE6B  0000              add [bx+si],al
0000BE6D  0000              add [bx+si],al
0000BE6F  0000              add [bx+si],al
0000BE71  0000              add [bx+si],al
0000BE73  0000              add [bx+si],al
0000BE75  0000              add [bx+si],al
0000BE77  0000              add [bx+si],al
0000BE79  0000              add [bx+si],al
0000BE7B  0000              add [bx+si],al
0000BE7D  0000              add [bx+si],al
0000BE7F  0000              add [bx+si],al
0000BE81  0000              add [bx+si],al
0000BE83  0000              add [bx+si],al
0000BE85  0000              add [bx+si],al
0000BE87  0000              add [bx+si],al
0000BE89  0000              add [bx+si],al
0000BE8B  0000              add [bx+si],al
0000BE8D  0000              add [bx+si],al
0000BE8F  0000              add [bx+si],al
0000BE91  0014              add [si],dl
0000BE93  000F              add [bx],cl
0000BE95  0018              add [bx+si],bl
0000BE97  0011              add [bx+di],dl
0000BE99  0000              add [bx+si],al
0000BE9B  0000              add [bx+si],al
0000BE9D  0000              add [bx+si],al
0000BE9F  0000              add [bx+si],al
0000BEA1  0000              add [bx+si],al
0000BEA3  00FF              add bh,bh
0000BEA5  0000              add [bx+si],al
0000BEA7  0000              add [bx+si],al
0000BEA9  0000              add [bx+si],al
0000BEAB  0101              add [bx+di],ax
0000BEAD  0000              add [bx+si],al
0000BEAF  0000              add [bx+si],al
0000BEB1  0000              add [bx+si],al
0000BEB3  00E5              add ch,ah
0000BEB5  0200              add al,[bx+si]
0000BEB7  00C0              add al,al
0000BEB9  07                pop es
0000BEBA  0000              add [bx+si],al
0000BEBC  D7                xlatb
0000BEBD  0F0000            sldt [bx+si]
0000BEC0  F5                cmc
0000BEC1  1300              adc ax,[bx+si]
0000BEC3  00A21700          add [bp+si+0x17],ah
0000BEC7  00C8              add al,cl
0000BEC9  1D0000            sbb ax,0x0
0000BECC  7221              jc 0xbeef
0000BECE  0000              add [bx+si],al
0000BED0  1925              sbb [di],sp
0000BED2  0000              add [bx+si],al
0000BED4  7D28              jnl 0xbefe
0000BED6  0000              add [bx+si],al
0000BED8  DB2C              fld tword [si]
0000BEDA  0000              add [bx+si],al
0000BEDC  C52F              lds bp,[bx]
0000BEDE  0000              add [bx+si],al
0000BEE0  9D                popf
0000BEE1  3D0000            cmp ax,0x0
0000BEE4  A13F00            mov ax,[0x3f]
0000BEE7  006F42            add [bx+0x42],ch
0000BEEA  0000              add [bx+si],al
0000BEEC  684A00            push word 0x4a
0000BEEF  00B04E00          add [bx+si+0x4e],dh
0000BEF3  00835400          add [bp+di+0x54],al
0000BEF7  00C6              add dh,al
0000BEF9  56                push si
0000BEFA  0000              add [bx+si],al
0000BEFC  805C0000          sbb byte [si+0x0],0x0
0000BF00  365D              ss pop bp
0000BF02  0000              add [bx+si],al
0000BF04  83670000          and word [bx+0x0],byte +0x0
0000BF08  DD                db 0xdd
0000BF09  69000039          imul ax,[bx+si],word 0x3900
0000BF0D  6C                insb
0000BF0E  0000              add [bx+si],al
0000BF10  5D                pop bp
0000BF11  6F                outsw
0000BF12  0000              add [bx+si],al
0000BF14  0B7100            or si,[bx+di+0x0]
0000BF17  00FC              add ah,bh
0000BF19  7200              jc 0xbf1b
0000BF1B  006175            add [bx+di+0x75],ah
0000BF1E  0000              add [bx+si],al
0000BF20  AA                stosb
0000BF21  7500              jnz 0xbf23
0000BF23  00267C00          add [0x7c],ah
0000BF27  0000              add [bx+si],al
0000BF29  0000              add [bx+si],al
0000BF2B  0034              add [si],dh
0000BF2D  0000              add [bx+si],al
0000BF2F  006800            add [bx+si+0x0],ch
0000BF32  0000              add [bx+si],al
0000BF34  9C                pushf
0000BF35  0000              add [bx+si],al
0000BF37  0037              add [bx],dh
0000BF39  0100              add [bx+si],ax
0000BF3B  006B01            add [bp+di+0x1],ch
0000BF3E  0000              add [bx+si],al
0000BF40  06                push es
0000BF41  0200              add al,[bx+si]
0000BF43  003A              add [bp+si],bh
0000BF45  0200              add al,[bx+si]
0000BF47  006E02            add [bp+0x2],ch
0000BF4A  0000              add [bx+si],al
0000BF4C  0903              or [bp+di],ax
0000BF4E  0000              add [bx+si],al
0000BF50  A4                movsb
0000BF51  0300              add ax,[bx+si]
0000BF53  003F              add [bx],bh
0000BF55  0400              add al,0x0
0000BF57  00DA              add dl,bl
0000BF59  0400              add al,0x0
0000BF5B  007505            add [di+0x5],dh
0000BF5E  0000              add [bx+si],al
0000BF60  A90500            test ax,0x5
0000BF63  004406            add [si+0x6],al
0000BF66  0000              add [bx+si],al
0000BF68  54                push sp
0000BF69  07                pop es
0000BF6A  0000              add [bx+si],al
0000BF6C  55                push bp
0000BF6D  0800              or [bx+si],al
0000BF6F  0010              add [bx+si],dl
0000BF71  0900              or [bx+si],ax
0000BF73  00F6              add dh,dh
0000BF75  0900              or [bx+si],ax
0000BF77  00C4              add ah,al
0000BF79  0A00              or al,[bx+si]
0000BF7B  0013              add [bp+di],dl
0000BF7D  0C00              or al,0x0
0000BF7F  00E4              add ah,ah
0000BF81  0C00              or al,0x0
0000BF83  009C0D00          add [si+0xd],bl
0000BF87  007F0E            add [bx+0xe],bh
0000BF8A  0000              add [bx+si],al
0000BF8C  1A0F              sbb cl,[bx]
0000BF8E  0000              add [bx+si],al
0000BF90  CA0F00            retf 0xf
0000BF93  00A21000          add [bp+si+0x10],ah
0000BF97  007E11            add [bp+0x11],bh
0000BF9A  0000              add [bx+si],al
0000BF9C  0000              add [bx+si],al
0000BF9E  0000              add [bx+si],al
0000BFA0  230D              and cx,[di]
0000BFA2  2809              sub [bx+di],cl
0000BFA4  2B07              sub ax,[bx]
0000BFA6  4B                dec bx
0000BFA7  0A5A0B            or bl,[bp+si+0xb]
0000BFAA  0000              add [bx+si],al
0000BFAC  0100              add [bx+si],ax
0000BFAE  0200              add al,[bx+si]
0000BFB0  0300              add ax,[bx+si]
0000BFB2  0400              add al,0x0
0000BFB4  050006            add ax,0x600
0000BFB7  0007              add [bx],al
0000BFB9  0008              add [bx+si],cl
0000BFBB  0009              add [bx+di],cl
0000BFBD  000A              add [bp+si],cl
0000BFBF  000B              add [bp+di],cl
0000BFC1  000C              add [si],cl
0000BFC3  000D              add [di],cl
0000BFC5  000E000F          add [0xf00],cl
0000BFC9  0010              add [bx+si],dl
0000BFCB  0011              add [bx+di],dl
0000BFCD  0012              add [bp+si],dl
0000BFCF  0013              add [bp+di],dl
0000BFD1  0014              add [si],dl
0000BFD3  0017              add [bx],dl
0000BFD5  0014              add [si],dl
0000BFD7  0017              add [bx],dl
0000BFD9  001A              add [bp+si],bl
0000BFDB  001A              add [bp+si],bl
0000BFDD  001A              add [bp+si],bl
0000BFDF  001C              add [si],bl
0000BFE1  001C              add [si],bl
0000BFE3  004D55            add [di+0x55],cl
0000BFE6  53                push bx
0000BFE7  2E48              cs dec ax
0000BFE9  55                push bp
0000BFEA  46                inc si
0000BFEB  00534E            add [bp+di+0x4e],dl
0000BFEE  44                inc sp
0000BFEF  2E48              cs dec ax
0000BFF1  55                push bp
0000BFF2  46                inc si
0000BFF3  0000              add [bx+si],al
0000BFF5  0020              add [bx+si],ah
0000BFF7  0200              add al,[bx+si]
0000BFF9  1000              adc [bx+si],al
0000BFFB  0001              add [bx+di],al
0000BFFD  00800800          add [bx+si+0x8],al
0000C001  0008              add [bx+si],cl
0000C003  800001            add byte [bx+si],0x1
0000C006  0000              add [bx+si],al
0000C008  1004              adc [si],al
0000C00A  0000              add [bx+si],al
0000C00C  40                inc ax
0000C00D  40                inc ax
0000C00E  0000              add [bx+si],al
0000C010  0420              add al,0x20
0000C012  0000              add [bx+si],al
0000C014  0200              add al,[bx+si]
0000C016  2002              and [bp+si],al
0000C018  0010              add [bx+si],dl
0000C01A  0000              add [bx+si],al
0000C01C  0100              add [bx+si],ax
0000C01E  800800            or byte [bx+si],0x0
0000C021  0008              add [bx+si],cl
0000C023  800001            add byte [bx+si],0x1
0000C026  0000              add [bx+si],al
0000C028  1004              adc [si],al
0000C02A  0000              add [bx+si],al
0000C02C  40                inc ax
0000C02D  40                inc ax
0000C02E  0000              add [bx+si],al
0000C030  0420              add al,0x20
0000C032  0000              add [bx+si],al
0000C034  0208              add cl,[bx+si]
0000C036  800440            add byte [si],0x40
0000C039  0220              add ah,[bx+si]
0000C03B  0110              add [bx+si],dx
0000C03D  800840            or byte [bx+si],0x40
0000C040  0420              add al,0x20
0000C042  0210              add dl,[bx+si]
0000C044  0110              add [bx+si],dx
0000C046  0120              add [bx+si],sp
0000C048  024004            add al,[bx+si+0x4]
0000C04B  800801            or byte [bx+si],0x1
0000C04E  1002              adc [bp+si],al
0000C050  2004              and [si],al
0000C052  40                inc ax
0000C053  08800880          or [bx+si-0x7ff8],al
0000C057  0440              add al,0x40
0000C059  0220              add ah,[bx+si]
0000C05B  0110              add [bx+si],dx
0000C05D  800840            or byte [bx+si],0x40
0000C060  0420              add al,0x20
0000C062  0210              add dl,[bx+si]
0000C064  0110              add [bx+si],dx
0000C066  0120              add [bx+si],sp
0000C068  024004            add al,[bx+si+0x4]
0000C06B  800801            or byte [bx+si],0x1
0000C06E  1002              adc [bp+si],al
0000C070  2004              and [si],al
0000C072  40                inc ax
0000C073  08800080          or [bx+si-0x8000],al
0000C077  004000            add [bx+si+0x0],al
0000C07A  2000              and [bx+si],al
0000C07C  1000              adc [bx+si],al
0000C07E  0800              or [bx+si],al
0000C080  0400              add al,0x0
0000C082  0200              add al,[bx+si]
0000C084  01800040          add [bx+si+0x4000],ax
0000C088  0020              add [bx+si],ah
0000C08A  0010              add [bx+si],dl
0000C08C  0008              add [bx+si],cl
0000C08E  0004              add [si],al
0000C090  0002              add [bp+si],al
0000C092  0001              add [bx+di],al
0000C094  0000              add [bx+si],al
0000C096  800040            add byte [bx+si],0x40
0000C099  0020              add [bx+si],ah
0000C09B  0010              add [bx+si],dl
0000C09D  0008              add [bx+si],cl
0000C09F  0004              add [si],al
0000C0A1  0002              add [bp+si],al
0000C0A3  0001              add [bx+di],al
0000C0A5  800040            add byte [bx+si],0x40
0000C0A8  0020              add [bx+si],ah
0000C0AA  0010              add [bx+si],dl
0000C0AC  0008              add [bx+si],cl
0000C0AE  0004              add [si],al
0000C0B0  0002              add [bp+si],al
0000C0B2  0001              add [bx+di],al
0000C0B4  0008              add [bx+si],cl
0000C0B6  800880            or byte [bx+si],0x80
0000C0B9  0440              add al,0x40
0000C0BB  0440              add al,0x40
0000C0BD  0220              add ah,[bx+si]
0000C0BF  0220              add ah,[bx+si]
0000C0C1  0110              add [bx+si],dx
0000C0C3  0110              add [bx+si],dx
0000C0C5  800880            or byte [bx+si],0x80
0000C0C8  084004            or [bx+si+0x4],al
0000C0CB  40                inc ax
0000C0CC  0420              add al,0x20
0000C0CE  0220              add ah,[bx+si]
0000C0D0  0210              add dl,[bx+si]
0000C0D2  0110              add [bx+si],dx
0000C0D4  0108              add [bx+si],cx
0000C0D6  800880            or byte [bx+si],0x80
0000C0D9  0440              add al,0x40
0000C0DB  0440              add al,0x40
0000C0DD  0220              add ah,[bx+si]
0000C0DF  0220              add ah,[bx+si]
0000C0E1  0110              add [bx+si],dx
0000C0E3  0110              add [bx+si],dx
0000C0E5  800880            or byte [bx+si],0x80
0000C0E8  084004            or [bx+si+0x4],al
0000C0EB  40                inc ax
0000C0EC  0420              add al,0x20
0000C0EE  0220              add ah,[bx+si]
0000C0F0  0210              add dl,[bx+si]
0000C0F2  0110              add [bx+si],dx
0000C0F4  0101              add [bx+di],ax
0000C0F6  0004              add [si],al
0000C0F8  0010              add [bx+si],dl
0000C0FA  004000            add [bx+si+0x0],al
0000C0FD  0001              add [bx+di],al
0000C0FF  0004              add [si],al
0000C101  0010              add [bx+si],dl
0000C103  004000            add [bx+si+0x0],al
0000C106  800020            add byte [bx+si],0x20
0000C109  0008              add [bx+si],cl
0000C10B  0002              add [bp+si],al
0000C10D  800020            add byte [bx+si],0x20
0000C110  0008              add [bx+si],cl
0000C112  0002              add [bp+si],al
0000C114  0001              add [bx+di],al
0000C116  0004              add [si],al
0000C118  0010              add [bx+si],dl
0000C11A  004000            add [bx+si+0x0],al
0000C11D  0001              add [bx+di],al
0000C11F  0004              add [si],al
0000C121  0010              add [bx+si],dl
0000C123  004000            add [bx+si+0x0],al
0000C126  800020            add byte [bx+si],0x20
0000C129  0008              add [bx+si],cl
0000C12B  0002              add [bp+si],al
0000C12D  800020            add byte [bx+si],0x20
0000C130  0008              add [bx+si],cl
0000C132  0002              add [bp+si],al
0000C134  0001              add [bx+di],al
0000C136  000A              add [bp+si],cl
0000C138  0012              add [bp+si],dl
0000C13A  0024              add [si],ah
0000C13C  00880008          add [bx+si+0x800],cl
0000C140  00900420          add [bx+si+0x2004],dl
0000C144  0920              or [bx+si],sp
0000C146  024024            add al,[bx+si+0x24]
0000C149  802800            sub byte [bx+si],0x0
0000C14C  0100              add [bx+si],ax
0000C14E  26005800          add [es:bx+si+0x0],bl
0000C152  C00080            rol byte [bx+si],byte 0x80
0000C155  0100              add [bx+si],ax
0000C157  0A00              or al,[bx+si]
0000C159  1200              adc al,[bx+si]
0000C15B  2400              and al,0x0
0000C15D  8800              mov [bx+si],al
0000C15F  0800              or [bx+si],al
0000C161  90                nop
0000C162  0420              add al,0x20
0000C164  0920              or [bx+si],sp
0000C166  024024            add al,[bx+si+0x24]
0000C169  802800            sub byte [bx+si],0x0
0000C16C  0100              add [bx+si],ax
0000C16E  26005800          add [es:bx+si+0x0],bl
0000C172  C00080            rol byte [bx+si],byte 0x80
0000C175  0000              add [bx+si],al
0000C177  0000              add [bx+si],al
0000C179  0002              add [bp+si],al
0000C17B  F8                clc
0000C17C  FD                std
0000C17D  0300              add ax,[bx+si]
0000C17F  C03A04            sar byte [bp+si],byte 0x4
0000C182  0020              add [bx+si],ah
0000C184  7B04              jpo 0xc18a
0000C186  0058BF            add [bx+si-0x41],bl
0000C189  0400              add al,0x0
0000C18B  98                cbw
0000C18C  07                pop es
0000C18D  050030            add ax,0x3000
0000C190  54                push sp
0000C191  050048            add ax,0x4800
0000C194  A5                movsw
0000C195  050038            add ax,0x3800
0000C198  FB                sti
0000C199  050048            add ax,0x4800
0000C19C  56                push si
0000C19D  06                push es
0000C19E  00C0              add al,al
0000C1A0  B606              mov dh,0x6
0000C1A2  00F0              add al,dh
0000C1A4  1C07              sbb al,0x7
0000C1A6  0038              add [bx+si],bh
0000C1A8  8907              mov [bx],ax
0000C1AA  0010              add [bx+si],dl
0000C1AC  0804              or [si],al
0000C1AE  0201              add al,[bx+di]
0000C1B0  0101              add [bx+di],ax
0000C1B2  030F              add cx,[bx]
0000C1B4  050001            add ax,0x100
0000C1B7  030F              add cx,[bx]
0000C1B9  0000              add [bx+si],al
0000C1BB  0001              add [bx+di],al
0000C1BD  0000              add [bx+si],al
0000C1BF  0101              add [bx+di],ax
0000C1C1  0F07              sysret
0000C1C3  0002              add [bp+si],al
0000C1C5  0400              add al,0x0
0000C1C7  0000              add [bx+si],al
0000C1C9  0100              add [bx+si],ax
0000C1CB  0000              add [bx+si],al
0000C1CD  0000              add [bx+si],al
0000C1CF  0A04              or al,[si]
0000C1D1  0008              add [bx+si],cl
0000C1D3  0C0B              or al,0xb
0000C1D5  0000              add [bx+si],al
0000C1D7  0001              add [bx+di],al
0000C1D9  0000              add [bx+si],al
0000C1DB  0000              add [bx+si],al
0000C1DD  0D0400            or ax,0x4
0000C1E0  06                push es
0000C1E1  0F0000            sldt [bx+si]
0000C1E4  0000              add [bx+si],al
0000C1E6  0100              add [bx+si],ax
0000C1E8  000C              add [si],cl
0000C1EA  000F              add [bx],cl
0000C1EC  0B00              or ax,[bx+si]
0000C1EE  0805              or [di],al
0000C1F0  0000              add [bx+si],al
0000C1F2  0000              add [bx+si],al
0000C1F4  0000              add [bx+si],al
0000C1F6  0004              add [si],al
0000C1F8  000F              add [bx],cl
0000C1FA  0B00              or ax,[bx+si]
0000C1FC  07                pop es
0000C1FD  050000            add ax,0x0
0000C200  0000              add [bx+si],al
0000C202  0000              add [bx+si],al
0000C204  0001              add [bx+di],al
0000C206  000F              add [bx],cl
0000C208  0B00              or ax,[bx+si]
0000C20A  050500            add ax,0x5
0000C20D  0000              add [bx+si],al
0000C20F  0000              add [bx+si],al
0000C211  0000              add [bx+si],al
0000C213  0100              add [bx+si],ax
0000C215  0F0B              ud2
0000C217  0007              add [bx],al
0000C219  050000            add ax,0x0
0000C21C  0000              add [bx+si],al
0000C21E  0000              add [bx+si],al
0000C220  0003              add [bp+di],al
0000C222  0104              add [si],ax
0000C224  0205              add al,[di]
0000C226  06                push es
0000C227  0907              or [bx],ax
0000C229  0A08              or cl,[bx+si]
0000C22B  0B0C              or cx,[si]
0000C22D  0F0D10            prefetchwt1 byte [bx+si]
0000C230  0E                push cs
0000C231  110C              adc [si],cx
0000C233  0F1000            movups xmm0,oword [bx+si]
0000C236  0E                push cs
0000C237  0011              add [bx+di],dl
0000C239  000D              add [di],cl
0000C23B  0000              add [bx+si],al
0000C23D  0102              add [bp+si],ax
0000C23F  0304              add ax,[si]
0000C241  050809            add ax,0x908
0000C244  0A0B              or cl,[bp+di]
0000C246  0C0D              or al,0xd
0000C248  1011              adc [bx+di],dl
0000C24A  1213              adc dl,[bp+di]
0000C24C  1415              adc al,0x15
0000C24E  0000              add [bx+si],al
0000C250  0001              add [bx+di],al
0000C252  0101              add [bx+di],ax
0000C254  0000              add [bx+si],al
0000C256  0001              add [bx+di],al
0000C258  0101              add [bx+di],ax
0000C25A  0000              add [bx+si],al
0000C25C  0001              add [bx+di],al
0000C25E  0101              add [bx+di],ax
0000C260  0001              add [bx+di],al
0000C262  0200              add al,[bx+si]
0000C264  0102              add [bp+si],ax
0000C266  0304              add ax,[si]
0000C268  050304            add ax,0x403
0000C26B  050607            add ax,0x706
0000C26E  08060708          or [0x807],al
0000C272  FF                db 0xff
0000C273  FF                db 0xff
0000C274  FF                db 0xff
0000C275  FF00              inc word [bx+si]
0000C277  0000              add [bx+si],al
0000C279  0000              add [bx+si],al
0000C27B  0000              add [bx+si],al
0000C27D  0000              add [bx+si],al
0000C27F  0000              add [bx+si],al
0000C281  0000              add [bx+si],al
0000C283  0000              add [bx+si],al
0000C285  0000              add [bx+si],al
0000C287  0000              add [bx+si],al
0000C289  0000              add [bx+si],al
0000C28B  0000              add [bx+si],al
0000C28D  0100              add [bx+si],ax
0000C28F  0000              add [bx+si],al
0000C291  0000              add [bx+si],al
0000C293  0000              add [bx+si],al
0000C295  00C8              add al,cl
0000C297  0000              add [bx+si],al
0000C299  0000              add [bx+si],al
0000C29B  0001              add [bx+di],al
0000C29D  0000              add [bx+si],al
0000C29F  005353            add [bp+di+0x53],dl
0000C2A2  53                push bx
0000C2A3  53                push bx
0000C2A4  53                push bx
0000C2A5  53                push bx
0000C2A6  53                push bx
0000C2A7  53                push bx
0000C2A8  53                push bx
0000C2A9  53                push bx
0000C2AA  53                push bx
0000C2AB  53                push bx
0000C2AC  53                push bx
0000C2AD  53                push bx
0000C2AE  53                push bx
0000C2AF  53                push bx
0000C2B0  53                push bx
0000C2B1  53                push bx
0000C2B2  53                push bx
0000C2B3  53                push bx
0000C2B4  53                push bx
0000C2B5  53                push bx
0000C2B6  53                push bx
0000C2B7  53                push bx
0000C2B8  53                push bx
0000C2B9  53                push bx
0000C2BA  53                push bx
0000C2BB  53                push bx
0000C2BC  53                push bx
0000C2BD  53                push bx
0000C2BE  53                push bx
0000C2BF  53                push bx
0000C2C0  53                push bx
0000C2C1  53                push bx
0000C2C2  53                push bx
0000C2C3  53                push bx
0000C2C4  53                push bx
0000C2C5  53                push bx
0000C2C6  53                push bx
0000C2C7  53                push bx
0000C2C8  53                push bx
0000C2C9  53                push bx
0000C2CA  53                push bx
0000C2CB  53                push bx
0000C2CC  53                push bx
0000C2CD  53                push bx
0000C2CE  53                push bx
0000C2CF  53                push bx
0000C2D0  53                push bx
0000C2D1  53                push bx
0000C2D2  53                push bx
0000C2D3  53                push bx
0000C2D4  53                push bx
0000C2D5  53                push bx
0000C2D6  53                push bx
0000C2D7  53                push bx
0000C2D8  53                push bx
0000C2D9  53                push bx
0000C2DA  53                push bx
0000C2DB  53                push bx
0000C2DC  53                push bx
0000C2DD  53                push bx
0000C2DE  53                push bx
0000C2DF  53                push bx
0000C2E0  53                push bx
0000C2E1  53                push bx
0000C2E2  53                push bx
0000C2E3  53                push bx
0000C2E4  53                push bx
0000C2E5  53                push bx
0000C2E6  53                push bx
0000C2E7  53                push bx
0000C2E8  53                push bx
0000C2E9  53                push bx
0000C2EA  53                push bx
0000C2EB  53                push bx
0000C2EC  53                push bx
0000C2ED  53                push bx
0000C2EE  53                push bx
0000C2EF  53                push bx
0000C2F0  53                push bx
0000C2F1  53                push bx
0000C2F2  53                push bx
0000C2F3  53                push bx
0000C2F4  53                push bx
0000C2F5  53                push bx
0000C2F6  53                push bx
0000C2F7  53                push bx
0000C2F8  53                push bx
0000C2F9  53                push bx
0000C2FA  53                push bx
0000C2FB  53                push bx
0000C2FC  53                push bx
0000C2FD  53                push bx
0000C2FE  53                push bx
0000C2FF  53                push bx
0000C300  53                push bx
0000C301  53                push bx
0000C302  53                push bx
0000C303  53                push bx
0000C304  53                push bx
0000C305  53                push bx
0000C306  53                push bx
0000C307  53                push bx
0000C308  53                push bx
0000C309  53                push bx
0000C30A  53                push bx
0000C30B  53                push bx
0000C30C  53                push bx
0000C30D  53                push bx
0000C30E  53                push bx
0000C30F  53                push bx
0000C310  53                push bx
0000C311  53                push bx
0000C312  53                push bx
0000C313  53                push bx
0000C314  53                push bx
0000C315  53                push bx
0000C316  53                push bx
0000C317  53                push bx
0000C318  53                push bx
0000C319  53                push bx
0000C31A  53                push bx
0000C31B  53                push bx
0000C31C  53                push bx
0000C31D  53                push bx
0000C31E  53                push bx
0000C31F  53                push bx
0000C320  53                push bx
0000C321  53                push bx
0000C322  53                push bx
0000C323  53                push bx
0000C324  53                push bx
0000C325  53                push bx
0000C326  53                push bx
0000C327  53                push bx
0000C328  53                push bx
0000C329  53                push bx
0000C32A  53                push bx
0000C32B  53                push bx
0000C32C  53                push bx
0000C32D  53                push bx
0000C32E  53                push bx
0000C32F  53                push bx
0000C330  53                push bx
0000C331  53                push bx
0000C332  53                push bx
0000C333  53                push bx
0000C334  53                push bx
0000C335  53                push bx
0000C336  53                push bx
0000C337  53                push bx
0000C338  53                push bx
0000C339  53                push bx
0000C33A  53                push bx
0000C33B  53                push bx
0000C33C  53                push bx
0000C33D  53                push bx
0000C33E  53                push bx
0000C33F  53                push bx
0000C340  53                push bx
0000C341  53                push bx
0000C342  53                push bx
0000C343  53                push bx
0000C344  53                push bx
0000C345  53                push bx
0000C346  53                push bx
0000C347  53                push bx
0000C348  53                push bx
0000C349  53                push bx
0000C34A  53                push bx
0000C34B  53                push bx
0000C34C  53                push bx
0000C34D  53                push bx
0000C34E  53                push bx
0000C34F  53                push bx
0000C350  53                push bx
0000C351  53                push bx
0000C352  53                push bx
0000C353  53                push bx
0000C354  53                push bx
0000C355  53                push bx
0000C356  53                push bx
0000C357  53                push bx
0000C358  53                push bx
0000C359  53                push bx
0000C35A  53                push bx
0000C35B  53                push bx
0000C35C  53                push bx
0000C35D  53                push bx
0000C35E  53                push bx
0000C35F  53                push bx
0000C360  53                push bx
0000C361  53                push bx
0000C362  53                push bx
0000C363  53                push bx
0000C364  53                push bx
0000C365  53                push bx
0000C366  53                push bx
0000C367  53                push bx
0000C368  53                push bx
0000C369  53                push bx
0000C36A  53                push bx
0000C36B  53                push bx
0000C36C  53                push bx
0000C36D  53                push bx
0000C36E  53                push bx
0000C36F  53                push bx
0000C370  53                push bx
0000C371  53                push bx
0000C372  53                push bx
0000C373  53                push bx
0000C374  53                push bx
0000C375  53                push bx
0000C376  53                push bx
0000C377  53                push bx
0000C378  53                push bx
0000C379  53                push bx
0000C37A  53                push bx
0000C37B  53                push bx
0000C37C  53                push bx
0000C37D  53                push bx
0000C37E  53                push bx
0000C37F  53                push bx
0000C380  53                push bx
0000C381  53                push bx
0000C382  53                push bx
0000C383  53                push bx
0000C384  53                push bx
0000C385  53                push bx
0000C386  53                push bx
0000C387  53                push bx
0000C388  53                push bx
0000C389  53                push bx
0000C38A  53                push bx
0000C38B  53                push bx
0000C38C  53                push bx
0000C38D  53                push bx
0000C38E  53                push bx
0000C38F  53                push bx
0000C390  53                push bx
0000C391  53                push bx
0000C392  53                push bx
0000C393  53                push bx
0000C394  53                push bx
0000C395  53                push bx
0000C396  53                push bx
0000C397  53                push bx
0000C398  53                push bx
0000C399  53                push bx
0000C39A  53                push bx
0000C39B  53                push bx
0000C39C  53                push bx
0000C39D  53                push bx
0000C39E  53                push bx
0000C39F  53                push bx
0000C3A0  53                push bx
0000C3A1  53                push bx
0000C3A2  53                push bx
0000C3A3  53                push bx
0000C3A4  53                push bx
0000C3A5  53                push bx
0000C3A6  53                push bx
0000C3A7  53                push bx
0000C3A8  53                push bx
0000C3A9  53                push bx
0000C3AA  53                push bx
0000C3AB  53                push bx
0000C3AC  53                push bx
0000C3AD  53                push bx
0000C3AE  53                push bx
0000C3AF  53                push bx
0000C3B0  53                push bx
0000C3B1  53                push bx
0000C3B2  53                push bx
0000C3B3  53                push bx
0000C3B4  53                push bx
0000C3B5  53                push bx
0000C3B6  53                push bx
0000C3B7  53                push bx
0000C3B8  53                push bx
0000C3B9  53                push bx
0000C3BA  53                push bx
0000C3BB  53                push bx
0000C3BC  53                push bx
0000C3BD  53                push bx
0000C3BE  53                push bx
0000C3BF  53                push bx
0000C3C0  53                push bx
0000C3C1  53                push bx
0000C3C2  53                push bx
0000C3C3  53                push bx
0000C3C4  53                push bx
0000C3C5  53                push bx
0000C3C6  53                push bx
0000C3C7  53                push bx
0000C3C8  53                push bx
0000C3C9  53                push bx
0000C3CA  53                push bx
0000C3CB  53                push bx
0000C3CC  53                push bx
0000C3CD  53                push bx
0000C3CE  53                push bx
0000C3CF  53                push bx
0000C3D0  53                push bx
0000C3D1  53                push bx
0000C3D2  53                push bx
0000C3D3  53                push bx
0000C3D4  53                push bx
0000C3D5  53                push bx
0000C3D6  53                push bx
0000C3D7  53                push bx
0000C3D8  53                push bx
0000C3D9  53                push bx
0000C3DA  53                push bx
0000C3DB  53                push bx
0000C3DC  53                push bx
0000C3DD  53                push bx
0000C3DE  53                push bx
0000C3DF  53                push bx
0000C3E0  53                push bx
0000C3E1  53                push bx
0000C3E2  53                push bx
0000C3E3  53                push bx
0000C3E4  53                push bx
0000C3E5  53                push bx
0000C3E6  53                push bx
0000C3E7  53                push bx
0000C3E8  53                push bx
0000C3E9  53                push bx
0000C3EA  53                push bx
0000C3EB  53                push bx
0000C3EC  53                push bx
0000C3ED  53                push bx
0000C3EE  53                push bx
0000C3EF  53                push bx
0000C3F0  53                push bx
0000C3F1  53                push bx
0000C3F2  53                push bx
0000C3F3  53                push bx
0000C3F4  53                push bx
0000C3F5  53                push bx
0000C3F6  53                push bx
0000C3F7  53                push bx
0000C3F8  53                push bx
0000C3F9  53                push bx
0000C3FA  53                push bx
0000C3FB  53                push bx
0000C3FC  53                push bx
0000C3FD  53                push bx
0000C3FE  53                push bx
0000C3FF  53                push bx
0000C400  53                push bx
0000C401  53                push bx
0000C402  53                push bx
0000C403  53                push bx
0000C404  53                push bx
0000C405  53                push bx
0000C406  53                push bx
0000C407  53                push bx
0000C408  53                push bx
0000C409  53                push bx
0000C40A  53                push bx
0000C40B  53                push bx
0000C40C  53                push bx
0000C40D  53                push bx
0000C40E  53                push bx
0000C40F  53                push bx
0000C410  53                push bx
0000C411  53                push bx
0000C412  53                push bx
0000C413  53                push bx
0000C414  53                push bx
0000C415  53                push bx
0000C416  53                push bx
0000C417  53                push bx
0000C418  53                push bx
0000C419  53                push bx
0000C41A  53                push bx
0000C41B  53                push bx
0000C41C  53                push bx
0000C41D  53                push bx
0000C41E  53                push bx
0000C41F  53                push bx
0000C420  53                push bx
0000C421  53                push bx
0000C422  53                push bx
0000C423  53                push bx
0000C424  53                push bx
0000C425  53                push bx
0000C426  53                push bx
0000C427  53                push bx
0000C428  53                push bx
0000C429  53                push bx
0000C42A  53                push bx
0000C42B  53                push bx
0000C42C  53                push bx
0000C42D  53                push bx
0000C42E  53                push bx
0000C42F  53                push bx
0000C430  53                push bx
0000C431  53                push bx
0000C432  53                push bx
0000C433  53                push bx
0000C434  53                push bx
0000C435  53                push bx
0000C436  53                push bx
0000C437  53                push bx
0000C438  53                push bx
0000C439  53                push bx
0000C43A  53                push bx
0000C43B  53                push bx
0000C43C  53                push bx
0000C43D  53                push bx
0000C43E  53                push bx
0000C43F  53                push bx
0000C440  53                push bx
0000C441  53                push bx
0000C442  53                push bx
0000C443  53                push bx
0000C444  53                push bx
0000C445  53                push bx
0000C446  53                push bx
0000C447  53                push bx
0000C448  53                push bx
0000C449  53                push bx
0000C44A  53                push bx
0000C44B  53                push bx
0000C44C  53                push bx
0000C44D  53                push bx
0000C44E  53                push bx
0000C44F  53                push bx
0000C450  53                push bx
0000C451  53                push bx
0000C452  53                push bx
0000C453  53                push bx
0000C454  53                push bx
0000C455  53                push bx
0000C456  53                push bx
0000C457  53                push bx
0000C458  53                push bx
0000C459  53                push bx
0000C45A  53                push bx
0000C45B  53                push bx
0000C45C  53                push bx
0000C45D  53                push bx
0000C45E  53                push bx
0000C45F  53                push bx
0000C460  53                push bx
0000C461  53                push bx
0000C462  53                push bx
0000C463  53                push bx
0000C464  53                push bx
0000C465  53                push bx
0000C466  53                push bx
0000C467  53                push bx
0000C468  53                push bx
0000C469  53                push bx
0000C46A  53                push bx
0000C46B  53                push bx
0000C46C  53                push bx
0000C46D  53                push bx
0000C46E  53                push bx
0000C46F  53                push bx
0000C470  53                push bx
0000C471  53                push bx
0000C472  53                push bx
0000C473  53                push bx
0000C474  53                push bx
0000C475  53                push bx
0000C476  53                push bx
0000C477  53                push bx
0000C478  53                push bx
0000C479  53                push bx
0000C47A  53                push bx
0000C47B  53                push bx
0000C47C  53                push bx
0000C47D  53                push bx
0000C47E  53                push bx
0000C47F  53                push bx
0000C480  53                push bx
0000C481  53                push bx
0000C482  53                push bx
0000C483  53                push bx
0000C484  53                push bx
0000C485  53                push bx
0000C486  53                push bx
0000C487  53                push bx
0000C488  53                push bx
0000C489  53                push bx
0000C48A  53                push bx
0000C48B  53                push bx
0000C48C  53                push bx
0000C48D  53                push bx
0000C48E  53                push bx
0000C48F  53                push bx
0000C490  53                push bx
0000C491  53                push bx
0000C492  53                push bx
0000C493  53                push bx
0000C494  53                push bx
0000C495  53                push bx
0000C496  53                push bx
0000C497  53                push bx
0000C498  53                push bx
0000C499  53                push bx
0000C49A  53                push bx
0000C49B  53                push bx
0000C49C  53                push bx
0000C49D  53                push bx
0000C49E  53                push bx
0000C49F  53                push bx
0000C4A0  0000              add [bx+si],al
0000C4A2  0000              add [bx+si],al
0000C4A4  0000              add [bx+si],al
0000C4A6  0000              add [bx+si],al
0000C4A8  0000              add [bx+si],al
0000C4AA  0000              add [bx+si],al
0000C4AC  0000              add [bx+si],al
0000C4AE  0000              add [bx+si],al
0000C4B0  0000              add [bx+si],al
0000C4B2  0000              add [bx+si],al
0000C4B4  0000              add [bx+si],al
0000C4B6  0000              add [bx+si],al
0000C4B8  0000              add [bx+si],al
0000C4BA  0000              add [bx+si],al
0000C4BC  0000              add [bx+si],al
0000C4BE  0000              add [bx+si],al
0000C4C0  0000              add [bx+si],al
0000C4C2  0000              add [bx+si],al
0000C4C4  0000              add [bx+si],al
0000C4C6  0000              add [bx+si],al
0000C4C8  0000              add [bx+si],al
0000C4CA  0000              add [bx+si],al
0000C4CC  0000              add [bx+si],al
0000C4CE  0101              add [bx+di],ax
0000C4D0  0101              add [bx+di],ax
0000C4D2  0101              add [bx+di],ax
0000C4D4  0101              add [bx+di],ax
0000C4D6  0101              add [bx+di],ax
0000C4D8  0101              add [bx+di],ax
0000C4DA  0101              add [bx+di],ax
0000C4DC  0101              add [bx+di],ax
0000C4DE  0202              add al,[bp+si]
0000C4E0  0202              add al,[bp+si]
0000C4E2  0202              add al,[bp+si]
0000C4E4  0202              add al,[bp+si]
0000C4E6  0202              add al,[bp+si]
0000C4E8  0202              add al,[bp+si]
0000C4EA  0202              add al,[bp+si]
0000C4EC  0202              add al,[bp+si]
0000C4EE  0303              add ax,[bp+di]
0000C4F0  0303              add ax,[bp+di]
0000C4F2  0303              add ax,[bp+di]
0000C4F4  0303              add ax,[bp+di]
0000C4F6  0303              add ax,[bp+di]
0000C4F8  0303              add ax,[bp+di]
0000C4FA  0303              add ax,[bp+di]
0000C4FC  0303              add ax,[bp+di]
0000C4FE  0404              add al,0x4
0000C500  0404              add al,0x4
0000C502  0404              add al,0x4
0000C504  0404              add al,0x4
0000C506  050505            add ax,0x505
0000C509  050505            add ax,0x505
0000C50C  050506            add ax,0x605
0000C50F  06                push es
0000C510  06                push es
0000C511  06                push es
0000C512  06                push es
0000C513  06                push es
0000C514  06                push es
0000C515  06                push es
0000C516  07                pop es
0000C517  07                pop es
0000C518  07                pop es
0000C519  07                pop es
0000C51A  07                pop es
0000C51B  07                pop es
0000C51C  07                pop es
0000C51D  07                pop es
0000C51E  0808              or [bx+si],cl
0000C520  0808              or [bx+si],cl
0000C522  0808              or [bx+si],cl
0000C524  0808              or [bx+si],cl
0000C526  0909              or [bx+di],cx
0000C528  0909              or [bx+di],cx
0000C52A  0909              or [bx+di],cx
0000C52C  0909              or [bx+di],cx
0000C52E  0A0A              or cl,[bp+si]
0000C530  0A0A              or cl,[bp+si]
0000C532  0A0A              or cl,[bp+si]
0000C534  0A0A              or cl,[bp+si]
0000C536  0B0B              or cx,[bp+di]
0000C538  0B0B              or cx,[bp+di]
0000C53A  0B0B              or cx,[bp+di]
0000C53C  0B0B              or cx,[bp+di]
0000C53E  0C0C              or al,0xc
0000C540  0C0C              or al,0xc
0000C542  0D0D0D            or ax,0xd0d
0000C545  0D0E0E            or ax,0xe0e
0000C548  0E                push cs
0000C549  0E                push cs
0000C54A  0F                db 0x0f
0000C54B  0F                db 0x0f
0000C54C  0F                db 0x0f
0000C54D  0F1010            movups xmm2,oword [bx+si]
0000C550  1010              adc [bx+si],dl
0000C552  1111              adc [bx+di],dx
0000C554  1111              adc [bx+di],dx
0000C556  1212              adc dl,[bp+si]
0000C558  1212              adc dl,[bp+si]
0000C55A  1313              adc dx,[bp+di]
0000C55C  1313              adc dx,[bp+di]
0000C55E  1414              adc al,0x14
0000C560  1414              adc al,0x14
0000C562  151515            adc ax,0x1515
0000C565  151616            adc ax,0x1616
0000C568  16                push ss
0000C569  16                push ss
0000C56A  17                pop ss
0000C56B  17                pop ss
0000C56C  17                pop ss
0000C56D  17                pop ss
0000C56E  1818              sbb [bx+si],bl
0000C570  1919              sbb [bx+di],bx
0000C572  1A1A              sbb bl,[bp+si]
0000C574  1B1B              sbb bx,[bp+di]
0000C576  1C1C              sbb al,0x1c
0000C578  1D1D1E            sbb ax,0x1e1d
0000C57B  1E                push ds
0000C57C  1F                pop ds
0000C57D  1F                pop ds
0000C57E  2020              and [bx+si],ah
0000C580  2121              and [bx+di],sp
0000C582  2222              and ah,[bp+si]
0000C584  2323              and sp,[bp+di]
0000C586  2424              and al,0x24
0000C588  252526            and ax,0x2625
0000C58B  2627              es daa
0000C58D  27                daa
0000C58E  2828              sub [bx+si],ch
0000C590  2929              sub [bx+di],bp
0000C592  2A2A              sub ch,[bp+si]
0000C594  2B2B              sub bp,[bp+di]
0000C596  2C2C              sub al,0x2c
0000C598  2D2D2E            sub ax,0x2e2d
0000C59B  2E2F              cs das
0000C59D  2F                das
0000C59E  3031              xor [bx+di],dh
0000C5A0  3233              xor dh,[bp+di]
0000C5A2  3435              xor al,0x35
0000C5A4  3637              ss aaa
0000C5A6  3839              cmp [bx+di],bh
0000C5A8  3A3B              cmp bh,[bp+di]
0000C5AA  3C3D              cmp al,0x3d
0000C5AC  3E3F              ds aas
0000C5AE  0303              add ax,[bp+di]
0000C5B0  0303              add ax,[bp+di]
0000C5B2  0303              add ax,[bp+di]
0000C5B4  0303              add ax,[bp+di]
0000C5B6  0303              add ax,[bp+di]
0000C5B8  0303              add ax,[bp+di]
0000C5BA  0303              add ax,[bp+di]
0000C5BC  0303              add ax,[bp+di]
0000C5BE  0303              add ax,[bp+di]
0000C5C0  0303              add ax,[bp+di]
0000C5C2  0303              add ax,[bp+di]
0000C5C4  0303              add ax,[bp+di]
0000C5C6  0303              add ax,[bp+di]
0000C5C8  0303              add ax,[bp+di]
0000C5CA  0303              add ax,[bp+di]
0000C5CC  0303              add ax,[bp+di]
0000C5CE  0404              add al,0x4
0000C5D0  0404              add al,0x4
0000C5D2  0404              add al,0x4
0000C5D4  0404              add al,0x4
0000C5D6  0404              add al,0x4
0000C5D8  0404              add al,0x4
0000C5DA  0404              add al,0x4
0000C5DC  0404              add al,0x4
0000C5DE  0404              add al,0x4
0000C5E0  0404              add al,0x4
0000C5E2  0404              add al,0x4
0000C5E4  0404              add al,0x4
0000C5E6  0404              add al,0x4
0000C5E8  0404              add al,0x4
0000C5EA  0404              add al,0x4
0000C5EC  0404              add al,0x4
0000C5EE  0404              add al,0x4
0000C5F0  0404              add al,0x4
0000C5F2  0404              add al,0x4
0000C5F4  0404              add al,0x4
0000C5F6  0404              add al,0x4
0000C5F8  0404              add al,0x4
0000C5FA  0404              add al,0x4
0000C5FC  0404              add al,0x4
0000C5FE  050505            add ax,0x505
0000C601  050505            add ax,0x505
0000C604  050505            add ax,0x505
0000C607  050505            add ax,0x505
0000C60A  050505            add ax,0x505
0000C60D  050505            add ax,0x505
0000C610  050505            add ax,0x505
0000C613  050505            add ax,0x505
0000C616  050505            add ax,0x505
0000C619  050505            add ax,0x505
0000C61C  050505            add ax,0x505
0000C61F  050505            add ax,0x505
0000C622  050505            add ax,0x505
0000C625  050505            add ax,0x505
0000C628  050505            add ax,0x505
0000C62B  050505            add ax,0x505
0000C62E  050505            add ax,0x505
0000C631  050505            add ax,0x505
0000C634  050505            add ax,0x505
0000C637  050505            add ax,0x505
0000C63A  050505            add ax,0x505
0000C63D  050606            add ax,0x606
0000C640  06                push es
0000C641  06                push es
0000C642  06                push es
0000C643  06                push es
0000C644  06                push es
0000C645  06                push es
0000C646  06                push es
0000C647  06                push es
0000C648  06                push es
0000C649  06                push es
0000C64A  06                push es
0000C64B  06                push es
0000C64C  06                push es
0000C64D  06                push es
0000C64E  06                push es
0000C64F  06                push es
0000C650  06                push es
0000C651  06                push es
0000C652  06                push es
0000C653  06                push es
0000C654  06                push es
0000C655  06                push es
0000C656  06                push es
0000C657  06                push es
0000C658  06                push es
0000C659  06                push es
0000C65A  06                push es
0000C65B  06                push es
0000C65C  06                push es
0000C65D  06                push es
0000C65E  06                push es
0000C65F  06                push es
0000C660  06                push es
0000C661  06                push es
0000C662  06                push es
0000C663  06                push es
0000C664  06                push es
0000C665  06                push es
0000C666  06                push es
0000C667  06                push es
0000C668  06                push es
0000C669  06                push es
0000C66A  06                push es
0000C66B  06                push es
0000C66C  06                push es
0000C66D  06                push es
0000C66E  07                pop es
0000C66F  07                pop es
0000C670  07                pop es
0000C671  07                pop es
0000C672  07                pop es
0000C673  07                pop es
0000C674  07                pop es
0000C675  07                pop es
0000C676  07                pop es
0000C677  07                pop es
0000C678  07                pop es
0000C679  07                pop es
0000C67A  07                pop es
0000C67B  07                pop es
0000C67C  07                pop es
0000C67D  07                pop es
0000C67E  07                pop es
0000C67F  07                pop es
0000C680  07                pop es
0000C681  07                pop es
0000C682  07                pop es
0000C683  07                pop es
0000C684  07                pop es
0000C685  07                pop es
0000C686  07                pop es
0000C687  07                pop es
0000C688  07                pop es
0000C689  07                pop es
0000C68A  07                pop es
0000C68B  07                pop es
0000C68C  07                pop es
0000C68D  07                pop es
0000C68E  07                pop es
0000C68F  07                pop es
0000C690  07                pop es
0000C691  07                pop es
0000C692  07                pop es
0000C693  07                pop es
0000C694  07                pop es
0000C695  07                pop es
0000C696  07                pop es
0000C697  07                pop es
0000C698  07                pop es
0000C699  07                pop es
0000C69A  07                pop es
0000C69B  07                pop es
0000C69C  07                pop es
0000C69D  07                pop es
0000C69E  0808              or [bx+si],cl
0000C6A0  0808              or [bx+si],cl
0000C6A2  0808              or [bx+si],cl
0000C6A4  0808              or [bx+si],cl
0000C6A6  0808              or [bx+si],cl
0000C6A8  0808              or [bx+si],cl
0000C6AA  0808              or [bx+si],cl
0000C6AC  0808              or [bx+si],cl
0000C6AE  0000              add [bx+si],al
0000C6B0  0000              add [bx+si],al
0000C6B2  0000              add [bx+si],al
0000C6B4  0000              add [bx+si],al
0000C6B6  0013              add [bp+di],dl
0000C6B8  0202              add al,[bp+si]
0000C6BA  0405              add al,0x5
0000C6BC  06                push es
0000C6BD  0808              or [bx+si],cl
0000C6BF  0814              or [si],dl
0000C6C1  150513            adc ax,0x1305
0000C6C4  FF160511          call [0x1105]
0000C6C8  02FF              add bh,bh
0000C6CA  FF                db 0xff
0000C6CB  FF                db 0xff
0000C6CC  FF                db 0xff
0000C6CD  FF                db 0xff
0000C6CE  FF                db 0xff
0000C6CF  FF                db 0xff
0000C6D0  FF                db 0xff
0000C6D1  FF                db 0xff
0000C6D2  FF                db 0xff
0000C6D3  FF                db 0xff
0000C6D4  FF                db 0xff
0000C6D5  FF05              inc word [di]
0000C6D7  05FFFF            add ax,0xffff
0000C6DA  FF                db 0xff
0000C6DB  FF                db 0xff
0000C6DC  FF                db 0xff
0000C6DD  FF                db 0xff
0000C6DE  FF                db 0xff
0000C6DF  FF                db 0xff
0000C6E0  FF                db 0xff
0000C6E1  FF                db 0xff
0000C6E2  FF                db 0xff
0000C6E3  FF                db 0xff
0000C6E4  FF                db 0xff
0000C6E5  FF                db 0xff
0000C6E6  FF                db 0xff
0000C6E7  FF0F              dec word [bx]
0000C6E9  FF23              jmp [bp+di]
0000C6EB  02FF              add bh,bh
0000C6ED  0FFF              ud0
0000C6EF  FF                db 0xff
0000C6F0  FF                db 0xff
0000C6F1  FF13              call [bp+di]
0000C6F3  FF                db 0xff
0000C6F4  FF02              inc word [bp+si]
0000C6F6  0205              add al,[di]
0000C6F8  0F02FF            lar di,di
0000C6FB  FF                db 0xff
0000C6FC  FF13              call [bp+di]
0000C6FE  FF                db 0xff
0000C6FF  FF                db 0xff
0000C700  FF                db 0xff
0000C701  FF                db 0xff
0000C702  FF                db 0xff
0000C703  FF                db 0xff
0000C704  FF                db 0xff
0000C705  FF23              jmp [bp+di]
0000C707  FF                db 0xff
0000C708  FF                db 0xff
0000C709  FF                db 0xff
0000C70A  FF23              jmp [bp+di]
0000C70C  FF13              call [bp+di]
0000C70E  FF00              inc word [bx+si]
0000C710  06                push es
0000C711  00E3              add bl,ah
0000C713  090600E3          or [0xe300],ax
0000C717  090600E3          or [0xe300],ax
0000C71B  0900              or [bx+si],ax
0000C71D  1000              adc [bx+si],al
0000C71F  0000              add [bx+si],al
0000C721  0000              add [bx+si],al
0000C723  0000              add [bx+si],al
0000C725  0000              add [bx+si],al
0000C727  0000              add [bx+si],al
0000C729  0000              add [bx+si],al
0000C72B  0000              add [bx+si],al
0000C72D  009F019F          add [bx-0x60ff],bl
0000C731  01A60100          add [bp+0x1],sp
0000C735  53                push bx
0000C736  6764205720        and [fs:edi+0x20],dl
0000C73B  56                push si
0000C73C  6461              fs popa
0000C73E  002D              add [di],ch
0000C740  207676            and [bp+0x76],dh
0000C743  762E              jna 0xc773
0000C745  6B7A6D6A          imul di,[bp+si+0x6d],byte +0x6a
0000C749  676E              a32 outsb
0000C74B  712E              jno 0xc77b
0000C74D  6D                insw
0000C74E  647300            fs jnc 0xc751
